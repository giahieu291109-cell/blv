import React, { useEffect, useRef, useState } from 'react';
import { GameEngine } from './game/engine';
import { DIALOG_SCRIPTS } from './game/loreData';
import { DialogSequence, GameScreen, PlayerStats, Quest, Zone } from './game/types';
import { GameHUD } from './components/GameHUD';
import { TouchControls } from './components/TouchControls';
import { TitleScreen } from './components/TitleScreen';
import { DialogModal } from './components/DialogModal';
import { CodexModal } from './components/CodexModal';
import { InventoryModal } from './components/InventoryModal';
import { PauseModal } from './components/PauseModal';
import { GameOverModal } from './components/GameOverModal';
import { VictoryModal } from './components/VictoryModal';
import { LandscapeNotice } from './components/LandscapeNotice';
import { ArcPortalModal } from './components/ArcPortalModal';
import { SukunaSpriteModal } from './components/SukunaSpriteModal';
import { sound } from './game/audio';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // React UI state mirrored from engine
  const [screen, setScreen] = useState<GameScreen>('title');
  const [stats, setStats] = useState<PlayerStats | null>(null);
  const [currentZone, setCurrentZone] = useState<Zone | null>(null);
  const [quests, setQuests] = useState<Quest[]>([]);
  const [unlockedLore, setUnlockedLore] = useState<string[]>([]);
  const [activeDialog, setActiveDialog] = useState<DialogSequence | null>(null);
  const [interactivePrompt, setInteractivePrompt] = useState<string | null>(null);

  // Modals
  const [showCodex, setShowCodex] = useState(false);
  const [showInventory, setShowInventory] = useState(false);
  const [showPause, setShowPause] = useState(false);
  const [showArcPortalModal, setShowArcPortalModal] = useState(false);
  const [showSukunaModal, setShowSukunaModal] = useState(false);
  const [hasSaveGame, setHasSaveGame] = useState(false);

  // Initialize engine on mount
  useEffect(() => {
    if (!canvasRef.current) return;

    // Check if previous save exists in localStorage
    try {
      const existing = localStorage.getItem('binh_lieu_vuong_save');
      setHasSaveGame(!!existing);
    } catch {
      // restricted
    }

    const engine = new GameEngine(canvasRef.current, {
      onStatsChange: updatedStats => setStats({ ...updatedStats }),
      onZoneChange: updatedZone => setCurrentZone(updatedZone),
      onDialogTrigger: dialogId => {
        const sequence = DIALOG_SCRIPTS[dialogId];
        if (sequence) setActiveDialog(sequence);
      },
      onQuestUpdate: updatedQuests => setQuests([...updatedQuests]),
      onGameOver: () => setScreen('gameover'),
      onVictory: () => setScreen('victory'),
      onLoreUnlocked: (loreId) => {
        setUnlockedLore(prev => (prev.includes(loreId) ? prev : [...prev, loreId]));
      },
      onInteractPrompt: prompt => setInteractivePrompt(prompt),
      onOpenArcPortalModal: () => setShowArcPortalModal(true),
    });

    engineRef.current = engine;
    setStats({ ...engine.stats });
    setCurrentZone(engine.currentZone);
    setQuests([...engine.quests]);
    setUnlockedLore([...engine.unlockedLore]);

    // Handle Window Resize / Orientation Change
    const handleResize = () => {
      engine.resizeCanvas();
    };
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    // Keyboard controls
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }

      const input = engine.input;
      if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') input.left = true;
      if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') input.right = true;
      if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp' || e.key === ' ') {
        input.jump = true;
        input.justJumped = true;
      }
      if (e.key === 'j' || e.key === 'J' || e.key === 'k' || e.key === 'K') {
        input.attack = true;
        input.justAttacked = true;
      }
      if (e.key === 'l' || e.key === 'L' || e.key === 'Shift') {
        input.dash = true;
        input.justDashed = true;
      }
      if (e.key === 'u' || e.key === 'U') {
        input.skill1 = true;
        input.justSkill1 = true;
      }
      if (e.key === 'i' || e.key === 'I') {
        input.skill2 = true;
        input.justSkill2 = true;
      }
      // Sukuna's Innate Technique & Malevolent Shrine & World Slash key bindings
      if (e.key === '1' || e.key === 'z' || e.key === 'Z') {
        input.skillDismantle = true;
        input.justSkillDismantle = true;
      }
      if (e.key === '2' || e.key === 'x' || e.key === 'X') {
        input.skillCleave = true;
        input.justSkillCleave = true;
      }
      if (e.key === '3' || e.key === 'c' || e.key === 'C') {
        input.skillKamino = true;
        input.justSkillKamino = true;
      }
      if (e.key === '4' || e.key === 'v' || e.key === 'V') {
        input.skillShrine = true;
        input.justSkillShrine = true;
      }
      if (e.key === '5' || e.key === 'o' || e.key === 'O' || e.key === 'b' || e.key === 'B') {
        input.skillWorldSlash = true;
        input.justSkillWorldSlash = true;
      }
      if (e.key === 'e' || e.key === 'E' || e.key === 'Enter') {
        input.interact = true;
        input.justInteracted = true;
      }

      // Pause toggle
      if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') {
        if (engine.activeScreen === 'playing') {
          setShowPause(true);
          engine.activeScreen = 'paused';
        } else if (engine.activeScreen === 'paused') {
          setShowPause(false);
          engine.activeScreen = 'playing';
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const input = engine.input;
      if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') input.left = false;
      if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') input.right = false;
      if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp' || e.key === ' ') input.jump = false;
      if (e.key === 'j' || e.key === 'J' || e.key === 'k' || e.key === 'K') input.attack = false;
      if (e.key === 'l' || e.key === 'L' || e.key === 'Shift') input.dash = false;
      if (e.key === 'u' || e.key === 'U') input.skill1 = false;
      if (e.key === 'i' || e.key === 'I') input.skill2 = false;
      if (e.key === '1' || e.key === 'z' || e.key === 'Z') input.skillDismantle = false;
      if (e.key === '2' || e.key === 'x' || e.key === 'X') input.skillCleave = false;
      if (e.key === '3' || e.key === 'c' || e.key === 'C') input.skillKamino = false;
      if (e.key === '4' || e.key === 'v' || e.key === 'V') input.skillShrine = false;
      if (e.key === '5' || e.key === 'o' || e.key === 'O' || e.key === 'b' || e.key === 'B') input.skillWorldSlash = false;
      if (e.key === 'e' || e.key === 'E' || e.key === 'Enter') input.interact = false;
    };

    const handleBlur = () => {
      const input = engine.input;
      input.left = false;
      input.right = false;
      input.up = false;
      input.down = false;
      input.jump = false;
      input.attack = false;
      input.dash = false;
      input.skill1 = false;
      input.skill2 = false;
      input.skillDismantle = false;
      input.skillCleave = false;
      input.skillKamino = false;
      input.skillShrine = false;
      input.skillWorldSlash = false;
      input.interact = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', handleBlur);
      engine.stop();
    };
  }, []);

  const handleStartGame = () => {
    if (!engineRef.current) return;
    engineRef.current.resetGame();
    engineRef.current.activeScreen = 'playing';
    setScreen('playing');
    setStats({ ...engineRef.current.stats });
    setCurrentZone(engineRef.current.currentZone);
    setQuests([...engineRef.current.quests]);
    setUnlockedLore([...engineRef.current.unlockedLore]);
    engineRef.current.start();
  };

  const handleContinueGame = () => {
    if (!engineRef.current) return;
    engineRef.current.loadGame();
    engineRef.current.activeScreen = 'playing';
    setScreen('playing');
    setStats({ ...engineRef.current.stats });
    setCurrentZone(engineRef.current.currentZone);
    setQuests([...engineRef.current.quests]);
    setUnlockedLore([...engineRef.current.unlockedLore]);
    engineRef.current.start();
  };

  const handleResume = () => {
    setShowPause(false);
    if (engineRef.current) {
      engineRef.current.activeScreen = 'playing';
    }
  };

  const handleRestartCheckpoint = () => {
    if (!engineRef.current) return;
    engineRef.current.stats.hp = engineRef.current.stats.maxHp;
    engineRef.current.player.x = engineRef.current.currentZone.playerStartX;
    engineRef.current.player.y = engineRef.current.currentZone.playerStartY;
    engineRef.current.player.state = 'idle';
    engineRef.current.activeScreen = 'playing';
    setStats({ ...engineRef.current.stats });
    setScreen('playing');
    setShowPause(false);
  };

  const handleResetGame = () => {
    if (!engineRef.current) return;
    engineRef.current.resetGame();
    setHasSaveGame(false);
    setShowPause(false);
    setScreen('title');
  };

  const handleReturnToTitle = () => {
    if (engineRef.current) {
      engineRef.current.saveGame();
      engineRef.current.stop();
      engineRef.current.activeScreen = 'title';
    }
    setShowPause(false);
    setScreen('title');
    setHasSaveGame(true);
  };

  const handleUseInventoryItem = (itemId: string) => {
    if (engineRef.current) {
      engineRef.current.useItem(itemId);
      setStats({ ...engineRef.current.stats });
    }
  };

  const handleSelectArc = (arcNumber: number) => {
    if (!engineRef.current) return;
    const ARC_ZONE_MAP: Record<number, { zoneId: string; x: number; y: number }> = {
      1: { zoneId: 'zone_ban_cau', x: 100, y: 440 },
      2: { zoneId: 'zone_san_truong_ngo_cu', x: 100, y: 440 },
      3: { zoneId: 'zone_noc_cho_binh_lieu', x: 100, y: 440 },
      4: { zoneId: 'zone_moc_bien_cuong_1088', x: 100, y: 440 },
      5: { zoneId: 'zone_shibuya_crosswalk_109', x: 100, y: 440 },
      6: { zoneId: 'zone_thac_khe_van', x: 100, y: 440 },
      7: { zoneId: 'zone_doi_mo_tai_dog', x: 100, y: 440 },
      8: { zoneId: 'zone_nguc_mon_cuong', x: 100, y: 440 },
      9: { zoneId: 'zone_hang_da_lang_son', x: 100, y: 440 },
      10: { zoneId: 'zone_vach_da_nguc_mon_2068', x: 100, y: 440 },
      11: { zoneId: 'zone_mam_non_midnight', x: 100, y: 440 },
      12: { zoneId: 'zone_ban_cau', x: 100, y: 440 },
    };

    const target = ARC_ZONE_MAP[arcNumber] || { zoneId: 'zone_ban_cau', x: 100, y: 440 };
    engineRef.current.stats.currentArc = arcNumber;
    engineRef.current.stats.waveNumber = 1;
    engineRef.current.stats.totalWaves = 5;
    engineRef.current.stats.monstersRemainingInArc = 100;
    engineRef.current.switchZone(target.zoneId, target.x, target.y);
    setStats({ ...engineRef.current.stats });
    setCurrentZone(engineRef.current.currentZone);
    setShowArcPortalModal(false);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none touch-none">
      {/* 2D Canvas Viewport */}
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-crosshair"
      />

      {/* Screen: Title Screen */}
      {screen === 'title' && (
        <TitleScreen
          onStartGame={handleStartGame}
          onContinueGame={handleContinueGame}
          hasSaveGame={hasSaveGame}
          onOpenCodex={() => setShowCodex(true)}
        />
      )}

      {/* Screen: Playing HUD & Touch Controls */}
      {screen === 'playing' && stats && currentZone && (
        <>
          <GameHUD
            stats={stats}
            currentZone={currentZone}
            quests={quests}
            onOpenCodex={() => setShowCodex(true)}
            onOpenInventory={() => setShowInventory(true)}
            onOpenSukunaModal={() => setShowSukunaModal(true)}
            onPause={() => {
              if (engineRef.current) engineRef.current.activeScreen = 'paused';
              setShowPause(true);
            }}
          />

          <TouchControls
            engine={engineRef.current}
            interactivePrompt={interactivePrompt}
          />
        </>
      )}

      {/* Dialogue Modal */}
      {activeDialog && (
        <DialogModal
          sequence={activeDialog}
          onClose={() => setActiveDialog(null)}
        />
      )}

      {/* Lore Codex Modal */}
      {showCodex && (
        <CodexModal
          unlockedLoreIds={unlockedLore}
          onClose={() => setShowCodex(false)}
        />
      )}

      {/* Inventory & Weapon Forge Modal */}
      {showInventory && engineRef.current && (
        <InventoryModal
          items={engineRef.current.inventory}
          stats={stats || engineRef.current.stats}
          onUseItem={handleUseInventoryItem}
          onUpgradeWeapon={() => {
            if (engineRef.current) {
              engineRef.current.upgradeWeapon();
              setStats({ ...engineRef.current.stats });
            }
          }}
          onSetElement={(element) => {
            if (engineRef.current) {
              engineRef.current.setWeaponElement(element);
              setStats({ ...engineRef.current.stats });
            }
          }}
          onClose={() => setShowInventory(false)}
        />
      )}

      {/* Pause Modal */}
      {showPause && (
        <PauseModal
          onResume={handleResume}
          onRestartCheckpoint={handleRestartCheckpoint}
          onResetGame={handleResetGame}
          onReturnToTitle={handleReturnToTitle}
        />
      )}

      {/* Game Over Modal */}
      {screen === 'gameover' && (
        <GameOverModal
          onRespawn={handleRestartCheckpoint}
          onReturnToTitle={handleReturnToTitle}
        />
      )}

      {/* Victory Modal */}
      {screen === 'victory' && (
        <VictoryModal
          onContinueFreePlay={() => {
            setScreen('playing');
            if (engineRef.current) engineRef.current.activeScreen = 'playing';
          }}
          onOpenCodex={() => setShowCodex(true)}
          onReturnToTitle={handleReturnToTitle}
        />
      )}

      {/* 12-Arc Universal Portal Hub Modal */}
      {showArcPortalModal && (
        <ArcPortalModal
          currentArc={stats?.currentArc || 1}
          onSelectArc={handleSelectArc}
          onClose={() => setShowArcPortalModal(false)}
        />
      )}

      {/* Ryomen Sukuna 32x32 Terraria Sprite Sheet & Skin Modal */}
      {showSukunaModal && (
        <SukunaSpriteModal
          isOpen={showSukunaModal}
          onClose={() => setShowSukunaModal(false)}
          currentSkin={stats?.characterSkin || 'khoi'}
          onSelectSkin={(newSkin) => {
            if (engineRef.current) {
              engineRef.current.stats.characterSkin = newSkin;
              setStats({ ...engineRef.current.stats });
            }
          }}
        />
      )}

      {/* Mobile Landscape Orientation Notice & Fullscreen Trigger */}
      <LandscapeNotice />
    </div>
  );
}
