import React from 'react';
import { X, Sparkles, Compass, Shield, Award, CheckCircle } from 'lucide-react';
import { sound } from '../game/audio';

interface ArcPortalModalProps {
  currentArc: number;
  onSelectArc: (arcNumber: number) => void;
  onClose: () => void;
}

const ARC_LIST = [
  { num: 1, title: 'Arc 1: Nguồn Gốc Người Giữ Làng', year: '1970 – 1995', zoneId: 'zone_ban_cau', desc: 'Tuổi thơ Cụ Thọ, y thư Nam Dược Thần Hiệu, bãi mìn Mốc 1305 và gậy trúc Hoàng Cần.' },
  { num: 2, title: 'Arc 2: Thằng Nhóc Bị Bắt Nạt', year: '2012 – 2015', zoneId: 'zone_san_truong_ngo_cu', desc: 'Khôi 12 tuổi bị con nhà võ bắt nạt, chòi lá 500 nhát liềm giá rét căm căm.' },
  { num: 3, title: 'Arc 3: Đêm Giết Thầy Nóc Chợ', year: '2015 – 2017', zoneId: 'zone_chua_co_nguyet', desc: 'Trận thư hùng với Trúc Thánh Hoàng Cần trên nóc chợ trong đêm mưa bão.' },
  { num: 4, title: 'Arc 4: Bình Liêu Vương 18 Tuổi & Chữ DỪNG', year: '2018', zoneId: 'zone_moc_bien_cuong_1088', desc: 'Bảo vệ thương nhân Mốc 1088, so tài 7 đêm với Chu Hiếu Què 16 tuổi.' },
  { num: 5, title: 'Arc 5: Winter Shibuya Incident', year: '2028', zoneId: 'zone_shibuya_crosswalk_109', desc: 'Tuyết trắng ngã tư Shibuya 109, còi xe cứu thương 3:17AM và Huyết Trúc Tokyo.' },
  { num: 6, title: 'Arc 6: Chiến Binh Thác Khe Vằn', year: '2029', zoneId: 'zone_thac_khe_van', desc: 'Treo mình 6 tháng dưới thác 100 tầng, ngộ ra tuyệt kỹ liềm Khe Vằn Trảm.' },
  { num: 7, title: 'Arc 7: Tài Dog & Cái "Giữ" Cuối Cùng', year: '2030 – 2065', zoneId: 'zone_doi_mo_tai_dog', desc: 'Chăm sóc đứa cháu bệnh tim, treo liềm vào két sắt và chó Đốm canh mộ 3 ngày.' },
  { num: 8, title: 'Arc 8: Rubik Ngục Môn Cương & Ba Chú Linh', year: '2065 – 2068', zoneId: 'zone_nguc_mon_cuong', desc: 'Tự nguyện bước vào khối đá Rubik 1m³, tha thứ Ba Chú Linh và bát cháo gừng Bà Mận.' },
  { num: 9, title: 'Arc 9: Chu Mạnh Hiếu & Thuật Hoán Não', year: '2065 – 2068', zoneId: 'zone_hang_da_lang_son', desc: 'Sào huyệt hang đá Lạng Sơn, phản phệ não Tài chảy huyết lệ, gặp Lục Triều Dư.' },
  { num: 10, title: 'Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại', year: '2068', zoneId: 'zone_vach_da_nguc_mon_2068', desc: 'Gõ 108 nhịp sóng âm phá Rubik, khoác áo phao đen rách kéo Khôi trở lại.' },
  { num: 11, title: 'Arc 11: Trận Cuối Ở Trường Mầm Non', year: '2068', zoneId: 'zone_mam_non_midnight', desc: 'Bẫy cáp xích đu, chém gãy tay thép, Lôi Ảnh Thủ Chu Hiếu Què, nhát liềm DỪNG LẠI.' },
  { num: 12, title: 'Arc 12: Đại Kết Cục Thần Thoại & Hai Thằng Canh Cổng', year: '2068+', zoneId: 'zone_ban_cau', desc: 'Bình minh chiếu rọi non cao, giải cứu 20 đứa trẻ, hồn Tài siêu thoát, bảo hộ vĩnh hằng.' }
];

export const ArcPortalModal: React.FC<ArcPortalModalProps> = ({ currentArc, onSelectArc, onClose }) => {
  return (
    <div className="absolute inset-0 z-50 bg-black/90 flex items-center justify-center p-3 md:p-6 backdrop-blur-md select-none">
      <div className="bg-slate-950 border border-cyan-500/80 rounded-2xl w-full max-w-3xl h-[88vh] max-h-[620px] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex justify-between items-center bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-400 flex items-center justify-center text-cyan-300">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-100 uppercase tracking-wide flex items-center gap-2">
                <span>Cổng Luân Hồi 12 Arc</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono font-normal">
                  Chuyển Giao Trực Tiếp
                </span>
              </h2>
              <span className="text-[11px] text-slate-400">
                Toàn bộ 12 Arc được quy tụ về một cổng đầu. Chọn một Arc để dịch chuyển và kích hoạt ngay lập tức!
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Arc Grid */}
        <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 md:grid-cols-2 gap-3 bg-slate-950/40">
          {ARC_LIST.map(arc => {
            const isCurrent = currentArc === arc.num;
            return (
              <div
                key={arc.num}
                onClick={() => {
                  sound.playLevelUp();
                  onSelectArc(arc.num);
                  onClose();
                }}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between gap-2 text-left ${
                  isCurrent
                    ? 'bg-cyan-950/40 border-cyan-400 shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-400/50'
                    : 'bg-slate-900/50 border-slate-800 hover:border-slate-600 hover:bg-slate-900 text-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-cyan-500/30">
                      Arc {arc.num} • {arc.year}
                    </span>
                    {isCurrent && (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400">
                        <CheckCircle className="w-3.5 h-3.5" />
                        Đang chọn
                      </span>
                    )}
                  </div>

                  <h3 className="text-xs md:text-sm font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                    {arc.title}
                  </h3>

                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {arc.desc}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                    <Compass className="w-3 h-3 text-cyan-400" />
                    {arc.zoneId}
                  </span>
                  <button className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors active:scale-95 shadow">
                    Dịch Chuyển ➔
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
