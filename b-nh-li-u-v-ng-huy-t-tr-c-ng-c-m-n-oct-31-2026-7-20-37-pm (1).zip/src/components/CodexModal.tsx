import React, { useState } from 'react';
import { LORE_ENTRIES, LoreEntry } from '../game/loreData';
import { ARC_1_DATA, ARC_1_AUDIT_TABLE, ARC_2_DATA, ARC_2_AUDIT_TABLE, ARC_3_DATA, ARC_3_AUDIT_TABLE, ARC_4_DATA, ARC_4_AUDIT_TABLE, ARC_5_DATA, ARC_5_AUDIT_TABLE, ARC_6_DATA, ARC_6_AUDIT_TABLE, ARC_7_DATA, ARC_7_AUDIT_TABLE, ARC_8_DATA, ARC_8_AUDIT_TABLE, ARC_9_DATA, ARC_9_AUDIT_TABLE, ARC_10_DATA, ARC_10_AUDIT_TABLE, ARC_11_DATA, ARC_11_AUDIT_TABLE } from '../game/arcStoryData';
import { arcManager } from '../game/arcManager';
import { X, BookOpen, User, Compass, Shield, Award, Lock, CheckCircle2, Clock, ScrollText, AlertCircle } from 'lucide-react';

interface CodexModalProps {
  unlockedLoreIds: string[];
  onClose: () => void;
}

export const CodexModal: React.FC<CodexModalProps> = ({ unlockedLoreIds, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedEntry, setSelectedEntry] = useState<LoreEntry>(LORE_ENTRIES[0]);
  const [viewArcNumber, setViewArcNumber] = useState<number>(arcManager.currentArcNumber);

  const activeArcData = viewArcNumber === 11 ? ARC_11_DATA : viewArcNumber === 10 ? ARC_10_DATA : viewArcNumber === 9 ? ARC_9_DATA : viewArcNumber === 8 ? ARC_8_DATA : viewArcNumber === 7 ? ARC_7_DATA : viewArcNumber === 6 ? ARC_6_DATA : viewArcNumber === 5 ? ARC_5_DATA : viewArcNumber === 4 ? ARC_4_DATA : viewArcNumber === 3 ? ARC_3_DATA : viewArcNumber === 2 ? ARC_2_DATA : ARC_1_DATA;

  const [selectedArcEventId, setSelectedArcEventId] = useState<string>(
    viewArcNumber === 11 ? 'A11-E001' : viewArcNumber === 10 ? 'A10-E001' : viewArcNumber === 9 ? 'A09-E001' : viewArcNumber === 8 ? 'A08-E001' : viewArcNumber === 7 ? 'A07-E001' : viewArcNumber === 6 ? 'A06-E001' : viewArcNumber === 5 ? 'A05-E001' : viewArcNumber === 4 ? 'A04-E001' : viewArcNumber === 3 ? 'A03-E001' : viewArcNumber === 2 ? 'A02-E001' : 'A01-E001'
  );

  const categories = [
    { id: 'all', label: 'Tất Cả', icon: BookOpen },
    { id: 'arc_story', label: `📜 Tiến Trình & Kiểm Toán (Arc ${viewArcNumber})`, icon: ScrollText },
    { id: 'Nhân Vật', label: 'Nhân Vật', icon: User },
    { id: 'Triết Lý', label: 'Triết Lý', icon: Shield },
    { id: 'Địa Danh', label: 'Địa Danh', icon: Compass },
    { id: 'Bảo Vật & Kỹ Năng', label: 'Bảo Vật & Võ Công', icon: Award },
  ];

  const filteredEntries = LORE_ENTRIES.filter(e => {
    if (selectedCategory === 'all') return true;
    return e.category === selectedCategory;
  });

  return (
    <div className="absolute inset-0 z-50 bg-black/85 flex items-center justify-center p-3 md:p-8 backdrop-blur-xs select-none">
      <div className="bg-slate-950 border border-slate-700 rounded-2xl w-full max-w-4xl h-[90vh] max-h-[640px] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-slate-100 uppercase tracking-wide">
                Bách Khoa Toàn Thư Bình Liêu
              </h2>
              <span className="text-[11px] text-slate-400">
                Hồ sơ canon thế giới, nhân vật và sự kiện đã khám phá ({unlockedLoreIds.length} / {LORE_ENTRIES.length})
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 px-5 py-2.5 border-b border-slate-800 bg-slate-900/30 overflow-x-auto text-xs">
          {categories.map(cat => {
            const Icon = cat.icon;
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        {/* Content Body */}
        {selectedCategory === 'arc_story' ? (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Left: Event List */}
            <div className="w-full md:w-80 border-r border-slate-800 overflow-y-auto p-3 space-y-2 bg-slate-950/60">
              {/* Arc Selector Buttons */}
              <div className="grid grid-cols-6 md:grid-cols-11 gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800 text-[10px]">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(num => (
                  <button
                    key={num}
                    onClick={() => {
                      setViewArcNumber(num);
                      setSelectedArcEventId(
                        num === 11 ? 'A11-E001' : num === 10 ? 'A10-E001' : num === 9 ? 'A09-E001' : num === 8 ? 'A08-E001' : num === 7 ? 'A07-E001' : num === 6 ? 'A06-E001' : num === 5 ? 'A05-E001' : num === 4 ? 'A04-E001' : num === 3 ? 'A03-E001' : num === 2 ? 'A02-E001' : 'A01-E001'
                      );
                    }}
                    className={`py-1 rounded font-bold transition-colors ${
                      viewArcNumber === num
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Arc {num}
                  </button>
                ))}
              </div>

              <div className="text-[11px] font-bold text-amber-400 px-1 uppercase tracking-wider flex items-center justify-between">
                <span>{activeArcData.events.length} Sự Kiện Canon {activeArcData.title.split(':')[0]}</span>
                <span className="text-[10px] text-slate-400">
                  {activeArcData.events.filter((e: any) => {
                    const managerEv = arcManager.getEvent(e.id);
                    return managerEv ? managerEv.status === 'completed' : e.status === 'completed';
                  }).length} / {activeArcData.events.length} Hoàn thành
                </span>
              </div>

              {activeArcData.events.map((ev: any) => {
                const managerEv = arcManager.getEvent(ev.id);
                const currentStatus = managerEv ? managerEv.status : ev.status;
                const isSelected = selectedArcEventId === ev.id;
                const isDone = currentStatus === 'completed';
                const isActive = currentStatus === 'active';

                return (
                  <button
                    key={ev.id}
                    onClick={() => setSelectedArcEventId(ev.id)}
                    className={`w-full text-left p-3 rounded-xl transition-all flex items-start gap-2.5 border ${
                      isSelected
                        ? 'bg-slate-800 border-amber-500 shadow-md'
                        : isDone
                        ? 'bg-slate-900/40 border-emerald-800/40 hover:bg-slate-900 text-slate-300'
                        : isActive
                        ? 'bg-amber-950/20 border-amber-600/50 hover:bg-slate-900 text-amber-200'
                        : 'bg-slate-950 border-slate-800/50 opacity-60 text-slate-500'
                    }`}
                  >
                    <div className="mt-0.5 flex-shrink-0">
                      {isDone ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : isActive ? (
                        <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
                      ) : (
                        <Lock className="w-4 h-4 text-slate-600" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-amber-400">{ev.id}</span>
                        <span className="text-[9px] text-slate-400">{ev.year}</span>
                      </div>
                      <div className="text-xs font-bold truncate text-slate-100">{ev.title}</div>
                      <div className="text-[10px] text-slate-400 truncate">{ev.location}</div>
                    </div>
                  </button>
                );
              })}

              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-[10px] text-slate-400 space-y-1">
                <div className="font-bold text-slate-200">Triết Lý Cốt Lõi:</div>
                <div className="italic text-amber-200/90 font-serif">
                  {activeArcData.corePhilosophy}
                </div>
              </div>
            </div>

            {/* Right: Selected Arc Event Detail & Audit Table */}
            {(() => {
              const currentEv = activeArcData.events.find((e: any) => e.id === selectedArcEventId) || activeArcData.events[0];
              const auditTable = viewArcNumber === 11 ? ARC_11_AUDIT_TABLE : viewArcNumber === 10 ? ARC_10_AUDIT_TABLE : viewArcNumber === 9 ? ARC_9_AUDIT_TABLE : viewArcNumber === 8 ? ARC_8_AUDIT_TABLE : viewArcNumber === 7 ? ARC_7_AUDIT_TABLE : viewArcNumber === 6 ? ARC_6_AUDIT_TABLE : viewArcNumber === 5 ? ARC_5_AUDIT_TABLE : viewArcNumber === 4 ? ARC_4_AUDIT_TABLE : viewArcNumber === 3 ? ARC_3_AUDIT_TABLE : viewArcNumber === 2 ? ARC_2_AUDIT_TABLE : ARC_1_AUDIT_TABLE;
              const auditEntry = auditTable.find(a => a.eventCode === currentEv.id);

              return (
                <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-950">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                          {currentEv.id}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">{currentEv.year}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          currentEv.status === 'completed'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-500'
                            : currentEv.status === 'active'
                            ? 'bg-amber-950 text-amber-300 border border-amber-500'
                            : 'bg-slate-900 text-slate-500'
                        }`}>
                          {currentEv.status === 'completed' ? '✓ ĐÃ HOÀN THÀNH' : currentEv.status === 'active' ? '⚡ ĐANG DIỄN RA' : '🔒 CHƯA KÍCH HOẠT'}
                        </span>
                      </div>
                      <h3 className="text-lg font-black text-slate-100 mt-1">{currentEv.title}</h3>
                      <div className="text-xs text-emerald-400 font-medium">{currentEv.location}</div>
                    </div>

                    <div className="text-right">
                      <div className="text-[11px] text-slate-400">Phần Thưởng:</div>
                      <div className="text-xs font-bold text-amber-300">+{currentEv.rewardXp} EXP</div>
                    </div>
                  </div>

                  {/* Objective */}
                  <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-600/40 text-xs">
                    <span className="font-bold text-amber-300 uppercase tracking-wide">Mục Tiêu Sự Kiện: </span>
                    <span className="text-slate-200">{currentEv.objective}</span>
                  </div>

                  {/* Canonical Lore Details */}
                  <div className="space-y-2">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Nội Dung Cốt Truyện Gốc (Verbatim Canon):
                    </div>
                    <div className="space-y-1.5 text-xs text-slate-300 leading-relaxed bg-slate-900/50 p-3.5 rounded-xl border border-slate-800">
                      {currentEv.description.map((p: string, idx: number) => (
                        <div key={idx} className="flex items-start gap-2">
                          <span className="text-amber-400 select-none">•</span>
                          <span>{p}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Verbatim Quotes */}
                  <div className="space-y-1.5">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Trích Dẫn Nguyên Bản:
                    </div>
                    {currentEv.verbatimLore.map((quote: string, idx: number) => (
                      <blockquote key={idx} className="p-2.5 rounded-lg bg-slate-900 border-l-2 border-emerald-400 text-xs italic text-emerald-200 font-serif">
                        {quote}
                      </blockquote>
                    ))}
                  </div>

                  {/* Audit Cross-Reference Card */}
                  {auditEntry && (
                    <div className="mt-4 p-4 rounded-xl bg-slate-900 border border-slate-700/80 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span className="text-slate-200 flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 text-cyan-400" />
                          Đối Chiếu Độ Trung Thành (Audit):
                        </span>
                        <span className="text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/50 text-[10px]">
                          Trạng Thái: {auditEntry.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-300">
                        <span className="font-semibold text-slate-400">Vị trí trong game: </span>
                        <span className="font-mono text-cyan-300">{auditEntry.inGameImplementationLocation}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 italic">
                        {auditEntry.notes}
                      </div>
                    </div>
                  )}

                  {/* Full Audit Table Quick Link */}
                  <div className="pt-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Bảng Tổng Hợp Kiểm Toán {activeArcData.title.split(':')[0]} ({auditTable.length}/{auditTable.length} Sự Kiện):
                    </div>
                    <div className="overflow-x-auto rounded-lg border border-slate-800">
                      <table className="w-full text-left text-[11px] text-slate-300">
                        <thead className="bg-slate-900 text-slate-400 font-mono text-[10px] border-b border-slate-800">
                          <tr>
                            <th className="p-2">Mã</th>
                            <th className="p-2">Nội Dung Gốc</th>
                            <th className="p-2">Vị Trí Game</th>
                            <th className="p-2">Trạng Thái</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60">
                          {auditTable.map(row => (
                            <tr key={row.eventCode} className="hover:bg-slate-900/40">
                              <td className="p-2 font-mono font-bold text-amber-300 whitespace-nowrap">{row.eventCode}</td>
                              <td className="p-2 max-w-[200px] truncate">{row.sourceLoreSummary}</td>
                              <td className="p-2 font-mono text-[10px] text-cyan-300 max-w-[180px] truncate">{row.inGameImplementationLocation}</td>
                              <td className="p-2 text-emerald-400 font-bold whitespace-nowrap">{row.status}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        ) : (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Left: Entry List */}
            <div className="w-full md:w-72 border-r border-slate-800 overflow-y-auto p-3 space-y-1.5 bg-slate-950/40">
              {filteredEntries.map(entry => {
                const isUnlocked = unlockedLoreIds.includes(entry.id);
                const isSelected = selectedEntry.id === entry.id;

                return (
                  <button
                    key={entry.id}
                    onClick={() => {
                      if (isUnlocked) setSelectedEntry(entry);
                    }}
                    disabled={!isUnlocked}
                    className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start gap-2.5 ${
                      isSelected
                        ? 'bg-slate-800 border border-amber-500/60 shadow'
                        : isUnlocked
                        ? 'hover:bg-slate-900/80 text-slate-300'
                        : 'opacity-40 cursor-not-allowed bg-slate-950 text-slate-600'
                    }`}
                  >
                    {isUnlocked ? (
                      <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 mt-0.5 text-slate-600 flex-shrink-0" />
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold truncate text-slate-200">
                        {isUnlocked ? entry.title : 'Chưa Mở Khóa'}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {isUnlocked ? entry.subtitle || entry.category : 'Tiếp tục cốt truyện để khám phá'}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Right: Entry Detail View */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-950">
              <div>
                <div className="text-[11px] font-mono uppercase tracking-wider text-emerald-400">
                  {selectedEntry.category}
                </div>
                <h3 className="text-xl font-black text-slate-100 mt-0.5">
                  {selectedEntry.title}
                </h3>
                {selectedEntry.subtitle && (
                  <div className="text-xs text-amber-300 font-medium">
                    {selectedEntry.subtitle}
                  </div>
                )}
              </div>

              {selectedEntry.canonicalQuote && (
                <blockquote className="p-3 rounded-xl bg-amber-950/20 border-l-2 border-amber-400/80 text-xs md:text-sm italic text-amber-200 font-serif">
                  {selectedEntry.canonicalQuote}
                </blockquote>
              )}

              <div className="space-y-2 text-xs md:text-sm text-slate-300 leading-relaxed font-sans">
                <div className="font-semibold text-slate-100">{selectedEntry.tagline}</div>
                {selectedEntry.description.map((paragraph, idx) => (
                  <p key={idx}>{paragraph}</p>
                ))}
              </div>

              {/* Note on Canon Fidelity */}
              <div className="mt-6 pt-4 border-t border-slate-800/80 text-[10px] text-slate-500 space-y-1">
                <div className="font-bold text-slate-400 uppercase tracking-wider">
                  Ghi chú đối chiếu Canon:
                </div>
                <p>
                  Dữ liệu tuân thủ 100% hồ sơ gốc Bình Liêu Vương. Các chi tiết mâu thuẫn thời gian (năm sinh 2028 / 2065, tuổi thọ, hố đá Khe Vằn vs Rubik Ngục Môn) được bảo tồn nguyên vẹn như tài liệu gốc ghi nhận mà không tự ý sửa đổi.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
