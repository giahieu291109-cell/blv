import React, { useEffect, useState } from 'react';
import { DialogSequence } from '../game/types';
import { sound } from '../game/audio';
import { ChevronRight } from 'lucide-react';

interface DialogModalProps {
  sequence: DialogSequence | null;
  onClose: () => void;
}

export const DialogModal: React.FC<DialogModalProps> = ({ sequence, onClose }) => {
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const currentLine = sequence?.lines[currentLineIndex];

  useEffect(() => {
    setCurrentLineIndex(0);
  }, [sequence]);

  useEffect(() => {
    if (!currentLine) return;

    let charIndex = 0;
    setDisplayedText('');
    setIsTyping(true);

    const interval = window.setInterval(() => {
      charIndex++;
      setDisplayedText(currentLine.text.slice(0, charIndex));
      if (charIndex % 3 === 0) {
        sound.playBlip();
      }

      if (charIndex >= currentLine.text.length) {
        window.clearInterval(interval);
        setIsTyping(false);
      }
    }, 24);

    return () => window.clearInterval(interval);
  }, [currentLine]);

  if (!sequence || !currentLine) return null;

  const handleNext = () => {
    if (isTyping) {
      // Instant finish typing
      setDisplayedText(currentLine.text);
      setIsTyping(false);
      return;
    }

    if (currentLineIndex < sequence.lines.length - 1) {
      setCurrentLineIndex(currentLineIndex + 1);
    } else {
      if (sequence.onFinish) sequence.onFinish();
      onClose();
    }
  };

  // Avatar icon rendering based on avatarId
  const renderAvatar = (avatarId: string) => {
    const avatars: Record<string, { label: string; bg: string; border: string }> = {
      avatar_khoi: { label: 'KHÔI', bg: 'bg-slate-800', border: 'border-cyan-400' },
      avatar_tho: { label: 'CỤ THỌ', bg: 'bg-amber-950', border: 'border-amber-400' },
      avatar_thanh: { label: 'THANH', bg: 'bg-emerald-950', border: 'border-emerald-400' },
      avatar_tai: { label: 'TÀI', bg: 'bg-yellow-950', border: 'border-yellow-400' },
      avatar_can: { label: 'CẦN', bg: 'bg-indigo-950', border: 'border-green-400' },
      avatar_du: { label: 'DƯ', bg: 'bg-sky-950', border: 'border-sky-400' },
      avatar_hieu: { label: 'HIẾU', bg: 'bg-red-950', border: 'border-red-500' },
      avatar_hieu_khuyet_tat: { label: 'HIẾU QUÈ', bg: 'bg-emerald-950', border: 'border-emerald-400' },
    };

    const av = avatars[avatarId] || { label: '?', bg: 'bg-slate-800', border: 'border-slate-500' };

    return (
      <div
        className={`w-14 h-14 md:w-16 md:h-16 rounded-xl ${av.bg} border-2 ${av.border} shadow-lg flex items-center justify-center font-black text-xs md:text-sm tracking-wider text-slate-100 flex-shrink-0`}
      >
        {av.label}
      </div>
    );
  };

  return (
    <div
      onClick={handleNext}
      className="absolute inset-0 z-40 bg-black/50 backdrop-blur-xs flex flex-col justify-end p-4 md:p-8 cursor-pointer select-none"
    >
      <div className="bg-slate-950/95 border-2 border-slate-700 rounded-2xl p-4 md:p-6 shadow-2xl max-w-3xl mx-auto w-full flex items-start gap-4">
        {renderAvatar(currentLine.speaker.avatarId)}

        <div className="flex-1 flex flex-col justify-between min-h-[90px]">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span
                className="text-sm md:text-base font-bold"
                style={{ color: currentLine.speaker.color }}
              >
                {currentLine.speaker.name}
              </span>
              <span className="text-[11px] text-slate-400 font-serif">
                ({currentLine.speaker.title})
              </span>
            </div>

            <p className="text-sm md:text-base text-slate-100 leading-relaxed font-sans min-h-[48px]">
              {displayedText}
            </p>
          </div>

          <div className="flex justify-end items-center gap-1 text-[11px] text-amber-400 font-mono mt-2">
            <span>{isTyping ? 'Nhấp để hiện nhanh' : 'Nhấp để tiếp tục'}</span>
            <ChevronRight className="w-3.5 h-3.5 animate-pulse" />
          </div>
        </div>
      </div>
    </div>
  );
};
