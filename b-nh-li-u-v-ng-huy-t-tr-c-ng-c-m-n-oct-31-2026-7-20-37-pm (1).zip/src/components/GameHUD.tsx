import React, { useState } from 'react';
import { PlayerStats, Quest, Zone } from '../game/types';
import { BookOpen, Backpack, Volume2, VolumeX, Pause, ChevronDown, ChevronUp, Zap, Sparkles } from 'lucide-react';
import { sound } from '../game/audio';

interface GameHUDProps {
  stats: PlayerStats;
  currentZone: Zone;
  quests: Quest[];
  onOpenCodex: () => void;
  onOpenInventory: () => void;
  onOpenSukunaModal: () => void;
  onPause: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  stats,
  currentZone,
  quests,
  onOpenCodex,
  onOpenInventory,
  onOpenSukunaModal,
  onPause,
}) => {
  const [isMuted, setIsMuted] = useState(sound.getMuted());
  const [questExpanded, setQuestExpanded] = useState(false);

  const toggleSound = () => {
    const nextState = !isMuted;
    sound.setMuted(nextState);
    setIsMuted(nextState);
  };

  const hpPercent = Math.max(0, Math.min(100, (stats.hp / stats.maxHp) * 100));
  const armorPercent = Math.max(0, Math.min(100, (stats.armor / stats.maxArmor) * 100));
  const qiPercent = Math.max(0, Math.min(100, (stats.qi / stats.maxQi) * 100));
  const xpPercent = Math.max(0, Math.min(100, (stats.xp / stats.maxXp) * 100));

  const elementBadges = {
    none: { label: 'Vũ Khí Thường', color: 'text-slate-300 bg-slate-800' },
    ice: { label: '❄ Băng Hàn', color: 'text-sky-300 bg-sky-950 border border-sky-400' },
    neon: { label: '🔥 Neon Thiêu Đốt', color: 'text-fuchsia-300 bg-fuchsia-950 border border-fuchsia-400' },
    lightning: { label: '⚡ Lôi Điện Lan', color: 'text-amber-300 bg-amber-950 border border-amber-400' },
    lifesteal: { label: '🩸 Huyết Sắc (Hút Máu)', color: 'text-rose-300 bg-rose-950 border border-rose-400' },
  };

  return (
    <div className="absolute top-0 left-0 right-0 p-2 md:p-3 pointer-events-none z-10 flex flex-col md:flex-row justify-between items-start gap-1.5">
      {/* LEFT: Character status cluster (includes Backpack next to HP) */}
      <div className="pointer-events-auto bg-slate-950/90 border border-slate-700/80 rounded-xl p-2 shadow-2xl flex items-center gap-2.5 backdrop-blur-xs">
        {/* Avatar indicator */}
        <div className="relative w-10 h-10 rounded-lg bg-slate-900 border border-slate-600 flex items-center justify-center overflow-hidden shrink-0">
          <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-600 to-slate-800 border border-cyan-400 flex items-center justify-center text-[10px] font-bold text-white shadow">
            KHÔI
          </div>
          <span className="absolute bottom-0 right-0 bg-amber-500 text-slate-950 text-[8px] font-black px-1 rounded-tl-sm">
            Lv.{stats.level}
          </span>
        </div>

        {/* HP, Armor, Qi, and XP bars */}
        <div className="flex flex-col gap-0.5 w-36 sm:w-44">
          {/* Máu */}
          <div className="flex items-center justify-between text-[10px] font-bold">
            <span className="text-red-400">MÁU (+5/s)</span>
            <span className="text-slate-300 font-mono text-[9px] tabular-nums">
              {Math.round(stats.hp)} / {stats.maxHp}
            </span>
          </div>
          <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-red-600 to-rose-400 transition-all duration-150"
              style={{ width: `${hpPercent}%` }}
            />
          </div>

          {/* Giáp & Độ bền */}
          <div className="flex items-center justify-between text-[9px] font-bold">
            <span className="text-sky-300 flex items-center gap-1">
              🛡 GIÁP {stats.armorDurability > 0 ? `(${stats.armorDurability}%)` : '(HỎNG)'}
            </span>
            <span className="text-sky-200 font-mono text-[8px] tabular-nums">
              {Math.round(stats.armor)} / {stats.maxArmor}
            </span>
          </div>
          <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden border border-slate-700">
            <div
              className={`h-full transition-all duration-150 ${stats.armorDurability > 0 ? 'bg-gradient-to-r from-sky-500 to-cyan-300' : 'bg-red-800'}`}
              style={{ width: `${armorPercent}%` }}
            />
          </div>

          {/* Nội Lực / Chú Lực */}
          <div className="flex items-center justify-between text-[9px] font-bold">
            <span className="text-cyan-400">CHÚ LỰC</span>
            <span className="text-slate-300 font-mono text-[8px] tabular-nums">
              {Math.round(stats.qi)} / {stats.maxQi}
            </span>
          </div>
          <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-cyan-600 to-sky-300 transition-all duration-150"
              style={{ width: `${qiPercent}%` }}
            />
          </div>

          {/* XP Progress Bar */}
          <div className="w-full h-0.5 bg-slate-900 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-400"
              style={{ width: `${xpPercent}%` }}
            />
          </div>

          {/* Status Badges: Awakening, Crit, Elements */}
          <div className="flex flex-wrap items-center gap-1 mt-0.5 text-[8px] font-bold">
            {stats.isAwakened && (
              <span className="px-1 py-0.2 rounded bg-amber-500 text-slate-950 font-black animate-pulse flex items-center gap-0.5 shadow">
                <Zap className="w-2.5 h-2.5 fill-current" /> THỨC TỈNH 120%
              </span>
            )}
            <span className="px-1 py-0.2 rounded bg-amber-950/80 border border-amber-500/60 text-amber-200">
              ⚔ +{stats.weaponLevel} ({Math.round(stats.critRate * 100)}% Crit)
            </span>
            <span className={`px-1 py-0.2 rounded ${elementBadges[stats.weaponElement]?.color || ''}`}>
              {elementBadges[stats.weaponElement]?.label || 'Băng Hàn'}
            </span>
          </div>
        </div>

        {/* TÚI ĐỒ BUTTON (Moved near HP Bar as requested) */}
        <button
          onClick={onOpenInventory}
          className="shrink-0 p-2 rounded-lg bg-teal-950/80 border border-teal-500/80 text-teal-300 hover:bg-teal-900 active:scale-95 transition-all shadow-md flex flex-col items-center gap-0.5"
          title="Túi Đồ & Trang Bị (6 Ô)"
        >
          <Backpack className="w-4 h-4" />
          <span className="text-[8px] font-black uppercase tracking-tight">Túi Đồ</span>
        </button>
      </div>

      {/* CENTER: Compact Boss Health & Compact Zone/Wave Strip */}
      <div className="flex flex-col items-center pointer-events-auto gap-1 self-center">
        {/* Active Boss Health Bar (Compact for mobile) */}
        {(() => {
          const activeBoss = currentZone.enemies.find(e => e.isBoss && e.hp > 0);
          if (!activeBoss) return null;
          const bossHpPercent = Math.max(0, Math.min(100, (activeBoss.hp / activeBoss.maxHp) * 100));
          return (
            <div className="bg-slate-950/95 border border-red-700/80 rounded-xl px-2.5 py-1 shadow-xl flex flex-col items-center gap-0.5 w-52 sm:w-72 md:w-80 backdrop-blur-xs">
              <div className="flex items-center justify-between w-full text-[10px] font-black tracking-wider text-red-400">
                <span className="uppercase text-amber-300 drop-shadow truncate max-w-[130px]">{activeBoss.name}</span>
                <span className="font-mono text-[9px] text-red-200 tabular-nums">
                  700M HP: {Math.max(0, Math.round(activeBoss.hp)).toLocaleString()}
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-red-900/80">
                <div
                  className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 transition-all duration-100"
                  style={{ width: `${bossHpPercent}%` }}
                />
              </div>
              {stats.chantText && (
                <div className="text-[8px] font-black text-purple-300 animate-pulse truncate max-w-full">
                  ⚡ {stats.chantText}
                </div>
              )}
            </div>
          );
        })()}

        {/* Compact Wave & Monster Counter */}
        {currentZone.id !== 'zone_ban_cau' && (
          <div className="bg-slate-950/80 border border-slate-700/60 rounded-full px-2.5 py-0.5 text-[9px] font-black text-rose-300 flex items-center gap-1.5 shadow">
            <span>⚔ ĐỢT {stats.waveNumber}/5</span>
            <span className="text-slate-400">•</span>
            <span className="text-amber-300">CÒN {stats.monstersRemainingInArc ?? 100}/100 QUÁI</span>
          </div>
        )}
      </div>

      {/* RIGHT: Compact Quest Ticker & Menu Controls */}
      <div className="pointer-events-auto flex items-start gap-1.5 self-end md:self-auto">
        {/* Compact & Collapsible Quest Tracker (Reduced size for mobile) */}
        <div className="flex flex-col bg-slate-950/90 border border-amber-500/60 rounded-xl px-2 py-1 shadow-lg max-w-[170px] sm:max-w-xs backdrop-blur-xs">
          <div
            className="flex items-center justify-between gap-1 text-[9px] font-bold text-amber-400 cursor-pointer"
            onClick={() => setQuestExpanded(!questExpanded)}
          >
            <div className="flex items-center gap-1 truncate">
              <span className="px-1 rounded bg-amber-500/20 text-amber-300 font-mono text-[8px]">
                NHIỆM VỤ
              </span>
              <span className="truncate text-amber-200 text-[9px]">
                {stats.objectiveTitle || 'Đứa Trẻ Mồ Côi'}
              </span>
            </div>
            {questExpanded ? <ChevronUp className="w-3 h-3 shrink-0" /> : <ChevronDown className="w-3 h-3 shrink-0" />}
          </div>

          {questExpanded && (
            <div className="mt-1 pt-1 border-t border-slate-800 text-[8px] text-slate-200 leading-tight">
              <p className="line-clamp-2">{stats.objectiveDetail || 'Khám phá và tiêu diệt quái vật.'}</p>
              {stats.woodCount !== undefined && stats.woodCount < 3 && !stats.isHearthLit && (
                <div className="text-yellow-300 font-bold mt-0.5">🪵 Củi khô: {stats.woodCount}/3</div>
              )}
              {stats.currentArc && (
                <div className="text-cyan-300 font-bold mt-0.5">Tiến trình: Arc {stats.currentArc}/12</div>
              )}
            </div>
          )}
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 bg-slate-950/85 border border-slate-700/80 p-1 rounded-xl shadow-lg">
          <button
            onClick={() => {
              if (document.fullscreenElement) {
                document.exitFullscreen().catch(() => {});
              } else if (document.documentElement.requestFullscreen) {
                document.documentElement.requestFullscreen().then(() => {
                  if (screen.orientation && 'lock' in screen.orientation) {
                    (screen.orientation as any).lock('landscape').catch(() => {});
                  }
                }).catch(() => {});
              }
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-sky-300 hover:bg-slate-700 active:scale-95 transition-all"
            title="Xoay Ngang & Toàn Màn Hình"
          >
            <span className="text-[9px] font-black tracking-tight">⛶</span>
          </button>

          <button
            onClick={onOpenSukunaModal}
            className={`p-1.5 rounded-lg border active:scale-95 transition-all flex items-center gap-1 ${
              stats.characterSkin === 'sukuna'
                ? 'bg-red-950 text-red-300 border-red-500 shadow-sm shadow-red-500/50'
                : 'bg-slate-800 text-rose-300 border-slate-700 hover:bg-slate-700'
            }`}
            title="Ryomen Sukuna 32x32 Terraria Pixel Sprite Sheet & Đổi Skin"
          >
            <Sparkles className="w-3.5 h-3.5 text-red-400" />
            <span className="text-[8px] font-black tracking-tighter uppercase hidden sm:inline">Sukuna 32x32</span>
          </button>

          <button
            onClick={onOpenCodex}
            className="p-1.5 rounded-lg bg-slate-800 text-amber-300 hover:bg-slate-700 active:scale-95 transition-all"
            title="Bách Khoa Toàn Thư"
          >
            <BookOpen className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={toggleSound}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 active:scale-95 transition-all"
            title={isMuted ? 'Bật âm thanh' : 'Tắt âm thanh'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-green-400" />}
          </button>

          <button
            onClick={onPause}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 active:scale-95 transition-all"
            title="Tạm Dừng"
          >
            <Pause className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
