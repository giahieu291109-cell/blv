import React from 'react';
import { RotateCcw, Home } from 'lucide-react';
import { sound } from '../game/audio';

interface GameOverModalProps {
  onRespawn: () => void;
  onReturnToTitle: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ onRespawn, onReturnToTitle }) => {
  return (
    <div className="absolute inset-0 z-50 bg-black/90 flex items-center justify-center p-6 backdrop-blur-xs select-none">
      <div className="bg-slate-950 border border-red-900/80 rounded-2xl w-full max-w-md shadow-2xl p-6 text-center space-y-5">
        <div className="w-16 h-16 rounded-full bg-red-950/60 border-2 border-red-500/80 mx-auto flex items-center justify-center text-red-400 font-black text-2xl shadow-lg">
          !
        </div>

        <div>
          <h2 className="text-xl md:text-2xl font-black text-red-500 tracking-wider uppercase">
            TÂM THẦN KIỆT QUỆ
          </h2>
          <p className="text-xs text-slate-400 mt-2 italic font-serif">
            “Mày không giết người. Mày bình người. Ngã xuống rồi thì đứng lên bước tiếp.”
          </p>
          <span className="text-[10px] text-amber-400 font-mono">
            — Lời Dặn Của Cụ Thọ —
          </span>
        </div>

        <div className="flex flex-col gap-2.5 pt-2">
          <button
            onClick={() => {
              sound.playLevelUp();
              onRespawn();
            }}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all border border-red-400/50"
          >
            <RotateCcw className="w-4 h-4" />
            <span>HỒI SINH TẠI ĐIỂM LƯU</span>
          </button>

          <button
            onClick={onReturnToTitle}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all border border-slate-700"
          >
            <Home className="w-4 h-4" />
            <span>VỀ MÀN HÌNH CHÍNH</span>
          </button>
        </div>
      </div>
    </div>
  );
};
