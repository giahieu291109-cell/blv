import React, { useState } from 'react';
import { InventoryItem, PlayerStats } from '../game/types';
import { X, Backpack, Sparkles, Heart, Zap, Shield, Flame, Hammer } from 'lucide-react';

interface InventoryModalProps {
  items: InventoryItem[];
  stats?: PlayerStats;
  onUseItem: (itemId: string) => void;
  onUpgradeWeapon?: () => void;
  onSetElement?: (element: 'none' | 'ice' | 'neon' | 'lightning' | 'lifesteal') => void;
  onClose: () => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  items,
  stats,
  onUseItem,
  onUpgradeWeapon,
  onSetElement,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'items' | 'forge'>('items');

  const elements = [
    {
      id: 'ice' as const,
      name: 'Băng Hàn',
      icon: '❄',
      desc: '35% đóng băng kẻ thù 1.2s và làm chậm',
      color: 'border-sky-400 bg-sky-950/60 text-sky-200',
    },
    {
      id: 'lightning' as const,
      name: 'Lôi Điện',
      icon: '⚡',
      desc: 'Giật sét lan sang 3 kẻ địch xung quanh',
      color: 'border-amber-400 bg-amber-950/60 text-amber-200',
    },
    {
      id: 'neon' as const,
      name: 'Neon Rực Cháy',
      icon: '🔥',
      desc: 'Thiêu đốt kẻ địch liên tục với sát thương cao',
      color: 'border-fuchsia-400 bg-fuchsia-950/60 text-fuchsia-200',
    },
    {
      id: 'lifesteal' as const,
      name: 'Huyết Sắc',
      icon: '🩸',
      desc: 'Hút 10% sát thương gây ra thành Máu cho Khôi',
      color: 'border-rose-400 bg-rose-950/60 text-rose-200',
    },
  ];

  return (
    <div className="absolute inset-0 z-50 bg-black/85 flex items-center justify-center p-3 md:p-6 backdrop-blur-xs select-none">
      <div className="bg-slate-950 border border-slate-700 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header with Tabs */}
        <div className="px-5 py-3 border-b border-slate-800 flex justify-between items-center bg-slate-900/60">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('items')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'items'
                  ? 'bg-teal-600 text-white shadow'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Backpack className="w-4 h-4" />
              <span>HÀNH TRANG</span>
            </button>
            <button
              onClick={() => setActiveTab('forge')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'forge'
                  ? 'bg-amber-600 text-white shadow'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Hammer className="w-4 h-4" />
              <span>RÈN & GHÉP NGUYÊN TỐ</span>
            </button>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TAB 1: ITEMS */}
        {activeTab === 'items' && (
          <div className="p-4 overflow-y-auto space-y-3 flex-1">
            {/* Quick status bar */}
            {stats && (
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-[11px] font-bold text-slate-300">
                <span className="flex items-center gap-1 text-sky-300">
                  <Shield className="w-3.5 h-3.5" />
                  Giáp: {Math.round(stats.armor)} / {stats.maxArmor} (Độ bền: {stats.armorDurability}%)
                </span>
                <span className="flex items-center gap-1 text-amber-400">
                  <Sparkles className="w-3.5 h-3.5" />
                  Mảnh rèn: {stats.upgradeShards} mảnh
                </span>
              </div>
            )}

            {items.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">
                Hành trang trống rỗng.
              </div>
            ) : (
              items.map(item => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start justify-between gap-3 shadow-sm hover:border-slate-700 transition-colors"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-100">
                        {item.name}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-teal-300">
                        x{item.quantity}
                      </span>
                      {item.category === 'armor' && (
                        <span className="text-[9px] font-bold text-sky-400 bg-sky-950/80 border border-sky-600 px-1.5 py-0.5 rounded">
                          CHIẾN GIÁP
                        </span>
                      )}
                      {item.category === 'material' && (
                        <span className="text-[9px] font-bold text-amber-400 bg-amber-950/80 border border-amber-600 px-1.5 py-0.5 rounded">
                          VẬT LIỆU RÈN
                        </span>
                      )}
                      {item.category === 'relic' && (
                        <span className="text-[9px] font-bold text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded">
                          KỶ VẬT
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {item.description}
                    </p>

                    {item.loreNote && (
                      <p className="text-[10px] italic text-amber-300/80 font-serif">
                        {item.loreNote}
                      </p>
                    )}
                  </div>

                  {(item.category === 'consumable' || item.category === 'armor' || item.category === 'material') && (
                    <button
                      onClick={() => onUseItem(item.id)}
                      className="flex items-center gap-1 py-1.5 px-3 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow active:scale-95 transition-all self-center"
                    >
                      {item.effect === 'heal' && <Heart className="w-3 h-3 fill-white" />}
                      {item.effect === 'qi' && <Zap className="w-3 h-3 fill-white" />}
                      {item.effect === 'armor' && <Shield className="w-3 h-3 fill-white" />}
                      {item.effect === 'buff' && <Flame className="w-3 h-3 fill-white" />}
                      {item.effect === 'upgrade' && <Hammer className="w-3 h-3 fill-white" />}
                      <span>{item.category === 'armor' ? 'MẶC' : item.category === 'material' ? 'RÈN' : 'DÙNG'}</span>
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 2: FORGE & WEAPON SOCKETS */}
        {activeTab === 'forge' && stats && (
          <div className="p-4 overflow-y-auto space-y-4 flex-1">
            {/* Weapon Overview Card */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-slate-900 to-amber-950/40 border border-amber-600/60 shadow flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-amber-300 uppercase tracking-wide">
                    Liềm Tử Thần & Bút Băng
                  </h4>
                  <span className="text-xs font-bold text-slate-200">
                    Cấp Độ Vũ Khí: <span className="text-amber-400 font-mono text-sm">+{stats.weaponLevel}</span> / 10
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-sky-300 block">
                    Bạo kích: {Math.round(stats.critRate * 100)}%
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Sát thương bạo kích: {Math.round(stats.critDamageMultiplier * 100)}%
                  </span>
                </div>
              </div>

              {/* Upgrade Button */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <span className="text-xs text-slate-300">
                  Mảnh rèn hiện có: <strong className="text-amber-400 font-mono">{stats.upgradeShards}</strong> (Cần 2 mảnh / 1 cấp)
                </span>
                <button
                  onClick={() => onUpgradeWeapon && onUpgradeWeapon()}
                  disabled={stats.upgradeShards < 2 || stats.weaponLevel >= 10}
                  className={`flex items-center gap-1.5 py-1.5 px-4 rounded-xl font-bold text-xs shadow transition-all ${
                    stats.upgradeShards >= 2 && stats.weaponLevel < 10
                      ? 'bg-amber-600 hover:bg-amber-500 text-white active:scale-95'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Hammer className="w-3.5 h-3.5" />
                  <span>{stats.weaponLevel >= 10 ? 'ĐẠT TỐI ĐA' : 'NÂNG CẤP VŨ KHÍ'}</span>
                </button>
              </div>
            </div>

            {/* Elemental Sockets */}
            <div className="space-y-2">
              <h5 className="text-xs font-black text-slate-200 uppercase tracking-wide flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Ghép Hiệu Ứng Nguyên Tố Vào Lưỡi Liềm
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {elements.map(el => {
                  const isSelected = stats.weaponElement === el.id;
                  return (
                    <div
                      key={el.id}
                      onClick={() => onSetElement && onSetElement(el.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col justify-between gap-1.5 ${
                        isSelected
                          ? `${el.color} ring-2 ring-amber-400 shadow-md`
                          : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold flex items-center gap-1">
                          <span>{el.icon}</span>
                          <span>{el.name}</span>
                        </span>
                        {isSelected && (
                          <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-amber-500 text-slate-950">
                            ĐANG GHÉP
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-300 leading-tight">
                        {el.desc}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
