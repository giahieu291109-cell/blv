import React, { useEffect, useState } from 'react';
import { Smartphone, RotateCw, X } from 'lucide-react';

export const LandscapeNotice: React.FC = () => {
  const [isPortrait, setIsPortrait] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      // If height > width and screen width is mobile-sized (< 900px), it's portrait mobile
      const portrait = window.innerHeight > window.innerWidth && window.innerWidth < 900;
      setIsPortrait(portrait);
      if (!portrait) {
        setDismissed(false); // Reset when user actually rotates to landscape
      }
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);
    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  const handleRequestLandscape = async () => {
    try {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
      }
      if (screen.orientation && 'lock' in screen.orientation) {
        await (screen.orientation as any).lock('landscape');
      }
    } catch {
      // Orientation lock might require user settings
    }
    setDismissed(true);
  };

  if (!isPortrait || dismissed) return null;

  return (
    <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center select-none animate-in fade-in">
      <div className="relative max-w-sm w-full bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl flex flex-col items-center gap-4">
        {/* Dismiss button */}
        <button
          onClick={() => setDismissed(true)}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          title="Bỏ qua"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Animated Rotating Phone Graphic */}
        <div className="relative w-20 h-20 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-emerald-500/10 animate-ping" />
          <div className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-emerald-400 flex items-center justify-center shadow-lg transition-transform duration-700 animate-spin [animation-duration:4s]">
            <RotateCw className="w-8 h-8 text-emerald-400" />
          </div>
        </div>

        <div>
          <h3 className="text-base font-black text-slate-100 uppercase tracking-wide">
            XOAY NGANG MÀN HÌNH
          </h3>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            Game RPG <strong className="text-amber-400">Bình Liêu Vương</strong> được thiết kế tối ưu nhất ở <span className="text-emerald-400 font-bold">chế độ xoay ngang (Landscape)</span> để bạn có tầm nhìn rộng và thao tác hai tay dễ dàng.
          </p>
        </div>

        <div className="flex flex-col gap-2 w-full mt-2">
          <button
            onClick={handleRequestLandscape}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold text-xs shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 border border-emerald-400/50"
          >
            <Smartphone className="w-4 h-4 rotate-90" />
            <span>XOAY NGANG & TOÀN MÀN HÌNH</span>
          </button>

          <button
            onClick={() => setDismissed(true)}
            className="w-full py-2 px-3 text-[11px] text-slate-400 hover:text-slate-200 transition-colors"
          >
            Vẫn chơi ở chế độ dọc
          </button>
        </div>
      </div>
    </div>
  );
};
