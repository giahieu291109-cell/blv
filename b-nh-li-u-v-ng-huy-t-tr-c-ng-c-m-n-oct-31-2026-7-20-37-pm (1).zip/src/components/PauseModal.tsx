import React, { useState } from 'react';
import { Play, RotateCcw, Volume2, VolumeX, Trash2, Home, X } from 'lucide-react';
import { sound } from '../game/audio';

interface PauseModalProps {
  onResume: () => void;
  onRestartCheckpoint: () => void;
  onResetGame: () => void;
  onReturnToTitle: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestartCheckpoint,
  onResetGame,
  onReturnToTitle,
}) => {
  const [isMuted, setIsMuted] = useState(sound.getMuted());
  const [volume, setVolume] = useState(0.4);
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  const handleToggleMute = () => {
    const nextState = !isMuted;
    sound.setMuted(nextState);
    setIsMuted(nextState);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    sound.setVolume(val);
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-xs select-none">
      <div className="bg-slate-950 border border-slate-700 rounded-2xl w-full max-w-sm shadow-2xl p-6 flex flex-col gap-5">
        {/* Title */}
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-slate-100 uppercase tracking-wider">
            TẠM DỪNG TRẬN ĐẤU
          </h3>
          <button
            onClick={onResume}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audio Volume Controls */}
        <div className="space-y-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
          <div className="flex justify-between items-center text-xs">
            <span className="font-semibold text-slate-300">Âm Lượng & Hiệu Ứng:</span>
            <button
              onClick={handleToggleMute}
              className="flex items-center gap-1 text-[11px] font-bold text-amber-400"
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-green-400" />}
              <span>{isMuted ? 'Đang Tắt' : 'Đang Bật'}</span>
            </button>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volume}
            onChange={handleVolumeChange}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
        </div>

        {/* Menu Buttons */}
        <div className="space-y-2.5">
          <button
            onClick={onResume}
            className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>TIẾP TỤC CHƠI</span>
          </button>

          <button
            onClick={onRestartCheckpoint}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all border border-slate-700"
          >
            <RotateCcw className="w-4 h-4" />
            <span>HỒI SINH TẠI ĐIỂM LƯU</span>
          </button>

          <button
            onClick={onReturnToTitle}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all border border-slate-700"
          >
            <Home className="w-4 h-4" />
            <span>VỀ MÀN HÌNH CHÍNH</span>
          </button>

          <button
            onClick={() => setShowConfirmReset(true)}
            className="w-full py-2 px-4 rounded-xl text-rose-400 hover:bg-rose-950/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors pt-2"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Xóa Dữ Liệu Lưu Cục Bộ</span>
          </button>
        </div>

        {/* Confirmation Modal */}
        {showConfirmReset && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/80 space-y-2 text-center">
            <p className="text-xs text-red-200 font-medium">
              Bạn có chắc chắn muốn xóa toàn bộ tiến trình và chơi lại từ đầu?
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  onResetGame();
                  setShowConfirmReset(false);
                }}
                className="flex-1 py-1.5 rounded-lg bg-red-700 hover:bg-red-600 text-white text-xs font-bold"
              >
                Xác Nhận Xóa
              </button>
              <button
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Hủy
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
