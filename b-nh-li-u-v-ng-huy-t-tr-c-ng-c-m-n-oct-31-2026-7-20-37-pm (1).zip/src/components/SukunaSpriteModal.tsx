import React, { useEffect, useRef, useState } from 'react';
import { SukunaSpriteEngine, SukunaAnimationState } from '../game/sukunaSprite';

interface SukunaSpriteModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSkin: 'khoi' | 'sukuna';
  onSelectSkin: (skin: 'khoi' | 'sukuna') => void;
}

export const SukunaSpriteModal: React.FC<SukunaSpriteModalProps> = ({
  isOpen,
  onClose,
  currentSkin,
  onSelectSkin,
}) => {
  const sheetCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activeAnim, setActiveAnim] = useState<SukunaAnimationState>('idle');
  const [animSpeed, setAnimSpeed] = useState<number>(1);
  const [isFacingLeft, setIsFacingLeft] = useState<boolean>(false);

  // Generate full 8x2 sprite sheet preview
  useEffect(() => {
    if (!isOpen || !sheetCanvasRef.current) return;
    const canvas = sheetCanvasRef.current;
    const sheetCanvas = SukunaSpriteEngine.generateFullSpriteSheet();
    canvas.width = sheetCanvas.width;
    canvas.height = sheetCanvas.height;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(sheetCanvas, 0, 0);
    }
  }, [isOpen]);

  // Animated 128x128 preview loop
  useEffect(() => {
    if (!isOpen || !previewCanvasRef.current) return;
    const canvas = previewCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    let frameIndex = 0;
    let lastTime = performance.now();
    let animId: number;

    const frameCounts: Record<SukunaAnimationState, number> = {
      idle: 4,
      walk: 4,
      jump: 1,
      fall: 1,
      dismantle: 4,
      cleave: 4,
      kamino: 5,
      shrine: 6,
      worldSlash: 5,
      attack1: 2,
      attack2: 2,
      attack3: 3,
    };

    const loop = (now: number) => {
      const dt = (now - lastTime) / 1000;
      const interval = 0.15 / animSpeed;

      if (dt >= interval) {
        frameIndex = (frameIndex + 1) % frameCounts[activeAnim];
        lastTime = now;
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background podium
      ctx.fillStyle = '#0a0708';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Floor grid & demonic circle
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(64, 110, 42, 0, Math.PI * 2);
      ctx.stroke();

      ctx.save();
      if (isFacingLeft) {
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
      }

      // Render 32x32 sprite scaled 4x to 128x128
      SukunaSpriteEngine.renderFrame(ctx, activeAnim, frameIndex, 0, 0, 4);
      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isOpen, activeAnim, animSpeed, isFacingLeft]);

  if (!isOpen) return null;

  const animations: { id: SukunaAnimationState; label: string; desc: string }[] = [
    { id: 'idle', label: 'Tĩnh Lặng (Idle)', desc: 'Tư thế đứng ngạo nghễ, khí đen huyết sắc vần vũ' },
    { id: 'walk', label: 'Di Bộ (Walk)', desc: 'Bước đi lướt nhẹ nhàng của Vua Nguyền Hồn' },
    { id: 'jump', label: 'Nhảy Vọt (Jump)', desc: 'Bật cao né tránh địa hình và đòn đánh' },
    { id: 'fall', label: 'Rơi Hạ (Fall)', desc: 'Hạ cánh đè bẹp trọng lực' },
    { id: 'dismantle', label: 'Bát - Dismantle', desc: 'Vung tay phóng trảm kích biến dạng không khí' },
    { id: 'cleave', label: 'Giải - Cleave', desc: 'Nhát chém áp sát tự động thích ứng với mục tiêu' },
    { id: 'kamino', label: 'Hỏa / Khai - Fuga', desc: 'Mở Hộp Đen, giương cung lửa thiêu rụi vạn vật' },
    { id: 'shrine', label: 'Phục Ma Ngự Trù Tử', desc: 'Thủ ấn Diêm Ma Thiên triệu hồi Lãnh Địa Mở' },
    { id: 'worldSlash', label: 'Trảm Kích Thế Gian', desc: 'Trảm đứt tọa độ không gian vũ trụ' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-gradient-to-b from-[#180f12] via-[#12090b] to-[#0a0507] border-2 border-red-700/60 rounded-2xl shadow-2xl shadow-red-950/80 flex flex-col overflow-hidden text-red-100 font-sans">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-red-900/40 bg-red-950/20">
          <div className="flex items-center gap-3">
            <span className="w-3.5 h-3.5 rounded-full bg-red-500 animate-ping"></span>
            <div>
              <h2 className="text-xl font-bold tracking-wide text-red-300 drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]">
                RYOMEN SUKUNA • 32x32 PIXEL SPRITE SHEET (TERRARIA STYLE)
              </h2>
              <p className="text-xs text-red-400/80">
                Pixel Art 32x32 • Cụm đổ bóng & viền 1px chuẩn Terraria • Bảng màu Anime Jujutsu Kaisen
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-red-950/60 border border-red-600/50 hover:bg-red-900/60 text-red-200 text-sm font-semibold transition"
          >
            ✕ Đóng
          </button>
        </div>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Main preview section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            {/* Live 128x128 preview box */}
            <div className="flex flex-col items-center justify-center p-4 bg-black/60 rounded-xl border border-red-800/40 shadow-inner">
              <span className="text-xs uppercase tracking-widest text-red-400 font-semibold mb-2">
                Live 4X Animation Preview
              </span>
              <div className="relative p-2 bg-[#0c0809] border border-red-900/60 rounded-lg shadow-lg">
                <canvas
                  ref={previewCanvasRef}
                  width={128}
                  height={128}
                  className="rounded image-rendering-pixelated"
                  style={{ imageRendering: 'pixelated' }}
                />
                <div className="absolute bottom-3 right-3 text-[10px] px-1.5 py-0.5 rounded bg-red-950/80 border border-red-800/60 text-red-300">
                  32×32 @ 400%
                </div>
              </div>

              {/* Controls */}
              <div className="mt-3 flex items-center gap-2">
                <button
                  onClick={() => setIsFacingLeft(!isFacingLeft)}
                  className="px-2.5 py-1 text-xs rounded bg-red-900/40 hover:bg-red-800/50 border border-red-700/40 text-red-200"
                >
                  {isFacingLeft ? '◀ Đang quay Trái' : 'Quay Phải ▶'}
                </button>
                <button
                  onClick={() => setAnimSpeed(animSpeed === 1 ? 0.5 : animSpeed === 0.5 ? 2 : 1)}
                  className="px-2.5 py-1 text-xs rounded bg-red-900/40 hover:bg-red-800/50 border border-red-700/40 text-red-200"
                >
                  Tốc độ: {animSpeed}x
                </button>
              </div>

              {/* Skin toggle action */}
              <div className="mt-4 w-full">
                <button
                  onClick={() => onSelectSkin(currentSkin === 'sukuna' ? 'khoi' : 'sukuna')}
                  className={`w-full py-2.5 px-4 rounded-xl font-bold text-sm tracking-wide transition shadow-lg flex items-center justify-center gap-2 ${
                    currentSkin === 'sukuna'
                      ? 'bg-gradient-to-r from-red-700 to-rose-900 text-white shadow-red-900/60 border border-red-400'
                      : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-600'
                  }`}
                >
                  {currentSkin === 'sukuna' ? '✓ Đang Dùng Skin Sukuna Terraria' : 'Trang Bị Skin Sukuna (32x32)'}
                </button>
              </div>
            </div>

            {/* Animation Selector List */}
            <div className="md:col-span-2 space-y-2">
              <span className="text-xs uppercase tracking-widest text-red-400 font-semibold block mb-1">
                Các Động Tác / Thuật Thức Bẩm Sinh & Lãnh Địa
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
                {animations.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => setActiveAnim(a.id)}
                    className={`text-left p-2.5 rounded-lg border transition ${
                      activeAnim === a.id
                        ? 'bg-red-950/80 border-red-500 shadow-md shadow-red-950/50 text-white'
                        : 'bg-black/40 border-red-900/30 hover:bg-red-950/30 text-red-200/80'
                    }`}
                  >
                    <div className="font-semibold text-sm flex items-center justify-between">
                      <span>{a.label}</span>
                      {activeAnim === a.id && <span className="text-red-400 text-xs">● Active</span>}
                    </div>
                    <div className="text-[11px] text-zinc-400 mt-0.5 line-clamp-1">{a.desc}</div>
                  </button>
                ))}
              </div>

              {/* Technique Mechanics Detail */}
              <div className="mt-3 p-3 bg-red-950/30 rounded-lg border border-red-900/50 text-xs text-red-200/90 leading-relaxed">
                <span className="font-bold text-red-300">Đặc tính kỹ thuật Anime & Terraria:</span>
                <ul className="list-disc list-inside mt-1 space-y-0.5 text-[11px] text-zinc-300">
                  <li><strong className="text-red-400">Dismantle (Bát):</strong> Tia cắt biến dạng vô hình, vệt tia đỏ đen xé toạc không khí tầm xa.</li>
                  <li><strong className="text-red-400">Cleave (Giải):</strong> Đòn trảm áp sát, tự động mở rộng theo kích cỡ và độ bền của kẻ địch.</li>
                  <li><strong className="text-red-400">Kamino (Hỏa / Khai):</strong> Mũi tên lửa cực nóng bùng nổ nhiệt áp pixel quy mô lớn.</li>
                  <li><strong className="text-red-400">Phục Ma Ngự Trù Tử:</strong> Lãnh địa mở không kết giới, phù chú và sọ người khắc sâu vào mặt đất, đền xương tự do, bão vi trảm cắt liên tục.</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Full 8x2 Sprite Sheet Canvas */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-widest text-red-400 font-semibold">
                Toàn Bộ Sprite Sheet 8x2 Frames (Terraria 32x32 Grid)
              </span>
              <span className="text-[11px] text-zinc-400">
                Hàng 1: Idle, Walk, Jump, Fall, Dismantle • Hàng 2: Cleave, Kamino, Shrine, World Slash
              </span>
            </div>
            <div className="p-3 bg-black/80 rounded-xl border border-red-900/40 overflow-x-auto flex justify-center">
              <canvas
                ref={sheetCanvasRef}
                className="image-rendering-pixelated rounded border border-red-900/30 shadow-md"
                style={{ imageRendering: 'pixelated', maxWidth: '100%' }}
              />
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-red-900/40 bg-black/60 flex items-center justify-between text-xs text-red-300/80">
          <div>
            Tự động kích hoạt Sukuna khi bật <span className="text-red-400 font-bold">Thức Tỉnh 120%</span> hoặc thi triển <span className="text-red-400 font-bold">Phục Ma Ngự Trù Tử</span>.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold transition"
          >
            Hoàn Tất
          </button>
        </div>

      </div>
    </div>
  );
};
