import React, { useEffect, useState } from 'react';
import { Play, RotateCcw, BookOpen, HelpCircle } from 'lucide-react';
import { sound } from '../game/audio';

interface TitleScreenProps {
  onStartGame: () => void;
  onContinueGame: () => void;
  hasSaveGame: boolean;
  onOpenCodex: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartGame,
  onContinueGame,
  hasSaveGame,
  onOpenCodex,
}) => {
  const [showControlsModal, setShowControlsModal] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        sound.playSlash();
        if (hasSaveGame) {
          onContinueGame();
        } else {
          onStartGame();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [hasSaveGame, onContinueGame, onStartGame]);

  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-between items-center p-6 md:p-12 overflow-hidden bg-radial from-slate-900 via-[#070b12] to-[#03060a]">
      {/* Parallax pixel bamboo silhouette background decoration */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px]" />

      {/* Atmospheric misty layers */}
      <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-emerald-950/40 via-slate-900/20 to-transparent pointer-events-none" />

      {/* TOP: Subtitle & Heritage kicker */}
      <div className="flex flex-col items-center gap-1 mt-4 z-10 text-center">
        <span className="text-[11px] md:text-xs font-mono uppercase tracking-[0.3em] text-emerald-400 font-semibold">
          HUYỀN THOẠI BIÊN GIỚI ĐÔNG BẮC · LORE CANON
        </span>
      </div>

      {/* CENTER: Bespoke SVG Title Lockup */}
      <div className="flex flex-col items-center z-10 max-w-2xl text-center px-4">
        {/* Inline SVG title graphic */}
        <svg
          className="w-full max-w-lg h-28 md:h-36 drop-shadow-[0_10px_25px_rgba(239,68,68,0.25)]"
          viewBox="0 0 540 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Stylized background scythe slash arc */}
          <path
            d="M 40 100 Q 270 20 500 90"
            stroke="url(#bladeGlow)"
            strokeWidth="3"
            strokeDasharray="6 4"
            className="opacity-70"
          />
          <path
            d="M 80 85 Q 260 30 460 78"
            stroke="#ef4444"
            strokeWidth="1.5"
            className="opacity-50"
          />

          <defs>
            <linearGradient id="titleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f8fafc" />
              <stop offset="50%" stopColor="#e2e8f0" />
              <stop offset="100%" stopColor="#94a3b8" />
            </linearGradient>
            <linearGradient id="subGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ef4444" />
              <stop offset="50%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
            <linearGradient id="bladeGlow" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#ef4444" />
            </linearGradient>
          </defs>

          {/* Main Title: BÌNH LIÊU VƯƠNG */}
          <text
            x="270"
            y="68"
            textAnchor="middle"
            fill="url(#titleGrad)"
            className="font-black text-[42px] md:text-[50px] tracking-wider"
            style={{
              fontFamily: "'Cinzel', serif",
              filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.9))',
            }}
          >
            BÌNH LIÊU VƯƠNG
          </text>

          {/* Subtitle: HUYẾT TRÚC & NGỤC MÔN */}
          <text
            x="270"
            y="102"
            textAnchor="middle"
            fill="url(#subGrad)"
            className="font-extrabold text-[15px] md:text-[18px] tracking-[0.25em]"
            style={{ fontFamily: "'Be Vietnam Pro', sans-serif" }}
          >
            HUYẾT TRÚC & NGỤC MÔN
          </text>
        </svg>

        {/* Canonical lore proverb */}
        <p className="text-xs md:text-sm text-slate-300 italic mt-3 max-w-lg leading-relaxed font-serif">
          “Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người.”
        </p>
        <p className="text-[11px] text-emerald-400/90 font-mono mt-1">
          — Hoàng Minh Bình Khôi · Vua Của Sự Dừng —
        </p>

        {/* ACTION BUTTONS */}
        <div className="flex flex-col sm:flex-row items-center gap-3 mt-8 w-full max-w-sm">
          {hasSaveGame && (
            <button
              onClick={() => {
                sound.playSlash();
                onContinueGame();
              }}
              className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 border border-emerald-400/50"
            >
              <RotateCcw className="w-4 h-4" />
              <span>TIẾP TỤC HÀNH TRÌNH</span>
            </button>
          )}

          <button
            onClick={() => {
              sound.playSlash();
              onStartGame();
            }}
            className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-red-600 via-rose-700 to-amber-700 hover:from-red-500 hover:to-amber-600 text-white font-bold text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 border border-red-400/50"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>{hasSaveGame ? 'CHƠI MỚI' : 'BẮT ĐẦU CHƠI'}</span>
          </button>
        </div>

        {/* Secondary options */}
        <div className="flex flex-wrap justify-center items-center gap-2.5 mt-4 text-xs font-semibold text-slate-400">
          <button
            onClick={() => {
              if (document.fullscreenElement) {
                document.exitFullscreen().catch(() => {});
              } else if (document.documentElement.requestFullscreen) {
                document.documentElement.requestFullscreen().then(() => {
                  if (screen.orientation && 'lock' in screen.orientation) {
                    (screen.orientation as any).lock('landscape').catch(() => {});
                  }
                }).catch(() => {});
              }
            }}
            className="flex items-center gap-1.5 text-sky-300 hover:text-sky-200 py-1.5 px-3 rounded-lg bg-sky-950/60 border border-sky-600/50 shadow"
          >
            <span>⛶ Xoay Ngang Toàn Màn Hình</span>
          </button>

          <button
            onClick={onOpenCodex}
            className="flex items-center gap-1.5 hover:text-amber-300 transition-colors py-1.5 px-3 rounded-lg bg-slate-900/60 border border-slate-700/60"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span>Bách Khoa Toàn Thư</span>
          </button>

          <button
            onClick={() => setShowControlsModal(true)}
            className="flex items-center gap-1.5 hover:text-cyan-300 transition-colors py-1.5 px-3 rounded-lg bg-slate-900/60 border border-slate-700/60"
          >
            <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
            <span>Hướng Dẫn</span>
          </button>
        </div>
      </div>

      {/* BOTTOM: Flat Control-Hint Line */}
      <div className="z-10 text-center flex flex-col items-center gap-1 text-[11px] text-slate-400/80 font-mono">
        <p className="hidden md:block">
          WASD / Phím Mũi Tên: Di Chuyển · J / K: Chém Liềm · W / Space: Nhảy · L / Shift: Lướt Né · U / I: Tuyệt Kỹ · E: Tương Tác
        </p>
        <p className="md:hidden">
          Hỗ trợ cảm ứng toàn diện: Cần xoay trái · Nút nhảy, chém liềm, tuyệt kỹ bên phải
        </p>
      </div>

      {/* Controls Modal */}
      {showControlsModal && (
        <div className="absolute inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-cyan-400" />
              <span>HƯỚNG DẪN ĐIỀU KHIỂN</span>
            </h3>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex justify-between border-b border-slate-800 pb-1.5">
                <span className="font-semibold text-amber-300">Điện thoại / Cảm ứng:</span>
                <span className="text-right">Joystick ảo trái + 6 nút hành động bên phải</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-1.5">
                <span className="font-semibold text-cyan-300">Di chuyển / Chạy:</span>
                <span className="font-mono text-slate-200">A / D hoặc Mũi tên Trái / Phải</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-1.5">
                <span className="font-semibold text-cyan-300">Nhảy / Bật cao:</span>
                <span className="font-mono text-slate-200">W / Mũi tên Lên / Phím Space</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-1.5">
                <span className="font-semibold text-red-400">Chém Liềm Tử Thần:</span>
                <span className="font-mono text-slate-200">J hoặc K (Combo 3 đòn)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-1.5">
                <span className="font-semibold text-teal-300">Lướt né tránh (Dash):</span>
                <span className="font-mono text-slate-200">L hoặc Phím Shift</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-1.5">
                <span className="font-semibold text-sky-400">Tuyệt Kỹ Khe Vằn Trảm:</span>
                <span className="font-mono text-slate-200">Phím U (Sóng liềm tầm xa)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-1.5">
                <span className="font-semibold text-purple-400">Tử Thần Đột Kích:</span>
                <span className="font-mono text-slate-200">Phím I (Lướt trảm tốc sát)</span>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold text-amber-400">Tương tác NPC / Cổng / Bàn thờ:</span>
                <span className="font-mono text-slate-200">Phím E hoặc Enter</span>
              </div>
            </div>

            <button
              onClick={() => setShowControlsModal(false)}
              className="mt-6 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
            >
              ĐÃ HIỂU, ĐÓNG HƯỚNG DẪN
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
