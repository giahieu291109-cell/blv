import React, { useRef, useState } from 'react';
import { GameEngine } from '../game/engine';
import { Sword, Wind, Zap, MessageSquare, ArrowUp, Flame, Scissors, ShieldAlert, Sparkles, Heart } from 'lucide-react';

interface TouchControlsProps {
  engine: GameEngine | null;
  interactivePrompt: string | null;
}

export const TouchControls: React.FC<TouchControlsProps> = ({ engine, interactivePrompt }) => {
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const [isJoystickActive, setIsJoystickActive] = useState(false);
  const joystickTouchIdRef = useRef<number | null>(null);

  // Joystick touch handlers
  const handleJoystickStart = (e: React.PointerEvent) => {
    e.preventDefault();
    joystickTouchIdRef.current = e.pointerId;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsJoystickActive(true);
    updateJoystickPos(e.clientX, e.clientY);
  };

  const handleJoystickMove = (e: React.PointerEvent) => {
    if (!isJoystickActive || e.pointerId !== joystickTouchIdRef.current) return;
    e.preventDefault();
    updateJoystickPos(e.clientX, e.clientY);
  };

  const handleJoystickEnd = (e: React.PointerEvent) => {
    if (e.pointerId !== joystickTouchIdRef.current) return;
    setIsJoystickActive(false);
    setJoystickPos({ x: 0, y: 0 });
    joystickTouchIdRef.current = null;
    if (engine) {
      engine.input.left = false;
      engine.input.right = false;
      engine.input.joystickX = 0;
      engine.input.joystickY = 0;
    }
  };

  const updateJoystickPos = (clientX: number, clientY: number) => {
    if (!joystickBaseRef.current || !engine) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const dist = Math.hypot(dx, dy);
    const maxRadius = rect.width / 2;

    const angle = Math.atan2(dy, dx);
    const clampedDist = Math.min(dist, maxRadius);

    const normX = (Math.cos(angle) * clampedDist) / maxRadius;
    const normY = (Math.sin(angle) * clampedDist) / maxRadius;

    setJoystickPos({
      x: Math.cos(angle) * clampedDist,
      y: Math.sin(angle) * clampedDist,
    });

    engine.input.joystickX = normX;
    engine.input.joystickY = normY;
    engine.input.left = normX < -0.25;
    engine.input.right = normX > 0.25;
  };

  // Action button touch helpers
  const bindAction = (
    actionKey:
      | 'jump'
      | 'attack'
      | 'dash'
      | 'skillDismantle'
      | 'skillCleave'
      | 'skillKamino'
      | 'skillShrine'
      | 'skillWorldSlash'
      | 'skillKamutoke'
      | 'useQuickHeal'
      | 'interact'
      | 'skillHoiQuang'
      | 'tearScroll'
  ) => {
    return {
      onPointerDown: (e: React.PointerEvent) => {
        e.preventDefault();
        if (!engine) return;
        engine.input[actionKey] = true;
        if (actionKey === 'jump') engine.input.justJumped = true;
        if (actionKey === 'attack') engine.input.justAttacked = true;
        if (actionKey === 'dash') engine.input.justDashed = true;
        if (actionKey === 'skillDismantle') engine.input.justSkillDismantle = true;
        if (actionKey === 'skillCleave') engine.input.justSkillCleave = true;
        if (actionKey === 'skillKamino') engine.input.justSkillKamino = true;
        if (actionKey === 'skillShrine') engine.input.justSkillShrine = true;
        if (actionKey === 'skillWorldSlash') engine.input.justSkillWorldSlash = true;
        if (actionKey === 'skillKamutoke') engine.input.justSkillKamutoke = true;
        if (actionKey === 'useQuickHeal') engine.input.justUseQuickHeal = true;
        if (actionKey === 'interact') engine.input.justInteracted = true;
        if (actionKey === 'skillHoiQuang') engine.input.justSkillHoiQuang = true;
        if (actionKey === 'tearScroll') engine.input.justTearScroll = true;
      },
      onPointerUp: (e: React.PointerEvent) => {
        e.preventDefault();
        if (!engine) return;
        engine.input[actionKey] = false;
      },
      onPointerLeave: (e: React.PointerEvent) => {
        e.preventDefault();
        if (!engine) return;
        engine.input[actionKey] = false;
      },
    };
  };

  const isSealed = engine?.stats.isSealedInIce || (engine?.stats.ngucMonTimer ?? 0) > 0;
  const equippedWeapon = engine?.stats.equippedWeapon || 'than_vu_giai';

  // Cooldown timers
  const cdDismantle = engine?.stats.skillCooldowns.dismantle || 0;
  const cdCleave = engine?.stats.skillCooldowns.cleave || 0;
  const cdKamino = engine?.stats.skillCooldowns.kamino || 0;
  const cdShrine = engine?.stats.skillCooldowns.shrine || 0;
  const cdWorldSlash = engine?.stats.skillCooldowns.worldSlash || 0;
  const cdDash = engine?.stats.skillCooldowns.dash || 0;

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex justify-between items-end p-2 md:p-4">
      {/* LEFT: 6-slot Hotbar near joystick + Virtual Joystick */}
      <div className="pointer-events-auto flex flex-col items-start gap-1.5">
        {/* 6-slot Quick Hotbar */}
        <div className="flex items-center gap-1 bg-slate-950/90 border border-amber-500/60 rounded-xl p-1 shadow-2xl backdrop-blur-xs">
          {/* Slot 1: Weapon */}
          <button
            onClick={() => engine?.equipSlotItem(0)}
            className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-amber-950/90 border border-amber-400 text-amber-200 flex flex-col items-center justify-center active:scale-95 shadow transition-all touch-none"
            title="Slot 1: Vũ Khí (Đổi Thần Vũ Giải / Hắc Thiểm / Liềm)"
          >
            <span className="text-xs">
              {equippedWeapon === 'than_vu_giai' ? '⚡' : equippedWeapon === 'nam_dam_hac_thiem' ? '👊' : '🗡️'}
            </span>
            <span className="text-[6px] font-black uppercase text-amber-300">V.KHÍ</span>
          </button>

          {/* Slot 2: Mũ Giáp */}
          <button
            onClick={() => engine?.equipSlotItem(1)}
            className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-slate-900/90 border border-sky-400/80 text-sky-200 flex flex-col items-center justify-center active:scale-95 shadow transition-all touch-none"
            title="Slot 2: Mũ Giáp Thần Vũ"
          >
            <span className="text-xs">👑</span>
            <span className="text-[6px] font-bold text-sky-300">MŨ</span>
          </button>

          {/* Slot 3: Giáp Thân */}
          <button
            onClick={() => engine?.equipSlotItem(2)}
            className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-slate-900/90 border border-sky-400/80 text-sky-200 flex flex-col items-center justify-center active:scale-95 shadow transition-all touch-none"
            title="Slot 3: Giáp Thân Thần Vũ"
          >
            <span className="text-xs">🥋</span>
            <span className="text-[6px] font-bold text-sky-300">THÂN</span>
          </button>

          {/* Slot 4: Giáp Quần */}
          <button
            onClick={() => engine?.equipSlotItem(3)}
            className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-slate-900/90 border border-sky-400/80 text-sky-200 flex flex-col items-center justify-center active:scale-95 shadow transition-all touch-none"
            title="Slot 4: Giáp Quần Chí Tôn"
          >
            <span className="text-xs">👖</span>
            <span className="text-[6px] font-bold text-sky-300">QUẦN</span>
          </button>

          {/* Slot 5: Giáp Chân */}
          <button
            onClick={() => engine?.equipSlotItem(4)}
            className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-slate-900/90 border border-sky-400/80 text-sky-200 flex flex-col items-center justify-center active:scale-95 shadow transition-all touch-none"
            title="Slot 5: Giáp Chân Phong Lôi"
          >
            <span className="text-xs">👢</span>
            <span className="text-[6px] font-bold text-sky-300">CHÂN</span>
          </button>

          {/* Slot 6: Hồi Máu (Đại Hoàn Đan) */}
          <button
            onClick={() => engine?.equipSlotItem(5)}
            className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-emerald-950/90 border border-emerald-400 text-emerald-200 flex flex-col items-center justify-center active:scale-95 shadow transition-all touch-none animate-pulse"
            title="Slot 6: Đại Hoàn Đan (Hồi Máu Cấp Cứu)"
          >
            <Heart className="w-3.5 h-3.5 text-emerald-300" />
            <span className="text-[6px] font-black text-emerald-300">HỒI MÁU</span>
          </button>
        </div>

        {/* Virtual Joystick */}
        <div className="flex flex-col items-center gap-1">
          <div
            ref={joystickBaseRef}
            onPointerDown={handleJoystickStart}
            onPointerMove={handleJoystickMove}
            onPointerUp={handleJoystickEnd}
            onPointerCancel={handleJoystickEnd}
            className="relative w-22 h-22 md:w-26 md:h-26 rounded-full bg-slate-900/70 border border-slate-700/80 backdrop-blur-xs flex items-center justify-center touch-none shadow-xl active:border-cyan-500/80"
          >
            <div className="absolute inset-2 rounded-full border border-dashed border-slate-600/40" />
            <div
              className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-700 border border-cyan-300 shadow-md transform transition-transform duration-75 flex items-center justify-center pointer-events-none"
              style={{
                transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)`,
              }}
            >
              <div className="w-3 h-3 rounded-full bg-white/70" />
            </div>
          </div>
          <span className="text-[8px] uppercase font-bold tracking-wider text-slate-400">Di chuyển</span>
        </div>
      </div>

      {/* CENTER: Floating Interactive Prompt Banner or Break Seal Button */}
      {isSealed ? (
        <div className="pointer-events-auto absolute bottom-20 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-1">
          <button
            {...bindAction('attack')}
            className="px-6 py-2 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 border-2 border-yellow-300 text-white font-black text-xs md:text-sm shadow-2xl animate-bounce active:scale-95 touch-none"
          >
            ⚡ NHẤN LIÊN TỤC ĐỂ PHÁ BĂNG / XÉ TRANH!
          </button>
        </div>
      ) : interactivePrompt ? (
        <div className="pointer-events-auto absolute bottom-20 left-1/2 transform -translate-x-1/2 bg-slate-950/95 border border-amber-500/80 px-3.5 py-1.5 rounded-xl shadow-2xl flex items-center gap-1.5 animate-bounce">
          <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-[10px] font-semibold text-amber-200">{interactivePrompt}</span>
        </div>
      ) : null}

      {/* RIGHT: Sukuna Shrine Skills (Ngự Trù Tử) + Thế Giới Trảm + Primary Controls */}
      <div className="pointer-events-auto flex flex-col items-end gap-1.5">
        {/* Top row: Thuật thức Ngự Trù Tử của Sukuna (Dismantle, Cleave, Kamino, Shrine, World Slash) */}
        <div className="flex items-center gap-1 md:gap-1.5">
          {/* Lãnh địa: Phục Ma Ngự Trù Tử (Malevolent Shrine - 200m Toàn Arc) */}
          <button
            {...bindAction('skillShrine')}
            className="relative w-9 h-9 md:w-11 md:h-11 rounded-full bg-red-950/90 border-2 border-red-500 text-red-100 flex flex-col items-center justify-center shadow-lg active:scale-90 active:bg-red-700 transition-all touch-none animate-pulse overflow-hidden"
            title="Bành trướng Lãnh địa: Phục Ma Ngự Trù Tử (Toàn bộ Arc, ngàn nhát chém)"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-red-300" />
            <span className="text-[6px] font-black text-red-200 tracking-tighter">PHỤC MA</span>
            {cdShrine > 0 && (
              <div className="absolute inset-0 rounded-full bg-black/85 flex items-center justify-center border border-red-500/40 pointer-events-none">
                <span className="text-[8.5px] font-black text-amber-300 font-mono tracking-tighter">{cdShrine.toFixed(1)}s</span>
              </div>
            )}
          </button>

          {/* Nhát chém Cắt Đứt Thế Gian (World-Cutting Slash / Thế Giới Trảm) */}
          <button
            {...bindAction('skillWorldSlash')}
            className="relative w-9 h-9 md:w-11 md:h-11 rounded-full bg-purple-950/90 border-2 border-purple-400 text-purple-100 flex flex-col items-center justify-center shadow-lg active:scale-90 active:bg-purple-700 transition-all touch-none overflow-hidden"
            title="Nhát Chém Cắt Đứt Thế Gian (World Cutting Slash — Phá 100% giáp boss, cắt không gian)"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-300 animate-pulse" />
            <span className="text-[6px] font-black text-purple-200 tracking-tighter">THẾ GIỚI</span>
            {cdWorldSlash > 0 && (
              <div className="absolute inset-0 rounded-full bg-black/85 flex items-center justify-center border border-purple-400/40 pointer-events-none">
                <span className="text-[8.5px] font-black text-purple-300 font-mono tracking-tighter">{cdWorldSlash.toFixed(1)}s</span>
              </div>
            )}
          </button>

          {/* Táo (Kamino / Fuga - Hỏa Diệu) */}
          <button
            {...bindAction('skillKamino')}
            className="relative w-9 h-9 md:w-11 md:h-11 rounded-full bg-amber-950/90 border border-amber-500 text-amber-200 flex flex-col items-center justify-center shadow-lg active:scale-90 active:bg-amber-700 transition-all touch-none overflow-hidden"
            title="Táo (Kamino / Fuga - Mũi tên lửa cực nóng công phá siêu diện rộng)"
          >
            <Flame className="w-3.5 h-3.5 text-amber-300" />
            <span className="text-[6px] font-bold text-amber-200 tracking-tighter">TÁO(FUGA)</span>
            {cdKamino > 0 && (
              <div className="absolute inset-0 rounded-full bg-black/85 flex items-center justify-center border border-amber-500/40 pointer-events-none">
                <span className="text-[8.5px] font-black text-amber-300 font-mono tracking-tighter">{cdKamino.toFixed(1)}s</span>
              </div>
            )}
          </button>

          {/* Bát (Cleave) */}
          <button
            {...bindAction('skillCleave')}
            className="relative w-9 h-9 md:w-11 md:h-11 rounded-full bg-rose-950/85 border border-rose-400 text-rose-200 flex flex-col items-center justify-center shadow-lg active:scale-90 active:bg-rose-600 transition-all touch-none overflow-hidden"
            title="Bát (Cleave - Trảm kích điều chỉnh độ bền cắt thành nhiều mảnh)"
          >
            <Scissors className="w-3.5 h-3.5 text-rose-300" />
            <span className="text-[6px] font-bold text-rose-200 tracking-tighter">BÁT</span>
            {cdCleave > 0 && (
              <div className="absolute inset-0 rounded-full bg-black/85 flex items-center justify-center border border-rose-500/40 pointer-events-none">
                <span className="text-[8.5px] font-black text-rose-300 font-mono tracking-tighter">{cdCleave.toFixed(1)}s</span>
              </div>
            )}
          </button>

          {/* Giải (Dismantle) */}
          <button
            {...bindAction('skillDismantle')}
            className="relative w-9 h-9 md:w-11 md:h-11 rounded-full bg-cyan-950/85 border border-cyan-400 text-cyan-200 flex flex-col items-center justify-center shadow-lg active:scale-90 active:bg-cyan-600 transition-all touch-none overflow-hidden"
            title="Giải (Dismantle - Trảm kích tầm xa)"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-300" />
            <span className="text-[6px] font-bold text-cyan-200 tracking-tighter">GIẢI</span>
            {cdDismantle > 0 && (
              <div className="absolute inset-0 rounded-full bg-black/85 flex items-center justify-center border border-cyan-400/40 pointer-events-none">
                <span className="text-[8.5px] font-black text-cyan-300 font-mono tracking-tighter">{cdDismantle.toFixed(1)}s</span>
              </div>
            )}
          </button>

          {/* Tương tác / E */}
          <button
            {...bindAction('interact')}
            className="relative w-9 h-9 md:w-10 md:h-10 rounded-full bg-slate-900/90 border border-amber-400/80 text-amber-200 flex flex-col items-center justify-center shadow-lg active:scale-90 active:bg-amber-600 transition-all touch-none"
            title="Tương tác NPC / Cổng [E]"
          >
            <MessageSquare className="w-3 h-3 text-amber-300" />
            <span className="text-[6px] font-bold text-amber-300">NÓI/E</span>
          </button>
        </div>

        {/* Bottom row: Dash, Jump (4 lần nhảy), and Primary Attack (Kamutoke / Hắc Thiểm / Liềm) */}
        <div className="flex items-center gap-1.5 md:gap-2">
          {/* Lướt (Dash) */}
          <button
            {...bindAction('dash')}
            className="relative w-11 h-11 md:w-12 md:h-12 rounded-full bg-slate-900/85 border border-teal-500/70 text-teal-200 flex flex-col items-center justify-center shadow-lg active:scale-90 active:bg-teal-600 transition-all touch-none overflow-hidden"
            title="Lướt né [L/Shift]"
          >
            <Wind className="w-3.5 h-3.5 text-teal-300" />
            <span className="text-[7px] font-bold">LƯỚT</span>
            {cdDash > 0 && (
              <div className="absolute inset-0 rounded-full bg-black/85 flex items-center justify-center border border-teal-500/40 pointer-events-none">
                <span className="text-[8.5px] font-black text-teal-300 font-mono tracking-tighter">{cdDash.toFixed(1)}s</span>
              </div>
            )}
          </button>

          {/* Nhảy 4 lần (Quadruple Jump) */}
          <button
            {...bindAction('jump')}
            className="relative w-11 h-11 md:w-13 md:h-13 rounded-full bg-blue-950/90 border border-blue-400/80 text-blue-100 flex flex-col items-center justify-center shadow-xl active:scale-90 active:bg-blue-600 transition-all touch-none"
            title="Nhảy 4 lần [W / Space]"
          >
            <ArrowUp className="w-4 h-4 text-blue-200" />
            <span className="text-[7.5px] font-black">NHẢY x4</span>
          </button>

          {/* PRIMARY ATTACK: DYNAMIC (Thần Vũ Giải / Nắm Đấm Hắc Thiểm / Liềm) */}
          <button
            {...bindAction('attack')}
            className={`relative w-15 h-15 md:w-17 md:h-17 rounded-full border-2 flex flex-col items-center justify-center shadow-2xl active:scale-90 transition-all touch-none ${
              equippedWeapon === 'than_vu_giai'
                ? 'bg-gradient-to-br from-amber-500 via-yellow-600 to-sky-700 border-yellow-300 text-white'
                : equippedWeapon === 'nam_dam_hac_thiem'
                ? 'bg-gradient-to-br from-zinc-950 via-red-950 to-neutral-900 border-red-500 text-red-100 animate-pulse'
                : 'bg-gradient-to-br from-red-600 via-rose-700 to-amber-700 border-red-400 text-white'
            }`}
            title="Tấn công chính (Chạm vào Slot 1 để đổi vũ khí)"
          >
            {equippedWeapon === 'than_vu_giai' ? (
              <>
                <Zap className="w-5 h-5 text-yellow-200 drop-shadow" />
                <span className="text-[7px] font-black tracking-tighter text-yellow-100">THẦN VŨ</span>
              </>
            ) : equippedWeapon === 'nam_dam_hac_thiem' ? (
              <>
                <Sparkles className="w-5 h-5 text-red-400 drop-shadow" />
                <span className="text-[7px] font-black tracking-tighter text-red-200">HẮC THIỂM</span>
              </>
            ) : (
              <>
                <Sword className="w-5 h-5 text-white drop-shadow" />
                <span className="text-[7px] font-black tracking-tighter text-white">LIỀM</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
