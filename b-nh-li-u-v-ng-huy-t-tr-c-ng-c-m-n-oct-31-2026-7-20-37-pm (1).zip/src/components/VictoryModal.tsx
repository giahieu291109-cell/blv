import React from 'react';
import { Award, BookOpen, RotateCcw, Home } from 'lucide-react';
import { sound } from '../game/audio';

interface VictoryModalProps {
  onContinueFreePlay: () => void;
  onOpenCodex: () => void;
  onReturnToTitle: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  onContinueFreePlay,
  onOpenCodex,
  onReturnToTitle,
}) => {
  return (
    <div className="absolute inset-0 z-50 bg-black/90 flex items-center justify-center p-6 backdrop-blur-xs select-none">
      <div className="bg-slate-950 border border-emerald-500/80 rounded-2xl w-full max-w-lg shadow-2xl p-6 text-center space-y-5">
        <div className="w-16 h-16 rounded-full bg-emerald-950/60 border-2 border-emerald-400 mx-auto flex items-center justify-center text-emerald-300 font-black text-2xl shadow-lg">
          <Award className="w-8 h-8" />
        </div>

        <div>
          <span className="text-[10px] font-mono tracking-widest text-emerald-400 uppercase font-bold">
            ĐẠI KẾT CỤC — HOÀN THÀNH TOÀN BỘ 11 ARC (2068)
          </span>
          <h2 className="text-xl md:text-2xl font-black text-slate-100 tracking-wide uppercase mt-1">
            HAI THẰNG CANH CỔNG ĐÓN BÌNH MINH
          </h2>
          <p className="text-xs md:text-sm text-amber-200 mt-2.5 italic font-serif leading-relaxed">
            “Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người.”
          </p>
          <p className="text-xs text-slate-300 mt-2 font-sans leading-relaxed">
            Nhát liềm DỪNG LẠI cách cổ 1 tấc đã hóa giải tâm ma Chu Hiếu Què. 20 đứa trẻ trường mầm non an toàn trở về; linh hồn Tài Dog mỉm cười siêu thoát vào lòng đất mẹ. Trên non cao Bình Liêu năm 2068, tuyết tan, bình minh rạng rỡ, Hoàng Minh Khôi và Lục Triều Dư đứng thẳng canh giữ cổng đình!
          </p>
        </div>

        <div className="flex flex-col gap-2.5 pt-2">
          <button
            onClick={() => {
              sound.playLevelUp();
              onContinueFreePlay();
            }}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all border border-emerald-400/50"
          >
            <RotateCcw className="w-4 h-4" />
            <span>TIẾP TỤC KHÁM PHÁ THẾ GIỚI</span>
          </button>

          <button
            onClick={onOpenCodex}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all border border-slate-700"
          >
            <BookOpen className="w-4 h-4" />
            <span>MỞ BÁCH KHOA TOÀN THƯ CANON</span>
          </button>

          <button
            onClick={onReturnToTitle}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 font-bold text-xs shadow flex items-center justify-center gap-2 active:scale-95 transition-all border border-slate-800"
          >
            <Home className="w-4 h-4" />
            <span>VỀ MÀN HÌNH CHÍNH</span>
          </button>
        </div>
      </div>
    </div>
  );
};
