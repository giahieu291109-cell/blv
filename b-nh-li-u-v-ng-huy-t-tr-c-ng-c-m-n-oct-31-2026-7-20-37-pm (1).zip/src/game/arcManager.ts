/**
 * Arc Story Progression Manager
 * Quản lý và điều phối toàn bộ chuỗi sự kiện của từng Arc.
 * Tách biệt hoàn toàn cốt truyện khỏi gameplay/chiến đấu.
 */

import { ARC_1_DATA, ARC_1_AUDIT_TABLE, ARC_2_DATA, ARC_2_AUDIT_TABLE, ARC_3_DATA, ARC_3_AUDIT_TABLE, ARC_4_DATA, ARC_4_AUDIT_TABLE, ARC_5_DATA, ARC_5_AUDIT_TABLE, ARC_6_DATA, ARC_6_AUDIT_TABLE, ARC_7_DATA, ARC_7_AUDIT_TABLE, ARC_8_DATA, ARC_8_AUDIT_TABLE, ARC_9_DATA, ARC_9_AUDIT_TABLE, ARC_10_DATA, ARC_10_AUDIT_TABLE, ARC_11_DATA, ARC_11_AUDIT_TABLE, ArcAuditEntry } from './arcStoryData';
import { ArcStoryEvent } from './types';
import { sound } from './audio';

export class ArcManager {
  public currentArcNumber: number = 1;
  public events: ArcStoryEvent[];

  constructor() {
    // Clone events from canonical data
    this.events = JSON.parse(JSON.stringify(ARC_1_DATA.events));
    this.loadProgress();
  }

  public getActiveEvent(): ArcStoryEvent | undefined {
    return this.events.find(e => e.status === 'active') || this.events[this.events.length - 1];
  }

  public getAllEvents(): ArcStoryEvent[] {
    return this.events;
  }

  public getEvent(id: string): ArcStoryEvent | undefined {
    return this.events.find(e => e.id === id);
  }

  public isArcCompleted(): boolean {
    return this.events.every(e => e.status === 'completed');
  }

  public getAuditTable(): ArcAuditEntry[] {
    if (this.currentArcNumber === 11) return ARC_11_AUDIT_TABLE;
    if (this.currentArcNumber === 10) return ARC_10_AUDIT_TABLE;
    if (this.currentArcNumber === 9) return ARC_9_AUDIT_TABLE;
    if (this.currentArcNumber === 8) return ARC_8_AUDIT_TABLE;
    if (this.currentArcNumber === 7) return ARC_7_AUDIT_TABLE;
    if (this.currentArcNumber === 6) return ARC_6_AUDIT_TABLE;
    if (this.currentArcNumber === 5) return ARC_5_AUDIT_TABLE;
    if (this.currentArcNumber === 4) return ARC_4_AUDIT_TABLE;
    if (this.currentArcNumber === 3) return ARC_3_AUDIT_TABLE;
    if (this.currentArcNumber === 2) return ARC_2_AUDIT_TABLE;
    return ARC_1_AUDIT_TABLE;
  }

  /**
   * Chuyển sang Arc mới (Arc 1 đến Arc 11)
   */
  public advanceArc(newArcNumber: number) {
    this.currentArcNumber = newArcNumber;
    if (newArcNumber === 11) {
      this.events = JSON.parse(JSON.stringify(ARC_11_DATA.events));
    } else if (newArcNumber === 10) {
      this.events = JSON.parse(JSON.stringify(ARC_10_DATA.events));
    } else if (newArcNumber === 9) {
      this.events = JSON.parse(JSON.stringify(ARC_9_DATA.events));
    } else if (newArcNumber === 8) {
      this.events = JSON.parse(JSON.stringify(ARC_8_DATA.events));
    } else if (newArcNumber === 7) {
      this.events = JSON.parse(JSON.stringify(ARC_7_DATA.events));
    } else if (newArcNumber === 6) {
      this.events = JSON.parse(JSON.stringify(ARC_6_DATA.events));
    } else if (newArcNumber === 5) {
      this.events = JSON.parse(JSON.stringify(ARC_5_DATA.events));
    } else if (newArcNumber === 4) {
      this.events = JSON.parse(JSON.stringify(ARC_4_DATA.events));
    } else if (newArcNumber === 3) {
      this.events = JSON.parse(JSON.stringify(ARC_3_DATA.events));
    } else if (newArcNumber === 2) {
      this.events = JSON.parse(JSON.stringify(ARC_2_DATA.events));
    } else {
      this.events = JSON.parse(JSON.stringify(ARC_1_DATA.events));
    }
    this.saveProgress();
  }

  /**
   * Check if a specific event can be triggered at this zone & state
   */
  public canTriggerEvent(eventId: string, currentZoneId: string): boolean {
    const ev = this.events.find(e => e.id === eventId);
    if (!ev) return false;
    if (ev.status === 'completed') return false;
    if (ev.requiredZoneId && ev.requiredZoneId !== currentZoneId) return false;
    return true;
  }

  /**
   * Advance to next canonical event in sequence
   */
  public advanceEvent(completedEventId: string): ArcStoryEvent | null {
    const idx = this.events.findIndex(e => e.id === completedEventId);
    if (idx !== -1) {
      this.events[idx].status = 'completed';
      if (idx + 1 < this.events.length) {
        this.events[idx + 1].status = 'active';
        this.saveProgress();
        return this.events[idx + 1];
      }
    }
    this.saveProgress();
    return null;
  }

  /**
   * Save story state to local storage
   */
  public saveProgress() {
    try {
      const data = {
        arc: this.currentArcNumber,
        events: this.events.map(e => ({ id: e.id, status: e.status }))
      };
      localStorage.setItem('binh_lieu_vuong_arc_progress', JSON.stringify(data));
    } catch {
      // Ignore write error
    }
  }

  /**
   * Load story state from local storage
   */
  public loadProgress() {
    try {
      const raw = localStorage.getItem('binh_lieu_vuong_arc_progress');
      if (raw) {
        const data = JSON.parse(raw);
        if (data.arc === 11) {
          this.currentArcNumber = 11;
          this.events = JSON.parse(JSON.stringify(ARC_11_DATA.events));
        } else if (data.arc === 10) {
          this.currentArcNumber = 10;
          this.events = JSON.parse(JSON.stringify(ARC_10_DATA.events));
        } else if (data.arc === 9) {
          this.currentArcNumber = 9;
          this.events = JSON.parse(JSON.stringify(ARC_9_DATA.events));
        } else if (data.arc === 8) {
          this.currentArcNumber = 8;
          this.events = JSON.parse(JSON.stringify(ARC_8_DATA.events));
        } else if (data.arc === 7) {
          this.currentArcNumber = 7;
          this.events = JSON.parse(JSON.stringify(ARC_7_DATA.events));
        } else if (data.arc === 6) {
          this.currentArcNumber = 6;
          this.events = JSON.parse(JSON.stringify(ARC_6_DATA.events));
        } else if (data.arc === 5) {
          this.currentArcNumber = 5;
          this.events = JSON.parse(JSON.stringify(ARC_5_DATA.events));
        } else if (data.arc === 4) {
          this.currentArcNumber = 4;
          this.events = JSON.parse(JSON.stringify(ARC_4_DATA.events));
        } else if (data.arc === 3) {
          this.currentArcNumber = 3;
          this.events = JSON.parse(JSON.stringify(ARC_3_DATA.events));
        } else if (data.arc === 2) {
          this.currentArcNumber = 2;
          this.events = JSON.parse(JSON.stringify(ARC_2_DATA.events));
        } else {
          this.currentArcNumber = 1;
          this.events = JSON.parse(JSON.stringify(ARC_1_DATA.events));
        }

        if (data.events && Array.isArray(data.events)) {
          for (const saved of data.events) {
            const ev = this.events.find(e => e.id === saved.id);
            if (ev) {
              ev.status = saved.status;
            }
          }
        }
      }
    } catch {
      // Ignore read error
    }
  }

  public resetProgress() {
    localStorage.removeItem('binh_lieu_vuong_arc_progress');
    this.currentArcNumber = 1;
    this.events = JSON.parse(JSON.stringify(ARC_1_DATA.events));
  }
}

export const arcManager = new ArcManager();
