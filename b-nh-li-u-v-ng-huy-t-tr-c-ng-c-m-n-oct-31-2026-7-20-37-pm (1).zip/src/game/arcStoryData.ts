/**
 * Canonical Story Data for ARC 1: NGUỒN GỐC NHỮNG NGƯỜI GIỮ LÀNG (1970 - 1995)
 * Tách biệt hoàn toàn cốt truyện khỏi logic chiến đấu và vật lý trò chơi.
 * Sourced directly from the official Bình Liêu Vương lore document.
 */

import { ArcStoryEvent, DialogSequence } from './types';

export interface ArcCatalog {
  arcNumber: number;
  title: string;
  timeframe: string;
  mainCharacters: string[];
  corePhilosophy: string;
  summary: string;
  events: ArcStoryEvent[];
}

export const ARC_1_DATA: ArcCatalog = {
  arcNumber: 1,
  title: 'Arc 1: Nguồn Gốc Của Những Người Giữ Làng',
  timeframe: '1970 – 1995',
  mainCharacters: [
    'La Thanh Thọ (Cụ Thọ)',
    'Hoàng Cần (Trúc Thánh)',
    'Hoàng Minh Bình Khôi',
    'La Thanh',
    'Dân bản Tày, Dao Bản Cáu',
    '9 Chiến sĩ tuần tra biên giới Mốc 1305'
  ],
  corePhilosophy: '“Chân cụt thì đi bằng gậy. Mắt mờ thì nhìn bằng lòng. Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người.”',
  summary: 'Hành trình cuộc đời La Thanh Thọ từ đứa trẻ mồ côi nghèo đói tại Bản Cáu, cơ duyên tìm thấy y thư cổ Nam Dược Thần Hiệu 12 tuổi, hy sinh cẳng chân trái tại trận địa bãi mìn Mốc 1305 khi kéo 9 thương binh, trở về dựng lều tre Đình Lục Nà, nhận Gậy Trúc 108 rãnh từ Hoàng Cần và nghi thức khai sinh danh xưng Bình Liêu Vương cho Bình Khôi.',
  events: [
    {
      id: 'A01-E001',
      arcNumber: 1,
      title: 'Đứa Trẻ Mồ Côi Bản Cáu',
      year: '1970 – 1977',
      location: 'Chòi Lá Ven Suối, Bản Cáu, Bình Liêu',
      characters: ['La Thanh Thọ (7 tuổi)', 'Dân bản Tày, Dao Bản Cáu'],
      description: [
        'La Thanh Thọ sinh năm 1970 tại Bản Cáu trong nghèo đói cùng cực.',
        'Lên 7 tuổi, bố mẹ đều mất sớm trong cơn đói rét khắc nghiệt vùng biên giới.',
        'Thọ sống đơn độc trong căn chòi lá rách nát ven suối, nương nhờ từng bát cháo ngô loãng và củ sắn lùi của bà con dân tộc Tày, Dao.',
        'Từ đó, Thọ khắc sâu trong tim lời thề: Lớn lên quyết không để một người dân nào trong bản phải chết tức tưởi vì đói lạnh hay không có thầy bốc thuốc.'
      ],
      verbatimLore: [
        '“Mồ côi từ năm 7 tuổi, sống nhờ cháo ngô và manh áo vá của dân bản Bản Cáu.”',
        '“Chòi lá bên suối gió lùa buốt xương, nhưng tình người giữ ấm đứa trẻ không cha không mẹ.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Bà Mế Bản Cáu',
          text: 'Thọ à, ăn bát cháo ngô nóng này cho qua cơn rét. Bố mẹ mày mất rồi, nhưng cả bản này là người nhà của mày.'
        },
        {
          speaker: 'La Thanh Thọ (7 tuổi)',
          text: 'Cháu cảm ơn mế, cảm ơn bà con. Cháu hứa sau này lớn lên sẽ làm thầy thuốc, giữ cho bản mình ai cũng được sống lành lặn.'
        }
      ],
      objective: 'Tìm lại Chòi Lá Mồ Côi 1977 ven suối Bản Cáu và tiếp nhận Bát Cháo Ngô Nghèo Khó đùm bọc nghĩa tình.',
      status: 'active',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 260, y: 500 },
      rewardXp: 120,
      rewardItemIds: ['item_bat_chao_ngo'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A01-E002',
      arcNumber: 1,
      title: 'Cơ Duyên Y Thư Nam Dược Thần Hiệu',
      year: '1982',
      location: 'Hang Đá Sau Chùa Cổ Nguyệt, Rừng Ngải Cứu',
      characters: ['La Thanh Thọ (12 tuổi)', 'Bé gái Bản Cáu bị rắn lục cắn'],
      description: [
        'Năm 12 tuổi, Thọ đi hái củi gặp cơn giông bão biên giới trút nước, phải trú tạm trong hang đá bí mật sau Chùa Cổ Nguyệt.',
        'Trong hốc đá rêu phong, Thọ nhặt được cuốn y thư cổ rách nát “Nam Dược Thần Hiệu” của Đại danh y Tuệ Tĩnh bị thất lạc.',
        'Không có người chỉ dạy, đêm đêm Thọ thắp đèn dầu tự đánh vần chữ nôm, tự lên rừng nếm rễ cây, lá cỏ để phân biệt dược tính.',
        'Thọ dùng lá ngải dại và củ giải độc thử nghiệm cứu chữa cho heo gà trước, sau đó giã ngải cứu tươi đắp giải nọc rắn lục đuôi đỏ cứu sống một em nhỏ trong bản.',
        'Dân bản từ đó kính trọng gọi cậu bé là “Thầy Lang Rừng Nhỏ Tuổi”.'
      ],
      verbatimLore: [
        '“12 tuổi nhặt được cuốn Nam Dược Thần Hiệu rách sau hang chùa Cổ Nguyệt để tự học bốc thuốc cứu bản.”',
        '“Không có thầy dạy, tự học chữa cho gà, heo rồi chữa cho người.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'La Thanh Thọ (12 tuổi)',
          text: 'Cuốn sách này ghi tên cây ngải cứu, tía tô, lá lốt rừng... Rừng Bình Liêu toàn là thuốc quý! Mình phải học thuộc từng trang rách này.'
        },
        {
          speaker: 'Người Mẹ Trẻ Bản Cáu',
          text: 'Thọ ơi cứu con bé với, nó bị rắn lục đuôi đỏ cắn tím tái cả chân rồi!'
        },
        {
          speaker: 'La Thanh Thọ (12 tuổi)',
          text: 'Mợ giữ chặt cháu, cháu lấy bã ngải cứu rừng tươi với tía tô giã nhỏ đắp hút nọc ngay đây. Đừng sợ, có cháu ở đây thì em không chết được!'
        }
      ],
      objective: 'Tiến vào Hang Bí Mật Sau Chùa Cổ Nguyệt, thu thập dược thảo và tiếp nhận bí kíp Nam Dược Thần Hiệu.',
      status: 'locked',
      requiredZoneId: 'zone_chua_co_nguyet',
      targetCoords: { x: 720, y: 340 },
      rewardXp: 180,
      rewardItemIds: ['item_nam_duoc_than_hieu', 'item_la_ngai_cuu'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A01-E003',
      arcNumber: 1,
      title: 'Hòm Thuốc Dã Chiến Mốc 1305 & Mất Chân Trái',
      year: '1987',
      location: 'Chiến Hào Bão Tuyết Mốc Biên Giới 1305 (Sống Lưng Khủng Long)',
      characters: ['La Thanh Thọ (17 tuổi - Lính cứu thương)', '9 Chiến sĩ tuần tra biên giới bị thương'],
      description: [
        'Năm 17 tuổi, Thọ tình nguyện nhập ngũ biên phòng làm chiến sĩ quân y cứu thương tại chiến hào ranh giới Mốc 1305.',
        'Không cầm súng trường, Thọ chỉ vác duy nhất hòm thuốc dã chiến bằng gỗ thông bọc thép trên lưng, lao xuyên qua làn pháo kích và bão tuyết mù mịt.',
        'Lần lượt băng bó, tiêm thuốc và cõng/kéo 9 đồng đội bị thương nặng kẹt giữa bãi mìn về hầm trú ẩn an toàn.',
        'Khi quay lại kéo người chiến sĩ thứ 9 vượt qua gờ đá ranh giới sắc nhọn, một quả mìn râu tôm phát nổ hất văng Thọ xuống vực tuyết, cẳng chân trái bị đứt lìa.',
        'Thọ tỉnh dậy trong bệnh viện dã chiến, cất chiếc huy chương vào đáy hòm thuốc: “Người sống về được mới là huân chương.”'
      ],
      verbatimLore: [
        '“17 tuổi đi lính biên phòng, kéo 9 thương binh tại mốc 1305, mất chân trái do mìn nổ.”',
        '“Không cầm súng, chỉ vác hòm thuốc chạy sau đội. Kéo 9 người bị thương về.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Chiến sĩ Tuần Tra Mốc 1305',
          text: 'Thọ ơi... đừng ra! Bãi mìn râu tôm dày đặc, pháo đang nã... chạy đi em!'
        },
        {
          speaker: 'La Thanh Thọ (17 tuổi)',
          text: 'Các anh còn thở thì em còn kéo! Một người em cũng không bỏ lại trên tuyết!'
        },
        {
          speaker: 'Bác sĩ Quân Y Dã Chiến',
          text: 'Thọ, cậu đã cứu sống cả 9 chiến sĩ... nhưng chân trái của cậu không giữ lại được nữa rồi.'
        },
        {
          speaker: 'La Thanh Thọ (17 tuổi)',
          text: 'Chân mất thì đi nạng gỗ. 9 mạng người còn sống trở về với mẹ là em mãn nguyện rồi.'
        }
      ],
      objective: 'Vượt qua Bãi Mìn Ranh Giới Mốc 1305 (Chiến Hào 1987), cứu hộ 9 thương binh và thu hồi Hòm Thuốc Dã Chiến.',
      status: 'locked',
      requiredZoneId: 'zone_moc_1305',
      targetCoords: { x: 1400, y: 440 },
      rewardXp: 300,
      rewardItemIds: ['item_hom_thuoc_moc_1305'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A01-E004',
      arcNumber: 1,
      title: 'Lều Tre Đình Lục Nà & Gậy Trúc 108 Rãnh',
      year: '1995',
      location: 'Sân Đình Lục Nà, Bản Cáu',
      characters: ['La Thanh Thọ (Trưởng lão Cụ Thọ 40 tuổi)', 'Hoàng Cần (Trúc Thánh - Chưởng môn Hoàng Môn)'],
      description: [
        'Sau khi xuất ngũ trở về quê hương Bản Cáu với đôi nạng gỗ, Thọ dựng lều tre cạnh Đình Lục Nà: sáng dạy chữ cho con em nghèo, chiều bốc thuốc nam cứu mạng người không lấy một xu tiền.',
        'Trúc Thánh Hoàng Cần khi đó danh chấn giang hồ tìm đến thăm, tận mắt thấy Thọ khuyết tật một chân nhưng tâm sáng như gương, ngày ngày leo đồi hái thuốc cứu cả ngàn sinh linh.',
        'Hoàng Cần xúc động trao cho Thọ cây Gậy Trúc Hoàng Long gia truyền và dặn dò: “Khắc 108 rãnh, mỗi rãnh một mạng người mày cứu. Đủ 108 rãnh, cây gậy này sẽ có linh hồn bảo hộ bản làng.”',
        'Hoàng Cần khẳng định: “Võ chia hai nhánh, một nhánh giữ người, một nhánh bình người. Mày không học võ giết người, nhưng mày là cái gốc sâu nhất của nhánh Giữ.”',
        'Thọ cười đáp lại câu nói bất hủ: “Chân cụt thì đi bằng gậy. Mắt mờ thì nhìn bằng lòng.”'
      ],
      verbatimLore: [
        '“Dựng lều tre bên Đình Lục Nà sáng dạy chữ, chiều bốc thuốc.”',
        '“Gậy trúc khắc 108 rãnh, mỗi rãnh tương ứng một sinh mạng được cứu.”',
        '“Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Cần',
          text: 'Võ chia hai nhánh, một nhánh giữ người, một nhánh bình người. Cả đời tao đập gãy gậy của bao cao thủ, nhưng đứng trước cái lều tre này của mày, tao thấy võ công mình nhỏ bé.'
        },
        {
          speaker: 'Cụ Thọ',
          text: 'Bác Cần quá lời. Tôi chỉ là người lính tàn phế về làng, nhặt cỏ cứu người thôi.'
        },
        {
          speaker: 'Hoàng Cần',
          text: 'Cầm lấy cây gậy trúc này. Mỗi sinh mạng mày cứu, khắc vào đó một rãnh. Khi đủ 108 rãnh, nó sẽ thành thần mộc trấn giữ cõi biên cương này.'
        },
        {
          speaker: 'Cụ Thọ',
          text: 'Chân cụt thì đi bằng gậy. Mắt mờ thì nhìn bằng lòng. Ơn này già xin nhận.'
        }
      ],
      objective: 'Tương tác với Cột Mốc Lều Tre Đình Lục Nà, tiếp nhận truyền thừa Gậy Trúc 108 Rãnh từ Trúc Thánh Hoàng Cần.',
      status: 'locked',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 500, y: 440 },
      rewardXp: 350,
      rewardItemIds: ['item_gay_108_ranh'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A01-E005',
      arcNumber: 1,
      title: 'Nghi Thức Rửa Máu & Khai Sinh Chữ “Bình” Cho Khôi',
      year: 'Thời niên thiếu của Khôi',
      location: 'Trước Giếng Nước Lá Đình Lục Nà',
      characters: ['La Thanh Thọ (72 tuổi)', 'Bình Khôi (17-18 tuổi)', 'La Thanh'],
      description: [
        'Sau đêm giông bão trên nóc chợ Bình Liêu chém gãy gậy Hoàng Cần, Khôi mang theo đôi tay rớm máu và ánh mắt tràn đầy sát khí tìm về Đình Lục Nà.',
        'Cụ Thọ ngồi trầm ngâm bên chậu nước lá tía tô ngải cứu bốc khói nghi ngút. Cụ lấy khăn trắng gấp vuông góc, nhẹ nhàng cầm lấy hai bàn tay Khôi và lau sạch từng vệt máu.',
        'Cụ Thọ dạy: “Mày không giết người. Mày bình người. Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người.”',
        'Khôi hỏi lại bằng giọng nghẹn ngào: “Nếu một ngày con không dừng được thì sao hả Cụ?”',
        'Cụ Thọ mỉm cười đôn hậu: “Thì để thằng Dư nó kéo mày về.”',
        'Cụ Thọ chính thức đặt chữ “Bình” vào tên Khôi: Hoàng Minh Bình Khôi — biểu tượng của sự Dừng Lại, hoàn thành trọn vẹn chương Nguồn Gốc Người Giữ Làng.'
      ],
      verbatimLore: [
        '“Người đã lau vết máu trên tay Khôi và đặt chữ “Bình”: “Mày không giết người. Mày bình người.””',
        '“Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp.”',
        '“Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Bình Khôi',
          text: 'Cụ Thọ... Đêm qua gậy của thầy Cần gãy nát... Con tưởng mình đã giết người rồi.'
        },
        {
          speaker: 'Cụ Thọ',
          text: 'Đưa tay đây. Chậu nước lá tía tô này của con Thanh hái lúc sáng sớm đấy. Để già lau sạch máu cho con.'
        },
        {
          speaker: 'Bình Khôi',
          text: 'Tại sao Cụ không mắng con?'
        },
        {
          speaker: 'Cụ Thọ',
          text: 'Vì mày đã dừng lại được trước khi lưỡi liềm chạm cổ họng ông ấy. Mày không giết người. Mày bình người. Từ hôm nay, tên con là Hoàng Minh Bình Khôi — Bình Liêu Vương.'
        },
        {
          speaker: 'Bình Khôi',
          text: 'Nếu sau này con lạc lối... con không dừng được nữa thì sao?'
        },
        {
          speaker: 'Cụ Thọ',
          text: 'Thì thằng Dư trên vách đá Khe Vằn nó sẽ thả dây cáp kéo mày về. Đi đi con, giữ lấy sự bình yên này.'
        }
      ],
      objective: 'Thực hiện Nghi Thức Rửa Máu Nước Lá Tía Tô trước Đình Lục Nà, tiếp nhận danh hiệu Hoàng Minh Bình Khôi.',
      status: 'locked',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 500, y: 440 },
      rewardXp: 500,
      rewardItemIds: ['item_nuoc_la_tia_to'],
      auditStatus: 'hoàn thành'
    }
  ]
};

/**
 * Bảng đối chiếu độ trung thành Arc 1 (Audit Reference Table)
 */
export interface ArcAuditEntry {
  eventCode: string;
  sourceLoreSummary: string;
  inGameImplementationLocation: string;
  status: 'hoàn thành' | 'chưa hoàn thành' | 'cần làm rõ';
  notes: string;
}

export const ARC_1_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A01-E001',
    sourceLoreSummary: 'La Thanh Thọ mồ côi năm 7 tuổi, sống trong chòi lá ven suối Bản Cáu nhờ cháo ngô và manh áo vá bà con Tày, Dao.',
    inGameImplementationLocation: 'Zone Bản Cáu: Chòi Lá Ven Suối 1977 (`shrine_choi_la_1977`), đối thoại Bà Mế Bản Cáu, vật phẩm Bát Cháo Ngô Đùm Bọc.',
    status: 'hoàn thành',
    notes: 'Tái hiện đầy đủ tuổi thơ cơ cực và căn tính khởi nguyên của Người Giữ Làng.'
  },
  {
    eventCode: 'A01-E002',
    sourceLoreSummary: 'Thọ 12 tuổi tìm thấy y thư cổ Nam Dược Thần Hiệu rách sau hang chùa Cổ Nguyệt, tự nếm lá rừng chữa rắn cắn cứu đứa trẻ trong bản.',
    inGameImplementationLocation: 'Zone Chùa Cổ Nguyệt: Hốc Đá Nam Dược Thần Hiệu (`shrine_hang_nam_duoc`), thu thập Ngải Cứu rừng, nhận Y Thư 12 Tuổi.',
    status: 'hoàn thành',
    notes: 'Toàn bộ chi tiết tự học không thầy, nếm thử rễ cây và cứu bé gái bị rắn lục cắn được thể hiện nguyên văn.'
  },
  {
    eventCode: 'A01-E003',
    sourceLoreSummary: 'Thọ 17 tuổi đi lính quân y biên phòng, vác hòm thuốc dã chiến tại Mốc 1305, kéo 9 thương binh qua bãi mìn, trúng mìn mất chân trái.',
    inGameImplementationLocation: 'Playable Memory Zone Mốc 1305 (`zone_moc_1305`): Chiến hào bão tuyết, bãi mìn râu tôm, 9 thương binh tuần tra biên giới cần sơ cứu.',
    status: 'hoàn thành',
    notes: 'Có bản đồ chiến dịch riêng với sương mù tuyết, bãi mìn phát nổ thực tế, âm thanh pháo tuyết và phần thưởng Hòm Thuốc Dã Chiến Mốc 1305.'
  },
  {
    eventCode: 'A01-E004',
    sourceLoreSummary: 'Thọ 40 tuổi dựng lều tre Đình Lục Nà dạy chữ bốc thuốc; Hoàng Cần trao cây gậy trúc khắc 108 rãnh tương ứng 108 sinh mạng cứu sống.',
    inGameImplementationLocation: 'Zone Bản Cáu: Lều Tre Dạy Chữ Đình Lục Nà (`shrine_leu_tre_dinh_luc_na`), hoạt ảnh hội thoại Hoàng Cần & Cụ Thọ.',
    status: 'hoàn thành',
    notes: 'Câu nói kinh điển “Võ chia hai nhánh, một nhánh giữ người, một nhánh bình người” và “Chân cụt đi bằng gậy, mắt mờ nhìn bằng lòng” giữ nguyên 100%.'
  },
  {
    eventCode: 'A01-E005',
    sourceLoreSummary: 'Cụ Thọ lau vết máu trên tay Khôi bằng nước lá tía tô và đặt tên Hoàng Minh Bình Khôi: “Mày không giết người. Mày bình người.”',
    inGameImplementationLocation: 'Zone Bản Cáu: Giếng Nước Lá Đình Lục Nà (`shrine_rua_mau_binh_khoi`), cắt cảnh rửa máu, mở khóa danh hiệu Bình Liêu Vương.',
    status: 'hoàn thành',
    notes: 'Khai sinh triết lý Dừng Lại và bộ ba Giữ - Bình - Kéo, hoàn tất Arc 1.'
  }
];

export const ARC_1_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a01_e001: {
    id: 'dialog_a01_e001',
    lines: [
      {
        speaker: {
          id: 'me_ban_cau',
          name: 'Bà Mế Bản Cáu',
          title: 'Người nuôi dưỡng',
          color: '#f59e0b',
          avatarId: 'avatar_thanh'
        },
        text: 'Thọ à, vào đây ăn bát cháo ngô nóng cho đỡ đói con ơi. Mùa đông Bình Liêu năm 1977 rét thấu xương, chòi lá của con rách hết cả rồi.'
      },
      {
        speaker: {
          id: 'tho_young',
          name: 'La Thanh Thọ (7 tuổi)',
          title: 'Đứa trẻ mồ côi',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Cháu cảm ơn Mế và bà con trong bản. Bố mẹ cháu mất sớm vì đói và bệnh tật... Cháu thề sau này lớn lên, cháu sẽ làm thầy thuốc giữ cho dân bản mình ai cũng được sống ấm no lành lặn!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi (Hồi Tưởng)',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Thì ra đây là nguồn cội của Cụ Thọ... Căn tính “Người Giữ Làng” đã được ươm mầm từ bát cháo ngô tình nghĩa này.'
      }
    ]
  },

  dialog_a01_e002: {
    id: 'dialog_a01_e002',
    lines: [
      {
        speaker: {
          id: 'tho_12',
          name: 'La Thanh Thọ (12 tuổi)',
          title: 'Thầy Lang Rừng Nhỏ Tuổi',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Trời mưa bão to quá, may mà có hốc đá sau Chùa Cổ Nguyệt để trú... Ơ, trong hốc đá này có cuốn sách cổ bọc trong vỏ cây thông rách nát!'
      },
      {
        speaker: {
          id: 'tho_12',
          name: 'La Thanh Thọ (12 tuổi)',
          title: 'Thầy Lang Rừng Nhỏ Tuổi',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: '“Nam Dược Thần Hiệu”! Từng trang chữ ghi chép về ngải cứu rừng, củ bình vôi, lá tía tô núi. Không có thầy dạy, mình sẽ tự thắp đuốc dầu học, tự nếm từng ngọn cỏ!'
      },
      {
        speaker: {
          id: 'me_be_gai',
          name: 'Dân Bản Cáu',
          title: 'Người mẹ hoảng loạn',
          color: '#f43f5e',
          avatarId: 'avatar_thanh'
        },
        text: 'Thọ ơi cứu con bé với! Nó lên đồi hái nấm bị rắn lục đuôi đỏ cắn tím bầm cả đùi rồi!'
      },
      {
        speaker: {
          id: 'tho_12',
          name: 'La Thanh Thọ (12 tuổi)',
          title: 'Thầy Lang Rừng Nhỏ Tuổi',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Mợ đừng khóc, lấy dây rừng garô lại ngay! Cháu vừa giã búp ngải cứu non và tía tô tươi đây, đắp vào nọc rắn sẽ rút ra. Em bé sẽ sống!'
      }
    ]
  },

  dialog_a01_e003_start: {
    id: 'dialog_a01_e003_start',
    lines: [
      {
        speaker: {
          id: 'chi_huy',
          name: 'Trung Đội Trưởng Mốc 1305',
          title: 'Chỉ huy Biên Phòng 1987',
          color: '#22c55e',
          avatarId: 'avatar_du'
        },
        text: 'Đồng chí Thọ! Đội tuần tra tiền phương bị phục kích trúng bãi mìn râu tôm ở Sống Lưng Khủng Long! Có 9 đồng chí bị thương nặng đang kẹt giữa làn đạn tuyết!'
      },
      {
        speaker: {
          id: 'tho_17',
          name: 'La Thanh Thọ (17 tuổi)',
          title: 'Chiến sĩ Quân Y Cứu Thương',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Báo cáo chỉ huy! Tôi vác hòm thuốc dã chiến lên ngay! Dù chỉ còn một hơi thở, tôi quyết kéo cả 9 đồng đội về hầm an toàn!'
      }
    ]
  },

  dialog_a01_e003_finish: {
    id: 'dialog_a01_e003_finish',
    lines: [
      {
        speaker: {
          id: 'thuong_binh_9',
          name: 'Chiến Sĩ Thứ 9',
          title: 'Được cứu hộ',
          color: '#38bdf8',
          avatarId: 'avatar_du'
        },
        text: 'Thọ ơi... Cẩn thận quả mìn râu tôm dưới gờ đá... ẦM!!!... THỌ ƠI!!!'
      },
      {
        speaker: {
          id: 'bac_si_quan_y',
          name: 'Bác Sĩ Dã Chiến',
          title: 'Trạm Quân Y Tuyến Sau',
          color: '#e2e8f0',
          avatarId: 'avatar_thanh'
        },
        text: 'Thọ... Cậu đã cứu sống trọn vẹn cả 9 đồng đội. Nhưng mìn nổ đã cướp đi cẳng chân trái của cậu rồi. Đây là Huân Chương Chiến Công của cậu.'
      },
      {
        speaker: {
          id: 'tho_17',
          name: 'La Thanh Thọ (17 tuổi)',
          title: 'Người Giữ Mạng',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Cất huân chương vào đáy hòm thuốc dã chiến giùm tôi... Chân tôi mất thì về bản đi nạng gỗ. 9 người đồng đội còn sống trở về với mẹ cha, đó mới là huân chương vô giá.'
      }
    ]
  },

  dialog_a01_e004: {
    id: 'dialog_a01_e004',
    lines: [
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần',
          title: 'Trúc Thánh (Chưởng Môn Hoàng Môn)',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'Thọ! Cả đời ta luyện võ Hoàng Long, thắng 108 cao thủ mà không đổ một giọt mồ hôi. Nhưng hôm nay đứng trước lều tre này, nhìn mày một chân khập khiễng sáng dạy chữ, chiều bốc thuốc cứu ngàn người nghèo... ta thấy hổ thẹn.'
      },
      {
        speaker: {
          id: 'tho_40',
          name: 'Cụ Thọ (40 tuổi)',
          title: 'Thầy Lang Đình Lục Nà',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Bác Cần nói quá. Tôi là người lính tàn phế, giữ được chút hơi thở thì đem giữ lấy nụ cười của dân bản thôi.'
      },
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần',
          title: 'Trúc Thánh',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'Võ chia hai nhánh, một nhánh giữ người, một nhánh bình người. Mày không học một thế võ nào, nhưng chính mày là biểu tượng cao nhất của nhánh “Giữ”. Ta trao cho mày cây Gậy Trúc Hoàng Long này. Mỗi mạng người mày cứu, hãy khắc một rãnh. Đủ 108 rãnh, gậy sẽ có linh hồn.'
      },
      {
        speaker: {
          id: 'tho_40',
          name: 'Cụ Thọ (40 tuổi)',
          title: 'Cụ Thọ',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Chân cụt thì đi bằng gậy. Mắt mờ thì nhìn bằng lòng. Xin nhận cây gậy này để cùng dân bản vượt qua bao giông bão biên thùy.'
      }
    ]
  },

  dialog_a01_e005: {
    id: 'dialog_a01_e005',
    lines: [
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Cụ Thọ... Đêm qua trên nóc chợ Bình Liêu, con chém gãy gậy trúc của thầy Cần... Bàn tay con nhuốm máu... Con sợ sát khí của con sẽ làm hại người lương thiện.'
      },
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Ngồi xuống đây Khôi. Để già nhúng khăn trắng vào chậu nước lá tía tô này, lau sạch từng vết máu trên tay con.'
      },
      {
        speaker: {
          id: 'thanh',
          name: 'La Thanh',
          title: 'Con gái thầy lang',
          color: '#81c784',
          avatarId: 'avatar_thanh'
        },
        text: 'Nước lá tía tô và ngải cứu tao vừa đun xong đấy. Rửa đi Khôi. Người chưa giết người vô tội thì luôn đáng được giữ.'
      },
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Mày không giết người. Mày bình người. Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người. Từ giờ, tên của con là Hoàng Minh Bình Khôi — Bình Liêu Vương.'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Nếu một ngày con trượt chân vào bóng tối... con không dừng lại được thì sao hả Cụ?'
      },
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Thì để thằng Dư trên vách đá Khe Vằn nó quăng dây cáp kéo mày về! Đứng dậy đi con, hoàn thành trọn vẹn bổn phận của Người Giữ Bản!'
      }
    ]
  }
};

/**
 * ============================================================================
 * CANONICAL STORY DATA FOR ARC 2: THẰNG NHÓC BỊ BẮT NẠT (WINTER ARC 1.0)
 * Thời kỳ niên thiếu 12 - 15 tuổi của Hoàng Minh Khôi (2012 - 2015)
 * ============================================================================
 */
export const ARC_2_DATA: ArcCatalog = {
  arcNumber: 2,
  title: 'Arc 2: Thằng Nhóc Bị Bắt Nạt (Winter Arc 1.0)',
  timeframe: '2012 – 2015',
  mainCharacters: [
    'Hoàng Minh Khôi (12 - 15 tuổi)',
    'La Thanh (11 - 14 tuổi)',
    'Đạt "Hổ Mun" (Con nhà võ)',
    'Tú Rỗ & Kiên Sứt (Côn đồ học đường)',
    'Hoàng Cần (Trúc Thánh - Quan sát từ xa)',
    'Cụ Thọ'
  ],
  corePhilosophy: '“Mày nghèo thì người ta giẫm. Mày yếu thì người ta đập. Muốn không bị đập thì phải chém đến khi tay không còn run.”',
  summary: 'Hành trình niên thiếu của Khôi từ khi 12 tuổi bị đám con nhà võ chặn đường đánh gãy mũi ở ngõ cũ Bình Liêu, tự dựng chòi lá ngoại ô rèn luyện 500 nhát liềm mỗi ngày trong giá rét căm căm (Winter Arc 1.0), nhận cơm nguội 5h sáng và nước lá tía tô cứu sốt 40 độ từ La Thanh, đến trận quyết chiến tại chòi lá đánh bại đám bắt nạt và đưa ra quyết định Dừng Lại đầu tiên, mở ra sự chú ý của Trúc Thánh Hoàng Cần cho Arc 3.',
  events: [
    {
      id: 'A02-E001',
      arcNumber: 2,
      title: 'Bị Bắt Nạt Tại Sân Trường & Ngõ Cũ',
      year: '2012 (Khôi 12 tuổi)',
      location: 'Sân Trường Cấp 2 & Ngõ Cũ Khu Trọ Bình Liêu',
      characters: ['Hoàng Minh Khôi (12 tuổi)', 'Đạt "Hổ Mun"', 'Tú Rỗ', 'Kiên Sứt'],
      description: [
        'Khôi sinh ra trong khu trọ nghèo Bình Liêu, bố chạy xe ôm Grab, mẹ bán quán cơm bình dân.',
        'Ở trường, đám con nhà võ cậy thế giàu có dẫn đầu bởi Đạt "Hổ Mun" liên tục chặn đường trấn lột tiền ăn sáng, mỉa mai Khôi là “thằng con tài xế nghèo rách”.',
        'Tại ngõ cũ tan học, Đạt Hổ Mun cùng 2 tên đàn em vây đánh Khôi đến gãy sống mũi, máu chảy ròng ròng xuống áo đồng phục.',
        'Khôi bị đấm ngã nhưng mắt trừng trừng không chịu quỳ xin tha, khắc sâu lời thề: Phải mạnh lên để không bao giờ bị giẫm đạp nữa.'
      ],
      verbatimLore: [
        '“Sinh ra trong khu trọ Bình Liêu, bố chạy Grab, mẹ bán quán cơm. Bị bắt nạt thời niên thiếu.”',
        '“Bị đám con nhà võ đánh gãy mũi, không khóc một giọt nước mắt.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Đạt Hổ Mun',
          text: 'Thằng con xe ôm Grab kia! Tiền ăn trưa đâu? Không nộp bố đấm cho gãy sống mũi bây giờ!'
        },
        {
          speaker: 'Hoàng Minh Khôi (12 tuổi)',
          text: 'Tiền mẹ tao bán cơm chắt chiu... tao không cho đứa nào một xu!'
        },
        {
          speaker: 'Đạt Hổ Mun',
          text: 'Ranh con lì lợm! Tụi bây xông vào đập gãy mũi nó cho tao!'
        }
      ],
      objective: 'Chống đỡ và đánh lui đám Đạt Hổ Mun tại Ngõ Cũ, bảo vệ lòng tự trọng!',
      status: 'active',
      requiredZoneId: 'zone_san_truong_ngo_cu',
      targetCoords: { x: 450, y: 500 },
      rewardXp: 200,
      rewardItemIds: ['item_la_ngai_cuu'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A02-E002',
      arcNumber: 2,
      title: 'Dựng Chòi Lá & 500 Nhát Liềm Khổ Luyện (Winter Arc 1.0)',
      year: '2015 (Khôi 15 tuổi)',
      location: 'Bãi Đất Ngoại Ô Ven Rừng Trúc Bình Liêu',
      characters: ['Hoàng Minh Khôi (15 tuổi)'],
      description: [
        'Lên 15 tuổi, Khôi một mình ra bãi đất hoang ngoại ô ven rừng trúc tự chặt nứa dựng căn chòi lá tạm.',
        'Khôi tự chôn cọc tre làm Mộc Nhân Tre, lấy chiếc liềm cắt cỏ cũ cán gỗ mun của mẹ và bắt đầu kỷ luật thép: Winter Arc 1.0.',
        'Mỗi ngày chém đúng 500 nhát liềm vào thân tre mộc nhân, bất kể mưa rét căm căm hay gió bấc cắt da thịt, chém đến khi cổ tay rớm máu và không còn cảm giác run sợ.'
      ],
      verbatimLore: [
        '“Tự rèn luyện trong chòi lá từ năm 15 tuổi (Winter Arc 1.0).”',
        '“Mỗi ngày chém 500 nhát liềm vào thân tre, chém đến khi nghe được tiếng gió rẽ.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Khôi (15 tuổi)',
          text: 'Mày nghèo thì người ta giẫm. Mày yếu thì người ta đập. Nhát thứ 1... nhát thứ 100... nhát thứ 500! Tay tao sẽ không run nữa!'
        }
      ],
      objective: 'Tiến về Chòi Lá Ngoại Ô, tương tác Mộc Nhân Tre và chém đủ 20 đòn liềm rèn luyện phản xạ!',
      status: 'locked',
      requiredZoneId: 'zone_choi_la_winter',
      targetCoords: { x: 750, y: 460 },
      rewardXp: 300,
      rewardItemIds: ['item_dan_duoc_tang_luc'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A02-E003',
      arcNumber: 2,
      title: 'Cơm Nguội 5H Sáng & Đêm Mưa Sốt 40 Độ',
      year: '2015 (Khôi 15 tuổi)',
      location: 'Chòi Lá Ngoại Ô & Bếp Thuốc La Thanh',
      characters: ['Hoàng Minh Khôi (15 tuổi)', 'La Thanh (14 tuổi)'],
      description: [
        'La Thanh (cháu gái Cụ Thọ) phát hiện Khôi ngày đêm hành xác tại chòi lá.',
        'Suốt 3 tháng ròng mùa đông, mỗi sáng đúng 5h rét buốt, Thanh lặng lẽ mang gói cơm nguội và 2 quả trứng luộc bọc lá chuối để trước hiên chòi lá.',
        'Vào một đêm mưa lũ gầm thét, Khôi kiệt sức sốt cao 40 độ ngất gục ngoài trời bên mộc nhân.',
        'La Thanh trong đêm tối băng rừng tìm tới, cõng Khôi về lều, đun nồi nước lá tía tô ngải cứu xông đắp trán cứu Khôi qua cơn nguy kịch.',
        'Khi Khôi tỉnh dậy rơi nước mắt, Thanh nghiêm giọng: “Khóc xong chưa? Khóc xong thì đi học đi. Mai kiểm tra Toán.”'
      ],
      verbatimLore: [
        '“Suốt 3 tháng ròng, mỗi 5h sáng mang cơm nguội và trứng luộc để trước chòi lá của Khôi.”',
        '“Cõng Khôi về chữa sốt 40 độ trong đêm mưa lũ.”',
        '“Khóc xong chưa? Khóc xong thì đi học đi. Mai kiểm tra Toán.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'La Thanh (14 tuổi)',
          text: 'Khôi! Mày điên à? Mưa rét thế này mà dầm mưa chém liềm đến sốt 40 độ, mê sảng gọi tên mẹ!'
        },
        {
          speaker: 'Hoàng Minh Khôi (15 tuổi)',
          text: 'Thanh... sao mày lại ở đây? Tao... tao không yếu đuối...'
        },
        {
          speaker: 'La Thanh (14 tuổi)',
          text: 'Uống hết bát nước lá tía tô ngải cứu này đi cho hạ sốt! Cơm nguội với trứng luộc tao để ở bàn đấy. Khóc xong chưa? Khóc xong thì đi học đi. Mai kiểm tra Toán.'
        }
      ],
      objective: 'Tương tác với La Thanh tại Chòi Lá, uống Bát Nước Tía Tô giải sốt và ăn Gói Cơm Nguội Trứng Luộc.',
      status: 'locked',
      requiredZoneId: 'zone_choi_la_winter',
      targetCoords: { x: 380, y: 460 },
      rewardXp: 350,
      rewardItemIds: ['item_com_trung', 'item_nuoc_la_tia_to'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A02-E004',
      arcNumber: 2,
      title: 'Trận Chiến Chòi Lá — Quyết Định Dừng Lại',
      year: '2015 (Khôi 15 tuổi)',
      location: 'Cửa Chòi Lá Ngoại Ô Ven Rừng Trúc',
      characters: ['Hoàng Minh Khôi (15 tuổi)', 'Đạt "Hổ Mun"', 'Tú Rỗ & Kiên Sứt', 'Hoàng Cần (Chân Ảnh Quan Sát)'],
      description: [
        'Đạt Hổ Mun hay tin Khôi dựng chòi tập võ, liền dẫn theo đàn em mang gậy gộc kéo đến đòi đập nát chòi lá và bẻ gãy tay Khôi.',
        'Khôi cầm chiếc liềm đã tôi luyện qua ngàn nhát chém bước ra nghênh chiến. Lần đầu tiên, tốc độ liềm của Khôi áp đảo hoàn toàn võ công con nhà tông của Đạt Hổ Mun.',
        'Sau trận kịch chiến, Đạt Hổ Mun ngã quỵ xuống bùn, lưỡi liềm của Khôi quét vụt qua kề sát cổ áo nó chỉ cách 1 xen-ti-mét!',
        'Trong khoảnh khắc sát sinh cận kề, Khôi nhớ lại bát cơm nguội của Thanh và tự mình DỪNG LẠI: “Cút đi. Đừng để tao thấy mặt tụi bây nữa.”',
        'Trúc Thánh Hoàng Cần đứng trên mỏm đá chùa Cổ Nguyệt chứng kiến từ đầu đến cuối, mỉm cười gật đầu: “Thằng nhóc này... chém được mà dừng được. Nó là người thừa kế con đường Bình!” — Mở ra cuộc hẹn quyết đấu trên Nóc Chợ Bình Liêu (Arc 3).'
      ],
      verbatimLore: [
        '“Mạnh nhất là lúc dừng lại được.”',
        '“Đánh bại đám con nhà võ, nhưng hạ liềm sát cổ mà không giết.”',
        '“Hoàng Cần phát hiện ra Khôi từ khoảnh khắc biết dừng liềm.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Đạt Hổ Mun',
          text: 'Mày... mày tập thứ tà thuật gì mà nhanh như ma vậy?! Đừng... đừng giết tao!'
        },
        {
          speaker: 'Hoàng Minh Khôi (15 tuổi)',
          text: 'Tao không giết mày. Tao dừng liềm để mày sống mà nhớ rằng: kẻ yếu không phải để mày giẫm đạp. CÚT!'
        },
        {
          speaker: 'Hoàng Cần (Chân Ảnh)',
          text: 'Chém gãy uy phong kẻ thù, nhưng thu liềm cách cổ áo một sợi tóc... Thằng nhóc này có cái tâm của chữ “Bình”! Ta sẽ đợi nó ở Nóc Chợ Bình Liêu.'
        }
      ],
      objective: 'Đánh bại Boss Đạt Hổ Mun và 2 tên côn đồ, sau đó đưa ra quyết định Dừng Lại tha mạng!',
      status: 'locked',
      requiredZoneId: 'zone_choi_la_winter',
      targetCoords: { x: 500, y: 500 },
      rewardXp: 500,
      rewardItemIds: ['item_liem_tu_than'],
      auditStatus: 'hoàn thành'
    }
  ]
};

/**
 * Bảng đối chiếu độ trung thực Arc 2 (Audit Reference Table)
 */
export const ARC_2_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A02-E001',
    sourceLoreSummary: 'Khôi 12 tuổi con tài xế Grab bị đám con nhà võ Đạt Hổ Mun bắt nạt, đánh gãy mũi tại ngõ cũ khu trọ nhưng không khóc, không quỳ lạy.',
    inGameImplementationLocation: 'Zone Ngõ Cũ & Sân Trường (`zone_san_truong_ngo_cu`): Trận chiến phòng ngự thực tế chống Đạt Hổ Mun, Tú Rỗ, Kiên Sứt.',
    status: 'hoàn thành',
    notes: 'Kẻ địch có AI đấm móc, bao vây xô đẩy; tái hiện chân thực vết sẹo gãy sống mũi định mệnh.'
  },
  {
    eventCode: 'A02-E002',
    sourceLoreSummary: 'Khôi 15 tuổi ra bãi đất hoang dựng chòi lá, chôn mộc nhân tre, cầm liềm cắt cỏ cũ rèn 500 nhát liềm/ngày dưới mưa bão (Winter Arc 1.0).',
    inGameImplementationLocation: 'Zone Chòi Lá Ngoại Ô (`zone_choi_la_winter`): Tương tác Mộc Nhân Tre (`bamboo_dummy_choi`), trực tiếp chém đủ 20 nhát combo thực tế.',
    status: 'hoàn thành',
    notes: 'Có âm thanh va chạm, gỗ tre tóe mảnh vụn và tăng tốc độ chém khi hoàn thành mục tiêu.'
  },
  {
    eventCode: 'A02-E003',
    sourceLoreSummary: 'La Thanh suốt 3 tháng 5h sáng mang cơm nguội trứng luộc; đêm mưa bão Khôi sốt 40 độ được Thanh cõng về đun nước lá tía tô ngải cứu: “Khóc xong chưa? Khóc xong thì đi học đi. Mai kiểm tra Toán.”',
    inGameImplementationLocation: 'Zone Chòi Lá Ngoại Ô: Gói cơm nguội trứng luộc (`lunch_basket_thanh`), Nồi nước lá tía tô hạ sốt (`bed_fever_choi`), đối thoại độc quyền La Thanh.',
    status: 'hoàn thành',
    notes: 'Hồi phục sinh lực và giữ nguyên 100% câu thoại kinh điển đi vào lòng người của La Thanh.'
  },
  {
    eventCode: 'A02-E004',
    sourceLoreSummary: 'Đám Đạt Hổ Mun kéo tới phá chòi lá; Khôi dùng liềm đánh bại cả đám, kề liềm sát cổ áo nhưng tự kiềm chế Dừng Lại; Hoàng Cần quan sát từ xa và quyết định hẹn tái đấu Arc 3.',
    inGameImplementationLocation: 'Zone Chòi Lá Ngoại Ô: Boss fight Đạt Hổ Mun, cơ chế nhấn Dừng Lại tha mạng (`sparing_stone`), Trúc Thánh Hoàng Cần xuất hiện.',
    status: 'hoàn thành',
    notes: 'Đỉnh điểm của triết lý “Mạnh nhất là lúc dừng lại được”, mở khóa truyền thừa sang Arc 3: Trận Thầy Trò trên Nóc Chợ Bình Liêu.'
  }
];

export const ARC_2_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a02_e001: {
    id: 'dialog_a02_e001',
    lines: [
      {
        speaker: {
          id: 'dat_ho_mun',
          name: 'Đạt "Hổ Mun"',
          title: 'Con Nhà Võ',
          color: '#f97316',
          avatarId: 'avatar_du'
        },
        text: 'Thằng Khôi! Bố mày chạy xe ôm cả ngày không đủ tiền mua cho mày đôi dép lành lặn à? Nộp hết tiền ăn trưa ra đây!'
      },
      {
        speaker: {
          id: 'khoi_12',
          name: 'Hoàng Minh Khôi (12 tuổi)',
          title: 'Học sinh nghèo',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Bố tao chạy xe máy dầm mưa dãi nắng kiếm từng đồng sạch sẽ. Tao không cho mày đụng vào một hào!'
      },
      {
        speaker: {
          id: 'dat_ho_mun',
          name: 'Đạt "Hổ Mun"',
          title: 'Con Nhà Võ',
          color: '#f97316',
          avatarId: 'avatar_du'
        },
        text: 'Bố tao dạy võ Hoàng Môn, tao muốn lấy của ai thì lấy! Đấm cho gãy sống mũi nó!'
      }
    ]
  },

  dialog_a02_e002: {
    id: 'dialog_a02_e002',
    lines: [
      {
        speaker: {
          id: 'khoi_15',
          name: 'Hoàng Minh Khôi (15 tuổi)',
          title: 'Winter Arc 1.0',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Chòi lá này là nơi tao thuộc về... Dưới mưa rét, tay tao sẽ chém chiếc liềm này 500 nhát mỗi ngày. Chém đến khi không một ai có thể bắt tao quỳ xuống!'
      }
    ]
  },

  dialog_a02_e003: {
    id: 'dialog_a02_e003',
    lines: [
      {
        speaker: {
          id: 'thanh_14',
          name: 'La Thanh (14 tuổi)',
          title: 'Con gái thầy lang',
          color: '#4ade80',
          avatarId: 'avatar_thanh'
        },
        text: 'Khôi! Mày điên à? Mưa lũ bão bùng thế này mà dầm mưa chém liềm đến sốt 40 độ! Tao phải kéo mày từ bùn vào lều đấy!'
      },
      {
        speaker: {
          id: 'khoi_15',
          name: 'Hoàng Minh Khôi (15 tuổi)',
          title: 'Kiệt sức',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Thanh... ngực tao đau quá... mũi tao nghẹt thở... Tao không muốn làm gánh nặng của bố mẹ nữa...'
      },
      {
        speaker: {
          id: 'thanh_14',
          name: 'La Thanh (14 tuổi)',
          title: 'Con gái thầy lang',
          color: '#4ade80',
          avatarId: 'avatar_thanh'
        },
        text: 'Uống hết bát nước lá tía tô ngải cứu này mau! Gói cơm nguội với 2 quả trứng luộc tao để bên cạnh đấy. Ăn cho no bụng đi.'
      },
      {
        speaker: {
          id: 'thanh_14',
          name: 'La Thanh (14 tuổi)',
          title: 'Con gái thầy lang',
          color: '#4ade80',
          avatarId: 'avatar_thanh'
        },
        text: 'Khóc xong chưa? Khóc xong thì đi học đi. Mai kiểm tra Toán.'
      }
    ]
  },

  dialog_a02_e004_win: {
    id: 'dialog_a02_e004_win',
    lines: [
      {
        speaker: {
          id: 'dat_ho_mun',
          name: 'Đạt "Hổ Mun"',
          title: 'Ngã quỵ',
          color: '#f97316',
          avatarId: 'avatar_du'
        },
        text: 'Đừng... Khôi ơi tha cho tao! Lưỡi liềm mày bén quá... Tao xin mày đừng chém!'
      },
      {
        speaker: {
          id: 'khoi_15',
          name: 'Hoàng Minh Khôi (15 tuổi)',
          title: 'Người Biết Dừng',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Lưỡi liềm của tao chỉ cách cổ áo mày 1 sợi chỉ. Tao có thể chém đứt cổ họng mày, nhưng tao DỪNG LẠI. Bởi vì tao không giống tụi mày. CÚT KHỎI ĐÂY!'
      },
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Chân Ảnh)',
          title: 'Trúc Thánh',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'Võ thuật đạt đến cực hạn không phải là lúc chém đứt được bao nhiêu mạng người, mà là lúc có thể thu liềm dừng lại trong gang tấc! Cậu bé họ Hoàng... ta sẽ đợi con tại Nóc Chợ Bình Liêu trong đêm mưa bão (Arc 3)!'
      }
    ]
  }
};

/**
 * ============================================================================
 * CANONICAL STORY DATA FOR ARC 3: TRẬN THẦY TRÒ — ĐÊM GIẾT THẦY
 * Đêm giông bão Nóc Chợ Bình Liêu (Khôi 17 tuổi, học sinh lớp 12A2 — 2017)
 * ============================================================================
 */
export const ARC_3_DATA: ArcCatalog = {
  arcNumber: 3,
  title: 'Arc 3: Trận Thầy Trò — Đêm Giết Thầy',
  timeframe: 'Đêm giông bão tháng 11/2017 (Khôi 17 tuổi, học sinh lớp 12A2)',
  mainCharacters: [
    'Hoàng Minh Khôi (17 tuổi, học sinh lớp 12A2)',
    'Hoàng Cần (Trúc Thánh — Cựu Chưởng Môn Võ Hoàng Môn)',
    'La Thanh (16 tuổi)',
    'La Thanh Thọ (Cụ Thọ)',
    'Thầy giáo dạy Toán & Bạn học lớp 12A2 trường THPT Bình Liêu'
  ],
  corePhilosophy: '“Võ chia hai nhánh, một nhánh giữ người, một nhánh bình người... Thắng rồi thì phải giữ.”',
  summary: 'Trận chiến võ thuật đỉnh cao trong đêm giông bão sấm sét trên Nóc Chợ Bình Liêu giữa Trúc Thánh Hoàng Cần (nhánh Giữ) và Khôi 17 tuổi (nhánh Bình). Khôi dùng liềm tử thần chém gãy gậy trúc Hoàng Long; Hoàng Cần chủ động nhận lãnh việc bại trận để truyền thừa nhánh Bình và giữ cho môn phái không chia rẽ. Cụ Thọ rửa máu bằng nước lá tía tô, đặt tên Hoàng Minh Bình Khôi; sáng hôm sau Khôi trở về trường cấp 3 ngồi bàn cuối ngủ gật trong tiết Toán 12A2, mở ra Arc 4: Bình Liêu Vương 18 Tuổi.',
  events: [
    {
      id: 'A03-E001',
      arcNumber: 3,
      title: 'Lời Hẹn Ước Nóc Chợ Đêm Giông Bão',
      year: '2017 (Khôi 17 tuổi)',
      location: 'Nóc Chợ Trung Tâm Huyện Bình Liêu (Đêm Mưa To Sấm Sét)',
      characters: ['Hoàng Minh Khôi (17 tuổi)', 'Hoàng Cần (Trúc Thánh)'],
      description: [
        'Đúng hẹn sau 2 năm khổ luyện từ khi dừng liềm ở chòi lá, Khôi 17 tuổi khoác áo mưa rách, dắt liềm sau lưng leo lên Nóc Chợ Bình Liêu lúc nửa đêm.',
        'Trời đổ mưa rào xối xả, sấm chớp rạch ngang trời soi rõ bóng Trúc Thánh Hoàng Cần đứng tựa gậy trúc Hoàng Long trên chóp mái ngói rêu phong.',
        'Hoàng Cần tuyên bố: “Đêm nay, hoặc gậy trúc của ta gãy, hoặc liềm của con gãy. Ai thắng sẽ gánh vác vận mệnh đất Bình Liêu!”'
      ],
      verbatimLore: [
        '“Trận so tài mưa bão trên nóc chợ Bình Liêu.”',
        '“Ai là người thầy, ai là học trò... con đường chia hai nhánh Giữ và Bình.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Cần (Trúc Thánh)',
          text: 'Con đã đến đúng hẹn. Mưa bão đêm nay sẽ rửa sạch mọi nghi ngại. Con cầm liềm, ta cầm gậy trúc... Hãy cho ta thấy toàn bộ bản lĩnh của nhánh Bình!'
        },
        {
          speaker: 'Hoàng Minh Khôi (17 tuổi)',
          text: 'Thầy Cần... Chiếc liềm này rèn từ 500 nhát chém mỗi ngày dưới mưa tuyết. Đêm nay con sẽ không lùi một bước!'
        }
      ],
      objective: 'Tiến lên Nóc Chợ Bình Liêu (`zone_noc_cho_binh_lieu`), đối diện Trúc Thánh Hoàng Cần trong đêm giông bão!',
      status: 'active',
      requiredZoneId: 'zone_noc_cho_binh_lieu',
      targetCoords: { x: 300, y: 380 },
      rewardXp: 300,
      rewardItemIds: ['item_dan_duoc_tang_luc'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A03-E002',
      arcNumber: 3,
      title: 'Trận Chiến Thầy Trò — Hoàng Long Trấn Địa',
      year: '2017 (Khôi 17 tuổi)',
      location: 'Mái Ngói Dốc & Sân Nóc Chợ Bình Liêu',
      characters: ['Hoàng Minh Khôi (17 tuổi)', 'Hoàng Cần (Trúc Thánh - Boss)'],
      description: [
        'Trận quyết đấu bùng nổ giữa sấm chớp: Hoàng Cần thi triển tuyệt kỹ Trúc Thánh “Hoàng Long Trấn Địa”, mỗi cú đập gậy làm nứt toác mái ngói, chấn động đất trời và phóng ra luồng khí kình cuồng nộ.',
        'Khôi vận dụng thân pháp linh hoạt, né tránh đòn roi trúc thần tốc, dùng liềm đỡ đòn khiến tia lửa phát sáng rực rỡ giữa màn đêm mưa bão.',
        'Người chơi trực tiếp điều khiển Khôi chiến đấu với Boss Hoàng Cần, phá vỡ lớp Giáp Trúc Kim Cương và rút cạn sinh lực đối thủ.'
      ],
      verbatimLore: [
        '“40 tuổi thắng 108 cao thủ mà không đổ một giọt mồ hôi.”',
        '“Tuyệt kỹ Hoàng Long Trấn Địa: đập gậy làm nứt sân gạch, rung chuyển trời đất.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Cần (Trúc Thánh)',
          text: 'HOÀNG LONG TRẤN ĐỊA! Gậy trúc của ta uốn cong trước bão, đập tan mọi tà niệm!'
        },
        {
          speaker: 'Hoàng Minh Khôi (17 tuổi)',
          text: 'Lưỡi liềm này không để sát sinh, lưỡi liềm này là để BÌNH ĐỊNH!'
        }
      ],
      objective: 'Chiến đấu thực tế với Boss Hoàng Cần, né tránh Hoàng Long Trấn Địa và phá vỡ thế trận gậy trúc!',
      status: 'locked',
      requiredZoneId: 'zone_noc_cho_binh_lieu',
      targetCoords: { x: 700, y: 380 },
      rewardXp: 450,
      rewardItemIds: ['item_chien_giap_tuyet'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A03-E003',
      arcNumber: 3,
      title: 'Nhát Liềm Định Mệnh — Chém Gãy Gậy Trúc Hoàng Long',
      year: '2017 (Khôi 17 tuổi)',
      location: 'Mái Nóc Chợ Bình Liêu (Thời Khắc Trăng Vỡ)',
      characters: ['Hoàng Minh Khôi (17 tuổi)', 'Hoàng Cần (Trúc Thánh)'],
      description: [
        'Khi sinh lực Hoàng Cần cạn kiệt, giữa tia chớp xé rách bầu trời, Khôi xuất ra đường liềm nhanh nhất cuộc đời: 7 đường trong một chớp mắt!',
        'RẮC!!! Tiếng gãy giòn vang dội: Cây gậy trúc Hoàng Long 108 rãnh trứ danh bị chém đứt làm đôi! Lưỡi liềm của Khôi để lại một vết sứt mẻ nhỏ vĩnh viễn.',
        'Hoàng Cần buông tay lùi lại, mỉm cười thanh thản ngước nhìn trời: “Gậy trúc đã gãy... Ta giữ người đã đủ rồi. Từ nay, con đường Bình thuộc về con.”',
        'Thầy Cần trao lại nửa gậy trúc gãy bọc vải đỏ cho Khôi với lời dặn khắc cốt ghi tâm: “Thắng rồi thì phải giữ.”'
      ],
      verbatimLore: [
        '“Chủ động thua Khôi trong đêm giông bão để truyền thừa nhánh Bình và giữ cho môn phái không chia rẽ.”',
        '“Lưỡi bạc có vết mẻ nhỏ — minh chứng của sự chiến thắng và lòng kiềm giữ.”',
        '“Khôi luôn mang theo nửa gậy trúc gãy bọc vải đỏ bên mình: Thắng rồi thì phải giữ.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Cần (Trúc Thánh)',
          text: 'Gậy trúc gãy rồi... Tốt lắm, Khôi. Ta chủ động đón nhát liềm này của con. Võ Hoàng Môn từ nay không phân tranh nữa. Nửa gậy này con hãy giữ lấy... Thắng rồi thì phải giữ.'
        },
        {
          speaker: 'Hoàng Minh Khôi (17 tuổi)',
          text: 'Thầy Cần! Tay thầy chảy máu rồi... Con không cố ý làm thầy bị thương!'
        },
        {
          speaker: 'Hoàng Cần (Trúc Thánh)',
          text: 'Không sao cả. Một người ngã xuống để cả vùng biên cương này được bình yên. Mau về gặp cụ Thọ ở Chùa Cổ Nguyệt đi con!'
        }
      ],
      objective: 'Tương tác với Nửa Gậy Trúc Gãy trên mái chợ (`broken_bamboo_staff`), tiếp nhận truyền thừa nhánh Bình!',
      status: 'locked',
      requiredZoneId: 'zone_noc_cho_binh_lieu',
      targetCoords: { x: 720, y: 380 },
      rewardXp: 500,
      rewardItemIds: ['item_nua_gay_truc'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A03-E004',
      arcNumber: 3,
      title: 'Nước Lá Tía Tô & Mộ Trúc 7 Cây Chùa Cổ Nguyệt',
      year: '2017 (Khôi 17 tuổi)',
      location: 'Sau Chùa Cổ Nguyệt & Giếng Nước Bản Cáu',
      characters: ['Hoàng Minh Khôi (17 tuổi)', 'Cụ Thọ (La Thanh Thọ)', 'La Thanh (16 tuổi)', 'Hoàng Cần'],
      description: [
        'Khôi ôm nửa gậy trúc gãy bọc vải đỏ chạy về Chùa Cổ Nguyệt trong đêm mưa bão. Bàn tay Khôi rớm máu run rẩy vì vừa hạ gục người thầy vĩ đại.',
        'Cụ Thọ cùng La Thanh đã đợi sẵn bên hiên chùa với chậu nước lá tía tô ngải cứu bốc khói ấm.',
        'Cụ Thọ nhúng khăn trắng lau sạch từng vết máu trên tay Khôi, cất tiếng trầm vang: “Mày không giết người. Mày bình người. Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người. Từ giờ, con là Hoàng Minh Bình Khôi — Bình Liêu Vương!”',
        'Sau chùa, Hoàng Cần lui về ẩn cư, khóm trúc 7 cây mọc lên cạnh tảng đá khắc chữ “Người giữ đường”.'
      ],
      verbatimLore: [
        '“Mộ trúc sau chùa Cổ Nguyệt chỉ có khóm trúc 7 cây và tảng đá Người giữ đường.”',
        '“Người đã lau vết máu trên tay Khôi và đặt chữ Bình: Mày không giết người. Mày bình người.”',
        '“Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Khôi (17 tuổi)',
          text: 'Cụ Thọ... Thanh ơi... Tay tao vừa chém gãy gậy của thầy Cần... Máu và nước mưa dính đầy tay...'
        },
        {
          speaker: 'La Thanh (16 tuổi)',
          text: 'Đưa tay đây tao lau cho. Nước lá tía tô ngải cứu ấm lắm. Thầy Cần không chết, thầy đã thanh thản trao lại gánh nặng cho mày rồi.'
        },
        {
          speaker: 'Cụ Thọ',
          text: 'Mày không giết người. Mày bình người! Đeo nửa gậy trúc này trước ngực, mang danh hiệu Bình Liêu Vương mà bảo vệ bản làng!'
        }
      ],
      objective: 'Tương tác với Mộ Trúc 7 Cây (`mo_truc_7_cay`) sau Chùa Cổ Nguyệt, đón nhận danh xưng Bình Liêu Vương từ Cụ Thọ!',
      status: 'locked',
      requiredZoneId: 'zone_chua_co_nguyet',
      targetCoords: { x: 500, y: 440 },
      rewardXp: 500,
      rewardItemIds: ['item_nuoc_la_tia_to', 'item_la_ngai_cuu'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A03-E005',
      arcNumber: 3,
      title: 'Tiết Toán Lớp 12A2 — Vua Trở Về Đời Thường',
      year: 'Sáng hôm sau, 2017 (Khôi 17 tuổi)',
      location: 'Phòng Học Lớp 12A2 — Trường THPT Bình Liêu',
      characters: ['Hoàng Minh Khôi (17 tuổi)', 'Thầy giáo dạy Toán', 'Bạn học lớp 12A2'],
      description: [
        'Sau một đêm giông bão kinh thiên động địa thay đổi số phận giang hồ biên giới, 7h sáng hôm sau, Khôi khoác chiếc ba lô bạc màu bước vào lớp 12A2 trường THPT Bình Liêu.',
        'Ngoài trời nắng sớm chiếu rọi sườn núi xanh ngát. Trên bục giảng, thầy giáo đang viết phương trình hình học không gian phấn trắng bay mù mịt.',
        'Dưới cổ áo đồng phục trắng học sinh, Khôi giấu kín sợi dây chuyền bạc treo mảnh gậy trúc gãy bọc vải đỏ.',
        'Khôi gục đầu xuống mặt bàn gỗ ngủ gật vì kiệt sức sau trận chiến. Bạn học bên cạnh huých tay: “Khôi! Dậy đi, thầy Toán gọi mày lên bảng giải câu 3 kìa!”.',
        'Vị vua trẻ tuổi giật mình tỉnh dậy, chớp mắt cười ngượng ngùng bước lên bục giảng — Kết thúc Arc 3, mở ra cánh cửa Arc 4: Bình Liêu Vương 18 Tuổi — Vua Của Sự Dừng!'
      ],
      verbatimLore: [
        '“Sáng hôm sau Khôi ngủ gật trong tiết Toán 12A2.”',
        '“Ban đêm là vua của sự dừng, ban ngày là cậu học trò cấp 3 nghèo ngồi bàn cuối.”',
        '“Dây chuyền bạc đeo mảnh gậy trúc gãy.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Bạn Học Lớp 12A2',
          text: 'Ê Khôi! Mày thức trắng đêm qua chơi game hay sao mà mắt thâm quầng thế? Thầy Toán đang liếc mày kìa, mau dậy đi!'
        },
        {
          speaker: 'Thầy Giáo Dạy Toán',
          text: 'Hoàng Minh Khôi! Lên bảng tính thể tích khối chóp tứ giác đều cho tôi. Đi học mà cứ như vừa gánh cả thế giới trên vai thế à?'
        },
        {
          speaker: 'Hoàng Minh Khôi (17 tuổi)',
          text: 'Dạ... em lên ngay ạ! (Khôi mỉm cười sờ nhẹ mảnh gậy trúc gãy dưới ngực áo. Biên giới đã bình yên, bài toán này em giải được!)'
        }
      ],
      objective: 'Tương tác Bàn Học Bàn Cuối Lớp 12A2 (`math_desk_12a2`), trải nghiệm khoảnh khắc học trò ngủ gật và kích hoạt Arc 4!',
      status: 'locked',
      requiredZoneId: 'zone_lop_hoc_12a2',
      targetCoords: { x: 340, y: 460 },
      rewardXp: 600,
      rewardItemIds: ['item_so_tay_toan_12a2'],
      auditStatus: 'hoàn thành'
    }
  ]
};

/**
 * Bảng đối chiếu độ trung thực Arc 3 (Audit Reference Table)
 */
export const ARC_3_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A03-E001',
    sourceLoreSummary: 'Khôi 17 tuổi hẹn ước với Trúc Thánh Hoàng Cần lúc nửa đêm trên nóc chợ Bình Liêu trong cơn giông bão sấm sét mù trời.',
    inGameImplementationLocation: 'Zone Nóc Chợ Bình Liêu (`zone_noc_cho_binh_lieu`): Mái ngói rêu phong dốc đứng, mưa to sấm chớp, chạm mặt Trúc Thánh.',
    status: 'hoàn thành',
    notes: 'Tái hiện chân thực không gian đêm giông bão, hiệu ứng mưa xối xả và tiếng sấm rền vang.'
  },
  {
    eventCode: 'A03-E002',
    sourceLoreSummary: 'Trận so tài đỉnh cao: Hoàng Cần thi triển Hoàng Long Trấn Địa đập gậy nứt toác mái ngói rung chuyển trời đất; Khôi né đòn và phản công bằng liềm tốc độ cao.',
    inGameImplementationLocation: 'Zone Nóc Chợ Bình Liêu: Boss fight Hoàng Cần, AI tung Hoàng Long Trấn Địa tạo sóng xung kích AoE, Trúc Phong Trảm và lướt thân pháp bão.',
    status: 'hoàn thành',
    notes: 'Trận đánh boss thời gian thực, có thanh HP & Giáp Trúc Thánh, đòi hỏi người chơi né đòn và phản xạ chính xác.'
  },
  {
    eventCode: 'A03-E003',
    sourceLoreSummary: 'Khôi chém gãy gậy trúc Hoàng Long làm đôi, lưỡi liềm sứt một vết nhỏ; Hoàng Cần chủ động nhận thua để truyền thừa nhánh Bình: “Thắng rồi thì phải giữ”.',
    inGameImplementationLocation: 'Zone Nóc Chợ Bình Liêu: Cắt cảnh chém gãy gậy trúc khi Boss cạn máu, vật thể Nửa Gậy Trúc Gãy (`broken_bamboo_staff`), nhận di vật nửa gậy bọc vải đỏ.',
    status: 'hoàn thành',
    notes: 'Bảo tồn 100% chi tiết vết mẻ nhỏ trên lưỡi liềm và nửa gậy trúc bọc vải đỏ mang theo suốt cuộc đời Khôi.'
  },
  {
    eventCode: 'A03-E004',
    sourceLoreSummary: 'Cụ Thọ lau sạch vết máu bằng nước lá tía tô ngải cứu, khai sinh tên gọi Hoàng Minh Bình Khôi; Hoàng Cần lui về sau chùa Cổ Nguyệt với khóm trúc 7 cây và tảng đá Người giữ đường.',
    inGameImplementationLocation: 'Zone Chùa Cổ Nguyệt (`zone_chua_co_nguyet`): Mộ Trúc 7 Cây (`mo_truc_7_cay`), đối thoại rửa máu cùng Cụ Thọ và La Thanh.',
    status: 'hoàn thành',
    notes: 'Khắc ghi câu triết lý bất hủ: “Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người.”'
  },
  {
    eventCode: 'A03-E005',
    sourceLoreSummary: 'Sáng hôm sau Khôi mang ba lô đến trường THPT Bình Liêu, ngồi bàn cuối ngủ gật trong tiết Toán 12A2 với sợi dây chuyền treo mảnh gậy trúc gãy.',
    inGameImplementationLocation: 'Zone Phòng Học Lớp 12A2 (`zone_lop_hoc_12a2`): Bàn học cuối lớp (`math_desk_12a2`), bảng đen bài toán hình học, thầy giáo gọi lên bảng.',
    status: 'hoàn thành',
    notes: 'Khoảnh khắc tương phản tuyệt đẹp giữa Vị Vua của thế giới ngầm và Cậu Học Sinh cấp 3 đời thường; mở ra Arc 4.'
  }
];

export const ARC_3_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a03_e001: {
    id: 'dialog_a03_e001',
    lines: [
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Trúc Thánh)',
          title: 'Cựu Chưởng Môn Võ Hoàng Môn',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'Khôi! Con đã leo lên được đến nóc chợ này... Giông bão đêm nay là định mệnh của hai ta. Gậy trúc của ta uốn lượn bảo bọc người, chiếc liềm của con sắc bén bình định kẻ dữ.'
      },
      {
        speaker: {
          id: 'khoi_17',
          name: 'Hoàng Minh Khôi (17 tuổi)',
          title: 'Học sinh lớp 12A2',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Thầy Cần... Con biết ơn thầy đã chỉ dạy và dõi theo con suốt 2 năm qua. Nhưng nếu đêm nay con không vượt qua thầy, con sẽ không thể bảo vệ được Bản Cáu và người dân biên giới!'
      },
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Trúc Thánh)',
          title: 'Trúc Thánh',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'Tốt lắm! Rút liềm ra đi! Đêm nay hãy dốc toàn lực, đừng nương tay với lão già này!'
      }
    ]
  },

  dialog_a03_e002: {
    id: 'dialog_a03_e002',
    lines: [
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Trúc Thánh)',
          title: 'Trúc Thánh',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'HOÀNG LONG TRẤN ĐỊA! Gậy trúc 108 rãnh — Đập tan phong ba bão táp!'
      }
    ]
  },

  dialog_a03_e003: {
    id: 'dialog_a03_e003',
    lines: [
      {
        speaker: {
          id: 'khoi_17',
          name: 'Hoàng Minh Khôi (17 tuổi)',
          title: 'Bình Khôi',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'RẮC... Gậy trúc gãy rồi... Thầy Cần, tay thầy...!'
      },
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Trúc Thánh)',
          title: 'Trúc Thánh Mỉm Cười',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'Đừng hốt hoảng Khôi. Nhát liềm của con nhanh như ánh chớp, nhưng lúc chém trúng gậy, con đã tự hãm lực lại để không chém vào tay ta... Ta đã không nhìn lầm con.'
      },
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Trúc Thánh)',
          title: 'Truyền Thừa Nhánh Bình',
          color: '#10b981',
          avatarId: 'avatar_can'
        },
        text: 'Cầm lấy nửa gậy trúc này, bọc vải đỏ đeo trước ngực. Nhớ lấy lời ta: “Thắng rồi thì phải giữ”. Môn phái Võ Hoàng Môn từ nay ta giao lại cho con đường Bình của con. Về gặp Cụ Thọ đi!'
      }
    ]
  },

  dialog_a03_e004: {
    id: 'dialog_a03_e004',
    lines: [
      {
        speaker: {
          id: 'khoi_17',
          name: 'Hoàng Minh Khôi (17 tuổi)',
          title: 'Bình Khôi',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cụ Thọ... Thanh ơi... Con vừa chém gãy gậy của thầy Cần trên nóc chợ... Máu và nước mưa dính đầy tay con...'
      },
      {
        speaker: {
          id: 'thanh_16',
          name: 'La Thanh (16 tuổi)',
          title: 'Con gái thầy lang',
          color: '#4ade80',
          avatarId: 'avatar_thanh'
        },
        text: 'Đưa tay đây tao lau cho. Nước lá tía tô ngải cứu ấm lắm. Thầy Cần đã an lòng lui về sau chùa rồi, thầy dặn tao nấu nước thuốc đợi mày về đấy.'
      },
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng Lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Mày không giết người. Mày bình người! Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người. Từ giờ phút này, tên của con là HOÀNG MINH BÌNH KHÔI — BÌNH LIÊU VƯƠNG!'
      }
    ]
  },

  dialog_a03_e005: {
    id: 'dialog_a03_e005',
    lines: [
      {
        speaker: {
          id: 'ban_hoc_toan',
          name: 'Bạn Cùng Bàn 12A2',
          title: 'Học sinh trường huyện',
          color: '#facc15',
          avatarId: 'avatar_tai'
        },
        text: 'Khôi! Dậy đi mày, ngủ gục từ đầu tiết đến giờ rồi! Thầy giáo đang nhìn kìa, hôm nay kiểm tra 1 tiết Hình học không gian đấy!'
      },
      {
        speaker: {
          id: 'thay_toan',
          name: 'Thầy Giáo Dạy Toán',
          title: 'Giáo viên THPT Bình Liêu',
          color: '#94a3b8',
          avatarId: 'avatar_can'
        },
        text: 'Hoàng Minh Khôi! Đứng dậy lên bảng giải câu 3 hình chóp cho tôi! Đi học mà mặt mày phờ phạc như vừa đánh giặc xong thế à?'
      },
      {
        speaker: {
          id: 'khoi_17',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (17 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Dạ... thưa thầy em lên ngay ạ! (Khôi mỉm cười, chạm tay vào mảnh gậy trúc bọc vải đỏ giấu dưới áo đồng phục. Đêm qua bão tố đã qua, hôm nay biên giới đã bình yên!)'
      }
    ]
  }
};

/**
 * Canonical Story Data for ARC 4: BÌNH LIÊU VƯƠNG 18 TUỔI (2018)
 * Sourced directly from the official Bình Liêu Vương lore document.
 */
export const ARC_4_DATA: ArcCatalog = {
  arcNumber: 4,
  title: 'Arc 4: Bình Liêu Vương 18 Tuổi (Trật Tự Biên Giới & Chữ DỪNG)',
  timeframe: '2018',
  mainCharacters: [
    'Hoàng Minh Bình Khôi (18 tuổi)',
    'Chu Mạnh Hiếu (Chu Hiếu Què 16 tuổi)',
    'Thầy Huỳnh (Thầy thể dục cấp 2 của Hiếu)',
    'Lục Triều Dư (Thằng Treo Dây mốc 1088)',
    'La Thanh Thọ (Cụ Thọ)',
    'La Thanh (Con gái thầy lang)'
  ],
  corePhilosophy: '“Mạnh nhất là lúc dừng lại được. Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp. Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người. Dư kéo người.”',
  summary: 'Năm 2018, Khôi 18 tuổi chính thức tiếp nhận vai trò Bình Liêu Vương, khoác áo tactical đen bạc vai, cầm liềm tử thần cai quản trật tự biên cương. Chặn đứng các toán giang hồ tại Mốc 1088 bằng chữ DỪNG; đón tiếp Thầy Huỳnh dẫn thiếu niên Chu Hiếu Què 16 tuổi xuống Bản Cáu bái sư; trải qua trận so tài 7 đêm tại sân Đình Lục Nà cảm hóa Chu Hiếu Què bằng cơm nguội và chữ DỪNG; kề vai cùng Lục Triều Dư rèn dây cáp tại vách đá Khe Vằn; và tiếp nhận Cuộn Tranh Chưa Giao chuẩn bị khởi hành sang Tokyo mở ra biến cố Winter Shibuya Incident (2028).',
  events: [
    {
      id: 'A04-E001',
      arcNumber: 4,
      title: 'Tuần Tra Mốc 1088 & Chữ "DỪNG" Tuổi 18',
      year: '2018',
      location: 'Mốc Biên Cương 1088, Bình Liêu',
      characters: ['Hoàng Minh Bình Khôi (18 tuổi)', 'Toán Giang Hồ Biên Giới'],
      description: [
        'Khôi tròn 18 tuổi, thân hình rắn rỏi, giác quan nhạy bén nghe được tiếng muỗi cách 3 mét.',
        'Áo khoác tactical đen bạc vai, dây chuyền bạc nửa gậy trúc, túi áo luôn có khăn trắng lau liềm gấp vuông góc.',
        'Một toán giang hồ buôn lậu định tràn qua biên giới lúc chạng vạng. Khôi đứng trên mỏm đá Mốc 1088 rút liềm tử thần.',
        'Khôi hạ vũ khí của từng tên nhưng không lấy một mạng người, dùng chữ DỪNG đẩy lùi toàn bộ đám giang hồ bảo vệ bình yên cho các bản làng.'
      ],
      verbatimLore: [
        '“Mạnh nhất là lúc dừng lại được.”',
        '“Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Tên Cầm Đầu Buôn Lậu',
          text: 'Thằng nhóc con kia! Tránh đường cho tao qua Mốc 1088! Cầm cây liềm làm nông mà dám chắn lối giang hồ à?'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (18 tuổi)',
          text: 'Tao là Bình Liêu Vương. Đất này dưới chân cụ Thọ, trên đầu có ngọn núi Cao Xiêm. Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp!'
        }
      ],
      objective: 'Tiến lên đỉnh Mốc Biên Cương 1088, đánh bại 4 tên giang hồ biên giới và tương tác Mốc Đá 1088 (`moc_da_1088`) để khẳng định chữ DỪNG!',
      status: 'active',
      requiredZoneId: 'zone_moc_bien_cuong_1088',
      targetCoords: { x: 800, y: 440 },
      rewardXp: 400,
      rewardItemIds: ['item_khan_trang_lau_liem'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A04-E002',
      arcNumber: 4,
      title: 'Thầy Huỳnh Dẫn "Chu Hiếu Què" Xuống Bản Cáu',
      year: '2018',
      location: 'Sân Đình Lục Nà, Bản Cáu',
      characters: ['Thầy Huỳnh', 'Chu Mạnh Hiếu (16 tuổi)', 'Cụ Thọ', 'Hoàng Minh Bình Khôi (18 tuổi)'],
      description: [
        'Thầy Huỳnh — thầy giáo thể dục bụng bia chạy 100m 11s — đưa học trò cưng Chu Mạnh Hiếu từ Móng Cái xuống Bản Cáu.',
        'Hiếu 16 tuổi, chân phải ngắn hơn 2cm, đi khập khiễng, mặc áo sát nách thầy Huỳnh cho, tay có vết sẹo tia sét do Nữ Thánh Rắn cứu sống thời nhỏ.',
        'Cụ Thọ nhìn Hiếu rồi nói câu định mệnh: “Mày vừa điên vừa què, nhưng tâm không què. Đi theo ta.”',
        'Hiếu nhìn thấy Khôi mang liềm tử thần bên hông liền nổi máu hiếu thắng, đòi so tài tay không.'
      ],
      verbatimLore: [
        '“Thầy Huỳnh từng bảo: Mày què mà chạy nhanh hơn cả tao, sau này làm anh hùng đi. Hiếu ghi nhớ cả đời.”',
        '“Cụ Thọ nhìn Hiếu rồi nói: Mày vừa điên vừa què, nhưng tâm không què. Đi theo ta.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Thầy Huỳnh',
          text: 'Báo cáo cụ Thọ! Thằng Hiếu này mồ côi, nghèo đói liếm cả rỉ sắt, nhưng nó chạy nhanh và gan dạ lắm. Con dắt nó xuống nhờ cụ và anh Khôi uốn nắn giúp!'
        },
        {
          speaker: 'Chu Mạnh Hiếu (16 tuổi)',
          text: 'Anh kia là Bình Liêu Vương đấy à? Nhìn cũng thường thôi! Em đứng một chân tập trên cột điện suốt 5 năm, đấm gãy xương đấy!'
        },
        {
          speaker: 'Cụ Thọ',
          text: 'Mày vừa điên vừa què, nhưng tâm không què. Muốn so tài thì ra sân đình. Nhưng nhớ lấy: võ để giữ người, không phải để đập người.'
        }
      ],
      objective: 'Tương tác Thầy Huỳnh và Chu Hiếu Què tại Sân Đình Lục Nà (`npc_thay_huynh`), mở màn trận so tài 7 đêm!',
      status: 'locked',
      requiredZoneId: 'zone_san_dinh_luc_na',
      targetCoords: { x: 620, y: 460 },
      rewardXp: 450,
      rewardItemIds: ['item_ao_sat_nach_thay_huynh'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A04-E003',
      arcNumber: 4,
      title: 'Trận So Tài 7 Đêm Tại Sân Đình (Khôi vs Chu Hiếu Què)',
      year: '2018',
      location: 'Sàn Đấu Sân Đình Lục Nà',
      characters: ['Hoàng Minh Bình Khôi (18 tuổi)', 'Chu Mạnh Hiếu (Lôi Ảnh Thủ)'],
      description: [
        'Hiếu Què cởi áo để lộ sẹo tia sét, đứng trụ một chân thi triển Lôi Ảnh Thủ sấm sét cực kỳ hung hãn.',
        'Khôi và Hiếu so tài ròng rã 7 đêm trên sân đình và nóc chợ.',
        'Khôi dùng sống liềm và thân pháp chữ DỪNG chặn đứng mọi nắm đấm của Hiếu mà không làm tổn thương chân khuyết tật của cậu.',
        'Đêm thứ 7, hai đứa ngồi bệt dưới gốc đa ăn cơm nguội trứng luộc của La Thanh. Hiếu tâm sự chuyện tuổi thơ nghèo đói bị bắt nạt, Khôi mỉm cười đồng cảm.'
      ],
      verbatimLore: [
        '“Đứng một chân đấm gãy xương. Cái gì không giết được tao thì làm tao mạnh hơn!”',
        '“Hai đứa đánh 7 đêm, rồi Hiếu kể hết mấy chuyện xấu hổ cấp 1. Khôi chỉ cười: Tao cũng từng liếm chân sau khi chạy 10km. Bình thường.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Chu Mạnh Hiếu (16 tuổi)',
          text: 'Lôi Ảnh Thủ! Đứng một chân đấm gãy xương! Em không tin không đấm trúng anh một cái!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (18 tuổi)',
          text: 'Đấm trúng thì sao? Mạnh nhất là lúc dừng lại được. Đêm thứ 7 rồi, ngồi xuống ăn bát cơm nguội trứng luộc với tao.'
        },
        {
          speaker: 'Chu Mạnh Hiếu (16 tuổi)',
          text: 'Anh Khôi... Hồi nhỏ đói quá em từng liếm rỉ sắt, liếm mồ hôi chân sau khi đá bóng... ai cũng cười chê em...'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (18 tuổi)',
          text: 'Tao cũng từng liếm chân sau khi chạy 10km rừng Lục Nà. Bình thường. Cái gì không giết được mình thì làm mình mạnh hơn. Từ nay mày là em tao, ở lại đây học thuốc với cụ Thọ.'
        }
      ],
      objective: 'Giao đấu thực tế cùng Boss Chu Hiếu Què (Lôi Ảnh Thủ) tại Sân Đấu Đình Lục Nà, đánh cho Hiếu tâm phục khẩu phục và tương tác Sàn Đấu 7 Đêm (`san_dau_7_dem`)!',
      status: 'locked',
      requiredZoneId: 'zone_san_dinh_luc_na',
      targetCoords: { x: 740, y: 460 },
      rewardXp: 600,
      rewardItemIds: ['item_com_trung'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A04-E004',
      arcNumber: 4,
      title: 'Vách Đá Thác Khe Vằn & Thằng Treo Dây Lục Triều Dư',
      year: '2018',
      location: 'Vách Đá Thác Khe Vằn (Mốc 1088)',
      characters: ['Hoàng Minh Bình Khôi (18 tuổi)', 'Lục Triều Dư (Thằng Treo Dây)'],
      description: [
        'Lục Triều Dư — người Nùng, cựu đặc công biên phòng mốc 1088 gãy 3 đốt sống lưng — treo mình rèn cơ trên dây cáp thép giữa 2 vách đá thác Khe Vằn.',
        'Dư là hiện thân của phe “Kéo”: không phân tranh Giữ hay Bình, hễ ai chìm xuống vực sâu thì dùng roi cáp kéo lên.',
        'Khôi leo lên vách đá cheo leo thử thách sức chịu đựng cùng Dư. Dư kiểm chứng nhát liềm và sự kiềm chế của Bình Liêu Vương.',
        'Dư trao cho Khôi sự tin cậy tuyệt đối: “Giết xong thì về. Ngồi lại ở cổng. Tao canh cho.”'
      ],
      verbatimLore: [
        '“Đại diện cho phe Kéo: không phân tranh Giữ hay Bình, hễ thấy ai chìm xuống vực sâu thì dùng dây kéo lên.”',
        '“Giết xong thì về. Ngồi lại ở cổng. Tao canh cho.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: 'Khôi! Lên đây đu dây với tao! Lưng tao gãy 3 đốt sống còn treo được giữa nghìn roi nước thác, người gánh chữ Bình như mày có dám leo lên không?'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (18 tuổi)',
          text: 'Anh Dư! Dây cáp của anh giữ mạng người vùng biên này bao năm nay rồi. Bình Liêu Vương có anh bọc lót phía sau thì không bao giờ sợ ngã.'
        }
      ],
      objective: 'Đến Vách Đá Thác Khe Vằn, tương tác Dây Cáp Thép Treo Vách Đá (`day_cap_khe_van`) và vượt qua thử thách đu dây cùng Lục Triều Dư!',
      status: 'locked',
      requiredZoneId: 'zone_thac_khe_van',
      targetCoords: { x: 1120, y: 260 },
      rewardXp: 500,
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A04-E005',
      arcNumber: 4,
      title: 'Nhận Mệnh "Cuộn Tranh Chưa Giao" — Khởi Hành Đi Shibuya',
      year: '2018 – 2028',
      location: 'Bàn Thờ Cổ Bản Cáu & Cổng Đình Lục Nà',
      characters: ['Cụ Thọ', 'La Thanh', 'Hoàng Minh Bình Khôi (18 tuổi)'],
      description: [
        'Một phong thư khẩn cấp và bảo vật “Cuộn Tranh Chưa Giao” được chuyển đến Bản Cáu. Tranh chứa phong ấn cổ xưa cần hộ tống sang Tokyo (Ngã tư Shibuya 109) để trấn áp dị biến tuyết trắng.',
        'Cụ Thọ trao thêm bát nước lá tía tô và căn dặn Khôi: “Cuộn tranh này chưa giao, mày chưa được phép ngã.”',
        'La Thanh buộc dải chỉ đỏ ngải cứu lên tay Khôi: “Đi xong thì về Bản Cáu nhé. Tao canh chòi lá đợi mày.”',
        'Khôi khoác ba lô chứa nửa gậy trúc bọc vải đỏ, giắt liềm tử thần sau lưng, bước chân lên chuyến xe rời Bình Liêu — hướng về mùa đông tuyết trắng Tokyo 2028 (Winter Shibuya Incident)!'
      ],
      verbatimLore: [
        '“Tao chưa giao được tranh, nên chưa được phép ngã.”',
        '“Tuyết chôn tên, Cửa chôn người. Mày chọn đi, Khôi.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Cụ Thọ',
          text: 'Khôi à, tuổi 18 của con đã giữ trọn vẹn bình yên cho Bình Liêu. Nhưng vận mệnh lớn hơn đang đợi ở phương Bắc tuyết trắng. Cầm lấy Cuộn Tranh Chưa Giao này đi!'
        },
        {
          speaker: 'La Thanh',
          text: 'Khôi! Nhớ lời tao dặn: Cứu người trước, giết người sau. Sang đất Nhật tuyết lạnh lắm, nhớ ăn bánh mì nóng và đừng để bị đóng băng đấy!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (18 tuổi)',
          text: 'Cháu hiểu rồi cụ Thọ. Thanh ơi, tao đi rồi tao sẽ về. Chừng nào cuộn tranh chưa giao xong, tao nhất định không ngã xuống!'
        }
      ],
      objective: 'Tương tác Bàn Nhận Cuộn Tranh Chưa Giao (`cuon_tranh_altar`) tại Bản Cáu, nhận bảo vật và kích hoạt chuyển giao sang Arc 5: Winter Shibuya Incident!',
      status: 'locked',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 1400, y: 500 },
      rewardXp: 1000,
      rewardItemIds: ['item_cuon_tranh_chua_giao'],
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_4_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A04-E001',
    sourceLoreSummary: 'Khôi 18 tuổi cai quản trật tự biên cương bằng chữ DỪNG, tuần tra Mốc 1088, chặn đứng các toán giang hồ bằng câu nói: “Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp.”',
    inGameImplementationLocation: 'Zone Mốc Biên Cương 1088 (`zone_moc_bien_cuong_1088`): Cột mốc đá 1088, gió rít, toán giang hồ `bien_gioi_thug`.',
    status: 'hoàn thành',
    notes: 'Khắc họa trọn vẹn phong thái Bình Liêu Vương tuổi 18: áo tactical đen bạc vai, dây chuyền nửa gậy trúc, chữ DỪNG dập tắt bạo lực.'
  },
  {
    eventCode: 'A04-E002',
    sourceLoreSummary: 'Thầy Huỳnh (người lùn bụng bia chạy 100m 11s) đưa Chu Mạnh Hiếu 16 tuổi (Hiếu Què) xuống Bản Cáu gặp Cụ Thọ; Cụ Thọ nhận xét: “Mày vừa điên vừa què, nhưng tâm không què. Đi theo ta.”',
    inGameImplementationLocation: 'Zone Sân Đình Lục Nà (`zone_san_dinh_luc_na`): NPC Thầy Huỳnh (`npc_thay_huynh`), Chu Hiếu Què 16 tuổi mặc áo sát nách thầy Huỳnh cho.',
    status: 'hoàn thành',
    notes: 'Giữ nguyên 100% bối cảnh gốc: áo sát nách thầy Huỳnh, sẹo tia sét do Nữ Thánh Rắn cứu mạng thời nhỏ.'
  },
  {
    eventCode: 'A04-E003',
    sourceLoreSummary: 'Hiếu Què cởi trần đứng một chân Lôi Ảnh Thủ so tài Khôi 7 đêm tại sân đình và nóc chợ; kết thúc bằng việc ngồi ăn cơm nguội, tâm sự chuyện liếm rỉ sắt và liếm mồ hôi chân sau khi đá bóng.',
    inGameImplementationLocation: 'Zone Sân Đình Lục Nà: Boss battle Chu Hiếu Què (Lôi Ảnh Thủ), sàn đấu 7 đêm (`san_dau_7_dem`), chia sẻ cơm nguội trứng luộc.',
    status: 'hoàn thành',
    notes: 'Trận so tài đỉnh cao thời niên thiếu giúp Hiếu kính phục Khôi như anh ruột, tạo nên nút thắt bi kịch sâu sắc khi Hiếu sa ngã sau này.'
  },
  {
    eventCode: 'A04-E004',
    sourceLoreSummary: 'Lục Triều Dư (Thằng Treo Dây, cựu đặc công mốc 1088 gãy 3 đốt sống) đu mình trên dây cáp thép giữa 2 vách đá thác Khe Vằn rèn cơ lưng; đại diện phe “Kéo”.',
    inGameImplementationLocation: 'Zone Thác Khe Vằn (`zone_thac_khe_van`): Dây Cáp Thép Treo Vách Đá (`day_cap_khe_van`), NPC Lục Triều Dư rèn thân pháp.',
    status: 'hoàn thành',
    notes: 'Tái hiện không gian thác nước hùng vĩ và triết lý phe Kéo: cứu vớt những người đang chìm xuống vực sâu.'
  },
  {
    eventCode: 'A04-E005',
    sourceLoreSummary: 'Cụ Thọ trao Cuộn Tranh Chưa Giao cho Khôi; La Thanh dặn dò; Khôi 18 tuổi rời Bình Liêu hướng về Nhật Bản, chuẩn bị cho thảm kịch Winter Shibuya Incident (2028).',
    inGameImplementationLocation: 'Zone Bản Cáu (`zone_ban_cau`): Bàn nhận Cuộn Tranh Chưa Giao (`cuon_tranh_altar`), nhận thánh vật và chuyển giao Arc 5.',
    status: 'hoàn thành',
    notes: 'Nối kết hoàn hảo với hệ thống kỹ năng Tuyết Phủ 109, Cuộn Tranh Chưa Giao và Ngục Môn Cương ở Shibuya.'
  }
];

export const ARC_4_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a04_e001: {
    id: 'dialog_a04_e001',
    lines: [
      {
        speaker: {
          id: 'thug_boss',
          name: 'Toán Giang Hồ Mốc 1088',
          title: 'Kẻ Buôn Lậu Vùng Biên',
          color: '#f87171',
          avatarId: 'avatar_dat'
        },
        text: 'Thằng nhóc con kia! Mày chặn đường ở cột mốc 1088 này làm gì? Lưỡi liềm sắt rỉ của mày đòi ngăn được xe hàng của tụi tao à?'
      },
      {
        speaker: {
          id: 'khoi_18',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (18 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tao là Bình Liêu Vương. Đất này dưới chân cụ Thọ, trên đầu có tổ tiên người Tày, Dao gìn giữ. Tao đếm đến ba: Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp!'
      }
    ]
  },

  dialog_a04_e002: {
    id: 'dialog_a04_e002',
    lines: [
      {
        speaker: {
          id: 'thay_huynh',
          name: 'Thầy Huỳnh',
          title: 'Thầy Thể Dục Bụng Bia (Móng Cái)',
          color: '#fbbf24',
          avatarId: 'avatar_can'
        },
        text: 'Báo cáo cụ Thọ, chào anh Bình Khôi! Tôi là Huỳnh, dạy thể dục ở Móng Cái. Tôi chạy 100m mất 11 giây, nhưng thằng nhóc Hiếu què này chạy còn nhanh hơn tôi! Nó cởi áo cân 3 lớp, đánh thắng cả lũ bắt nạt!'
      },
      {
        speaker: {
          id: 'hieu_16',
          name: 'Chu Mạnh Hiếu (16 tuổi)',
          title: 'Chu Hiếu Què (Lôi Ảnh Thủ)',
          color: '#34d399',
          avatarId: 'avatar_tai'
        },
        text: 'Thầy Huỳnh nói em què mà chạy nhanh, sau này làm anh hùng! Em luyện đứng một chân trên cột điện 5 năm rồi! Anh Khôi ơi, ra sân đình đánh với em 7 đêm xem ai mạnh hơn!'
      },
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng Lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Mày vừa điên vừa què, nhưng tâm không què. Đi theo ta vào đình học chữ và bốc thuốc. Còn Khôi, con nhận lời so tài đi, dạy thằng bé hiểu thế nào là chữ DỪNG.'
      }
    ]
  },

  dialog_a04_e003: {
    id: 'dialog_a04_e003',
    lines: [
      {
        speaker: {
          id: 'hieu_16',
          name: 'Chu Mạnh Hiếu (16 tuổi)',
          title: 'Thở Dốc Sau 7 Đêm',
          color: '#34d399',
          avatarId: 'avatar_tai'
        },
        text: 'Hộc... hộc... Đánh suốt 7 đêm mà liềm của anh chặn hết đòn Lôi Ảnh Thủ của em... Anh không đánh gãy chân em một lần nào cả...'
      },
      {
        speaker: {
          id: 'khoi_18',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (18 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Chân mày để chạy, không phải để gãy. Cơm nguội trứng luộc của Thanh mang tới đây, ăn đi cho ấm bụng.'
      },
      {
        speaker: {
          id: 'hieu_16',
          name: 'Chu Mạnh Hiếu (16 tuổi)',
          title: 'Rưng Rưng Nước Mắt',
          color: '#34d399',
          avatarId: 'avatar_tai'
        },
        text: 'Anh Khôi... Cấp 1 em nghèo đói quá, liếm rỉ sắt trên xích cổng trường, bạn bè gọi em là thằng ăn rỉ chim... Đá bóng về em liếm mồ hôi chân vì tiếc muối... Em xấu hổ lắm...'
      },
      {
        speaker: {
          id: 'khoi_18',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Mỉm Cười Vỗ Vai Hiếu',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tao cũng từng liếm mồ hôi chân sau khi chạy 10km rừng Lục Nà. Bình thường. Cái gì không giết được mình thì làm mình mạnh hơn. Từ nay mày là em tao, ở lại đây học thuốc với cụ Thọ.'
      }
    ]
  },

  dialog_a04_e004: {
    id: 'dialog_a04_e004',
    lines: [
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây (Phe Kéo)',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! Lên đến mỏm đá Khe Vằn rồi đấy à? Nhìn nghìn roi nước đập vào đá xem. Hoàng Cần chọn “Giữ”, mày chọn “Bình”, còn tao chọn “Kéo”. Thằng nào sắp rơi xuống vực, tao giật cáp kéo nó lên!'
      },
      {
        speaker: {
          id: 'khoi_18',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (18 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cảm ơn anh Dư. Ở biên giới này có anh canh vách đá, có thầy lang giữ đình, em mới an tâm vững bước.'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây (Phe Kéo)',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Giết xong thì về. Ngồi lại ở cổng. Tao canh cho.'
      }
    ]
  },

  dialog_a04_e005: {
    id: 'dialog_a04_e005',
    lines: [
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng Lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Khôi à, 18 tuổi rồi. Biên cương Bình Liêu đã vững như bàn thạch. Nhưng vết nứt tuyết trắng ở phương Bắc xa xôi đang cần con mang Cuộn Tranh Chưa Giao này sang Tokyo giao cho người giữ ngục môn.'
      },
      {
        speaker: {
          id: 'thanh',
          name: 'La Thanh',
          title: 'Con Gái Thầy Lang',
          color: '#4ade80',
          avatarId: 'avatar_thanh'
        },
        text: 'Khôi! Nhớ lời tao dặn: Đi học đi, thi xong rồi hẵng đi. Sang bên Shibuya tuyết rơi dày lắm, nhớ gói kỹ nửa gậy trúc bọc vải đỏ trước ngực. Giao tranh xong là phải về ngay đấy!'
      },
      {
        speaker: {
          id: 'khoi_18',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (Khởi Hành Đi Shibuya)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cháu ghi lòng tạc dạ lời cụ Thọ và Thanh. “Tao chưa giao được tranh, nên chưa được phép ngã.” Tokyo hay Shibuya, Bình Liêu Vương đi rồi sẽ trở về!'
      }
    ]
  }
};

/**
 * ============================================================================
 * ARC 5: WINTER SHIBUYA INCIDENT (2028) — BĂNG DƯỚI ĐÈN NEON
 * ============================================================================
 * Thời kỳ Khôi 20 tuổi mang Cuộn Tranh Chưa Giao sang Tokyo đêm 25/12/2028.
 * Đánh bại 12 đao thủ Huyết Trúc trong 7 phút không sát sinh, cứu người tị nạn,
 * nhận biệt danh "Khe Vằn Tử Thần" và quay về Thác Khe Vằn rèn luyện (Arc 6).
 */
export const ARC_5_DATA: ArcCatalog = {
  arcNumber: 5,
  title: 'Arc 5: Winter Shibuya Incident (2028)',
  timeframe: '2028 (Ngã Tư Shibuya 109 & Cầu Vượt Tokyo)',
  mainCharacters: [
    'Hoàng Minh Bình Khôi (20 tuổi)',
    'Đinh Quốc Tuấn (Chú Linh quét tuyết)',
    'Ông Táy (Chú Linh bánh mì lò than 24/7)',
    'Hùng Đỏ (Chú Linh áo khoác đỏ)',
    'Thủ Lĩnh Huyết Trúc Tokyo',
    'Con tin người Việt lánh nạn tại Shibuya'
  ],
  corePhilosophy: '“Tuyết rơi phủ hết. Nhưng vết máu này… tao không lau. Tao chưa giao được tranh, nên chưa được phép ngã.”',
  summary: 'Biến cố Shibuya tuyết trắng đêm 25/12/2028: Khôi mang Cuộn Tranh Chưa Giao sang Tokyo, được Ba Chú Linh tiếp tế, đánh gục toán đao thủ trên Cầu Vượt bằng bảng neon gãy và tước vũ khí Thủ Lĩnh Huyết Trúc giải cứu con tin.',
  events: [
    {
      id: 'A05-E001',
      arcNumber: 5,
      title: 'Ngã Tư Shibuya 109 — Tuyết Trắng & Tiếng Còi 3:17AM',
      year: '2028',
      location: 'Ngã Tư Shibuya 109, Tokyo (Đêm 25/12)',
      characters: ['Hoàng Minh Bình Khôi (20 tuổi)'],
      description: [
        'Khôi 20 tuổi khoác áo tactical đen bạc vai, ngực đeo dây chuyền nửa gậy trúc gãy bọc vải đỏ, tay mang Liềm Tử Thần và ba lô chứa Cuộn Tranh Chưa Giao.',
        'Đêm giáng sinh 25/12/2028, bão tuyết bất thường chôn vùi toàn bộ ngã tư Shibuya 109 trong tuyết trắng lạnh buốt, đèn neon thành phố chập chờn mất điện.',
        'Tiếng còi xe cứu thương lúc 3 giờ 17 phút sáng xé rách màn đêm. Băng Huyết Trúc phản đồ lợi dụng tuyết lạnh đang lùng sục bắt cóc người vô tội và đồng hương tị nạn.',
        'Khôi tiếp cận hiện trường Xe Cứu Thương 3:17 AM ven đường, đứng vững trước gió tuyết khẳng định bản lĩnh Bình Liêu Vương.'
      ],
      verbatimLore: [
        '“Tuyết rơi không ngừng, phố đèn neon mất điện và tiếng còi xe cứu thương 3:17 sáng.”',
        '“Tuyết rơi phủ hết. Nhưng vết máu này… tao không lau.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Bình Khôi (20 tuổi)',
          text: 'Shibuya... Tuyết trắng rơi dày như vôi bột. Tiếng còi xe cứu thương 3:17 sáng... Băng Huyết Trúc đang lộng hành. Cuộn tranh này chưa giao, ta chưa được phép ngã.'
        }
      ],
      objective: 'Tiến vào Ngã Tư Shibuya 109, tiếp cận hiện trường Xe Cứu Thương 3:17AM (`xe_cuu_thuong_317`) để nắm bắt tình hình bạo loạn của băng Huyết Trúc!',
      status: 'active',
      requiredZoneId: 'zone_shibuya_crosswalk_109',
      targetCoords: { x: 960, y: 440 },
      rewardXp: 400,
      rewardItemIds: ['item_banh_mi_ong_tay'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A05-E002',
      arcNumber: 5,
      title: 'Ba Chú Linh Tokyo — Bánh Mì Lò Than & Xe Quét Muối',
      year: '2028',
      location: 'Góc Phố Đi Bộ Shibuya 109',
      characters: ['Đinh Quốc Tuấn (Kẻ Vác Cán Quét)', 'Ông Táy (Bán Bánh Mì 24/7)', 'Hùng Đỏ (Giang Hồ Áo Đỏ)', 'Hoàng Minh Bình Khôi'],
      description: [
        'Khôi hội ngộ 3 người bảo hộ thầm lặng của cộng đồng người yếu thế tại Tokyo:',
        '1. Đinh Quốc Tuấn (60 tuổi) vác cán quét rải muối chống đóng băng, giữ đường sinh tử cho dân lánh nạn.',
        '2. Ông Táy giữ xe bánh mì lò than nóng 24/7 bốc khói ấm, phân phát bánh mì nóng giúp người dân chống hạ thân nhiệt.',
        '3. Hùng Đỏ khoác áo đỏ neon xông pha thu hút hỏa lực và đỡ đòn cho con tin.',
        'Khôi tiếp nhận hơi ấm từ bánh mì lò than và rải muối tan băng, thấu hiểu tấm lòng bảo bọc đồng bào nơi đất khách quê người.'
      ],
      verbatimLore: [
        '“Đinh Quốc Tuấn quét. Ông Táy giữ lửa. Hùng Đỏ đỡ đạn. Khôi mới có đường sống đến bình minh.”',
        '“Tuấn quét đường muối, Táy giữ lò than, Hùng Đỏ đỡ đạn.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Đinh Quốc Tuấn',
          text: 'Thằng nhóc áo tactical kia! Đứng yên trong tuyết lạnh lắm, lấy muối xoa vào tay cho tan băng đi! Băng Huyết Trúc đang lùng sục dồn người lên cầu vượt!'
        },
        {
          speaker: 'Ông Táy',
          text: 'Ăn ổ bánh mì nóng từ lò than của già đi cháu. Giữ lấy hơi ấm mà chiến đấu, đừng để cái lạnh Tokyo nuốt chửng linh hồn mày!'
        },
        {
          speaker: 'Hùng Đỏ',
          text: 'Anh Khôi! Lũ phản đồ Huyết Trúc đang dồn đồng hương lên Cầu Vượt Shibuya! Cầm liềm đi, tao bọc lót phía sau đỡ đạn cho mày!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (20 tuổi)',
          text: 'Cảm ơn ba chú. Đồng hương ta nơi xứ người, một cọng tóc cũng không để lũ phản đồ đụng tới!'
        }
      ],
      objective: 'Tương tác Xe Bánh Mì Lò Than (`xe_banh_mi_ong_tay`) và Đống Muối Tuyết (`dong_muoi_dinh_quoc_tuan`), tiếp nhận tiếp tế của Ba Chú Linh trước khi lên cầu vượt!',
      status: 'locked',
      requiredZoneId: 'zone_shibuya_crosswalk_109',
      targetCoords: { x: 550, y: 440 },
      rewardXp: 450,
      rewardItemIds: ['item_banh_mi_ong_tay', 'item_lo_than_ong_tay'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A05-E003',
      arcNumber: 5,
      title: 'Trận Chiến Cầu Vượt Đêm 25/12 — Băng Dưới Đèn Neon',
      year: '2028',
      location: 'Cầu Vượt Shibuya (Đêm 25/12, 3:17AM)',
      characters: ['Hoàng Minh Bình Khôi (20 tuổi)', 'Băng Đao Thủ Huyết Trúc Tokyo'],
      description: [
        'Khôi tiến lên Cầu Vượt Shibuya nơi bão tuyết gào thét. Băng Huyết Trúc Tokyo dàn trận chặn đường đòi tàn sát con tin.',
        'Khôi kích hoạt cơ chế [Bảng Neon Gãy] tạo chớp sáng mù địch 1.5s, nhận buff 40% tốc đánh, đồng thời đứng vững trong tuyết kích hoạt [Tuyết Phủ 109 - Băng Giáp].',
        'Vận dụng tốc độ liềm 7 đường/giây và triết lý chữ BÌNH, Khôi đánh bại toàn bộ toán đao thủ Huyết Trúc trong 7 phút mà không cướp đi một sinh mạng nào.'
      ],
      verbatimLore: [
        '“Đứng càng lâu càng lạnh, nhưng lạnh thì không ai đọc được mắt mày.”',
        '“Bẻ bảng neon rơi tạo vùng sáng 5m, địch bị Mù 1.5s, Khôi tăng 40% tốc đánh.”',
        '“Đánh bại 12 tên trong 7 phút không sát sinh; nhận biệt danh Khe Vằn Tử Thần.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Toán Đao Thủ Huyết Trúc',
          text: 'Thằng nhóc từ Bình Liêu sang đây tìm chết à? Cầu vượt Shibuya này là địa bàn của Huyết Trúc! Băm vát nó ra!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (20 tuổi)',
          text: 'Liềm của tao không chém người vô tội. Bảng neon gãy soi sáng đường về cho đồng bào tao. DỪNG TAY LẠI!'
        }
      ],
      objective: 'Lên Cầu Vượt Shibuya, tương tác Bảng Neon Gãy (`bang_neon_gay_109`), kích hoạt Tuyết Phủ 109 và đánh gục 6 tên đao thủ Huyết Trúc Tokyo!',
      status: 'locked',
      requiredZoneId: 'zone_cau_vuot_shibuya_midnight',
      targetCoords: { x: 780, y: 440 },
      rewardXp: 650,
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A05-E004',
      arcNumber: 5,
      title: 'Đại Chiến Thủ Lĩnh Huyết Trúc & Tuyết Trắng Chôn Tên',
      year: '2028',
      location: 'Đài Quan Sát Cầu Vượt Shibuya',
      characters: ['Hoàng Minh Bình Khôi (20 tuổi)', 'Boss Thủ Lĩnh Huyết Trúc Tokyo'],
      description: [
        'Thủ Lĩnh Phản Đồ Huyết Trúc rút đại đao cuồng sát, thi triển Huyết Đao sấm sét hòng tiêu diệt toàn bộ con tin.',
        'Khôi đâm Cuộn Tranh Chưa Giao xuống mặt tuyết, kích hoạt tuyệt kỹ tối thượng [Phong Ấn: Tuyết Trắng Chôn Tên] & [Winter Shibuya - Hồi Quang].',
        'Không gian chuyển trắng đen, Khôi bất tử lướt liềm bút băng tước vũ khí và phong ấn toàn bộ sát khí của Boss mà không sát sinh, cứu thoát an toàn nhóm con tin.'
      ],
      verbatimLore: [
        '“Đâm cuộn tranh chưa giao xuống đất, tuyết 15m xung quanh đóng băng lại thành lăng mộ trắng.”',
        '“Đêm nay, tao chết một lần. Để ngày mai không ai chết thay tao.”',
        '“Tao chưa giao được tranh, nên chưa được phép ngã.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Thủ Lĩnh Huyết Trúc Tokyo',
          text: 'Huyết Đao Cuồng Sát! Lũ người này tao sẽ bán ra biển đen, cuộn tranh cổ của mày không cứu nổi ai đâu!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (20 tuổi)',
          text: 'Cuộn tranh này cụ Thọ giao cho tao, một khi chưa giao, tao chưa được phép ngã! Tuyết Trắng Chôn Tên — PHONG BĂNG!'
        }
      ],
      objective: 'Đánh bại Boss Thủ Lĩnh Huyết Trúc Tokyo (`boss_huyet_truc_tokyo_leader`) và tương tác Bàn Phong Ấn Cuộn Tranh (`cuon_tranh_phong_an_altar`) giải cứu con tin!',
      status: 'locked',
      requiredZoneId: 'zone_cau_vuot_shibuya_midnight',
      targetCoords: { x: 1350, y: 440 },
      rewardXp: 850,
      rewardItemIds: ['item_cuon_tranh_chua_giao'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A05-E005',
      arcNumber: 5,
      title: 'Biệt Danh "Khe Vằn Tử Thần" — Hồi Hương Về Thác 100 Tầng (Mở Đầu Arc 6)',
      year: '2028',
      location: 'Sân Bay & Bến Xe Hồi Hương Tokyo ↔ Bình Liêu',
      characters: ['Hoàng Minh Bình Khôi', 'Ba Chú Linh', 'Các Nạn Nhân Được Cứu'],
      description: [
        'Nhóm người được giải cứu cúi đầu cảm tạ ân đức của Khôi. Giới giang hồ Tokyo bàng hoàng trước kỳ tích đánh bại 12 đao thủ trong 7 phút không sát sinh, xưng tụng Khôi là "Khe Vằn Tử Thần".',
        'Tuy nhiên, sau trận huyết chiến bão tuyết, Khôi nhận thấy trong mắt mình đã xuất hiện những vệt máu đỏ của sát khí.',
        'Khôi quyết định không nán lại vinh quang, cầm vé máy bay hồi hương trở về Bình Liêu, tiến thẳng lên ngọn Thác Khe Vằn 100 Tầng để treo mình 6 tháng rửa sạch sát khí — Mở ra Arc 6: Chiến Binh Thác Khe Vằn!'
      ],
      verbatimLore: [
        '“Đánh bại 12 tên trong 7 phút không sát sinh; nhận biệt danh Khe Vằn Tử Thần.”',
        '“Treo mình giữa dòng thác ngút ngàn 6 tháng, rửa sạch vệt máu đỏ trong mắt, ngộ ra tuyệt kỹ Khe Vằn Trảm.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Đinh Quốc Tuấn',
          text: 'Thằng nhóc làm được rồi! Tokyo từ nay sẽ nhớ mãi tên "Khe Vằn Tử Thần"!'
        },
        {
          speaker: 'Ông Táy',
          text: 'Về quê đi cháu. Thác Khe Vằn nước trong vắt sẽ rửa sạch tuyết lạnh Tokyo trong tim mày.'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (20 tuổi)',
          text: 'Cảm ơn các chú. Sát khí trong mắt con đã nổi lên... Con phải về Thác Khe Vằn treo mình rèn tâm thôi. Tạm biệt Tokyo!'
        }
      ],
      objective: 'Tương tác Vé Máy Bay Hồi Hương Về Thác Khe Vằn (`ve_may_bay_ve_khe_van`), hoàn thành trọn vẹn Arc 5 và bước sang Arc 6: Chiến Binh Thác Khe Vằn!',
      status: 'locked',
      requiredZoneId: 'zone_cau_vuot_shibuya_midnight',
      targetCoords: { x: 1950, y: 440 },
      rewardXp: 1000,
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_5_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A05-E001',
    sourceLoreSummary: 'Khôi 20 tuổi mang Cuộn Tranh Chưa Giao đến Tokyo đêm 25/12/2028; bão tuyết, mất điện neon và còi xe cứu thương 3:17 sáng; tiếp cận hiện trường.',
    inGameImplementationLocation: 'Zone Ngã Tư Shibuya 109 (`zone_shibuya_crosswalk_109`): Xe cứu thương 3:17AM (`xe_cuu_thuong_317`), bão tuyết rơi, đèn đường chập chờn.',
    status: 'hoàn thành',
    notes: 'Tái hiện chân thực không gian đêm đông Tokyo tuyết trắng, tiếng còi xe cứu thương và trang phục tactical đen bạc vai mang nửa gậy trúc.'
  },
  {
    eventCode: 'A05-E002',
    sourceLoreSummary: 'Khôi gặp Ba Chú Linh Tokyo: Đinh Quốc Tuấn quét đường rải muối, Ông Táy giữ lò than bánh mì nóng 24/7, Hùng Đỏ khoác áo đỏ neon xông pha đỡ đạn.',
    inGameImplementationLocation: 'Zone Ngã Tư Shibuya 109: Xe bánh mì lò than (`xe_banh_mi_ong_tay`), đống muối tuyết (`dong_muoi_dinh_quoc_tuan`), NPC Ba Chú Linh.',
    status: 'hoàn thành',
    notes: 'Giữ nguyên 100% câu thoại và cơ chế: ăn bánh mì hồi phục sinh lực và rải muối chống đóng băng.'
  },
  {
    eventCode: 'A05-E003',
    sourceLoreSummary: 'Trận chiến cầu vượt đêm 25/12: Khôi kích hoạt Bảng Neon Gãy (+40% tốc đánh, mù địch 1.5s) và Tuyết Phủ 109 (Băng Giáp -25%), đánh gục toán đao thủ trong 7 phút không sát sinh.',
    inGameImplementationLocation: 'Zone Cầu Vượt Shibuya (`zone_cau_vuot_shibuya_midnight`): Bảng Neon Gãy (`bang_neon_gay_109`), bão tuyết, 6-12 đao thủ Huyết Trúc Tokyo.',
    status: 'hoàn thành',
    notes: 'Cơ chế chiến đấu thực tế với hitbox, đòn chém lướt, buff neon và hiệu ứng Băng Giáp bảo vệ.'
  },
  {
    eventCode: 'A05-E004',
    sourceLoreSummary: 'Đại chiến Thủ Lĩnh Huyết Trúc: Khôi kích hoạt Cuộn Tranh Chưa Giao và tuyệt kỹ Tuyết Trắng Chôn Tên / Hồi Quang, tước vũ khí thủ lĩnh mà không sát sinh, cứu toàn bộ con tin.',
    inGameImplementationLocation: 'Zone Cầu Vượt Shibuya: Boss Thủ Lĩnh Huyết Trúc (`boss_huyet_truc_tokyo_leader`), Bàn Phong Ấn Cuộn Tranh (`cuon_tranh_phong_an_altar`).',
    status: 'hoàn thành',
    notes: 'Boss AI thi triển Huyết Đao Cuồng Sát; cơ chế phong ấn kén băng hồi phục sinh lực kinh điển.'
  },
  {
    eventCode: 'A05-E005',
    sourceLoreSummary: 'Khôi nhận biệt danh “Khe Vằn Tử Thần”, nhưng nhận thấy sát khí đỏ trong mắt; cầm vé máy bay rời Tokyo về Bình Liêu, lên Thác Khe Vằn 100 tầng treo mình 6 tháng (Mở đầu Arc 6).',
    inGameImplementationLocation: 'Zone Cầu Vượt Shibuya: Vé máy bay và vali hồi hương (`ve_may_bay_ve_khe_van`), chuyển giao sang Arc 6: Chiến Binh Thác Khe Vằn.',
    status: 'hoàn thành',
    notes: 'Cầu nối mạch lạc tuyệt đối giữa sự kiện Winter Shibuya và quá trình tẩy sát khí tại Thác Khe Vằn.'
  }
];

export const ARC_5_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a05_e001: {
    id: 'dialog_a05_e001',
    lines: [
      {
        speaker: {
          id: 'khoi_20',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (20 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tokyo... Ngã tư Shibuya 109 ngập trong tuyết trắng. Tiếng còi xe cứu thương lúc 3 giờ 17 phút sáng... Tuyết rơi phủ hết, nhưng vết máu của đồng hương tao... tao không lau.'
      },
      {
        speaker: {
          id: 'khoi_20',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (20 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cuộn tranh này cụ Thọ và La Thanh giao cho tao, một khi chưa giao được tranh, tao chưa được phép ngã!'
      }
    ]
  },

  dialog_a05_e002: {
    id: 'dialog_a05_e002',
    lines: [
      {
        speaker: {
          id: 'dinh_quoc_tuan',
          name: 'Đinh Quốc Tuấn',
          title: 'Kẻ Vác Cán Quét (60 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_can'
        },
        text: 'Thằng nhóc áo tactical kia! Đứng yên trong tuyết lạnh lắm, lấy muối từ xô của tao xoa vào tay cho tan băng đi! Băng Huyết Trúc đang lùng sục dồn người lên cầu vượt!'
      },
      {
        speaker: {
          id: 'ong_tay',
          name: 'Ông Táy',
          title: 'Bán Bánh Mì Nóng 24/7',
          color: '#f59e0b',
          avatarId: 'avatar_tho'
        },
        text: 'Ăn ổ bánh mì nóng từ lò than của già đi cháu! Giữ lấy hơi ấm mà chiến đấu, đừng để cái lạnh Tokyo nuốt chửng linh hồn mày!'
      },
      {
        speaker: {
          id: 'hung_do',
          name: 'Hùng Đỏ',
          title: 'Giang Hồ Áo Đỏ Neon',
          color: '#ef4444',
          avatarId: 'avatar_du'
        },
        text: 'Anh Khôi! Lũ phản đồ Huyết Trúc đang dồn đồng hương lên Cầu Vượt Shibuya! Cầm liềm đi, tao bọc lót phía sau đỡ đạn cho mày!'
      },
      {
        speaker: {
          id: 'khoi_20',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (20 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cảm ơn ba chú. Đinh Quốc Tuấn quét muối, Ông Táy giữ than, Hùng Đỏ đỡ đạn. Đồng hương ta nơi xứ người, tao nhất định bảo vệ bằng cả tính mạng!'
      }
    ]
  },

  dialog_a05_e003: {
    id: 'dialog_a05_e003',
    lines: [
      {
        speaker: {
          id: 'huyet_truc_scout',
          name: 'Đao Thủ Huyết Trúc Tokyo',
          title: 'Phản Đồ Buôn Lậu',
          color: '#dc2626',
          avatarId: 'avatar_dat'
        },
        text: 'Thằng nhóc từ Bình Liêu sang đây tìm chết à? Cầu vượt Shibuya này là địa bàn của Huyết Trúc! Băm vát nó ra!'
      },
      {
        speaker: {
          id: 'khoi_20',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (20 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Liềm của tao không chém người vô tội. Bảng neon gãy soi sáng đường về cho đồng bào tao. DỪNG TAY LẠI!'
      }
    ]
  },

  dialog_a05_e004: {
    id: 'dialog_a05_e004',
    lines: [
      {
        speaker: {
          id: 'boss_leader',
          name: 'Thủ Lĩnh Huyết Trúc Tokyo',
          title: 'Huyết Đao Cuồng Sát',
          color: '#b91c1c',
          avatarId: 'avatar_dat'
        },
        text: 'Huyết Đao Cuồng Sát! Lũ người này tao sẽ bán ra biển đen, cuộn tranh cổ của mày không cứu nổi ai đâu!'
      },
      {
        speaker: {
          id: 'khoi_20',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (20 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cuộn tranh này cụ Thọ giao cho tao, một khi chưa giao, tao chưa được phép ngã! Tuyết Trắng Chôn Tên — PHONG BĂNG!'
      }
    ]
  },

  dialog_a05_e005: {
    id: 'dialog_a05_e005',
    lines: [
      {
        speaker: {
          id: 'dinh_quoc_tuan',
          name: 'Đinh Quốc Tuấn',
          title: 'Kẻ Vác Cán Quét',
          color: '#38bdf8',
          avatarId: 'avatar_can'
        },
        text: 'Thằng nhóc làm được rồi! Toàn bộ đồng hương đã an toàn. Tokyo từ nay sẽ nhớ mãi tên "Khe Vằn Tử Thần"!'
      },
      {
        speaker: {
          id: 'ong_tay',
          name: 'Ông Táy',
          title: 'Bán Bánh Mì Nóng 24/7',
          color: '#f59e0b',
          avatarId: 'avatar_tho'
        },
        text: 'Về quê đi cháu. Thác Khe Vằn nước trong vắt sẽ rửa sạch tuyết lạnh Tokyo trong tim mày.'
      },
      {
        speaker: {
          id: 'khoi_20',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Khe Vằn Tử Thần (Hồi Hương)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cảm ơn các chú. Sát khí trong mắt con đã nổi lên... Con phải về Thác Khe Vằn treo mình 6 tháng rèn tâm thôi. Tạm biệt Tokyo!'
      }
    ]
  }
};

/**
 * ============================================================================
 * ARC 6: CHIẾN BINH THÁC KHE VẰN (2029) — TẨY RỬA SÁT KHÍ 6 THÁNG
 * ============================================================================
 * Thời kỳ Khôi 21 tuổi trở về từ Winter Shibuya Incident với tia máu đỏ trong mắt.
 * Khôi lên Thác Khe Vằn 100 tầng treo mình 6 tháng dưới nghìn roi nước đổ,
 * chiến đấu đánh tan ảo giác Tâm Ma Shibuya, ngộ ra tuyệt kỹ "Khe Vằn Trảm",
 * hạ sơn về cổng đình gặp cháu trai Tài Dog và chú chó què Đốm (Mở đầu Arc 7).
 */
export const ARC_6_DATA: ArcCatalog = {
  arcNumber: 6,
  title: 'Arc 6: Chiến Binh Thác Khe Vằn (Tẩy Rửa Sát Khí)',
  timeframe: '2029 (Thác Khe Vằn 100 Tầng, Bình Liêu)',
  mainCharacters: [
    'Hoàng Minh Bình Khôi (21 tuổi - Khe Vằn Tử Thần)',
    'Lục Triều Dư (32 tuổi - Thằng Treo Dây / Phe Kéo)',
    'Linh Ảnh Trúc Thánh Hoàng Cần',
    'Tâm Ma Shibuya (Ảo Giác Sát Khí Của Khôi)',
    'Lài Phúc Tài (Tài Dog - 8 tuổi)',
    'Chú chó cỏ què Đốm'
  ],
  corePhilosophy: '“Chỉ có dòng nước thác trắng xoá 100 tầng mới rửa được máu trong mắt. Đao chém đứt nước không sát sinh mới là Khe Vằn Trảm.”',
  summary: 'Khôi hồi hương từ Tokyo với tia máu đỏ sát khí trong mắt; leo lên Thác Khe Vằn vượt thử thách cáp thép của Lục Triều Dư; treo mình 6 tháng dưới nghìn roi nước đổ gột sạch tâm ma; ngộ ra tuyệt kỹ Khe Vằn Trảm chém đôi dòng thác và hạ sơn về cổng đình gặp Tài Dog.',
  events: [
    {
      id: 'A06-E001',
      arcNumber: 6,
      title: 'Hồi Hương Thác Khe Vằn — Vệt Máu Trong Mắt (2029)',
      year: '2029',
      location: 'Hồ Nước Chân Thác Khe Vằn, Bình Liêu',
      characters: ['Hoàng Minh Bình Khôi (21 tuổi)'],
      description: [
        'Rời bão tuyết Tokyo 2028 với biệt danh "Khe Vằn Tử Thần", Khôi 21 tuổi cầm vé máy bay hạ cánh trở về quê hương Bình Liêu yêu dấu.',
        'Đến chân Thác Khe Vằn 100 Tầng, Khôi cúi nhìn hình bóng phản chiếu dưới mặt hồ nước trong vắt.',
        'Trong con ngươi Khôi, một vệt máu đỏ tươi của sát khí cuồng bạo vẫn rực lên. Tiếng còi xe cứu thương 3:17AM và tuyết lạnh Tokyo vẫn dội về trong tâm trí: "Tuyết rơi phủ hết. Nhưng vết máu này... tao không lau".',
        'Khôi nhận ra nếu không gột rửa sát khí, bản thân sẽ trượt dài vào con đường tà ma cuồng sát. Khôi quyết tâm leo lên đỉnh thác 100 tầng để thanh tẩy tâm can.'
      ],
      verbatimLore: [
        '“Chỉ có dòng nước thác trắng xoá mới rửa được máu trong mắt.”',
        '“Nơi Hoàng Cần thời trẻ từng luyện gậy trúc và Khôi treo mình rèn luyện suốt 6 tháng sau Winter Shibuya Incident.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Bình Khôi (21 tuổi)',
          text: 'Vệt máu đỏ trong mắt vẫn còn... Khí lạnh Shibuya và tiếng đao chém đẫm máu đêm 25/12 vẫn chưa tan. Ta phải lên dòng thác 100 tầng gột sạch nó!'
        }
      ],
      objective: 'Tiến đến Bờ Hồ Chân Thác Khe Vằn (`ho_nuoc_chan_thac`), soi bóng mặt nước nhận diện sát khí Shibuya!',
      status: 'active',
      requiredZoneId: 'zone_thac_khe_van',
      targetCoords: { x: 260, y: 500 },
      rewardXp: 450,
      rewardItemIds: ['item_nuoc_la_tia_to'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A06-E002',
      arcNumber: 6,
      title: 'Vách Đá 100 Tầng — Thử Thách Cáp Thép Cùng Lục Triều Dư',
      year: '2029',
      location: 'Vách Đá Trung Tâm Thác Khe Vằn',
      characters: ['Lục Triều Dư (Thằng Treo Dây)', 'Hoàng Minh Bình Khôi'],
      description: [
        'Khôi leo lên lưng chừng thác, bắt gặp cố nhân Lục Triều Dư (32 tuổi, phe Kéo, cựu đặc công biên phòng mốc 1088 gãy 3 đốt sống) đang treo mình trên dây cáp thép giữa 2 bờ vách đá.',
        'Dư nhìn vào mắt Khôi liền nghiêm giọng: "Mắt mày đỏ quạch như máu quỷ Tokyo rồi Khôi. Muốn lên tầng thác cao nhất để tẩy sát khí, trước hết phải vượt qua đàn báo hoa mai vách đá và đọ thân pháp cáp thép với tao!"',
        'Khôi vung liềm Tử Thần đánh lui bầy Báo Hoa Mai Vách Đá hung dữ, sau đó đu mình trên giàn cáp thép (`day_cap_thac_100_tang`) thể hiện bản lĩnh thân pháp vững như bàn thạch.'
      ],
      verbatimLore: [
        '“Mày không cần bình nữa. Lần này để tao bình mày.”',
        '“Thường treo mình trên dây cáp giữa 2 vách đá Khe Vằn rèn cơ lưng. Thấy ai chìm xuống vực sâu thì dùng dây kéo lên.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: 'Khôi! Mắt mày đục ngầu sát khí Shibuya rồi! Dẹp sạch lũ báo vách đá kia rồi bám vào dây cáp thép của tao, tao kéo mày lên đỉnh thác!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Dư, giữ chắc dây! Đời này có anh em phe Kéo của mày canh giữ phía sau, tao nhất định không ngã!'
        }
      ],
      objective: 'Đánh bại 4 con Báo Hoa Mai Vách Đá và tương tác Giàn Cáp Thép (`day_cap_thac_100_tang`) so tài thân pháp cùng Lục Triều Dư!',
      status: 'locked',
      requiredZoneId: 'zone_thac_khe_van',
      targetCoords: { x: 1040, y: 310 },
      rewardXp: 550,
      rewardItemIds: ['item_dan_duoc_tang_luc'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A06-E003',
      arcNumber: 6,
      title: '6 Tháng Treo Mình Dưới Nghìn Roi Nước Đổ — Quyết Đấu Tâm Ma Shibuya',
      year: '2029',
      location: 'Đỉnh Tầng Thác Thứ 50 — Điểm Treo Mình Cực Hạn',
      characters: ['Hoàng Minh Bình Khôi', 'Tâm Ma Shibuya (Bóng Ma Sát Khí)'],
      description: [
        'Khôi dùng dây thừng gai thắt ngang hông, buông mình lơ lửng ngay giữa lòng thác nước 100 tầng ngút ngàn suốt 6 tháng ròng rã.',
        'Từng dòng thác cuộn trào ầm ầm như nghìn chiếc roi sắt giáng rát bỏng vào thân thể, rét buốt thấu tận xương tủy.',
        'Trong cơn kiệt cùng của thể xác và tinh thần, bóng ma sát khí Tokyo trỗi dậy hóa thành Boss Tâm Ma Shibuya (`boss_tam_ma_shibuya`), gầm thét tung ra tuyệt kỹ Huyết Đao Cuồng Sát đòi nuốt trọn linh hồn Khôi.',
        'Khôi vận khởi triết lý "Dừng Lại" của Cụ Thọ và Hoàng Cần, dồn toàn bộ nội lực vung liềm chém tan ảo ảnh Tâm Ma, chính thức xua tan vệt máu đỏ trong mắt!'
      ],
      verbatimLore: [
        '“Khôi treo mình rèn luyện suốt 6 tháng sau Winter Shibuya Incident.”',
        '“Nước đổ như nghìn roi sắt — nơi ngộ ra Khe Vằn Trảm.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Tâm Ma Shibuya',
          text: 'Ngươi là Khe Vằn Tử Thần! Máu ngươi đã dính đao đêm 25/12, ngươi không bao giờ có thể rửa sạch sát khí! Hãy chìm vào bóng tối!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Liềm của ta cầm là để giữ người, không phải để làm ác ma! Dù nghìn roi nước đập nát da thịt, ta cũng sẽ DỪNG LẠI! BIẾN ĐI TÂM MA!'
        }
      ],
      objective: 'Tương tác Điểm Treo Mình 6 Tháng (`diem_treo_minh_6_thang`), chịu đựng nghìn roi nước đổ và đánh bại Boss Tâm Ma Shibuya!',
      status: 'locked',
      requiredZoneId: 'zone_thac_khe_van',
      targetCoords: { x: 1420, y: 260 },
      rewardXp: 750,
      rewardItemIds: ['item_banh_mi_ong_tay'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A06-E004',
      arcNumber: 6,
      title: 'Ngộ Ra Tuyệt Kỹ "Khe Vằn Trảm" (Đường Liềm Vô Ảnh)',
      year: '2029',
      location: 'Đỉnh Thác 100 Tầng — Tảng Đá Giác Ngộ',
      characters: ['Hoàng Minh Bình Khôi (21 tuổi)', 'Linh Ảnh Trúc Thánh Hoàng Cần'],
      description: [
        'Sau khi Tâm Ma tan biến, trời quang mây tạnh, dòng thác 100 tầng gầm thét dữ dội bỗng trở nên êm ả, trong suốt như gương trong tâm nhãn của Khôi.',
        'Đứng trên tảng đá giác ngộ ngắm dòng nước đổ, Khôi nhẹ nhàng rút Liềm Tử Thần vung ra một nhát.',
        'Đường liềm lướt theo dòng nước: một nhát chém kinh thiên động địa xé toạc dòng thác đổ làm đôi mà giọt nước chưa kịp bắn toé!',
        'Linh ảnh Trúc Thánh Hoàng Cần hiện lên giữa làn sương thác, mỉm cười tán thán: "Đao chém đứt nước mà nước không giận, liềm chạm vào tâm mà người không chết. Đó chính là Khe Vằn Trảm!". Khôi chính thức lĩnh hội tuyệt kỹ Khe Vằn Trảm!'
      ],
      verbatimLore: [
        '“Tại đây Khôi ngộ ra chiêu ‘Khe Vằn Trảm’ — đường liềm lướt theo dòng nước chưa kịp bắn toé.”',
        '“Chỉ có dòng nước thác trắng xoá mới rửa được máu trong mắt.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Cần (Chân Ảnh)',
          text: 'Khôi! Mắt con đã trong veo trở lại. Đường liềm lướt theo dòng nước mà giọt nước chưa kịp bắn toé... Tuyệt kỹ Khe Vằn Trảm này chính là đỉnh cao của sự Bình Lặng!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Tạ ơn sư phụ! Con đã hiểu: Đao sắc không phải để giết chóc, mà là để bảo vệ những người ta yêu thương!'
        }
      ],
      objective: 'Tiến đến Tảng Đá Giác Ngộ (`tang_da_khe_van_tram`) trên đỉnh thác, thi triển và làm chủ tuyệt kỹ "Khe Vằn Trảm"!',
      status: 'locked',
      requiredZoneId: 'zone_thac_khe_van',
      targetCoords: { x: 2150, y: 400 },
      rewardXp: 900,
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A06-E005',
      arcNumber: 6,
      title: 'Hạ Sơn Về Cổng Đình — Chữ Bình & Lời Dặn Của Tài Dog (Mở Đầu Arc 7)',
      year: '2029 — Khởi đầu 2065',
      location: 'Cổng Đình Lục Nà, Thôn Bản Cáu',
      characters: ['Hoàng Minh Bình Khôi', 'Lài Phúc Tài (Tài Dog)', 'Chú chó cỏ què Đốm'],
      description: [
        'Rửa sạch hoàn toàn sát khí và thành thục Khe Vằn Trảm, Khôi hạ sơn rời khỏi Thác Khe Vằn, quay về Bản Cáu bình yên.',
        'Khôi quyết định cất Liềm Tử Thần vào két sắt, thề ngừng phân tranh thế sự, quay về làm người giữ làng thầm lặng.',
        'Tại cổng đình Lục Nà rợp bóng tre xanh, cháu trai Lài Phúc Tài (Tài Dog, 8 tuổi bị bệnh tim bẩm sinh) đang cùng chú chó cỏ què chân Đốm chạy lon ton đón Khôi.',
        'Tài ngước đôi mắt tròn xoe nhìn Khôi rồi ngây thơ nói: "Cậu ơi, đừng bình nữa. Cứ giữ thôi...". Khôi mỉm cười ôm lấy Tài và xoa đầu Đốm, chính thức hoàn thành Arc 6 và mở ra Arc 7: Lời Dặn Của Lài Phúc Tài.'
      ],
      verbatimLore: [
        '“Cậu ơi, đừng bình nữa. Cứ giữ thôi.”',
        '“Tài Dog nuôi chú chó cỏ què một chân tên Đốm. Khôi tặng Tài gậy trúc mỗi năm dù Tài không tập võ: ‘Vì mày không cần học. Mày chỉ cần sống.’”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lài Phúc Tài (Tài Dog)',
          text: 'Cậu Khôi! Cậu ơi cậu về rồi! Đốm ơi ra đón cậu Khôi kìa! Cậu đi đâu mà 6 tháng nay cháu với Đốm nhớ cậu quá chừng!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Ừ, cậu nghe Tài. Cậu cất liềm rồi, từ nay cậu ở nhà canh cổng đình, giữ bình yên cho mày và con Đốm lớn lên.'
        }
      ],
      objective: 'Qua cổng portal hạ sơn về Cổng Đình Bản Cáu (`cong_dinh_ban_cau_arc6`), gặp gỡ Tài Dog & Đốm, hoàn thành Arc 6 và mở lối Arc 7!',
      status: 'locked',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 1400, y: 440 },
      rewardXp: 1000,
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_6_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A06-E001',
    sourceLoreSummary: 'Khôi 21 tuổi hồi hương từ Tokyo với vệt máu đỏ sát khí trong mắt; nhìn bóng dưới suối chân Thác Khe Vằn tự vấn tâm can.',
    inGameImplementationLocation: 'Zone Thác Khe Vằn (`zone_thac_khe_van`): Hồ Nước Chân Thác (`ho_nuoc_chan_thac`), hiệu ứng nước đổ bọt tung trắng xóa.',
    status: 'hoàn thành',
    notes: 'Tái hiện vệt máu đỏ trong mắt và ký ức ám ảnh Winter Shibuya, khởi đầu quá trình gột rửa tâm can.'
  },
  {
    eventCode: 'A06-E002',
    sourceLoreSummary: 'Khôi leo vách đá 100 tầng, gặp lại Lục Triều Dư đang treo mình rèn cơ lưng; đánh lui báo hoa mai vách đá và vượt thử thách cáp thép.',
    inGameImplementationLocation: 'Zone Thác Khe Vằn: Giàn cáp thép vách đá (`day_cap_thac_100_tang`), 4 con Báo Hoa Mai Vách Đá (`bao_hoa_mai_khe_van`), NPC Lục Triều Dư.',
    status: 'hoàn thành',
    notes: 'Chiến đấu thực tế với quái thú vách đá và tương tác giàn cáp thép đặc trưng phe Kéo của Lục Triều Dư.'
  },
  {
    eventCode: 'A06-E003',
    sourceLoreSummary: 'Khôi treo mình 6 tháng dưới nghìn roi nước đổ; đối mặt và đánh tan ảo giác Tâm Ma Shibuya thi triển Huyết Đao Cuồng Sát hòng nuốt chửng linh hồn.',
    inGameImplementationLocation: 'Zone Thác Khe Vằn: Điểm Treo Mình 6 Tháng (`diem_treo_minh_6_thang`), Boss Tâm Ma Shibuya (`boss_tam_ma_shibuya`).',
    status: 'hoàn thành',
    notes: 'Trận Boss Fight tâm lý đỉnh cao: Khôi tự chiến đấu với sát khí bóng ma của chính mình để thanh tẩy tâm ma.'
  },
  {
    eventCode: 'A06-E004',
    sourceLoreSummary: 'Khôi giác ngộ trên đỉnh thác 100 tầng, vung liềm chém đôi dòng nước thác mà giọt nước chưa kịp bắn toé, lĩnh hội tuyệt kỹ "Khe Vằn Trảm".',
    inGameImplementationLocation: 'Zone Thác Khe Vằn: Tảng Đá Giác Ngộ (`tang_da_khe_van_tram`), mở khóa kỹ năng chủ động Khe Vằn Trảm trên thanh điều khiển.',
    status: 'hoàn thành',
    notes: 'Khai sinh tuyệt chiêu tối thượng của Bình Liêu Vương: đường liềm lướt theo dòng nước vô thanh vô ảnh.'
  },
  {
    eventCode: 'A06-E005',
    sourceLoreSummary: 'Khôi hạ sơn về cổng đình Lục Nà, cất liềm vào két sắt thề ngừng bình; gặp cháu trai Tài Dog và chú chó què Đốm dặn dò "Cứ giữ thôi" (Mở đầu Arc 7).',
    inGameImplementationLocation: 'Zone Bản Cáu (`zone_ban_cau`): Cổng Đình Bản Cáu (`cong_dinh_ban_cau_arc6`), NPC Lài Phúc Tài (Tài Dog) và chú chó Đốm.',
    status: 'hoàn thành',
    notes: 'Cầu nối xúc động và chuẩn xác dẫn dắt người chơi từ Arc 6 sang Arc 7: Lời Dặn Của Lài Phúc Tài.'
  }
];

export const ARC_6_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a06_e001: {
    id: 'dialog_a06_e001',
    lines: [
      {
        speaker: {
          id: 'khoi_21',
          name: 'Hoàng Minh Bình Khôi (21 tuổi)',
          title: 'Khe Vằn Tử Thần',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Nước Thác Khe Vằn vẫn lạnh buốt như ngày nào... Nhưng bóng ta dưới nước... vệt máu đỏ trong mắt vẫn chưa hề tan!'
      },
      {
        speaker: {
          id: 'khoi_21',
          name: 'Hoàng Minh Bình Khôi (21 tuổi)',
          title: 'Khe Vằn Tử Thần',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tiếng còi xe cứu thương 3:17 sáng và bão tuyết Tokyo vẫn réo rắt trong đầu. Ta phải lên tầng thác cao nhất, dùng nghìn roi nước đổ để rửa sạch vết máu này!'
      }
    ]
  },

  dialog_a06_e002: {
    id: 'dialog_a06_e002',
    lines: [
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây (Phe Kéo)',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! Mày về rồi à? Mắt đỏ quạch như quỷ nhập thế kia! Tokyo lạnh quá làm tim mày đông đá rồi phải không?'
      },
      {
        speaker: {
          id: 'khoi_21',
          name: 'Hoàng Minh Bình Khôi (21 tuổi)',
          title: 'Khe Vằn Tử Thần',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Dư... Tao cần lên đỉnh thác 100 tầng treo mình. Sát khí Shibuya đang gặm nhấm tâm trí tao từng ngày.'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây (Phe Kéo)',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Được! Bám lấy giàn cáp thép của tao! Tao sẽ giữ dây kéo mày lên đỉnh thác, nhưng tự mày phải đánh lui đàn báo hoa mai vách đá!'
      }
    ]
  },

  dialog_a06_e003: {
    id: 'dialog_a06_e003',
    lines: [
      {
        speaker: {
          id: 'tam_ma',
          name: 'Tâm Ma Shibuya',
          title: 'Bóng Ma Sát Khí',
          color: '#ef4444',
          avatarId: 'avatar_dat'
        },
        text: 'Khôi! Mày không thể gột rửa tao đâu! Mày là Khe Vằn Tử Thần! Nhát liềm bẻ gãy bảng neon Shibuya của mày khát máu, hãy buông tay và trở thành ác ma đi!'
      },
      {
        speaker: {
          id: 'khoi_21',
          name: 'Hoàng Minh Bình Khôi (21 tuổi)',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Nước thác Khe Vằn đổ như nghìn roi sắt đập nát ảo ảnh của mày! Cụ Thọ dạy: "Cần giữ người, Thọ bình người". Liềm của tao cầm là để cứu nhân độ thế! BIẾN ĐI TÂM MA!'
      }
    ]
  },

  dialog_a06_e004: {
    id: 'dialog_a06_e004',
    lines: [
      {
        speaker: {
          id: 'can_spirit',
          name: 'Hoàng Cần (Chân Ảnh)',
          title: 'Trúc Thánh',
          color: '#a5d6a7',
          avatarId: 'avatar_can'
        },
        text: 'Khôi... Con đã vượt qua 6 tháng thử thách nghìn roi nước đổ. Tia máu đỏ trong mắt con đã tan biến thành dòng nước mát lành.'
      },
      {
        speaker: {
          id: 'khoi_21',
          name: 'Hoàng Minh Bình Khôi (21 tuổi)',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Sư phụ... Nhát liềm vừa rồi con chém ra, dòng thác bị xé toạc làm đôi mà bọt nước chưa kịp bắn toé. Con đã hiểu thế nào là Dừng Lại.'
      },
      {
        speaker: {
          id: 'can_spirit',
          name: 'Hoàng Cần (Chân Ảnh)',
          title: 'Trúc Thánh',
          color: '#a5d6a7',
          avatarId: 'avatar_can'
        },
        text: 'Đó chính là "Khe Vằn Trảm"! Đao chém đứt nước mà nước không giận, liềm chạm vào giặc mà tâm không vấy máu. Hãy hạ sơn về giữ làng đi con!'
      }
    ]
  },

  dialog_a06_e005: {
    id: 'dialog_a06_e005',
    lines: [
      {
        speaker: {
          id: 'tai_child',
          name: 'Lài Phúc Tài (8 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Cậu Khôi! Cậu ơi cậu về rồi! Đốm ơi ra đón cậu Khôi kìa! Cậu đi đâu mà 6 tháng nay cháu với Đốm nhớ cậu quá chừng!'
      },
      {
        speaker: {
          id: 'khoi_21',
          name: 'Hoàng Minh Bình Khôi (21 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tài... Đốm... Cậu về với hai đứa đây. Cậu vừa ở Thác Khe Vằn xuống.'
      },
      {
        speaker: {
          id: 'tai_child',
          name: 'Lài Phúc Tài (8 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Mắt cậu không còn đỏ nữa rồi! Cậu ơi... Cháu thấy người ta đồn cậu đi đánh nhau dữ lắm. Cậu đừng bình nữa nhé... Cứ giữ thôi cậu ơi!'
      },
      {
        speaker: {
          id: 'khoi_21',
          name: 'Hoàng Minh Bình Khôi (21 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Ừ. Cậu hứa với Tài. Cậu cất liềm rồi. Từ nay cậu ở nhà canh cổng đình, giữ bình yên cho mày và con Đốm lớn lên.'
      }
    ]
  }
};

// =========================================================================================
// --- ARC 7: TÀI DOG VÀ CÁI "GIỮ" CUỐI CÙNG (2030 – 2065) ---
// =========================================================================================

export const ARC_7_DATA: ArcCatalog = {
  arcNumber: 7,
  title: 'Arc 7: Tài Dog Và Cái "Giữ" Cuối Cùng',
  timeframe: '2030 – 2065',
  mainCharacters: [
    'Hoàng Minh Bình Khôi (22 - 57 tuổi)',
    'Lài Phúc Tài (Tài Dog, 9 - 18 tuổi)',
    'Chú chó cỏ què Đốm',
    'La Thanh',
    'Dân bản Tày, Dao Bản Cáu',
    'Đao thủ tà môn Móng Cái'
  ],
  corePhilosophy: '“Cậu ơi, đừng bình nữa. Cứ giữ thôi... Cần giữ người, Thọ bình người. Khôi dừng người, Tài nhắc giữ.”',
  summary: 'Khôi trở về thôn Bản Cáu gác liềm, làm người giữ làng thầm lặng bên cổng đình Lục Nà; bảo bọc đứa cháu trai duy nhất Lài Phúc Tài bị bệnh tim bẩm sinh và chú chó cỏ què Đốm; mỗi năm tặng Tài một cây gậy trúc non dù không dạy võ (“Vì mày không cần học, mày chỉ cần sống”); chứng kiến Tài qua đời trong đêm đông 2065 với lời trăn trối “Cứ giữ thôi”; cởi bỏ chiến bào khóa Liềm Tử Thần vào két sắt; mang cháo dỗ chú chó Đốm 3 ngày phủ phục bên mộ và cùng Đốm đánh lui đám tà môn Hoán Não, mở đường sang Arc 8.',
  events: [
    {
      id: 'A07-E001',
      arcNumber: 7,
      title: 'Lời Hứa Cổng Đình — Chú Chó Què Đốm (2030)',
      year: '2030',
      location: 'Cổng Đình Lục Nà, Thôn Bản Cáu',
      characters: ['Hoàng Minh Bình Khôi (22 tuổi)', 'Lài Phúc Tài (9 tuổi)', 'Chú chó cỏ què Đốm'],
      description: [
        'Năm 2030, Khôi 22 tuổi sau khi gột sạch sát khí Thác Khe Vằn đã cất liềm trở về gắn bó với thôn Bản Cáu.',
        'Trước cổng đình Lục Nà cổ kính, đứa cháu trai duy nhất Lài Phúc Tài (Tài Dog, 9 tuổi) nuôi một chú chó cỏ bị què một chân tên là Đốm.',
        'Tài bị bệnh tim bẩm sinh, thể trạng gầy gò ốm yếu nhưng luôn hồn nhiên nở nụ cười, chạy lon ton bên chú chó ba chân.',
        'Khi bầy dã thú biên giới lảng vảng ven suối Bản Cáu, Tài lên cơn đau tim ngất xỉu bên bờ thềm. Khôi kịp thời lao tới bế thốc cháu, sắc bát thuốc nam dưỡng tim (`thuoc_nam_duong_tim`) từ y thuật Cụ Thọ để cứu tỉnh Tài.',
        'Khôi ôm Tài và xoa đầu chú chó Đốm, tự nhủ đời này sẽ bảo vệ hai sinh linh nhỏ bé này đến cùng.'
      ],
      verbatimLore: [
        '“Tài Dog nuôi chú chó cỏ què một chân tên Đốm.”',
        '“Người Tày quê Lạng Sơn, cháu trai duy nhất gọi Khôi bằng ‘cậu’. Bị bệnh tim bẩm sinh.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lài Phúc Tài (9 tuổi)',
          text: 'Cậu Khôi ơi, tim cháu lại nhói buốt... Con Đốm nó liếm tay cháu hoài nè cậu.'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Uống bát nước thuốc ngải cứu này đi Tài. Có cậu ở đây, cậu giữ cho mày và con Đốm an lành.'
        }
      ],
      objective: 'Tương tác Giếng Nước Bản Cáu sắc Bát Thuốc Nam Dưỡng Tim (`thuoc_nam_duong_tim`), bưng lại cứu tỉnh Tài Dog và xoa dịu chú chó Đốm!',
      status: 'active',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 1100, y: 500 },
      rewardXp: 500,
      rewardItemIds: ['item_bat_chao_ngo'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A07-E002',
      arcNumber: 7,
      title: 'Những Cây Gậy Trúc Không Tập Võ (2035 – 2050)',
      year: '2035 – 2050',
      location: 'Chùa Cổ Nguyệt & Bản Cáu',
      characters: ['Hoàng Minh Bình Khôi', 'Lài Phúc Tài (Tài Dog)', 'La Thanh'],
      description: [
        'Suốt nhiều năm ròng rã, cứ vào mỗi dịp sinh nhật Tài Dog, Khôi đều đích thân leo lên núi Chùa Cổ Nguyệt chặt một đoạn trúc non nhẵn mịn, cẩn thận gọt sạch mọi dằm gai rồi mang về tặng cháu.',
        'Dân làng và các đệ tử thắc mắc vì sao Khôi là cao thủ đệ nhất Bình Liêu Vương mà không dạy nửa thế võ nào cho Tài để nối nghiệp.',
        'Khôi mỉm cười xoa đầu cháu rồi bảo: "Vì mày không cần học võ. Mày chỉ cần sống." Nhánh Giữ của Khôi với Tài không phải là truyền đao búa, mà là giữ lấy nhịp tim và sự an yên.',
        'Tài cất từng cây gậy trúc đầu giường như báu vật vô giá, gõ lách cách vui đùa cùng chú chó Đốm suốt thời niên thiếu.'
      ],
      verbatimLore: [
        '“Khôi tặng Tài gậy trúc mỗi năm dù Tài không tập võ: ‘Vì mày không cần học. Mày chỉ cần sống.’”',
        '“Thế cậu là Wolf, chạy nhanh nhưng cắn chết người.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lài Phúc Tài (14 tuổi)',
          text: 'Cậu Khôi! Sao năm nào sinh nhật cậu cũng tặng cháu một cây gậy tre vậy? Cậu không dạy cháu múa liềm à?'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Mày không cần học võ, Tài à. Mày chỉ cần sống thôi. Đời chém giết đã có cậu gánh hết rồi.'
        }
      ],
      objective: 'Lên Rừng Trúc Chùa Cổ Nguyệt thu hoạch Cây Trúc Non Nhẵn Mịn (`cay_truc_non_tang_tai`), khắc chữ BÌNH mang về tặng sinh nhật Tài Dog!',
      status: 'locked',
      requiredZoneId: 'zone_chua_co_nguyet',
      targetCoords: { x: 920, y: 340 },
      rewardXp: 650,
      rewardItemIds: ['item_gay_108_ranh'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A07-E003',
      arcNumber: 7,
      title: 'Đêm Đông 2065 — Cơn Bộc Phát Tim & Lời Dặn "Cứ Giữ Thôi"',
      year: 'Mùa đông 2065',
      location: 'Giường Bệnh Chòi Lá Đình Lục Nà, Bản Cáu',
      characters: ['Lài Phúc Tài (18 tuổi)', 'Hoàng Minh Bình Khôi (57 tuổi)', 'Chú chó cỏ què Đốm'],
      description: [
        'Mùa đông năm 2065, gió bấc lạnh buốt rít qua rặng tre Bản Cáu. Căn bệnh tim bẩm sinh ủ sâu suốt 18 năm của Tài Dog bộc phát dữ dội.',
        'Tài nằm trên giường bệnh chòi lá (`giuong_benh_tai_dog`), môi tím tái, hơi thở thoi thóp. Chú chó Đốm gác mõm lên mép giường rên rỉ từng hồi thảm thiết.',
        'Khôi dồn toàn bộ nội lực truyền hơi ấm qua bàn tay gầy gò của cháu, mắt ngấn lệ cầu xin đất trời che chở.',
        'Trước khi trút hơi thở cuối cùng, Tài gắng gượng mở mắt, nhìn Khôi mỉm cười rồi thều thào lời trăn trối: "Cậu ơi... đừng bình nữa. Cứ giữ thôi...".',
        'Bàn tay Tài Dog buông thõng. Tiếng khóc nghẹn ngào của Khôi xé toạc màn đêm đông Bình Liêu lạnh giá.'
      ],
      verbatimLore: [
        '“Năm 2065, Tài qua đời vì bộc phát tim, khiến Khôi đau đớn treo liềm vào két sắt, thề ngừng ‘bình’ và giải tán phe phái.”',
        '“‘Cậu ơi, đừng bình nữa. Cứ giữ thôi.’”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lài Phúc Tài (18 tuổi)',
          text: 'Cậu ơi... Tay cậu ấm quá... Đừng... đừng đi đánh nhau nữa nhé cậu... Đừng bình nữa... Cứ giữ thôi...'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Tài ơi! Mở mắt ra nhìn cậu đi Tài! Cậu nghe lời mày mà! Cậu giữ... cậu giữ hết cho mày mà Tài ơi!'
        }
      ],
      objective: 'Tiến lại Giường Bệnh Tài Dog (`giuong_benh_tai_dog`), truyền nội lực ấm và lắng nghe lời dặn trăn trối thiêng liêng: "Cứ Giữ Thôi"!',
      status: 'locked',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 300, y: 500 },
      rewardXp: 850,
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A07-E004',
      arcNumber: 7,
      title: 'Treo Liềm Két Sắt — Chó Đốm 3 Ngày Bên Mộ (2065)',
      year: '2065',
      location: 'Đình Lục Nà & Đồi Mộ Bản Cáu',
      characters: ['Hoàng Minh Bình Khôi', 'Chú chó cỏ què Đốm bên nấm mộ Tài Dog'],
      description: [
        'Đau đớn tột cùng trước cái chết của đứa cháu duy nhất, Khôi quyết định thực hiện trọn vẹn lời dặn của Tài.',
        'Khôi cởi bỏ chiến bào đen, lau sạch lần cuối lưỡi Liềm Tử Thần, bọc vào tấm vải nhung đỏ rồi đem cất chặt trong Két Sắt Cổ (`ket_sat_khoa_liem`), thề từ nay vĩnh viễn ngừng “bình”, buông đao búa và giải tán toàn bộ thuộc hạ.',
        'Tài Dog được an táng tại Đồi Mộ Gia Tộc Bản Cáu (`bia_mo_tai_dog`). Suốt 3 ngày 3 đêm mưa tuyết, chú chó Đốm què một chân không chịu rời nửa bước, nằm phủ phục trước mộ không ăn không uống.',
        'Ngày thứ ba, Khôi mang bát cháo ngô nóng lên mộ, nghẹn ngào ôm lấy con Đốm vào lòng dỗ dành rồi đưa chú chó trở về cổng đình canh gác.'
      ],
      verbatimLore: [
        '“Sau khi Tài mất, Đốm nằm trước mộ 3 ngày rồi được Khôi đưa về nuôi tại cổng đình canh gác.”',
        '“Khôi đau đớn treo liềm vào két sắt, thề ngừng ‘bình’ và giải tán phe phái.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Đốm ngoan... Ăn miếng cháo ngô đi con. Thằng Tài nó đi thanh thản rồi. Về cổng đình với cậu, hai cậu cháu mình cùng canh giữ cho nó yên nghỉ.'
        },
        {
          speaker: 'Chú chó cỏ què Đốm',
          text: 'Ẳng... ư ử... (Đốm dụi đầu vào ngực Khôi, ngoe nguẩy chiếc đuôi nhỏ)'
        }
      ],
      objective: 'Tương tác Két Sắt (`ket_sat_khoa_liem`) khóa chặt Liềm Tử Thần, sau đó lên Đồi Mộ (`bia_mo_tai_dog`) mang cháo ấm đón chó Đốm về đình!',
      status: 'locked',
      requiredZoneId: 'zone_doi_mo_tai_dog',
      targetCoords: { x: 800, y: 460 },
      rewardXp: 1000,
      rewardItemIds: ['item_bat_chao_ngo'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A07-E005',
      arcNumber: 7,
      title: 'Bóng Đêm Hoán Não — Điềm Báo Mở Đầu Arc 8 (2065 – 2068)',
      year: '2065 – 2068',
      location: 'Đồi Mộ Hoang & Cổng Đình Bản Cáu',
      characters: ['Hoàng Minh Bình Khôi', 'Chú chó Đốm', 'Toán Đao Thủ Tà Môn Móng Cái (Chu Mạnh Hiếu giật dây)'],
      description: [
        'Đêm khuya sau khi Tài an nghỉ chưa được bao lâu, tà khí hắc ám từ Móng Cái âm thầm tràn về khu mộ hoang Bản Cáu.',
        'Chu Mạnh Hiếu — kẻ phản đồ Hoàng Môn bị trục xuất vì luyện tà thuật Hoán Não (mổ sọ tráo não người chết sang người sống) — đã sai toán đao thủ tà môn (`ta_mon_dao_thu`) rình rập đào mộ Tài Dog hòng cướp đoạt não bộ để có huyết thống với Khôi.',
        'Chú chó Đốm thức giấc bên cổng đình, sủa vang hồi còi báo động xé màn đêm. Khôi tay không lao ra đồi mộ, dùng thân pháp "Giữ" chặn đứng và đánh gục 4 tên đao thủ tà môn bảo vệ toàn vẹn nấm mồ của cháu trai.',
        'Trước khi tan rã, tên đao thủ hé lộ trận đồ Rubik Ngục Môn Cương đang giăng sẵn tại biên giới. Khôi nắm chặt tay, sẵn sàng bước vào Arc 8: Rubik Ngục Môn Cương / Ba Chú Linh!'
      ],
      verbatimLore: [
        '“Đêm Tài mất, Hiếu đào mộ tráo não Tài vào đầu mình để có huyết thống với Khôi, dùng khuôn mặt Tài để lừa gạt tiền bạc và giật dây 3 chú linh phong ấn Khôi vào Rubik.”',
        '“Sở hữu ‘Tay Thép của Thảo’ gõ 108 nhịp vào không khí và tà thuật hút vía giữ xác.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Đao Thủ Tà Môn Móng Cái',
          text: 'Khôi già rồi! Đại ca Hiếu lệnh cho bọn tao lấy não thằng nhóc này về luyện tà thuật Hoán Não! Khôn hồn thì cút ra!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Chạm vào nấm mồ của Tài, đừng hòng ai sống sót rời khỏi đất Bình Liêu! Đốm, canh cổng đình! Để cậu dẹp sạch lũ tà ma này!'
        }
      ],
      objective: 'Cùng chú chó Đốm đánh bại 4 tên Đao Thủ Tà Môn (`ta_mon_dao_thu`), bảo vệ nấm mộ Tài Dog và mở lối bước sang Arc 8!',
      status: 'locked',
      requiredZoneId: 'zone_doi_mo_tai_dog',
      targetCoords: { x: 1200, y: 460 },
      rewardXp: 1200,
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_7_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A07-E001',
    sourceLoreSummary: 'Khôi 22 tuổi gác liềm về Bản Cáu; cháu trai Tài Dog 9 tuổi nuôi chó cỏ què Đốm; Tài bị tim bẩm sinh ngất xỉu, Khôi sắc thuốc nam cứu tỉnh.',
    inGameImplementationLocation: 'Zone Bản Cáu (`zone_ban_cau`): Bát Thuốc Nam Dưỡng Tim (`thuoc_nam_duong_tim`), NPC Lài Phúc Tài (Tài Dog) và chú chó Đốm.',
    status: 'hoàn thành',
    notes: 'Khởi đầu Arc 7, thể hiện sự che chở của Khôi với hai sinh mệnh yếu ớt tại cổng đình Lục Nà.'
  },
  {
    eventCode: 'A07-E002',
    sourceLoreSummary: 'Khôi tặng gậy trúc non mỗi dịp sinh nhật Tài dù Tài không tập võ: “Vì mày không cần học. Mày chỉ cần sống.”',
    inGameImplementationLocation: 'Zone Chùa Cổ Nguyệt (`zone_chua_co_nguyet`): Khóm Trúc Non (`cay_truc_non_tang_tai`), thu hoạch gậy trúc mang về Bản Cáu tặng Tài Dog.',
    status: 'hoàn thành',
    notes: 'Thể hiện trọn vẹn triết lý “Giữ” của Khôi: Giữ lấy sự sống và tuổi thơ bình yên cho cháu.'
  },
  {
    eventCode: 'A07-E003',
    sourceLoreSummary: 'Năm 2065, Tài bộc phát cơn đau tim qua đời; trăn trối lời thiêng liêng: “Cậu ơi, đừng bình nữa. Cứ giữ thôi...”.',
    inGameImplementationLocation: 'Zone Bản Cáu: Giường Bệnh Chòi Lá Đình Lục Nà (`giuong_benh_tai_dog`), Khôi truyền nội lực và lắng nghe lời dặn cuối.',
    status: 'hoàn thành',
    notes: 'Bước ngoặt xúc động và then chốt nhất của toàn bộ tác phẩm Bình Liêu Vương.'
  },
  {
    eventCode: 'A07-E004',
    sourceLoreSummary: 'Khôi khóa Liềm Tử Thần vào két sắt, thề ngừng “bình”; chú chó Đốm nằm phủ phục 3 ngày bên mộ được Khôi mang cháo dỗ về cổng đình.',
    inGameImplementationLocation: 'Zone Đồi Mộ Tài Dog (`zone_doi_mo_tai_dog`): Két Sắt Khóa Liềm (`ket_sat_khoa_liem`), Nấm Mộ Đất (`bia_mo_tai_dog`), chó Đốm canh mộ.',
    status: 'hoàn thành',
    notes: 'Gameplay tương tác dỗ dành chú chó Đốm và thực hiện lời thề cất vũ khí của Khôi.'
  },
  {
    eventCode: 'A07-E005',
    sourceLoreSummary: 'Toán đao thủ tà môn của Chu Mạnh Hiếu rình rập đào mộ mưu toan Hoán Não; Khôi cùng Đốm đánh lui, mở ra điềm báo Arc 8 Rubik Ngục Môn Cương.',
    inGameImplementationLocation: 'Zone Đồi Mộ Tài Dog: 4 Đao Thủ Tà Môn Móng Cái (`ta_mon_dao_thu`), bảo vệ nấm mộ và mở khóa chuyển giao sang Arc 8.',
    status: 'hoàn thành',
    notes: 'Kết nối trực tiếp, liền mạch và chuẩn xác theo đúng lore sang Arc 8: Rubik Ngục Môn Cương / Ba Chú Linh.'
  }
];

export const ARC_7_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a07_e001: {
    id: 'dialog_a07_e001',
    lines: [
      {
        speaker: {
          id: 'tai_child',
          name: 'Lài Phúc Tài (9 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Khụ... khụ... Cậu Khôi ơi, tim cháu lại thắt lại rồi... Đốm ơi, đừng liếm mặt tao, tao mệt quá...'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi (22 tuổi)',
          title: 'Người Giữ Làng',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tài! Uống bát nước thuốc ngải cứu lá tía tô ấm này đi con. Cậu đã về rồi, từ nay cậu ở đây chăm sóc cho mày và con Đốm.'
      },
      {
        speaker: {
          id: 'tai_child',
          name: 'Lài Phúc Tài (9 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Nước thuốc ngọt ấm quá cậu ơi. Cậu đừng đi xa nữa nhé, ở cổng đình chơi với cháu và con Đốm nha cậu!'
      }
    ]
  },

  dialog_a07_e002: {
    id: 'dialog_a07_e002',
    lines: [
      {
        speaker: {
          id: 'tai_teen',
          name: 'Lài Phúc Tài (14 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Woa! Lại là một cây gậy trúc non bóng loáng! Cậu Khôi tự tay lên Chùa Cổ Nguyệt chặt về tặng sinh nhật cháu hả cậu?'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi (27 tuổi)',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Ừ. Cây trúc này nhẵn mịn, không có mấu nhọn, cậu đã vót tròn đầu rồi. Cầm lấy chống gậy đi dạo quanh bản với con Đốm.'
      },
      {
        speaker: {
          id: 'tai_teen',
          name: 'Lài Phúc Tài (14 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Người trong bản bảo cậu là đệ nhất cao thủ, sao cậu không dạy cháu chém liềm? Cháu cũng muốn ngầu như cậu!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi (27 tuổi)',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Mày không cần học võ đâu Tài à. Mày chỉ cần sống thôi. Đời chém giết cay đắng lắm, để một mình cậu gánh là đủ rồi.'
      }
    ]
  },

  dialog_a07_e003: {
    id: 'dialog_a07_e003',
    lines: [
      {
        speaker: {
          id: 'tai_dying',
          name: 'Lài Phúc Tài (18 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Cậu ơi... Gió đông ngoài kia thổi lạnh quá... Tay cậu... sao run thế này cậu ơi...'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cậu đang truyền nội lực sưởi ấm cho mày đây Tài! Đừng nhắm mắt, nghe cậu nói, mở mắt ra nhìn con Đốm kìa!'
      },
      {
        speaker: {
          id: 'tai_dying',
          name: 'Lài Phúc Tài (18 tuổi)',
          title: 'Tài Dog',
          color: '#f59e0b',
          avatarId: 'avatar_tai'
        },
        text: 'Cháu mệt lắm rồi cậu ơi... Cháu thấy Cụ Thọ đang đứng đón cháu bên khóm trúc... Cậu hứa với cháu đi... Đừng "bình" nữa nhé cậu... Cứ giữ thôi... Cứ giữ thôi cậu ơi...'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'TÀI ƠI! CẬU HỨA MÀ! CẬU KHÔNG BÌNH NỮA! CẬU CHỈ GIỮ THÔI MÀ TÀI ƠI! MỞ MẮT RA ĐI CON ƠI...!'
      }
    ]
  },

  dialog_a07_e004: {
    id: 'dialog_a07_e004',
    lines: [
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Lưỡi liềm này đã từng chém tan bão tuyết Shibuya... Nhưng hôm nay, ta khóa nó lại. Từ nay, Bình Liêu Vương đã chết, chỉ còn một kẻ giữ làng già nua giữ lời hứa với cháu mình.'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Đốm... Mưa tuyết 3 ngày rồi con ơi. Mày nằm đây gầy rộc cả người. Ăn bát cháo ngô này đi... Về cổng đình với cậu, hai cậu cháu mình cùng canh cho thằng Tài ngủ yên.'
      },
      {
        speaker: {
          id: 'dom',
          name: 'Chú chó cỏ què Đốm',
          title: 'Linh Khuyển Canh Cổng',
          color: '#cbd5e1',
          avatarId: 'avatar_dom'
        },
        text: 'Ẳng... ẳng... (Đốm quấn quýt dụi chiếc mõm ướt đẫm nước mưa vào bàn tay Khôi, cất bước ba chân tập tễnh theo Khôi về đình)'
      }
    ]
  },

  dialog_a07_e005: {
    id: 'dialog_a07_e005',
    lines: [
      {
        speaker: {
          id: 'ta_mon',
          name: 'Đao Thủ Tà Môn Móng Cái',
          title: 'Tay Sai Chu Mạnh Hiếu',
          color: '#ef4444',
          avatarId: 'avatar_bandit'
        },
        text: 'Lão già Khôi cất liềm rồi, chẳng khác nào hổ rụng nanh! Mau đào nấm mộ này lên, lấy đầu thằng nhóc Tài mang về dâng cho đại ca Hiếu luyện Hoán Não!'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Dù tao không cầm liềm, thân pháp này vẫn đủ để tước mạng lũ tà ma! Chạm vào mộ của Tài, đất Bình Liêu sẽ là mồ chôn của chúng mày!'
      },
      {
        speaker: {
          id: 'ta_mon',
          name: 'Đao Thủ Tà Môn Móng Cái',
          title: 'Tay Sai Chu Mạnh Hiếu',
          color: '#ef4444',
          avatarId: 'avatar_bandit'
        },
        text: 'Hộc... Lão già này tay không mà đấm gãy cả đao thép! Đại ca Hiếu... khối đá Rubik Ngục Môn Cương bên kia biên giới... sẽ kéo lão xuống địa ngục!'
      }
    ]
  }
};

export const ARC_8_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a08_e001: {
    id: 'dialog_a08_e001',
    lines: [
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tiếng gõ 108 nhịp âm vang trong lòng đất... Ma trận bẫy đá 6 mặt Rubik Ngục Môn Cương! Ba người họ... thật sự đang ở đây sao?'
      },
      {
        speaker: {
          id: 'spirit_voices',
          name: 'Ba Chú Linh Biên Giới',
          title: 'Hình Bóng Thoắt Ẩn Thoắt Hiện',
          color: '#a855f7',
          avatarId: 'avatar_bandit'
        },
        text: 'Khôi ơi... quay về đi... Chu Mạnh Hiếu nó dọa mổ sọ cả nhà tao nếu không yểm bùa nhốt mày... Cửa này vào rồi không ai kéo ra được đâu...!'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Năm xưa ở Shibuya, tao liều mạng giữ đường sống cho chúng mày. Hôm nay tao đến đây không phải để trả thù, mà để hóa giải nỗi sợ hãi cho tất cả!'
      }
    ]
  },
  dialog_a08_e002: {
    id: 'dialog_a08_e002',
    lines: [
      {
        speaker: {
          id: 'spirit_tuan',
          name: 'Đinh Quốc Tuấn (60 tuổi)',
          title: 'Kẻ Vác Cán Quét / Thằng Ghi Sổ',
          color: '#c084fc',
          avatarId: 'avatar_bandit'
        },
        text: 'Khôi ơi... đừng trách tao... Chu Mạnh Hiếu bắt tao phải cầm sổ đỏ này ghi tên mày, rải muối đen phong bế tử huyệt! Bọn tao sợ chết lắm Khôi ơi...!'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Chú Tuấn... cán quét ngày xưa chú rải muối cứu người trong bão tuyết, sao giờ lại để tà khí vấy bẩn? Đưa cuốn sổ đây, con tha thứ cho chú!'
      },
      {
        speaker: {
          id: 'spirit_tuan',
          name: 'Đinh Quốc Tuấn (60 tuổi)',
          title: 'Buông Cán Quét Quỳ Khóc',
          color: '#c084fc',
          avatarId: 'avatar_bandit'
        },
        text: 'Hu hu... Tao sai rồi... Cuốn sổ đỏ ghi phù chú đây... Mặt bùa thứ nhất của khối Rubik đã tan rồi Khôi ơi!'
      }
    ]
  },
  dialog_a08_e003: {
    id: 'dialog_a08_e003',
    lines: [
      {
        speaker: {
          id: 'spirit_tay',
          name: 'Ông Táy',
          title: 'Mặt Nứt 6 Vết Rubik / Lò Than Tà Khí',
          color: '#34d399',
          avatarId: 'avatar_bandit'
        },
        text: 'Nóng quá... Mặt tao nứt ra 6 vết đau buốt... Khôi ơi, Chu Mạnh Hiếu cướp não của thằng Tài thật rồi! Nó lệnh cho tao ném than ngục môn thiêu rụi mày!'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Bác Táy! Lò than bánh mì của bác từng sưởi ấm hàng trăm đồng hương giữa đêm đông Shibuya. Để con dập tắt tà hỏa này cho bác!'
      },
      {
        speaker: {
          id: 'spirit_tay',
          name: 'Ông Táy',
          title: 'Rơi Lệ Bên Ổ Bánh Mì Cháy',
          color: '#34d399',
          avatarId: 'avatar_bandit'
        },
        text: 'Khôi... tà hỏa tắt rồi... Cầm lấy mảnh bùa lò than này... Hãy cẩn thận thằng Hùng Đỏ, nó đang cầm chiếc chìa khóa định mệnh!'
      }
    ]
  },
  dialog_a08_e004: {
    id: 'dialog_a08_e004',
    lines: [
      {
        speaker: {
          id: 'spirit_hung',
          name: 'Hùng Đỏ',
          title: 'Giang Hồ Áo Đỏ / Kẻ Đâm Sau',
          color: '#f87171',
          avatarId: 'avatar_bandit'
        },
        text: 'Á... Nhát dao của em... sao không thể xuyên qua thân pháp của anh?! Anh Khôi... em là thằng đốn mạt... em sợ bị mổ sọ nên mới lén đâm sau lưng anh!'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Hùng Đỏ... chiếc áo đỏ này mày từng khoác để đỡ đạn cho con tin. Mày sợ chết, đó là bản năng con người. Tao không trách. Đưa chìa khóa Rubik cho tao!'
      },
      {
        speaker: {
          id: 'spirit_hung',
          name: 'Hùng Đỏ',
          title: 'Gục Ngã Trao Chìa Khóa',
          color: '#f87171',
          avatarId: 'avatar_bandit'
        },
        text: 'Anh Khôi... Đây là chiếc chìa khóa khối Rubik... Em quỳ lạy tạ tội với anh và linh hồn thằng bé Tài!'
      }
    ]
  },
  dialog_a08_e005: {
    id: 'dialog_a08_e005',
    lines: [
      {
        speaker: {
          id: 'ba_man',
          name: 'Bà Mận',
          title: 'Người Thôn Bản Chân Chất',
          color: '#fcd34d',
          avatarId: 'avatar_la_thanh'
        },
        text: 'Khôi ơi... Bà lụi cụi nấu bát cháo gừng nóng mang lên đây cho con. Gió bấc buốt quá, uống đi cho ấm bụng con ơi... Đời người ai chẳng sợ chết, đừng để cái lạnh làm đông cứng tình người.'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Người Canh Cổng Đình',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Bát cháo gừng của bà thơm nồng mùi gừng sẻ Bản Cáu... Uống vào ấm từ lồng ngực lan đến đầu ngón tay. Con cảm ơn bà!'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Nhìn Ba Chú Linh',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Ba chú hãy đứng dậy, theo bà Mận về làng trốn kỹ đi. Tao không giết ai cả. Lời dặn của thằng Tài tao vẫn giữ: Cứ giữ thôi. Mọi chuyện còn lại, tao sẽ gánh vác!'
      }
    ]
  },
  dialog_a08_e006: {
    id: 'dialog_a08_e006',
    lines: [
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Trước Khối Rubik 1m³',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi này đã mất đi nỗi sợ từ lâu. Khối đá 1m³ này sẽ là nơi tao thiền định 3 năm (2065 – 2068).'
      },
      {
        speaker: {
          id: 'khoi_old',
          name: 'Hoàng Minh Bình Khôi (57 tuổi)',
          title: 'Tra Chìa Khóa Vào Ổ Ngục Môn',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tài ơi... Cậu ngồi đây giữ cho não mày mục rã hoàn toàn. Ba năm nữa, thằng Dư sẽ gõ 108 nhịp kéo cậu dậy để kết thúc Chu Mạnh Hiếu!'
      },
      {
        speaker: {
          id: 'rubik_echo',
          name: 'Khối Đá Rubik Ngục Môn Cương',
          title: '108 Nhịp Phong Ấn Thời Gian',
          color: '#ef4444',
          avatarId: 'avatar_bandit'
        },
        text: 'Keng... Keng... Keng... (Khối Rubik 1m³ xoay chuyển 6 mặt, tỏa hào quang tím lam bao bọc lấy Khôi, phong ấn kiên cố mở ra định mệnh 3 năm!)'
      }
    ]
  }
};

export const ARC_8_DATA: ArcCatalog = {
  arcNumber: 8,
  title: 'Arc 8: Rubik Ngục Môn Cương — Ba Chú Linh',
  timeframe: '2065 – 2068',
  mainCharacters: [
    'Hoàng Minh Bình Khôi (57 tuổi)',
    'Đinh Quốc Tuấn (Kẻ Vác Cán Quét / Thằng Ghi Sổ)',
    'Ông Táy (Bán Bánh Mì Nóng 24/7 / Mặt Nứt 6 Vết Rubik)',
    'Hùng Đỏ (Giang Hồ Áo Đỏ / Kẻ Đâm Sau)',
    'Bà Mận (Người Nấu Bát Cháo Gừng Ấm Tình Người)',
    'Chu Mạnh Hiếu (Bóng Ma Giật Dây Tà Thuật Hoán Não)'
  ],
  corePhilosophy: '“Cửa này mở một lần. Vào rồi, không có ai kéo mày ra... Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi tự bước vào là không còn sợ chết.”',
  summary: 'Sau khi đánh lui đám tà môn đào mộ Tài Dog, Khôi lần theo dấu vết tà thuật đến trận địa ma trận Rubik Ngục Môn Cương 1m³ tại biên giới. Ba người đồng hương từng được Khôi xả thân cứu sống tại Shibuya (Đinh Quốc Tuấn, Ông Táy, Hùng Đỏ) vì nỗi sợ hãi cái chết và sự đe dọa mổ sọ của Chu Mạnh Hiếu mà quay lưng yểm bùa phong ấn ân nhân. Khôi dùng quyền cước hóa giải bùa muối đen của Tuấn, dập tắt lò than tà khí của Ông Táy, tước dao găm chìa khóa của Hùng Đỏ mà không sát hại họ. Giữa bão tuyết biên giới lạnh giá, Bà Mận mang bát cháo gừng ấm đến cho Khôi. Với tấm lòng bao dung, Khôi tha thứ cho Ba Chú Linh và tự nguyện bước vào khối đá Rubik 1m³, tự phong ấn chính mình suốt 3 năm (2065 – 2068) chờ não Tài mục rã để phá giải tà thuật Hoán Não, giữ gìn bình yên cho thôn bản.',
  events: [
    {
      id: 'A08-E001',
      arcNumber: 8,
      title: 'Tiếng Gõ 108 Nhịp & Trận Đồ Biên Giới (2065)',
      year: '2065',
      location: 'Trận Địa Bẫy Đá Biên Giới (Ma Trận Rubik Ngục Môn Cương)',
      characters: ['Hoàng Minh Bình Khôi (57 tuổi)', 'Ba Chú Linh Thoắt Ẩn Thoắt Hiện'],
      description: [
        'Năm 2065, ngay sau đêm Tài Dog mất và đám đao thủ tà môn bị đẩy lui, Khôi cầm theo tín vật tà môn (`item_nhan_tin_nguc_mon_cuong`) vượt đồi sương mù tiến về vùng biên giới hiểm trở.',
        'Tại đây sương mù dày đặc nhuốm ánh tím đen ma quái, mặt đất nứt toác để lộ các cột đá khắc phù chú Tày và Hán cổ.',
        'Ở trung tâm trận địa sừng sững Khối Đá Rubik Ngục Môn Cương kích thước chuẩn xác 1m x 1m (1m³), 6 mặt xoay chuyển với các luồng năng lượng tà ác chấn động.',
        'Từ trong khối đá vọng ra tiếng gõ 108 nhịp như chuông báo tử, cùng bóng hình Ba Chú Linh chập chờn trên các mỏm đá cao.',
        'Khôi tiến tới kích hoạt nhận diện trận đồ bẫy đá 6 mặt, chuẩn bị đối diện với thử thách đau đớn nhất: sự phản bội từ những người mình từng coi như máu thịt.'
      ],
      verbatimLore: [
        '“Hộp đá Rubik 1m³ yểm bùa; Khôi tự ở lại vì bát cháo gừng bà Mận.”',
        '“Năm 2068, chính Dư gõ 108 nhịp vào khối đá Rubik Ngục Môn Cương để kéo Khôi trở lại.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Tiếng gõ 108 nhịp... Trận đồ bẫy đá 6 mặt Rubik Ngục Môn Cương! Ba người họ... thật sự đang ở đây sao?'
        },
        {
          speaker: 'Bóng Hình Ba Chú Linh',
          text: 'Khôi ơi... quay về đi... Chu Mạnh Hiếu sẽ không tha cho ai đâu... Cửa này mở một lần, vào rồi không ai kéo ra được đâu...!'
        }
      ],
      objective: 'Tiến vào Ma Trận Rubik Ngục Môn Cương (`zone_nguc_mon_cuong`), tiếp cận Khối Đá Rubik 1m³ (`rubik_cube_center`) để nhận diện trận đồ bẫy đá!',
      status: 'active',
      requiredZoneId: 'zone_nguc_mon_cuong',
      targetCoords: { x: 1200, y: 460 },
      rewardXp: 800,
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A08-E002',
      arcNumber: 8,
      title: 'Đinh Quốc Tuấn — Muối Đen Phong Lộ & Cuốn Sổ Đỏ (Mặt Bùa 1 & 2)',
      year: '2065',
      location: 'Bình Đài Muối Đen Phía Tây Ma Trận Rubik',
      characters: ['Hoàng Minh Bình Khôi', 'Đinh Quốc Tuấn (Kẻ Vác Cán Quét / Thằng Ghi Sổ)'],
      description: [
        'Mặt bùa thứ nhất của Rubik bốc lên hàn khí đen kịt. Đinh Quốc Tuấn (60 tuổi) xuất hiện trên bình đài đá, vác chiếc cán quét đã nhuộm đen và tay cầm cuốn sổ đỏ yểm bùa.',
        'Người đàn ông từng quét muối mở đường sinh tử cho dân lánh nạn ở Shibuya nay run rẩy vì bị Chu Mạnh Hiếu đe dọa mổ sọ cả gia đình nếu không vâng lệnh.',
        'Tuấn tung bùa muối đen tạo chông gai mặt đất và dựng thùng rác phong ấn phản chấn hòng ngăn cản bước chân Khôi.',
        'Khôi dùng quyền pháp và gậy trúc đánh gãy rào chắn muối đen, áp sát tước cán quét của Tuấn mà không làm tổn thương tính mạng chú.',
        'Tuấn ngã quỵ xuống đống muối đen, buông rơi Cuốn Sổ Đỏ (`item_so_do_dinh_quoc_tuan`), khóc ròng xin lỗi vì nỗi hèn nhát của con người trước cái chết.'
      ],
      verbatimLore: [
        '“Đinh Quốc Tuấn quét đường rải muối... Thằng ghi sổ cầm cuốn sổ đỏ, ghi tên Khôi không ngừng.”',
        '“Ba người từng được Khôi cứu quay lưng vì sợ hãi.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Đinh Quốc Tuấn',
          text: 'Khôi ơi... đừng trách tao... Hiếu nó dọa mổ sọ cả nhà tao, tráo não như nó làm với thằng Tài! Tao phải ghi tên mày vào sổ bùa này để mặt Rubik khóa chặt!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Chú Tuấn... muối trắng Shibuya để cứu người, sao lại đem muối đen yểm hại đồng hương? Con không trách chú sợ chết, con sẽ phá tan rào chắn bùa này!'
        }
      ],
      objective: 'Đánh bại hình bóng Đinh Quốc Tuấn (`spirit_tuan`) và tương tác Bàn Thờ Bùa Muối Đen (`altar_muoi_den`) để giải phóng Mặt Bùa 1 trên Khối Rubik!',
      status: 'locked',
      requiredZoneId: 'zone_nguc_mon_cuong',
      targetCoords: { x: 500, y: 460 },
      rewardXp: 1000,
      rewardItemIds: ['item_so_do_dinh_quoc_tuan'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A08-E003',
      arcNumber: 8,
      title: 'Ông Táy — Lò Than Tà Khí & Mặt Nứt 6 Vết (Mặt Bùa 3 & 4)',
      year: '2065',
      location: 'Lò Lửa Hắc Khí Phía Đông Ma Trận Rubik',
      characters: ['Hoàng Minh Bình Khôi', 'Ông Táy (Bán Bánh Mì Nóng / Thằng Bỏ Bùa)'],
      description: [
        'Mặt bùa thứ hai của Rubik bốc khói cay nồng mùi lưu huỳnh. Ông Táy xuất hiện với khuôn mặt nứt toác 6 vết như 6 mặt của khối Rubik, đôi mắt lờ đờ rỉ tà khí.',
        'Chiếc xe bánh mì lò than 24/7 ấm nóng nghĩa tình ngày nào đã bị Chu Mạnh Hiếu biến thành vạc than ngục môn, ném ra những quả cầu than tà hỏa thiêu đốt tâm can.',
        'Khôi tả xung hữu đột né tránh hỏa bùa máu gà, vung chân đá lật vạc than đen, dùng kình lực dập tắt ngọn lửa độc đang thiêu đốt Ông Táy.',
        'Ngọn lửa tắt lịm, khuôn mặt Ông Táy trở lại bình thường nhưng kiệt sức run rẩy. Ông Táy rơi giọt nước mắt trên ổ bánh mì cháy khét, trao lại Mảnh Bùa Lò Than (`item_manh_bua_ong_tay`).'
      ],
      verbatimLore: [
        '“Ông Táy... mặt nứt ra 6 vết như 6 mặt Rubik, bùa máu gà.”',
        '“Lò Than Không Tắt... ném than hồng.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Ông Táy',
          text: 'Nóng quá... lửa ngục môn thiêu cháy não tao rồi Khôi ơi... Hiếu nó cướp não thằng Tài rồi, cái hộp đá 1m³ này sẽ nhốt linh hồn mày đời đời kiếp kiếp!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Bác Táy! Tỉnh lại đi bác! Bánh mì lò than của bác từng cứu đói bao người nơi đất khách, con sẽ không để lửa tà môn thiêu rụi lương tri của bác!'
        }
      ],
      objective: 'Đánh bại hình bóng Ông Táy (`spirit_tay`) và tương tác Vạc Than Tà Khí (`altar_lo_than`) để giải phóng Mặt Bùa 2 trên Khối Rubik!',
      status: 'locked',
      requiredZoneId: 'zone_nguc_mon_cuong',
      targetCoords: { x: 1900, y: 460 },
      rewardXp: 1100,
      rewardItemIds: ['item_manh_bua_ong_tay'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A08-E004',
      arcNumber: 8,
      title: 'Hùng Đỏ — Nhát Dao Phản Bội & Chìa Khóa Ngục Môn (Mặt Bùa 5)',
      year: '2065',
      location: 'Cầu Đá Trung Tâm — Ngay Trước Khối Rubik',
      characters: ['Hoàng Minh Bình Khôi', 'Hùng Đỏ (Giang Hồ Áo Đỏ / Kẻ Đâm Sau)'],
      description: [
        'Khi Khôi tiến lại gần khối Rubik, một bóng đỏ vụt lướt qua cực nhanh từ trong góc khuất. Hùng Đỏ — người thanh niên áo đỏ từng lao ra đỡ đạn cho Khôi ở Shibuya — xuất hiện với ánh mắt dại đi.',
        'Chiếc áo khoác vẫn đỏ rực, nhưng trên tay Hùng Đỏ không phải súng bảo vệ mà là con dao găm tà thuật và chiếc chìa khóa ma trận Rubik.',
        'Bị tà thuật Chu Mạnh Hiếu sai khiến và nỗi sợ hãi bủa vây, Hùng Đỏ tung ra nhát đâm bất ngờ nhằm sau lưng Khôi.',
        'Khôi bằng trực giác chiến trận lão luyện nghiêng người tránh đường dao chí mạng, dùng chiêu "Giữ" bẻ gãy đao tà và tước lấy Chìa Khóa Ma Trận Rubik (`item_chia_khoa_hung_do`).',
        'Hùng Đỏ ngã rạp xuống đất ôm mặt gào khóc trong sự tủi hổ cùng cực: "Anh Khôi... em là thằng đê tiện... giết em đi!"'
      ],
      verbatimLore: [
        '“Hùng Đỏ... Thằng đâm sau: áo vẫn đỏ, tay vẫn cầm chìa khóa Rubik.”',
        '“Đinh Quốc Tuấn quét. Ông Táy giữ lửa. Hùng Đỏ đỡ đạn.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hùng Đỏ',
          text: 'Anh Khôi... Tha thứ cho em... Hiếu bảo nếu không đâm nhát dao này và khóa anh vào Rubik, nó sẽ xé xác em thành trăm mảnh... Em sợ lắm anh ơi!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Hùng Đỏ... chiếc áo đỏ này mày từng mặc để đỡ đạn cho đồng hương. Nhát dao này tao không tính, mạng của mày tao vẫn giữ!'
        }
      ],
      objective: 'Hóa giải đòn tấn công của Hùng Đỏ (`spirit_hung`) và tương tác Ổ Khóa Dao Đỏ (`altar_dao_hung`) để thu hồi Chìa Khóa Ngục Môn Cương!',
      status: 'locked',
      requiredZoneId: 'zone_nguc_mon_cuong',
      targetCoords: { x: 1550, y: 460 },
      rewardXp: 1200,
      rewardItemIds: ['item_chia_khoa_hung_do'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A08-E005',
      arcNumber: 8,
      title: 'Bà Mận — Bát Cháo Gừng Tình Người & Lòng Trắc Ẩn Giữa Bão Lạnh',
      year: '2065',
      location: 'Chân Tháp Đá Cổ — Ven Bẫy Đá Ma Trận',
      characters: ['Hoàng Minh Bình Khôi', 'Bà Mận', 'Ba Chú Linh Đang Quỳ Tạ Tội'],
      description: [
        'Gió bấc rít gào buốt giá cắt da thịt trên trận địa ma trận biên giới. Giữa không gian u ám, một bóng dáng già nua còng lưng chống gậy tre từng bước leo lên dốc đá.',
        'Đó là Bà Mận — cụ bà chất phác của thôn Bản Cáu, người cả đời gắn bó với mảnh đất biên cương, mang trên tay chiếc rổ mây ủ ấm Bát Cháo Gừng nghi ngút khói cay nồng.',
        'Bà Mận nhìn Khôi, nhìn Ba Chú Linh đang quỳ gối run rẩy ôm mặt khóc, thở dài nói: "Ăn bát cháo gừng cho ấm bụng con ơi... Đời người ai chẳng có lúc khiếp sợ cái chết... Đừng để cái lạnh làm đông cứng tình người."',
        'Khôi đỡ lấy bát cháo gừng thơm phức, uống cạn từng thìa cháo cay ấm lan tỏa khắp lồng ngực. Khôi nhìn Ba Chú Linh, mỉm cười bao dung bảo họ hãy mau quay về làng trốn kỹ, việc bảo vệ đất Bình Liêu và linh hồn thằng Tài cứ để Khôi giữ.',
        'Chính Bát Cháo Gừng của Bà Mận đã cởi bỏ toàn bộ oán hận, giúp tâm thức Khôi đạt đến cảnh giới vô úy tuyệt đối.'
      ],
      verbatimLore: [
        '“Khôi tự ở lại vì bát cháo gừng bà Mận.”',
        '“Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi mở cửa một lần là mất đi nỗi sợ.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Bà Mận',
          text: 'Khôi à... Bà mang cho con bát cháo gừng nóng đây. Uống đi con... Ngoài này buốt lắm, nhưng cái rét của lòng người còn lạnh hơn. Ba đứa nó lầm đường vì sợ chết, tha cho chúng nó con nhé.'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Cháo gừng của bà ấm quá... ấm từ cổ họng vào tận tim. Ba chú, đứng dậy về đi. Tao không hận ai cả. Lời thằng Tài dặn tao còn nhớ: Cứ giữ thôi. Tao sẽ giữ cho mảnh đất này bình yên!'
        }
      ],
      objective: 'Tương tác với Bà Mận (`bep_chao_gung`), đón nhận Bát Cháo Gừng Ấm Tình Người (`item_bat_chao_gung_ba_man`) và tha thứ cho Ba Chú Linh!',
      status: 'locked',
      requiredZoneId: 'zone_nguc_mon_cuong',
      targetCoords: { x: 950, y: 460 },
      rewardXp: 1300,
      rewardItemIds: ['item_bat_chao_gung_ba_man'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A08-E006',
      arcNumber: 8,
      title: 'Khối Đá Rubik 1m³ — Khôi Tự Nguyện Ở Lại & Định Mệnh 3 Năm (2065 – 2068)',
      year: '2065 – 2068',
      location: 'Trung Tâm Khối Đá Rubik Ngục Môn Cương',
      characters: ['Hoàng Minh Bình Khôi (57 tuổi)', 'Khối Đá Rubik Ngục Môn Cương 1m³'],
      description: [
        'Khôi tiến lại trước Khối Đá Rubik Ngục Môn Cương 1m x 1m. Sáu mặt đá phù chú lúc này đã giải trừ toàn bộ tà khí, chỉ còn lại luồng sáng ma trận huyền bí xoay vần theo nhịp thở của núi rừng.',
        'Khôi hiểu rõ: Chu Mạnh Hiếu sau khi cướp não Tài Dog đang lùng sục thân xác Khôi để hoàn tất tà thuật Hoán Não nhằm chiếm đoạt danh tính Bình Liêu Vương.',
        'Nếu Khôi bỏ đi, Hiếu sẽ tàn sát thôn Bản Cáu. Hơn nữa, tế bào não của Tài cần đúng 3 năm (2065 – 2068) để mục rã hoàn toàn, khiến tà thuật Hoán Não vĩnh viễn không thể đồng hóa trọn vẹn.',
        'Khôi tra chiếc chìa khóa của Hùng Đỏ vào ổ khóa trung tâm, đặt bát cháo gừng đã cạn làm neo điểm ký ức, rồi mỉm cười tự nguyện bước chân vào bên trong khối đá Rubik 1m³.',
        'Khối đá Rubik khép lại, phong ấn 108 nhịp đóng kín không gian. Khôi ngồi thiền định bên trong khối đá suốt 3 năm ròng rã, bảo bọc linh hồn Tài và chờ đợi ngày người anh em Lục Triều Dư gõ 108 nhịp kéo mình trở lại.'
      ],
      verbatimLore: [
        '“Khôi ngồi trong Rubik 3 năm chờ não Tài mục rã.”',
        '“Năm 2068, chính Dư gõ 108 nhịp vào khối đá Rubik Ngục Môn Cương để kéo Khôi trở lại.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Bình Khôi (57 tuổi)',
          text: 'Tài ơi... Cậu không chạy trốn. Cậu ở lại đây, trong khối Rubik 1m³ này canh cho mày ngủ yên 3 năm. Chờ não mày mục rã, tà thuật của Chu Mạnh Hiếu sẽ tự tan tành. Ba năm sau... Dư sẽ kéo cậu dậy!'
        },
        {
          speaker: 'Khối Đá Rubik Ngục Môn Cương',
          text: 'Keng... Keng... (108 nhịp gõ ngân vang, 6 mặt Rubik chuyển màu đá xám cổ kính, khép lại phong ấn thời gian 2065 – 2068)'
        }
      ],
      objective: 'Tương tác với Khối Đá Rubik 1m³ (`rubik_cube_center`), tra chìa khóa kích hoạt 6 mặt bùa và tự nguyện bước vào phong ấn 3 năm (2065 – 2068)!',
      status: 'locked',
      requiredZoneId: 'zone_nguc_mon_cuong',
      targetCoords: { x: 1200, y: 460 },
      rewardXp: 2000,
      rewardItemIds: ['item_khoi_rubik_1m'],
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_8_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A08-E001',
    sourceLoreSummary: 'Khôi 57 tuổi lần theo dấu vết tà thuật đến trận địa biên giới; phát hiện Khối Đá Rubik 1m³ phát ra tiếng gõ 108 nhịp; bóng dáng Ba Chú Linh thoắt ẩn thoắt hiện.',
    inGameImplementationLocation: 'Zone Ma Trận Rubik Ngục Môn Cương (`zone_nguc_mon_cuong`): Khối Đá Rubik 1m³ (`rubik_cube_center`), tiếng gõ 108 nhịp và sương mù tím đỏ.',
    status: 'hoàn thành',
    notes: 'Mở đầu Arc 8, người chơi trực tiếp di chuyển khám phá trận đồ bẫy đá 6 mặt 1m³ theo đúng nguyên tác.'
  },
  {
    eventCode: 'A08-E002',
    sourceLoreSummary: 'Đinh Quốc Tuấn (Kẻ Vác Cán Quét / Thằng Ghi Sổ) sợ Chu Mạnh Hiếu mổ sọ cả nhà nên quay lưng rải muối đen yểm bùa; Khôi đánh lui và giải phóng bùa muối.',
    inGameImplementationLocation: 'Zone Ma Trận Rubik: Boss Đinh Quốc Tuấn (`spirit_tuan`) thi triển muối đen, Bàn Thờ Bùa Muối (`altar_muoi_den`), nhận Sổ Đỏ Phù Chú (`item_so_do_dinh_quoc_tuan`).',
    status: 'hoàn thành',
    notes: 'Trận chiến đối kháng bùa chú và cán quét rải muối, giải khai mặt Rubik 1 mà không sát hại Tuấn.'
  },
  {
    eventCode: 'A08-E003',
    sourceLoreSummary: 'Ông Táy mặt nứt ra 6 vết như Rubik, bị tà thuật điều khiển ném than hồng hắc ám; Khôi phá tan vạc than độc, Ông Táy rơi lệ thú nhận âm mưu cướp não của Hiếu.',
    inGameImplementationLocation: 'Zone Ma Trận Rubik: Boss Ông Táy (`spirit_tay`), Vạc Than Hắc Khí (`altar_lo_than`), thu hồi Mảnh Bùa Lò Than (`item_manh_bua_ong_tay`).',
    status: 'hoàn thành',
    notes: 'Cơ chế né tránh than nổ và bùa máu gà, giải tỏa ngọn lửa hắc ám trên khuôn mặt 6 vết nứt của Ông Táy.'
  },
  {
    eventCode: 'A08-E004',
    sourceLoreSummary: 'Hùng Đỏ áo vẫn đỏ nhưng tay cầm chìa khóa Rubik, tung nhát dao đâm sau lưng Khôi vì sợ chết; Khôi tước vũ khí và chìa khóa mà tha mạng cho Hùng.',
    inGameImplementationLocation: 'Zone Ma Trận Rubik: Boss Hùng Đỏ (`spirit_hung`) lướt đâm sau, Ổ Khóa Dao Đỏ (`altar_dao_hung`), thu hồi Chìa Khóa Ngục Môn (`item_chia_khoa_hung_do`).',
    status: 'hoàn thành',
    notes: 'Thử thách phản xạ tốc độ cao; người chơi tước vũ khí Hùng Đỏ, thể hiện triết lý "Giữ" kiên định.'
  },
  {
    eventCode: 'A08-E005',
    sourceLoreSummary: 'Bà Mận mang Bát Cháo Gừng nóng hổi đến giữa bão tuyết; Khôi uống cạn cháo gừng, tha thứ cho Ba Chú Linh và xóa bỏ mọi hoảng loạn, sợ hãi.',
    inGameImplementationLocation: 'Zone Ma Trận Rubik: NPC Bà Mận (`bep_chao_gung`), nhận Bát Cháo Gừng Ấm Tình Người (`item_bat_chao_gung_ba_man`), hồi phục sinh lực.',
    status: 'hoàn thành',
    notes: 'Điểm sáng nhân văn cốt lõi của tác phẩm: Bát cháo gừng của Bà Mận xua tan cái lạnh và nỗi sợ phản bội.'
  },
  {
    eventCode: 'A08-E006',
    sourceLoreSummary: 'Khôi tự nguyện bước vào khối đá Rubik 1m³, tự phong ấn 3 năm (2065 – 2068) chờ não Tài mục rã, mở đường cho Lục Triều Dư gõ 108 nhịp kéo Khôi ra (Arc 10).',
    inGameImplementationLocation: 'Zone Ma Trận Rubik: Tương tác Khối Đá Rubik 1m³ (`rubik_cube_center`), tra chìa khóa kích hoạt 6 mặt phong ấn, hoàn thành Arc 8.',
    status: 'hoàn thành',
    notes: 'Kết thúc Arc 8 hào hùng và cảm động; nối tiếp hoàn hảo sang Arc 9 (Chu Mạnh Hiếu) và Arc 10 (Lục Triều Dư).'
  }
];

export const ARC_9_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a09_e001: {
    id: 'dialog_a09_e001',
    lines: [
      {
        speaker: {
          id: 'cho_dom',
          name: 'Chó Đốm (Bản Cáu)',
          title: 'Bạn trung thành của Tài Dog',
          color: '#fbbf24',
          avatarId: 'avatar_tai'
        },
        text: 'Ẳng... Ẳng... Gâu gâu! (Đốm cào móng vào nấm mộ đất đỏ bị đào xới tung tóe, đôi mắt ầng ậc nước nhìn vào huyệt mộ trống hoác)'
      },
      {
        speaker: {
          id: 'khoi_57',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương (57 tuổi)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Nấm mộ của thằng Tài... bị đào xới tung rồi! Nắp ván vỡ vụn... thi thể thằng bé bị mổ sọ, hộp sọ rỗng không! Quân súc sinh tà môn nào dám làm chuyện nghịch thiên này?!'
      },
      {
        speaker: {
          id: 'khoi_57',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Lần theo dấu vết tà thuật',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cuốc đào mộ tà môn khắc bùa huyết chú... Mảnh áo sát nách rách màu chàm của Chu Mạnh Hiếu... Và vệt ma khí từ Tay Thép của Thảo gõ 108 nhịp! Là Hiếu! Hắn dùng thuật Hoán Não tráo não thằng Tài! Dấu vết tà khí dẫn thẳng về Hang Đá Lạng Sơn!'
      }
    ]
  },

  dialog_a09_e002: {
    id: 'dialog_a09_e002',
    lines: [
      {
        speaker: {
          id: 'ta_su_dau_so',
          name: 'Tà Sư Hoán Não Lạng Sơn',
          title: 'Đệ tử tà môn Chu Mạnh Hiếu',
          color: '#c084fc',
          avatarId: 'avatar_bandit'
        },
        text: 'Khặc khặc... Bình Liêu Vương! Mày đến muộn rồi! Sư phụ Chu Mạnh Hiếu của chúng tao đã hoàn tất thuật Hoán Não trên bàn mổ đá này! Máu mủ của Hoàng Minh Khôi sắp thuộc về sư phụ tao!'
      },
      {
        speaker: {
          id: 'khoi_57',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Bàn mổ mổ sọ dã man... Lũ chúng mày nhẫn tâm cướp đoạt cả người đã khuất! Hôm nay tao phá tan lò luyện sọ này, quét sạch đám tà đồ bất nhân!'
      },
      {
        speaker: {
          id: 'khoi_57',
          name: 'Thu thập Hồ Sơ Hoán Não',
          title: 'Hồ sơ cướp não 2065',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cuốn hồ sơ ghi rõ: “Chu Mạnh Hiếu, 35 tuổi, phản đồ đời thứ 9 Hoàng Môn, trục xuất 2049 vì luyện Hoán Não... Ghép não Lài Phúc Tài nhằm đoạt mệnh cách Bình Liêu Vương... Giới hạn tế bào não: 3 năm sẽ mục rã!” Ta phải tiến vào đài tế ngăn chặn hắn!'
      }
    ]
  },

  dialog_a09_e003: {
    id: 'dialog_a09_e003',
    lines: [
      {
        speaker: {
          id: 'chu_manh_hieu_avatar',
          name: 'Chu Mạnh Hiếu (Thuật Thức Hoán Não)',
          title: 'Phản đồ đời thứ 9 Hoàng Môn',
          color: '#ef4444',
          avatarId: 'avatar_hieu'
        },
        text: 'Khôi... Anh nhìn sọ của em xem! Đường chỉ khâu mổ sọ này... là não của thằng cháu Tài của anh đấy! Em lắp thêm cánh Tay Thép của Thảo, gõ 108 nhịp vào hư không để hút vía giữ xác! Giờ em mới là Bình Liêu Vương chân chính!'
      },
      {
        speaker: {
          id: 'khoi_57',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Hiếu! Năm 16 tuổi cụ Thọ từng bảo: "Mày què nhưng tâm không què". Giờ 35 tuổi, mày đem cái tâm què quặt đi mổ sọ một đứa trẻ đã chết! Dừng lại ngay trước khi quá muộn!'
      },
      {
        speaker: {
          id: 'chu_manh_hieu_avatar',
          name: 'Chu Mạnh Hiếu (Cuồng Nộ)',
          title: 'Kẻ Đoạt Hồn Hút Vía',
          color: '#ef4444',
          avatarId: 'avatar_hieu'
        },
        text: 'Dừng lại? Kẻ yếu mới cần dừng! Nhìn Tay Thép gõ 108 nhịp đây! Toàn bộ sinh lực của mày sẽ nuôi dưỡng bộ não mới của tao!'
      }
    ]
  },

  dialog_a09_e004: {
    id: 'dialog_a09_e004',
    lines: [
      {
        speaker: {
          id: 'chu_manh_hieu_avatar',
          name: 'Chu Mạnh Hiếu',
          title: 'Ôm đầu giằng xé dữ dội',
          color: '#ef4444',
          avatarId: 'avatar_hieu'
        },
        text: 'A... AAAA! Đầu tao... Trong đầu tao có giọng nói khác... Cút ra! Bộ não này là của tao!'
      },
      {
        speaker: {
          id: 'tai_brain_voice',
          name: 'Tiếng Khóc Linh Hồn Tài Dog',
          title: 'Ký ức não trỗi dậy phản phệ',
          color: '#38bdf8',
          avatarId: 'avatar_tai'
        },
        text: 'Cậu Khôi ơi... Cháu đau đầu quá... Hắn nhốt cháu trong hộp sọ tối om... Cậu ơi, cứu cháu với! Đốm ơi, cắn nó đi...!'
      },
      {
        speaker: {
          id: 'chu_manh_hieu_avatar',
          name: 'Chu Mạnh Hiếu (Chảy Huyết Lệ)',
          title: 'Tà Thuật Bị Phản Phệ',
          color: '#f87171',
          avatarId: 'avatar_hieu'
        },
        text: 'Huyết lệ... Mắt tao rỉ máu... Tiếng gậy trúc 108 rãnh của Hoàng Cần vang lên đập nát thần kinh tao... Khôi! Mày dùng ký ức gậy trúc giết tao...!'
      },
      {
        speaker: {
          id: 'khoi_57',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Không phải tao giết mày. Chính quy luật sinh tử và tình yêu thương của thằng Tài đã trừng phạt mày. Tế bào não của người chết sau 3 năm sẽ tự mục rã, tà thuật Hoán Não của mày đã cáo chung!'
      }
    ]
  },

  dialog_a09_e005: {
    id: 'dialog_a09_e005',
    lines: [
      {
        speaker: {
          id: 'luc_trieu_du_arc9',
          name: 'Lục Triều Dư (32 tuổi)',
          title: 'Thằng Treo Dây (Phe Kéo Mốc 1088)',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! Mày đã dập tắt được sào huyệt Hoán Não của thằng Hiếu rồi. Tà thuật của nó sụp đổ hoàn toàn vì não thằng Tài mục rã sau đúng 3 năm (2065 – 2068)!'
      },
      {
        speaker: {
          id: 'khoi_57',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Anh Dư... Suốt 3 năm qua em phải phong ấn tâm thức trong khối Rubik 1m³ để bảo hộ ký ức thằng Tài và canh giữ biên cương. Giờ thì mọi thứ đã an bài.'
      },
      {
        speaker: {
          id: 'luc_trieu_du_arc9',
          name: 'Lục Triều Dư (Trao Cuộn Cáp Thép)',
          title: 'Chuẩn bị Kéo Khôi Trở Lại (Arc 10)',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Cầm lấy Cuộn Cáp Thép 108 sợi này! Năm 2068 đã đến, tao sẽ đứng trên đỉnh vách đá gõ đúng 108 nhịp vào hư không kéo mày bước ra khỏi phong ấn thời gian, tái lập trật tự vĩnh cửu cho Bình Liêu! Bước sang Arc 10 thôi anh em!'
      }
    ]
  }
};

export const ARC_9_DATA: ArcCatalog = {
  arcNumber: 9,
  title: 'Arc 9: Chu Mạnh Hiếu và Thuật Thức Hoán Não',
  timeframe: '2065 – 2068',
  mainCharacters: [
    'Chu Mạnh Hiếu (35 tuổi, phản đồ đời thứ 9 Hoàng Môn)',
    'Hoàng Minh Bình Khôi (57 tuổi)',
    'Lài Phúc Tài (Tài Dog / Ký ức não trỗi dậy)',
    'Lục Triều Dư (32 tuổi, cựu đặc công biên phòng mốc 1088)',
    'Chó Đốm (Người bạn trung thành của Tài Dog)',
    'Toán Tà Sư Hoán Não Lạng Sơn'
  ],
  corePhilosophy: '“Hoán Não tráo sọ nhưng không tráo được ký ức. Tế bào não người chết mục rã sau 3 năm — cái giá tất yếu của kẻ trộm đoạt huyết thống Bình Liêu Vương.”',
  summary: 'Giai đoạn bi kịch và rùng rợn bậc nhất biên giới (2065 – 2068): Lợi dụng lúc Khôi thiền định trong khối Rubik 1m³, Chu Mạnh Hiếu — phản đồ đời thứ 9 của môn phái Hoàng Môn bị trục xuất năm 2049 vì nghiên cứu tà thuật — đã đào trộm mộ của Lài Phúc Tài tại Bản Cáu. Hắn mổ sọ tráo não Tài vào đầu mình nhằm đánh cắp huyết thống và danh tính Bình Liêu Vương. Hắn dùng Tay Thép của Thảo gõ 108 nhịp vào không khí để ổn định sóng não và thiết lập đài tế hút vía tại sào huyệt Hang Đá Lạng Sơn. Khôi cùng Chó Đốm phát hiện nấm mộ rỗng, lần theo tà khí tiến thẳng vào hang đá, tiêu diệt toán tà sư, phá hủy bàn mổ dã man và giao chiến ác liệt với Avatar Chu Mạnh Hiếu. Khi ký ức gậy trúc thức tỉnh, não Tài trỗi dậy phản phệ khiến Hiếu chảy huyết lệ, nhân cách vỡ nát. Đúng quy luật sinh tử, tế bào não mục rã sau 3 năm kết thúc ảo mộng tà thuật, mở đường cho Lục Triều Dư xuất hiện mang theo cáp thép chuẩn bị kéo Khôi trở lại trong Arc 10.',
  events: [
    {
      id: 'A09-E001',
      arcNumber: 9,
      title: 'Dấu Vết Đào Mộ & Nấm Mồ Trống Rỗng (2065)',
      year: '2065',
      location: 'Đồi Mộ Bản Cáu — Mộ Lài Phúc Tài',
      characters: ['Hoàng Minh Bình Khôi (57 tuổi)', 'Chó Đốm'],
      description: [
        'Năm 2065, ngay sau biến cố Rubik Ngục Môn Cương, tiếng chó Đốm sủa thê lương xé rách sương mù trên Đồi Mộ Bản Cáu.',
        'Khôi leo lên đỉnh đồi và bàng hoàng chứng kiến nấm mộ mới đắp của Tài Dog đã bị đào bới tanh bành, nắp quan tài mở toang và thi thể bị mổ sọ cướp não.',
        'Khôi cùng chó Đốm điều tra hiện trường, thu thập 3 manh mối then chốt: Cuốc Đào Mộ Tà Môn (`item_dao_mo_ta_mon`), Mảnh Áo Sát Nách Chàm của Chu Mạnh Hiếu (`item_manh_ao_sat_nach_hieu`), và Dấu Vết Ma Khí Tay Thép Thảo (`item_dau_tay_thep_thao`).',
        'Mọi chứng cứ chỉ rõ Chu Mạnh Hiếu đã tráo não Tài và ẩn náu tại Sào Huyệt Hang Đá Lạng Sơn.'
      ],
      verbatimLore: [
        '“Chu Mạnh Hiếu... đào mộ Tài Dog, tráo não người chết sang người sống.”',
        '“Tay Thép của Thảo gõ 108 nhịp vào không khí, vết sẹo mổ sọ rỉ máu.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Chó Đốm',
          text: 'Gâu gâu... Ẳng! (Đốm ngửi thấy mùi quen thuộc lẫn tà khí nồng nặc của kẻ đào mộ)'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Hiếu! Mày đã đi quá xa rồi! Tao sẽ lần theo dấu vết tà thuật vào tận hang đá bắt mày đền tội!'
        }
      ],
      objective: 'Đến Đồi Mộ Tài Dog (`zone_doi_mo_tai_dog`), khám nghiệm nấm mộ bị đào xới (`mo_tai_bi_dao`), thu thập 3 manh mối và bước qua cổng dịch chuyển sang Hang Đá Lạng Sơn!',
      status: 'active',
      requiredZoneId: 'zone_doi_mo_tai_dog',
      targetCoords: { x: 750, y: 460 },
      rewardXp: 900,
      rewardItemIds: ['item_dao_mo_ta_mon', 'item_manh_ao_sat_nach_hieu', 'item_dau_tay_thep_thao'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A09-E002',
      arcNumber: 9,
      title: 'Sào Huyệt Hang Đá Lạng Sơn — Lò Luyện Sọ Tà Môn (2066)',
      year: '2066',
      location: 'Sào Huyệt Hang Đá Lạng Sơn',
      characters: ['Hoàng Minh Bình Khôi', '5 Tà Sư Hoán Não'],
      description: [
        'Năm 2066, Khôi thâm nhập vào Hang Đá Lạng Sơn — nơi Chu Mạnh Hiếu lập sào huyệt bí mật luyện thuật Hoán Não.',
        'Hang động âm u lạnh lẽo, vách đá dựng đứng với vô số hộp sọ và thiết bị giải phẫu nhuốm máu tà môn.',
        '5 Tà Sư Hoán Não tay cầm dao mổ sọ lao vào chặn đường bảo vệ bí mật của sư phụ.',
        'Khôi tung gậy trúc và quyền cước khuất phục toàn bộ 5 tà sư, phá hủy Bàn Mổ Hoán Não dã man (`ban_mo_hoan_nao`), thu giữ Hồ Sơ Hoán Não (`item_ho_so_hoan_nao`) vạch trần âm mưu chiếm đoạt danh tính Bình Liêu Vương.'
      ],
      verbatimLore: [
        '“Chu Mạnh Hiếu bị trục xuất năm 2049 vì luyện thuật Hoán Não.”',
        '“Bàn mổ mổ sọ dã man trong hang đá lạnh lẽo.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Tà Sư Hoán Não',
          text: 'Không ai được chạm vào bàn mổ thần thánh của đại sư huynh Chu Mạnh Hiếu!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Tà đạo mổ sọ hại người, hôm nay tao đập tan bàn mổ của chúng mày!'
        }
      ],
      objective: 'Tiến sâu vào Hang Đá Lạng Sơn (`zone_hang_da_lang_son`), đánh bại 5 Tà Sư Hoán Não và phá hủy Bàn Mổ Hoán Não (`ban_mo_hoan_nao`)!',
      status: 'locked',
      requiredZoneId: 'zone_hang_da_lang_son',
      targetCoords: { x: 650, y: 460 },
      rewardXp: 1100,
      rewardItemIds: ['item_ho_so_hoan_nao'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A09-E003',
      arcNumber: 9,
      title: 'Đài Tế Hút Vía & Đại Chiến Avatar Chu Mạnh Hiếu (2066 – 2067)',
      year: '2066 – 2067',
      location: 'Đài Tế Hắc Ám — Tận Cùng Hang Đá Lạng Sơn',
      characters: ['Hoàng Minh Bình Khôi', 'Boss Chu Mạnh Hiếu (Avatar Hoán Não)'],
      description: [
        'Tại Đài Tế Hút Vía trung tâm hang đá, Chu Mạnh Hiếu xuất hiện với hình hài rùng rợn: hộp sọ chằng chịt vết khâu mổ não, tay phải gắn cánh Tay Thép của Thảo.',
        'Hiếu liên tục gõ ngón tay thép vào hư không theo nhịp 108 để tạo sóng dao động hút sinh khí xung quanh nuôi dưỡng bộ não Tài đang cấy ghép.',
        'Một trận đại chiến bùng nổ: Hiếu thi triển đòn Lôi Ảnh Thủ kết hợp sóng tà thuật đen tối, trong khi Khôi vận dụng thân pháp chữ BÌNH và gậy trúc 108 rãnh khắc chế tà khí.',
        'Khôi đánh vỡ Đài Tế Hút Vía (`dai_te_hut_via`), đẩy lui đòn tấn công cuồng loạn của Hiếu và tước được Mảnh Tay Thép của Thảo (`item_manh_tay_thep_thao`).'
      ],
      verbatimLore: [
        '“Tay Thép của Thảo gõ 108 nhịp vào không khí... hút vía giữ xác.”',
        '“Vết sẹo mổ sọ chạy quanh đầu, tà thuật cướp đoạt danh tính.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Chu Mạnh Hiếu',
          text: 'Tay Thép của Thảo gõ 108 nhịp... Toàn bộ sinh khí biên giới này sẽ thuộc về ta!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Võ thuật của Hoàng Môn không phải để hút vía hại người! Nhận lấy một đòn chữ DỪNG!'
        }
      ],
      objective: 'Đánh bại Boss Chu Mạnh Hiếu Avatar (`boss_chu_manh_hieu_avatar`) và phá hủy Đài Tế Hút Vía (`dai_te_hut_via`) tại Hang Đá Lạng Sơn!',
      status: 'locked',
      requiredZoneId: 'zone_hang_da_lang_son',
      targetCoords: { x: 1350, y: 460 },
      rewardXp: 1400,
      rewardItemIds: ['item_manh_tay_thep_thao'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A09-E004',
      arcNumber: 9,
      title: 'Sự Phản Phệ Của Não Tài — Huyết Lệ Trong Đêm (2067)',
      year: '2067',
      location: 'Khu Vực Ký Ức Não Tài — Hang Đá Lạng Sơn',
      characters: ['Hoàng Minh Bình Khôi', 'Chu Mạnh Hiếu (Bị Phản Phệ)', 'Linh Hồn Tài Dog'],
      description: [
        'Tà đài bị phá, bộ não của Lài Phúc Tài bên trong hộp sọ Hiếu bắt đầu trỗi dậy phản kháng mãnh liệt.',
        'Nhân cách của Hiếu bị phân liệt trầm trọng: một bên là dã tâm độc ác của Hiếu, một bên là giọng nói ngây thơ, nức nở của Tài khóc đòi cậu Khôi.',
        'Khôi đặt cây gậy trúc của Tài lên Bàn Ký Ức (`ky_uc_nao_tai`), cộng hưởng nhịp gõ 108 kích hoạt sự đào thải sinh học.',
        'Chu Mạnh Hiếu quằn quại ôm đầu, hai hàng huyết lệ đỏ thẫm tuôn trào trên gò má, tà thuật tan rã hoàn toàn trước quy luật: tế bào não người chết mục rã sau 3 năm.',
        'Khôi thu nhận Giọt Nước Mắt Tài Dog (`item_nuoc_mat_tai_dog`), an ủi linh hồn người cháu đã được thanh thản.'
      ],
      verbatimLore: [
        '“Não Tài phản phệ khiến Hiếu khóc nấc, chảy huyết lệ.”',
        '“Giới hạn 3 năm tế bào não người chết tự mục rã.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lài Phúc Tài (Trong tiềm thức)',
          text: 'Cậu Khôi ơi... Cháu không cho hắn làm hại cậu đâu! Cháu nhớ gậy trúc của cháu...!'
        },
        {
          speaker: 'Chu Mạnh Hiếu',
          text: 'Huyết lệ... Đầu tao nứt ra rồi! Khôi... tại sao não nó lại không nghe lệnh tao?!'
        }
      ],
      objective: 'Tương tác Bàn Ký Ức Não Tài (`ky_uc_nao_tai`), dùng gậy trúc kích hoạt phản phệ tế bào não và thu thập Giọt Nước Mắt Tài Dog!',
      status: 'locked',
      requiredZoneId: 'zone_hang_da_lang_son',
      targetCoords: { x: 1750, y: 460 },
      rewardXp: 1500,
      rewardItemIds: ['item_nuoc_mat_tai_dog'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A09-E005',
      arcNumber: 9,
      title: 'Điểm Hẹn Cáp Thép — Lục Triều Dư Xuất Hiện (2068)',
      year: '2068',
      location: 'Vách Đá Điểm Hẹn Cáp Thép — Cửa Ra Hang Đá Lạng Sơn',
      characters: ['Hoàng Minh Bình Khôi (57 tuổi)', 'Lục Triều Dư (32 tuổi)'],
      description: [
        'Năm 2068 gõ cửa — tròn 3 năm định mệnh từ khi Khôi tự nguyện phong ấn trong khối Rubik 1m³ và tế bào não của Tài mục rã hóa giải hoàn toàn thuật Hoán Não.',
        'Tại mỏm vách đá cửa ra hang đá, Lục Triều Dư (32 tuổi) — người Nùng, cựu đặc công biên phòng mốc 1088, khoác áo phao đen dày — xuất hiện sừng sững.',
        'Trên vai Dư vác cuộn cáp thép 108 sợi bện chặt sáng ánh thép tôi luyện, tượng trưng cho phe "Kéo" cứu vớt con người khỏi vực sâu.',
        'Dư nhìn Khôi cười tươi: "Khôi! 3 năm đã qua, tà thuật của Chu Mạnh Hiếu đã rã thành tro bụi! Tao đã chuẩn bị cáp thép gõ 108 nhịp để kéo mày trở lại đỉnh cao biên giới!"',
        'Khôi nhận Cuộn Cáp Thép Của Dư (`item_cuon_cap_thep_du`), khép lại trọn vẹn Arc 9 và chính thức bước sang Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại!'
      ],
      verbatimLore: [
        '“Năm 2068, chính Dư gõ 108 nhịp vào khối đá Rubik Ngục Môn Cương để kéo Khôi trở lại.”',
        '“Lục Triều Dư 32 tuổi... cựu đặc công mốc 1088 gãy 3 đốt sống lưng... phe Kéo.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: 'Khôi! Đã đến lúc ra ngoài rồi! Cuộn cáp thép 108 nhịp này sẽ kéo mày trở lại với Bản Cáu!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Cảm ơn anh Dư! Biên giới Bình Liêu từ nay sẽ lại có người gác cổng!'
        }
      ],
      objective: 'Tương tác với Lục Triều Dư tại Điểm Hẹn Cáp Thép (`diem_hen_luc_trieu_du`), tiếp nhận Cuộn Cáp Thép Của Dư và kích hoạt chuyển sang Arc 10!',
      status: 'locked',
      requiredZoneId: 'zone_hang_da_lang_son',
      targetCoords: { x: 2200, y: 460 },
      rewardXp: 2000,
      rewardItemIds: ['item_cuon_cap_thep_du'],
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_9_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A09-E001',
    sourceLoreSummary: 'Năm 2065, Chu Mạnh Hiếu đào mộ Lài Phúc Tài (Tài Dog) tại Bản Cáu, mổ sọ tráo não người chết sang người sống nhằm đánh cắp thân phận Bình Liêu Vương.',
    inGameImplementationLocation: 'Zone Đồi Mộ Tài Dog (`zone_doi_mo_tai_dog`): Nấm mộ bị đào xới (`mo_tai_bi_dao`), Chó Đốm cào đất khóc thương, thu thập Cuốc Đào Mộ Tà Môn, Mảnh Áo Sát Nách Chàm của Hiếu và Dấu Vết Tay Thép Thảo.',
    status: 'hoàn thành',
    notes: 'Trải nghiệm khám phá điều tra hiện trường chân thực; bảo đảm không gian u buồn và nỗi phẫn nộ trước tội ác đào mộ của Hiếu.'
  },
  {
    eventCode: 'A09-E002',
    sourceLoreSummary: 'Chu Mạnh Hiếu (35 tuổi, phản đồ đời 9 Hoàng Môn, bị trục xuất 2049 vì luyện Hoán Não) lập sào huyệt hang đá Lạng Sơn cùng đám tà sư mổ sọ.',
    inGameImplementationLocation: 'Zone Hang Đá Lạng Sơn (`zone_hang_da_lang_son`): Diệt 5 Tà Sư Hoán Não (`ta_su_hoan_nao`), phá hủy Bàn Mổ Hoán Não (`ban_mo_hoan_nao`), thu giữ Hồ Sơ Hoán Não (`item_ho_so_hoan_nao`).',
    status: 'hoàn thành',
    notes: 'Hệ thống chiến đấu thực sự: kẻ địch sử dụng dao mổ sọ và phi đao tà thuật, người chơi tương tác phá hủy bàn mổ để giải mã tài liệu.'
  },
  {
    eventCode: 'A09-E003',
    sourceLoreSummary: 'Chu Mạnh Hiếu lắp Tay Thép của Thảo, gõ 108 nhịp vào không khí để duy trì dao động sóng não và hút vía giữ xác; vết sẹo mổ sọ rỉ máu quanh đầu.',
    inGameImplementationLocation: 'Zone Hang Đá Lạng Sơn: Đại chiến Boss Avatar Chu Mạnh Hiếu (`boss_chu_manh_hieu_avatar`) tại Đài Tế Hút Vía (`dai_te_hut_via`), thu giữ Mảnh Tay Thép Thảo (`item_manh_tay_thep_thao`).',
    status: 'hoàn thành',
    notes: 'Boss AI phản xạ tấn công bằng tay thép và sóng âm tà thuật; cơ chế phá đài tế ngắt nguồn hút vía đúng chuẩn lore.'
  },
  {
    eventCode: 'A09-E004',
    sourceLoreSummary: 'Não Tài Dog phản phệ khiến Hiếu chảy huyết lệ, tiếng khóc của Tài trỗi dậy đòi cậu Khôi; giới hạn 3 năm (2065 – 2068) khiến tế bào não mục rã tự nhiên.',
    inGameImplementationLocation: 'Zone Hang Đá Lạng Sơn: Tương tác Bàn Ký Ức Não Tài (`ky_uc_nao_tai`), dùng gậy trúc thức tỉnh ký ức, Hiếu khóc nấc chảy huyết lệ, nhận Giọt Nước Mắt Tài Dog (`item_nuoc_mat_tai_dog`).',
    status: 'hoàn thành',
    notes: 'Tái hiện đầy cảm xúc và rùng rợn sự phân liệt nhân cách; minh chứng rõ ràng: Hoán Não không tráo được ký ức và tế bào não chết sẽ tự mục rã.'
  },
  {
    eventCode: 'A09-E005',
    sourceLoreSummary: 'Năm 2068, Lục Triều Dư 32 tuổi (Thằng Treo Dây mốc 1088, phe Kéo) xuất hiện mang theo cuộn cáp thép 108 sợi chuẩn bị gõ 108 nhịp kéo Khôi trở lại (mở ra Arc 10).',
    inGameImplementationLocation: 'Zone Hang Đá Lạng Sơn: NPC Lục Triều Dư (`npc_luc_trieu_du_arc9`) tại Điểm Hẹn Cáp Thép (`diem_hen_luc_trieu_du`), nhận Cuộn Cáp Thép Của Dư (`item_cuon_cap_thep_du`), chuyển sang Arc 10.',
    status: 'hoàn thành',
    notes: 'Liên kết hoàn hảo mạch truyện sang Arc 10 (Lục Triều Dư / Kéo Khôi Trở Lại), đáp ứng đầy đủ điều kiện kết thúc Arc 9.'
  }
];

// ============================================================================
// ARC 10: LỤC TRIỀU DƯ / KÉO KHÔI TRỞ LẠI (2068)
// ============================================================================

export const ARC_10_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a10_e001: {
    id: 'dialog_a10_e001',
    lines: [
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư (32 tuổi)',
          title: 'Thằng Treo Dây — Phe "Kéo" (Cựu Đặc Công Mốc 1088)',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: '(Nắm chặt cuộn cáp thép 108 sợi, lưng mang nẹp trợ lực kim loại sau chấn thương gãy 3 đốt sống) Vách đá Mốc 1088 gió tuyết buốt thấu xương... Năm 2068 đã điểm! Tròn 3 năm qua Khôi đã thiền định trong khối Rubik 1m³ để tế bào não thằng Tài tự mục rã hoàn toàn. Hôm nay tao sẽ đóng 3 mỏ neo giăng giàn cáp thép kéo nó ra!'
      },
      {
        speaker: {
          id: 'hac_dao_phong_toa',
          name: 'Toán Đao Thủ Hắc Đạo Móng Cái',
          title: 'Tàn dư được phái đi canh giữ ngục Rubik',
          color: '#ef4444',
          avatarId: 'avatar_bandit'
        },
        text: 'Thằng què nẹp lưng kia! Đại sư huynh Chu Mạnh Hiếu đã hạ lệnh: Không một ai được phép giải phong ấn cho Bình Liêu Vương! Muốn đưa nó ra thì để mạng lại đây!'
      },
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư',
          title: 'Phe "Kéo"',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Tao người Nùng, cựu đặc công mốc 1088 gãy 3 đốt sống lưng mà vẫn đu cáp rèn cơ giữa 2 vách Khe Vằn suốt 6 tháng. Đám tép riu chúng mày tưởng cản nổi phe Kéo sao?!'
      }
    ]
  },

  dialog_a10_e002: {
    id: 'dialog_a10_e002',
    lines: [
      {
        speaker: {
          id: 'boss_trum_dao_thu',
          name: 'Trùm Đao Thủ Hắc Đạo Canh Ngục',
          title: 'Cuồng tín bảo vệ phong ấn Rubik 1m³',
          color: '#f87171',
          avatarId: 'avatar_bandit'
        },
        text: 'Lục Triều Dư! Mày hạ được mấy tên canh ngoài nhưng Khóa Căng Cáp Thép đang nằm trong tay tao! Khối đá Rubik 1m³ này sẽ là mồ chôn vĩnh viễn của Hoàng Minh Bình Khôi!'
      },
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Cáp thép để cứu mạng người, không phải để khóa chết người! Đao to thì vung chậm, nếm thử một đòn giằng cáp của đặc công biên phòng!'
      },
      {
        speaker: {
          id: 'boss_trum_dao_thu',
          name: 'Trùm Đao Thủ (Khi Bị Hạ)',
          title: 'Gục ngã bên mép vách đá',
          color: '#f87171',
          avatarId: 'avatar_bandit'
        },
        text: 'Khặc... Cáp thép siết nát cổ tay tao rồi... Nhưng vô ích thôi... Chu Mạnh Hiếu đại sư huynh sau khi bị phản phệ hoán não đã phát điên... hắn đang dẫn quân bao vây Trường Mầm Non Bản Cáu... mày kéo được nó ra cũng không cứu kịp đâu...'
      }
    ]
  },

  dialog_a10_e003: {
    id: 'dialog_a10_e003',
    lines: [
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư (32 tuổi)',
          title: 'Kích hoạt nghi thức 108 nhịp cáp thép',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: '(Móc chặt 108 đầu cáp thép tôi luyện vào 6 mặt bùa khối Rubik 1m³, cầm ống thép gõ nhịp) 1... 2... 3... 107... ĐỦ 108 NHỊP! Sóng âm cộng hưởng rền vang vách đá Khe Vằn! NỨT RA CHO TAO, NGỤC MÔN CƯƠNG!'
      },
      {
        speaker: {
          id: 'rubik_echo',
          name: 'Tiếng Nứt Vỡ Khối Đá Rubik 1m³',
          title: 'Phong ấn 3 năm (2065 – 2068) sụp đổ',
          color: '#38bdf8',
          avatarId: 'avatar_rubik'
        },
        text: 'RẮC... RẮC... UỲNH! (Khối đá lập phương nứt toác làm đôi, ánh sáng băng tuyết 3 năm dồn nén tỏa ra ngút ngàn, mở toang lối thoát)'
      },
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư',
          title: 'Căng cơ lưng kéo cáp',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! 3 năm định mệnh đã trọn... Giờ thì theo tao BƯỚC RA NGOÀI!'
      }
    ]
  },

  dialog_a10_e004: {
    id: 'dialog_a10_e004',
    lines: [
      {
        speaker: {
          id: 'khoi_60',
          name: 'Hoàng Minh Bình Khôi (60 tuổi)',
          title: 'Bình Liêu Vương (Vừa bước ra khỏi ngục đá)',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: '(Thân hình gầy rộc sau 3 năm thiền định, môi thâm vì giá rét buốt thấu, hơi thở phả ra khói sương) Anh Dư... 3 năm rồi... Não thằng Tài bên sọ Hiếu đã mục rã tan biến thanh thản... Nhưng người em buốt quá... tay đông cứng không cầm nổi liềm...'
      },
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây — Phe "Kéo"',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: '(Lập tức cởi chiếc Áo Phao Đen Rách vai khoác trùm lên vai Khôi, trao bát nước gừng nóng bốc khói) Mặc áo vào! Uống cạn bát nước gừng này! Năm 18 tuổi mày cai quản biên cương, tao gãy lưng đu cáp ngắm mày. Mày bình cả thiên hạ, lần này để thằng Dư tao bình mày!'
      },
      {
        speaker: {
          id: 'khoi_60',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Hồi phục sinh lực đỉnh cao',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: '(Khí huyết ấm bừng kinh mạch, siết chặt cán Liềm Tử Thần) Áo phao của anh... ấm lắm. Mắt em không còn vệt máu sát khí Shibuya, tâm em không còn nỗi sợ chết. Cảm ơn anh Dư đã kéo em trở lại!'
      }
    ]
  },

  dialog_a10_e005: {
    id: 'dialog_a10_e005',
    lines: [
      {
        speaker: {
          id: 'cho_dom_ban_cau',
          name: 'Chó Đốm (Bản Cáu)',
          title: 'Chạy hớt hải ngậm chuông gió báo tin',
          color: '#fbbf24',
          avatarId: 'avatar_tai'
        },
        text: 'Ẳng... Gâu gâu! (Đốm thở dốc cào móng vào gấu áo Khôi, nhả chiếc chuông gió đẫm tuyết rơi leng keng)'
      },
      {
        speaker: {
          id: 'khoi_60',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Đốm! Sao mày chạy từ cổng đình lên tận vách đá Mốc 1088 thế này?! Chiếc chuông gió này... là của các cháu ở Trường Mầm Non Bản Cáu!'
      },
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư (32 tuổi)',
          title: 'Cựu đặc công biên phòng',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Lời tên trùm đao thủ lúc nãy là thật! Chu Mạnh Hiếu sau khi Hoán Não thất bại đã phát điên, kéo thuộc hạ tràn về bao vây Trường Mầm Non Bản Cáu, bắt giữ 20 đứa trẻ để cưỡng ép hút sinh khí bù vào não hoại tử!'
      },
      {
        speaker: {
          id: 'khoi_60',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Hai Thằng Canh Cổng',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Hai mươi đứa trẻ vô tội... Cụ Thọ từng dạy: "Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người!" Giờ đây, tao với anh là HAI THẰNG CANH CỔNG! Xuống núi giải cứu lũ trẻ thôi!'
      },
      {
        speaker: {
          id: 'luc_trieu_du_nguc_mon',
          name: 'Lục Triều Dư',
          title: 'Kề vai sát cánh',
          color: '#a78bfa',
          avatarId: 'avatar_du'
        },
        text: 'Xuống núi! Mày cầm liềm dừng, tao giăng cáp kéo! Cho thằng Hiếu biết thế nào là người giữ đất Bình Liêu! Sẵn sàng cho Arc 11!'
      }
    ]
  }
};

export const ARC_10_DATA: ArcCatalog = {
  arcNumber: 10,
  title: 'Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại',
  timeframe: '2068',
  mainCharacters: [
    'Lục Triều Dư (32 tuổi, cựu đặc công biên phòng Mốc 1088, phe "Kéo")',
    'Hoàng Minh Bình Khôi (60 tuổi, Bình Liêu Vương)',
    'Chó Đốm (Người bạn trung thành của Tài Dog)',
    'Trùm Đao Thủ Hắc Đạo Canh Ngục Rubik',
    'Toán Đao Thủ Hắc Đạo Phong Tỏa Mốc 1088'
  ],
  corePhilosophy: '“Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người. Kéo Khôi trở lại không chỉ là kéo một thể xác ra khỏi khối đá, mà là kéo một vị vua ra khỏi nỗi cô độc để cùng canh giữ cổng làng.”',
  summary: 'Năm 2068, tròn 3 năm kể từ ngày Khôi tự nguyện phong ấn tâm thức trong Khối Đá Rubik Ngục Môn Cương 1m³ để chờ tế bào não của Lài Phúc Tài tự mục rã hoàn toàn. Thuật thức Hoán Não của Chu Mạnh Hiếu đã tan thành mây khói, nhưng Khôi bị kẹt lại trong ngục đá lạnh buốt giữa mùa đông biên giới. Lục Triều Dư — 32 tuổi, người Nùng, cựu đặc công mốc 1088 bị gãy 3 đốt sống lưng, đại diện cho phe "Kéo" — mang theo cuộn cáp thép 108 sợi bện chặt leo lên vách đá cheo leo. Dư vượt qua toán đao thủ hắc đạo Móng Cái phục kích, đánh bại Trùm Đao Thủ canh ngục, đoạt Khóa Căng Cáp Thép và móc 108 đầu cáp vào 6 mặt bùa Rubik. Với 108 nhịp gõ rung chấn cộng hưởng, Dư phá tan Ngục Môn Cương, cởi chiếc Áo Phao Đen Rách khoác lên sưởi ấm cho Khôi và trao bát nước gừng nóng. Khôi tái sinh tuổi 60 với trọn vẹn phong thái Bình Liêu Vương. Đúng lúc đó, Chó Đốm ngậm Chuông Gió Trường Mầm Non Bản Cáu chạy lên báo tin dữ: Chu Mạnh Hiếu phát điên đang bao vây bắt giữ 20 đứa trẻ. Dư và Khôi kết thành "Hai Thằng Canh Cổng", sát cánh mở đường sang đại chiến Arc 11!',
  events: [
    {
      id: 'A10-E001',
      arcNumber: 10,
      title: 'Giàn Cáp Thép Mốc 1088 — Phe Kéo Vào Vị Trí (2068)',
      year: '2068',
      location: 'Vách Đá Ngục Môn Cương 2068 — Mốc 1088',
      characters: ['Lục Triều Dư (32 tuổi)', '4 Đao Thủ Hắc Đạo Phong Tỏa'],
      description: [
        'Năm 2068, mùa đông rét cắt da cắt thịt trên đỉnh đèo Mốc 1088.',
        'Lục Triều Dư mang cuộn cáp thép 108 sợi cứu sinh leo lên vách đá cheo leo nơi Khối Đá Rubik Ngục Môn Cương 1m³ đang bị phong tỏa.',
        'Toán 4 đao thủ hắc đạo Móng Cái do Chu Mạnh Hiếu phái đến mai phục giàn cáp hòng ngăn chặn mọi nỗ lực giải cứu.',
        'Người chơi điều khiển nhân vật chiến đấu dẹp tan 4 tên đao thủ hắc đạo, tiếp cận 3 điểm cắm neo cáp (`neo_cap_thep_1`, `neo_cap_thep_2`, `neo_cap_thep_3`) trên vách đá để cố định giàn cáp chịu lực 108 sợi.'
      ],
      verbatimLore: [
        '“Lục Triều Dư 32 tuổi... cựu đặc công mốc 1088 gãy 3 đốt sống... phe Kéo.”',
        '“Cuộn cáp thép 108 sợi vắt ngang hẻm vực hiểm trở.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: 'Vách đá Mốc 1088 gió tuyết buốt xương... Hôm nay tao sẽ cắm chặt 3 mỏ neo cáp thép kéo thằng Khôi ra!'
        },
        {
          speaker: 'Đao Thủ Hắc Đạo',
          text: 'Chặn đứng thằng nẹp lưng lại! Không cho nó tiếp cận khối đá Rubik!'
        }
      ],
      objective: 'Tiến vào Vách Đá Ngục Môn Cương (`zone_vach_da_nguc_mon_2068`), đánh bại 4 Đao Thủ Hắc Đạo và kích hoạt 3 Mỏ Neo Cáp Thép trên vách đá!',
      status: 'active',
      requiredZoneId: 'zone_vach_da_nguc_mon_2068',
      targetCoords: { x: 500, y: 440 },
      rewardXp: 1200,
      rewardItemIds: ['item_moc_neo_cap_thep'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A10-E002',
      arcNumber: 10,
      title: 'Đánh Bại Trùm Đao Thủ Canh Giữ Hộp Đá Rubik (2068)',
      year: '2068',
      location: 'Cửa Ngục Rubik 1m³ — Vách Đá Mốc 1088',
      characters: ['Lục Triều Dư', 'Boss Trùm Đao Thủ Hắc Đạo Canh Ngục'],
      description: [
        'Trước cửa ngục đá Rubik 1m³, tên Trùm Đao Thủ Hắc Đạo hung hãn xuất hiện với cây đại đao răng cưa.',
        'Hắn nắm giữ chiếc Khóa Căng Cáp Thép then chốt, quyết tử bảo vệ phong ấn theo lệnh Chu Mạnh Hiếu.',
        'Một trận quyết chiến nổ ra giữa bão tuyết: Boss thi triển đòn chém xoay cuồng sát và lao chém cực nhanh.',
        'Người chơi vận dụng thân pháp né tránh và đòn phản kích dứt điểm hạ gục Boss, thu giữ Khóa Căng Cáp Thép (`item_khoa_cang_cap`).'
      ],
      verbatimLore: [
        '“Đao to thì vung chậm, nhìn cáp thép giằng đao đây!”',
        '“Khóa căng cáp thép mở ra cơ hội giải phong ấn cuối cùng.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Trùm Đao Thủ Hắc Đạo',
          text: 'Khóa cáp thép nằm trong tay tao! Khối Rubik 1m³ này sẽ là mồ chôn vĩnh viễn của Bình Liêu Vương!'
        },
        {
          speaker: 'Lục Triều Dư',
          text: 'Cáp thép để cứu mạng người, không phải để khóa chết người! Đỡ lấy một đòn!'
        }
      ],
      objective: 'Đánh bại Boss Trùm Đao Thủ Hắc Đạo (`boss_trum_dao_thu_hac_dao`) tại Vách Đá Ngục Môn Cương và thu hồi Khóa Căng Cáp Thép!',
      status: 'locked',
      requiredZoneId: 'zone_vach_da_nguc_mon_2068',
      targetCoords: { x: 1200, y: 440 },
      rewardXp: 1500,
      rewardItemIds: ['item_khoa_cang_cap'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A10-E003',
      arcNumber: 10,
      title: 'Nghi Thức 108 Nhịp Cáp Thép — Phá Khối Đá Rubik 1m³ (2068)',
      year: '2068',
      location: 'Tâm Trận Khối Đá Rubik 1m³ — Vách Đá Ngục Môn Cương',
      characters: ['Lục Triều Dư', 'Khối Đá Rubik Ngục Môn Cương'],
      description: [
        'Có được khóa căng cáp, Lục Triều Dư móc 108 sợi cáp thép tôi luyện vào đúng 6 mặt khắc bùa của khối Rubik 1m³.',
        'Dư dùng nẹp sắt cổ tay và thanh gậy biên phòng gõ đúng 108 nhịp sóng âm rung chấn vào khối đá.',
        'Người chơi trực tiếp tương tác Khối Đá Rubik (`rubik_nguc_mon_cuong_108`), kích hoạt chuỗi chấn động 108 nhịp rền vang vách núi.',
        'Khối đá lập phương 1m³ nứt toác dữ dội, bùa phong ấn 3 năm nổ tung thành mây khói, người chơi nhặt Mảnh Đá Rubik 108 Nhịp (`item_manh_da_rubik_108`).'
      ],
      verbatimLore: [
        '“Năm 2068, chính Dư gõ 108 nhịp vào khối đá Rubik Ngục Môn Cương để kéo Khôi trở lại.”',
        '“Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi tự bước vào là không còn sợ chết.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: '1... 2... 3... đến 108 nhịp! Sóng âm cộng hưởng rền vang vách đá! NỨT RA CHO TAO, NGỤC MÔN CƯƠNG!'
        },
        {
          speaker: 'Lục Triều Dư',
          text: 'Khôi! 3 năm định mệnh đã trọn... Giờ thì theo tao BƯỚC RA NGOÀI!'
        }
      ],
      objective: 'Tương tác Khối Đá Rubik 1m³ (`rubik_nguc_mon_cuong_108`), kích hoạt chuỗi 108 nhịp rung chấn phá vỡ phong ấn Ngục Môn Cương!',
      status: 'locked',
      requiredZoneId: 'zone_vach_da_nguc_mon_2068',
      targetCoords: { x: 1600, y: 440 },
      rewardXp: 1800,
      rewardItemIds: ['item_manh_da_rubik_108'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A10-E004',
      arcNumber: 10,
      title: 'Kéo Khôi Trở Lại — Trao Chiếc Áo Phao Đen Rách (2068)',
      year: '2068',
      location: 'Bình Đài Giải Thoát Khôi — Vách Đá Mốc 1088',
      characters: ['Lục Triều Dư (32 tuổi)', 'Hoàng Minh Bình Khôi (60 tuổi)'],
      description: [
        'Khối Rubik vỡ tan, Hoàng Minh Bình Khôi bước ra sau 3 năm thiền định trong ngục đá.',
        'Khôi lúc này đã 60 tuổi, toàn thân đông cứng vì cái lạnh buốt thấu xương, cơ bắp kiệt quệ, nhưng ánh mắt đã sạch bóng sát khí Shibuya và linh hồn Tài đã siêu thoát thanh thản.',
        'Lục Triều Dư lập tức cởi chiếc Áo Phao Đen Rách vai của mình khoác trùm lên vai Khôi, trao Bát Nước Gừng Nóng Mốc 1088 làm ấm lại kinh mạch.',
        'Khôi nhận Áo Phao Đen Rách (`item_ao_phao_den_rach_du`) và Bát Nước Gừng Nóng (`item_bat_nuoc_gung_nong_1088`), cầm lại Liềm Tử Thần, khôi phục 100% sinh lực đỉnh cao của Bình Liêu Vương.'
      ],
      verbatimLore: [
        '“Mày không cần bình nữa. Lần này để tao bình mày.” — Lục Triều Dư',
        '“Trao chiếc áo phao đen rách vai và bát nước gừng sưởi ấm Khôi trở lại.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Anh Dư... 3 năm rồi... Não thằng Tài đã mục rã thanh thản... Nhưng người em buốt quá...'
        },
        {
          speaker: 'Lục Triều Dư',
          text: 'Mặc áo phao vào! Uống cạn bát nước gừng này! Mày bình cả thiên hạ, lần này để thằng Dư tao bình mày!'
        }
      ],
      objective: 'Tương tác Bình Đài Giải Thoát Khôi (`khung_khoi_phuc_sinh_luc`), nhận Áo Phao Đen Rách và Nước Gừng Nóng khôi phục thể trạng Bình Liêu Vương!',
      status: 'locked',
      requiredZoneId: 'zone_vach_da_nguc_mon_2068',
      targetCoords: { x: 1950, y: 440 },
      rewardXp: 2000,
      rewardItemIds: ['item_ao_phao_den_rach_du', 'item_bat_nuoc_gung_nong_1088'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A10-E005',
      arcNumber: 10,
      title: 'Hai Thằng Canh Cổng & Khúc Dạo Đầu Trận Trường Mầm Non (2068)',
      year: '2068',
      location: 'Cổng Đình Lục Nà — Thôn Bản Cáu',
      characters: ['Hoàng Minh Bình Khôi (60 tuổi)', 'Lục Triều Dư (32 tuổi)', 'Chó Đốm'],
      description: [
        'Khôi và Dư cùng hạ sơn trở về Bản Cáu. Cả hai phối hợp đòn thế "Một thằng kéo, một thằng dừng" quét sạch toán do thám tà môn đang rình rập quanh làng.',
        'Chó Đốm ngậm chiếc Chuông Gió Trường Mầm Non hớt hải chạy đến bên chân Khôi sủa vang báo tin dữ.',
        'Chu Mạnh Hiếu sau khi bị phản phệ Hoán Não đã phát điên, dẫn thuộc hạ tràn về bao vây Trường Mầm Non Bản Cáu bắt giữ 20 đứa trẻ để cưỡng ép hút sinh khí.',
        'Khôi và Dư kết thành "Hai Thằng Canh Cổng", tiếp nhận Tín Vật Chuông Gió Trường Mầm Non (`item_chuong_gio_mam_non`), chính thức hoàn thành Arc 10 và mở cánh cửa sẵn sàng bước vào đại chiến Arc 11!'
      ],
      verbatimLore: [
        '“Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người.”',
        '“Giết xong thì về. Ngồi lại ở cổng. Tao canh cho.” — Lục Triều Dư',
        '“Chu Mạnh Hiếu bắt giữ 20 đứa trẻ tại trường mầm non để hút vía.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Hai mươi đứa trẻ vô tội... Cụ Thọ từng dạy: Võ để giữ người! Tao với anh là Hai Thằng Canh Cổng, xuống trường mầm non ngay!'
        },
        {
          speaker: 'Lục Triều Dư',
          text: 'Mày vung liềm dừng, tao giăng cáp kéo! Cho thằng Hiếu biết thế nào là người giữ đất Bình Liêu! Sẵn sàng cho Arc 11!'
        }
      ],
      objective: 'Trở về Bản Cáu (`zone_ban_cau`), dẹp sạch toán trinh sát tà môn và tương tác Cổng Đình Lục Nà (`cong_dinh_hai_thang_canh_cong`) hoàn thành Arc 10!',
      status: 'locked',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 1600, y: 440 },
      rewardXp: 2500,
      rewardItemIds: ['item_chuong_gio_mam_non'],
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_10_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A10-E001',
    sourceLoreSummary: 'Năm 2068, Lục Triều Dư 32 tuổi (cựu đặc công biên phòng mốc 1088, gãy 3 đốt sống, nẹp lưng, phe Kéo) đưa cuộn cáp thép 108 sợi lên vách đá cheo leo Mốc 1088 giăng giàn cáp.',
    inGameImplementationLocation: 'Zone Vách Đá Ngục Môn Cương (`zone_vach_da_nguc_mon_2068`): Đánh bại 4 Đao Thủ Hắc Đạo Phong Tỏa (`hac_dao_phong_toa`), cắm 3 Mỏ Neo Cáp Thép (`neo_cap_thep_1`, `neo_cap_thep_2`, `neo_cap_thep_3`), nhận Móc Neo Cáp Thép (`item_moc_neo_cap_thep`).',
    status: 'hoàn thành',
    notes: 'Gameplay leo núi, cắm neo cáp chịu lực và chiến đấu thời gian thực; thể hiện chân thực địa hình hiểm trở biên giới và nghị lực của Dư.'
  },
  {
    eventCode: 'A10-E002',
    sourceLoreSummary: 'Chu Mạnh Hiếu để lại Trùm Đao Thủ cuồng tín canh giữ ngục Rubik 1m³, giữ Khóa Căng Cáp Thép để ngăn cản việc phá giải phong ấn.',
    inGameImplementationLocation: 'Zone Vách Đá Ngục Môn Cương: Đấu Boss Trùm Đao Thủ Hắc Đạo (`boss_trum_dao_thu_hac_dao`), né đại đao răng cưa, thu giữ Khóa Căng Cáp Thép (`item_khoa_cang_cap`).',
    status: 'hoàn thành',
    notes: 'Trận đấu Boss căng thẳng với AI chém quét và lướt chém; có thanh máu, hitbox rõ ràng và hội thoại hé lộ âm mưu Chu Mạnh Hiếu rút về trường mầm non.'
  },
  {
    eventCode: 'A10-E003',
    sourceLoreSummary: 'Lục Triều Dư móc 108 sợi cáp thép vào 6 mặt bùa Rubik Ngục Môn Cương, gõ đúng 108 nhịp sóng âm rung chấn phá vỡ khối đá lập phương 1m³ sau 3 năm (2065 – 2068).',
    inGameImplementationLocation: 'Zone Vách Đá Ngục Môn Cương: Tương tác Khối Đá Rubik 108 Nhịp (`rubik_nguc_mon_cuong_108`), kích hoạt cơ chế gõ 108 nhịp rung màn hình, vỡ khối đá và nhặt Mảnh Đá Rubik 108 Nhịp (`item_manh_da_rubik_108`).',
    status: 'hoàn thành',
    notes: 'Cơ chế tương tác âm thanh và rung chấn màn hình độc đáo, thể hiện đúng chi tiết gõ 108 nhịp vào khối đá Rubik trong lore.'
  },
  {
    eventCode: 'A10-E004',
    sourceLoreSummary: 'Khôi 60 tuổi bước ra sau 3 năm thiền định trong giá lạnh; Dư cởi Áo Phao Đen Rách vai của mình khoác lên Khôi, trao bát nước gừng nóng sưởi ấm, kéo Khôi trở lại làm Bình Liêu Vương.',
    inGameImplementationLocation: 'Zone Vách Đá Ngục Môn Cương: Tương tác Bình Đài Giải Thoát Khôi (`khung_khoi_phuc_sinh_luc`), nhận Áo Phao Đen Rách (`item_ao_phao_den_rach_du`) và Bát Nước Gừng Nóng (`item_bat_nuoc_gung_nong_1088`), hồi phục 100% sinh lực.',
    status: 'hoàn thành',
    notes: 'Hiện thực hóa trọn vẹn ý nghĩa "Kéo Khôi trở lại" — vừa giải thoát thể xác, vừa sưởi ấm tinh thần bằng chiếc áo phao đen rách vai và bát nước gừng tình nghĩa.'
  },
  {
    eventCode: 'A10-E005',
    sourceLoreSummary: 'Khôi và Dư trở về Bản Cáu thành "Hai Thằng Canh Cổng"; Chó Đốm ngậm chuông gió báo tin Chu Mạnh Hiếu bao vây Trường Mầm Non bắt 20 đứa trẻ hút sinh khí; mở ra Arc 11.',
    inGameImplementationLocation: 'Zone Bản Cáu (`zone_ban_cau`): Dẹp sạch Trinh Sát Tà Môn (`do_tham_ta_mon`), gặp Chó Đốm tại Cổng Đình Lục Nà (`cong_dinh_hai_thang_canh_cong`), nhận Chuông Gió Trường Mầm Non (`item_chuong_gio_mam_non`), kích hoạt Arc 11.',
    status: 'hoàn thành',
    notes: 'Liên kết hoàn hảo mạch truyện sang Arc 11 (Trận Cuối Trường Mầm Non 2068), đáp ứng đúng tiêu chuẩn triết lý "Cần giữ, Thọ bình, Khôi dừng, Dư kéo".'
  }
];

export const ARC_11_DIALOG_SEQUENCES: Record<string, DialogSequence> = {
  dialog_a11_e001: {
    id: 'dialog_a11_e001',
    lines: [
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây (Phe Kéo)',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! Đúng 3h sáng rồi. Trường mầm non Bản Cáu bị tà khí bao phủ buốt lạnh. 20 đứa trẻ đang bị nhốt trong phòng học phía cuối sân!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi (60 tuổi)',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cụ Thọ từng dạy: Võ là để giữ người. Đêm nay, một sợi tóc của lũ trẻ cũng không được phép đứt!'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Tao đã kiểm tra rào chắn cổng trường. Phía trước có toán đao thủ tà môn phục kích. Dẹp sạch chúng rồi mở cổng!'
      }
    ]
  },
  dialog_a11_e002: {
    id: 'dialog_a11_e002',
    lines: [
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Phe Kéo',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! Nhìn hai cột trụ xích đu bằng sắt kia kìa! Tao sẽ luồn 108 sợi cáp thép khóa chốt vào đó. Khi thằng Hiếu vung tay thép, tao sẽ giật sập giàn xích đu trói chặt tay nó!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Anh Dư, nẹp lưng anh còn đau không? Giữ chắc cáp nhé. Khi anh kéo, em sẽ chém!'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Phe Kéo',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Gãy 3 đốt sống mà tao còn kéo mày ra khỏi Rubik được thì xích đu này có là cái đinh gì! Khóa cáp đã cài! Lên đi Khôi!'
      }
    ]
  },
  dialog_a11_e003: {
    id: 'dialog_a11_e003',
    lines: [
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Mạnh Hiếu (Mặt Tài)',
          title: 'Tà Sư Hoán Não',
          color: '#ef4444',
          avatarId: 'avatar_hieu'
        },
        text: 'Hahaha! Bình Liêu Vương! Mày bước ra khỏi ngục đá rồi à? 20 đứa trẻ này sẽ là nguồn sinh khí vô tận nuôi dưỡng tay thép 108 nhịp của tao!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Chu Mạnh Hiếu! Mày mượn mặt thằng cháu tao, gắn cánh tay thép cơ khí của Thảo để làm điều tàn ác. Đêm nay, ngón tay thép của mày sẽ gãy vụn!'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Phe Kéo',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Cáp thép giật đổ xích đu! Tao giữ chặt hai tay nó rồi! Khôi, vung liềm chém nát tay thép nó mau!'
      }
    ]
  },
  dialog_a11_e004: {
    id: 'dialog_a11_e004',
    lines: [
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què (Xé Áo)',
          title: 'Bản Khuyết Tật',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: '(Xé toạc áo ngoài, lộ chiếc áo sát nách của Thầy Huỳnh và vết sẹo hình tia sét Nữ Thánh Rắn) Mày tưởng bẻ gãy tay thép của Thảo là thắng được tao à?! NÃO TÀI ĐÃ VỀ VỚI ĐẤT MẸ! GIỜ TAO ĐÁNH BẰNG CHÍNH TAO!'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Lôi Ảnh Thủ',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: 'Chân phải tao ngắn hơn chân trái 2cm! Tụi nó gọi tao là Hiếu Què, ăn rỉ chim, liếm chân! Nhưng thầy Huỳnh dạy tao đứng một chân trên cột điện luyện LÔI ẢNH THỦ! CÁI GÌ KHÔNG GIẾT ĐƯỢC TAO SẼ LÀM TAO MẠNH HƠN!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Hiếu què... Chiếc áo sát nách thầy Huỳnh cho mày... Thầy dạy mày võ để làm anh hùng, không phải để làm quỷ dữ! Đỡ lấy chiêu này!'
      }
    ]
  },
  dialog_a11_e005: {
    id: 'dialog_a11_e005',
    lines: [
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: '(Vung Liềm Tử Thần xé toạc màn tuyết... Lưỡi liềm sắc bén dừng lại cách cổ Chu Hiếu đúng một tấc, gió liềm thổi bay làn tóc) DỪNG LẠI!'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Lôi Ảnh Thủ',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: '(Khuỵu một chân xuống nền tuyết trắng, mắt trợn tròn nhìn lưỡi liềm không chém xuống) Sao... sao mày không chém đứt đầu tao?!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Mạnh nhất là lúc dừng lại được. Năm 15 tuổi tao dừng lại trước Đạt Hổ Mun. Năm 17 tuổi thầy Cần dừng lại trao chữ Bình. Cụ Thọ dạy: Mày không giết người, mày bình người. Hiếu, mày được tự do rồi.'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Đứa Con Rắn',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: '(Nước mắt hòa vào tuyết lạnh) Thầy Huỳnh ơi... con không làm bẩn áo thầy chứ? Bình Liêu Vương... mày thắng rồi.'
      }
    ]
  },
  dialog_a11_e006: {
    id: 'dialog_a11_e006',
    lines: [
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Phe Kéo',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Cửa phòng học đã mở! Hai mươi đứa trẻ đều an toàn nguyên vẹn, không một vết trầy xước!'
      },
      {
        speaker: {
          id: 'tai',
          name: 'Hồn Lài Phúc Tài',
          title: 'Tài Dog',
          color: '#ffb74d',
          avatarId: 'avatar_tai'
        },
        text: 'Cậu Khôi ơi... Cậu đã cứu được các em nhỏ rồi. Chú Hiếu cũng buông bỏ rồi. Cậu đừng buồn nữa nhé, cháu đi theo cụ Thọ với thầy Cần đây.'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Tài... Cậu bình yên rồi. Con hãy thanh thản nhé, mảnh đất Bình Liêu này, cậu với chú Dư sẽ canh giữ.'
      }
    ]
  },
  dialog_a11_e007: {
    id: 'dialog_a11_e007',
    lines: [
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Phe Kéo',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Khôi... Tuyết ngừng rơi rồi kìa. Mặt trời đang mọc trên đỉnh Cao Xiêm và Mốc 1088. Cáp thép tao đã thu gọn, ngồi xuống thềm đình uống ngụm nước chè ấm đi!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người. Bốn anh em, bốn số phận, kết lại thành một dải non sông.'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Hai Thằng Canh Cổng',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Giết xong thì về. Ngồi lại ở cổng. Tao canh cho mày, mày canh cho bản làng. Chúng ta là Hai Thằng Canh Cổng!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Hoàng Minh Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#38bdf8',
          avatarId: 'avatar_khoi'
        },
        text: 'Bình Liêu... từ nay bình yên.'
      }
    ]
  }
};

export const ARC_11_DATA: ArcCatalog = {
  arcNumber: 11,
  title: 'Arc 11: Trận Cuối Ở Trường Mầm Non (2068)',
  timeframe: 'Đêm Đông 2068 (3:00 AM – Bình Minh)',
  mainCharacters: [
    'Hoàng Minh Bình Khôi (60 tuổi, Bình Liêu Vương)',
    'Lục Triều Dư (32 tuổi, Phe Kéo, cựu đặc công Mốc 1088)',
    'Chu Mạnh Hiếu / Chu Hiếu Què (Bản Khuyết Tật, Lôi Ảnh Thủ)',
    'Hồn Lài Phúc Tài (Tài Dog, 17 tuổi)',
    '20 Đứa Trẻ Trường Mầm Non Bản Cáu',
    'Chó Đốm'
  ],
  corePhilosophy: '“Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người. Mạnh nhất là lúc dừng lại được.”',
  summary: 'Đại Kết Cục trường thiên Bình Liêu Vương: Đêm đông 2068 lúc 3h sáng tại Trường Mầm Non Bản Cáu, Khôi và Dư đột kích giải cứu 20 đứa trẻ, giăng bẫy cáp xích đu chém gãy tay thép 108 nhịp, vượt qua Lôi Ảnh Thủ của Chu Hiếu Què. Khôi dừng liềm cách cổ 1 tấc hóa giải tâm ma; linh hồn Tài Dog siêu thoát. Khôi và Dư đứng thẳng canh giữ cổng đình Lục Nà đón bình minh 2068!',
  events: [
    {
      id: 'A11-E001',
      arcNumber: 11,
      title: 'Đột Kích Trường Mầm Non 3H Sáng (2068)',
      year: '2068',
      location: 'Cổng Trường Mầm Non Bản Cáu — 3H Sáng',
      characters: ['Hoàng Minh Bình Khôi (60 tuổi)', 'Lục Triều Dư (32 tuổi)', 'Chó Đốm'],
      description: [
        'Đúng 3h sáng đêm đông 2068, tuyết rơi phủ trắng cổng Trường Mầm Non Bản Cáu.',
        'Chu Mạnh Hiếu sau khi thất bại tại hang đá đã rút về đây, giam lỏng 20 đứa trẻ tại phòng học để chuẩn bị nghi thức hút sinh khí lần cuối.',
        'Khôi và Dư hạ sơn tiếp cận cổng trường, quét sạch toán trinh sát tà môn phục kích quanh hàng rào.',
        'Người chơi trực tiếp điều khiển chiến đấu, tiêu diệt trinh sát và kiểm tra Rào Chắn Cổng Trường (`rao_chan_cong_mam_non`), thu hồi Chìa Khóa Cổng Trường (`item_chia_khoa_cong_mam_non`).'
      ],
      verbatimLore: [
        '“Trường mầm non 3h sáng, tuyết phủ trắng xóa... Chu Mạnh Hiếu bắt giữ 20 đứa trẻ.”',
        '“Hai Thằng Canh Cổng xuống núi, một sợi tóc của lũ trẻ cũng không được đứt.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: '20 đứa trẻ đang bị nhốt trong phòng học! Dẹp sạch đám lính canh ngoài cổng rồi xông vào!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Cụ Thọ dạy: Võ để giữ người! Đi thôi anh Dư!'
        }
      ],
      objective: 'Tiến vào Trường Mầm Non Bản Cáu (`zone_mam_non_midnight`), hạ gục 3 Trinh Sát Tà Môn và kiểm tra Rào Chắn Cổng Trường (`rao_chan_cong_mam_non`)!',
      status: 'active',
      requiredZoneId: 'zone_mam_non_midnight',
      targetCoords: { x: 300, y: 500 },
      rewardXp: 2000,
      rewardItemIds: ['item_chia_khoa_cong_mam_non'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A11-E002',
      arcNumber: 11,
      title: 'Dư Giăng Cáp Thép & Giật Sập Xích Đu (2068)',
      year: '2068',
      location: 'Sân Chơi Trường Mầm Non Bản Cáu',
      characters: ['Lục Triều Dư (Phe Kéo)', 'Hoàng Minh Bình Khôi'],
      description: [
        'Tiến sâu vào sân chơi trường mầm non giữa các xích đu và xà đu tuyết trắng.',
        'Lục Triều Dư vận dụng kỹ năng đặc công biên phòng, giăng cuộn cáp thép 108 sợi vòng qua hai cột trụ xích đu bằng sắt.',
        'Dư cài chốt căng cáp, chuẩn bị giật sập giàn xích đu để khóa chặt hai cánh tay thép của Hiếu khi giao chiến.',
        'Người chơi tương tác Cột Trụ Xích Đu (`cot_tru_xich_du_giang_cap`), hoàn thành trận địa cạm bẫy cáp thép và nhận Dây Cáp Khóa Thép (`item_day_cap_khoa_thep`).'
      ],
      verbatimLore: [
        '“Tao đã giăng sẵn cáp thép giữa hai vách cột. Tao giật đổ xích đu, mày bổ đứt tà niệm!” — Lục Triều Dư',
        '“Khôi dừng người, Dư kéo người.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: 'Cáp thép đã móc vào giàn xích đu! Khi thằng Hiếu lao tới, tao sẽ giật sập bẫy trói cứng nó!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Em đã sẵn sàng. Trận này kết thúc tất cả!'
        }
      ],
      objective: 'Tương tác Cột Trụ Xích Đu (`cot_tru_xich_du_giang_cap`), giăng cáp thép 108 sợi và giật sập giàn xích đu tạo bẫy khống chế!',
      status: 'locked',
      requiredZoneId: 'zone_mam_non_midnight',
      targetCoords: { x: 780, y: 310 },
      rewardXp: 2200,
      rewardItemIds: ['item_day_cap_khoa_thep'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A11-E003',
      arcNumber: 11,
      title: 'Quyết Chiến Chu Mạnh Hiếu Dạng 1 — Phá Vỡ Tay Thép 108 Nhịp (2068)',
      year: '2068',
      location: 'Đài Trung Tâm Sân Trường Mầm Non',
      characters: ['Chu Mạnh Hiếu (Mặt Tài - Tay Thép)', 'Hoàng Minh Bình Khôi', 'Lục Triều Dư'],
      description: [
        'Chu Mạnh Hiếu xuất hiện trên khán đài trung tâm trường mầm non với khuôn mặt gớm ghiếc mang tà thuật tráo não Tài Dog và cánh tay cơ khí thép của Thảo.',
        'Hắn thi triển 108 Nhịp Tay Thép gõ rung chuyển mặt đất, tung sóng tà hỏa hắc ám.',
        'Lục Triều Dư đu dây cáp giật sập giàn xích đu khóa chặt cánh tay thép, hỗ trợ đắc lực phía sau.',
        'Khôi trực tiếp áp sát, thi triển Liềm Tử Thần chém gãy vụn cánh tay thép cơ khí, tước bỏ hoàn toàn tà cụ hút vía và nhặt Mảnh Tay Thép Gãy Vụn (`item_tay_thep_gay_vun`).'
      ],
      verbatimLore: [
        '“Để xem cái liềm cùn của Bình Liêu Vương có dám chém vào khuôn mặt đứa cháu ruột này không!”',
        '“108 Nhịp Tay Thép — Sát Diệt!”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Chu Mạnh Hiếu (Mặt Tài)',
          text: 'Cậu ơi cứu cháu đi... Haha! Não Tài vẫn đang kêu khóc trong sọ tao đây này!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Tài đã thanh thản rồi. Mày không được phép lấy nó ra dọa tao nữa! ĐỠ LIỀM!'
        }
      ],
      objective: 'Đánh bại Boss Chu Mạnh Hiếu Dạng 1 (`boss_chu_manh_hieu`), phá vỡ lớp giáp và chém gãy cánh tay thép cơ khí 108 nhịp!',
      status: 'locked',
      requiredZoneId: 'zone_mam_non_midnight',
      targetCoords: { x: 1400, y: 440 },
      rewardXp: 3000,
      rewardItemIds: ['item_tay_thep_gay_vun'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A11-E004',
      arcNumber: 11,
      title: 'Chu Hiếu Què Xé Áo — Bộc Lộ Dạng 2 Bản Khuyết Tật (2068)',
      year: '2068',
      location: 'Tâm Sân Trường Mầm Non Bản Cáu',
      characters: ['Chu Hiếu Què (Lôi Ảnh Thủ - Bản Khuyết Tật)', 'Hoàng Minh Bình Khôi'],
      description: [
        'Cánh tay thép vỡ tan, ảo ảnh khuôn mặt Tài tan biến, Chu Mạnh Hiếu cười vang xé toạc áo ngoài.',
        'Lộ ra chiếc áo sát nách màu chàm của Thầy Huỳnh cho từ thuở nhỏ và vết sẹo hình tia sét do nọc độc rắn Móng Cái.',
        'Hắn bộc lộ thân phận Chu Hiếu Què (chân phải ngắn hơn chân trái 2cm), thi triển tuyệt kỹ độc môn Lôi Ảnh Thủ, đứng một chân phóng sấm sét xanh ngọc cực nhanh và tung đòn vật cởi áo cân ba.',
        'Người chơi trực tiếp điều khiển né tránh lôi điện, phản đòn bằng thân pháp và kiếm pháp thuần thục, thu giữ Mảnh Áo Sát Nách Thầy Huỳnh (`item_ao_sat_nach_thay_huynh`).'
      ],
      verbatimLore: [
        '“Cái gì không giết được tao thì làm tao mạnh hơn!” — Chu Hiếu Què',
        '“Đứng một chân trên cột điện 30 phút mỗi ngày để luyện Lôi Ảnh Thủ.”',
        '“Chân phải ngắn hơn chân trái 2cm... kẻ bị xã hội ruồng bỏ.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Chu Hiếu Què',
          text: 'Nhìn cho kỹ chân tao! Tao đứng một chân đấm gãy xương mày, Bình Liêu Vương!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Hiếu què... Mày què chân nhưng tâm mày từng không què. Hãy thức tỉnh đi!'
        }
      ],
      objective: 'Đánh bại Chu Hiếu Què Dạng 2 Bản Khuyết Tật (`boss_chu_manh_hieu` Phase 2), vượt qua Lôi Ảnh Thủ và đòn vật cởi áo cân ba!',
      status: 'locked',
      requiredZoneId: 'zone_mam_non_midnight',
      targetCoords: { x: 1400, y: 440 },
      rewardXp: 3500,
      rewardItemIds: ['item_ao_sat_nach_thay_huynh'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A11-E005',
      arcNumber: 11,
      title: 'Nhát Liềm Dừng Lại — Giải Thoát Chu Hiếu Què (2068)',
      year: '2068',
      location: 'Thềm Đá Trước Dãy Lớp Học Mầm Non',
      characters: ['Hoàng Minh Bình Khôi (Bình Liêu Vương)', 'Chu Hiếu Què'],
      description: [
        'Sau chuỗi giao tranh khốc liệt, Chu Hiếu Què hụt chân do bước nhảy lệch 2cm.',
        'Khôi lướt tới vung Liềm Tử Thần xé toạc màn tuyết — nhưng ngay khoảnh khắc đoạt mạng, Khôi đột ngột dừng lại cách yết hầu Hiếu đúng một tấc.',
        'Đỉnh cao của triết lý “Mạnh nhất là lúc dừng lại được”: chiến thắng bằng sự bao dung và hóa giải thay vì hận thù chém giết.',
        'Chu Hiếu khuỵu chân xuống tuyết khóc, tà niệm tiêu tan; người chơi nhận Dấu Ấn Chữ DỪNG Thành Tựu (`item_dau_an_chu_dung_thanh_tuu`).'
      ],
      verbatimLore: [
        '“Mạnh nhất là lúc dừng lại được.” — Triết lý tối thượng của Bình Liêu Vương',
        '“Mày không giết người. Mày bình người.” — Lời răn dạy của Cụ Thọ'
      ],
      canonicalDialogue: [
        {
          speaker: 'Chu Hiếu Què',
          text: 'Mày chém trúng rồi... Đòn Dừng của cụ Thọ... quả nhiên lợi hại.'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Hiếu què. Mày què nhưng chạy 100m vẫn 11 giây. Về thôi.'
        }
      ],
      objective: 'Tương tác Điểm Dừng Liềm Cuối (`diem_dung_liem_cuoi`), thực thi nhát chém DỪNG LẠI hóa giải tâm ma Chu Hiếu Què!',
      status: 'locked',
      requiredZoneId: 'zone_mam_non_midnight',
      targetCoords: { x: 1400, y: 440 },
      rewardXp: 4000,
      rewardItemIds: ['item_dau_an_chu_dung_thanh_tuu'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A11-E006',
      arcNumber: 11,
      title: 'Giải Cứu 20 Đứa Trẻ & Linh Hồn Tài Siêu Thoát (2068)',
      year: '2068',
      location: 'Cửa Phòng Học Mầm Non Bản Cáu',
      characters: ['20 Đứa Trẻ Bản Cáu', 'Hồn Lài Phúc Tài', 'Hoàng Minh Bình Khôi', 'Lục Triều Dư'],
      description: [
        'Khôi và Dư tiến tới cánh cửa phòng học mầm non, mở khóa rào chắn giải thoát an toàn 20 đứa trẻ.',
        'Tiếng cười trẻ thơ xua tan bầu không khí u ám buốt giá đêm đông.',
        'Linh hồn Lài Phúc Tài (Tài Dog) hiện về trong ánh hào quang ấm áp, mỉm cười chào tạm biệt cậu Khôi và chú Hiếu trước khi hòa mình vào đất mẹ non cao.',
        'Người chơi nhận Khung Tranh 20 Em Nhỏ (`item_khung_tranh_20_em_nho`) và Kỷ Vật Hồn Tài Siêu Thoát (`item_hon_tai_sieu_thoat`).'
      ],
      verbatimLore: [
        '“Cậu Khôi... Chú Hiếu trả lại não cho cháu rồi. Cháu thanh thản rồi cậu ơi!” — Hồn Tài Dog',
        '“Cảm ơn cậu đã giải thoát cho cả hai.”'
      ],
      canonicalDialogue: [
        {
          speaker: 'Hồn Tài Dog',
          text: 'Cậu ơi, đừng bình nữa nhé. Cứ giữ thôi... Cháu đi đây cậu ơi!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Tài... Đi thanh thản nhé con. Cậu hứa sẽ giữ trọn mảnh đất này.'
        }
      ],
      objective: 'Tương tác Cửa Phòng Học Mầm Non (`cua_phong_hoc_20_tre_em`), giải cứu 20 đứa trẻ và chứng kiến Linh Hồn Tài siêu thoát!',
      status: 'locked',
      requiredZoneId: 'zone_mam_non_midnight',
      targetCoords: { x: 1750, y: 500 },
      rewardXp: 4500,
      rewardItemIds: ['item_khung_tranh_20_em_nho', 'item_hon_tai_sieu_thoat'],
      auditStatus: 'hoàn thành'
    },
    {
      id: 'A11-E007',
      arcNumber: 11,
      title: 'Hai Thằng Canh Cổng — Bình Minh Trở Lại Đất Bình Liêu (Đại Kết Cục)',
      year: '2068',
      location: 'Cổng Đình Lục Nà — Bản Cáu',
      characters: ['Hoàng Minh Bình Khôi (60 tuổi)', 'Lục Triều Dư (32 tuổi)', 'Chó Đốm'],
      description: [
        'Khôi và Dư trở về cổng đình Lục Nà. Dư nhóm bếp than sưởi ấm, Khôi gấp vuông chiếc khăn trắng lau sạch lưỡi liềm.',
        'Chó Đốm quẫy đuôi mừng rỡ chạy vòng quanh chân hai người.',
        'Bầu trời hừng đông, tuyết Shibuya ngớt hạt, bình minh năm 2068 dát vàng rực rỡ lên đỉnh đèo biên thùy Mốc 1088, Thác Khe Vằn và Đồi Mộ Bản Cáu.',
        'Tứ trụ truyền thừa vĩnh hằng: “Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người”. Khôi và Dư trở thành Hai Thằng Canh Cổng muôn đời bảo hộ giang sơn!',
        'Người chơi tương tác Thềm Đá Cổng Đình (`them_da_hai_thang_canh_cong_ending`), hoàn tất toàn bộ 11 Arc và nhận Danh Hiệu Huyền Thoại Bình Liêu Vương Vĩ Đại (`item_danh_hieu_binh_lieu_vuong_vi_dai`).'
      ],
      verbatimLore: [
        '“Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người.”',
        '“Giết xong thì về. Ngồi lại ở cổng. Tao canh cho.” — Lục Triều Dư',
        '“Về. Nhưng không ngồi nữa. Đứng thẳng.” — Hoàng Minh Bình Khôi'
      ],
      canonicalDialogue: [
        {
          speaker: 'Lục Triều Dư',
          text: 'Hai thằng mày đều điên như nhau, nhưng tâm đều sáng. Về cổng đình thôi Khôi!'
        },
        {
          speaker: 'Hoàng Minh Bình Khôi',
          text: 'Về. Nhưng không ngồi nữa. Đứng thẳng!'
        }
      ],
      objective: 'Trở về Đình Lục Nà (`zone_ban_cau`), tương tác Thềm Đá Cổng Đình (`them_da_hai_thang_canh_cong_ending`) hoàn thành Đại Kết Cục Bình Liêu Vương!',
      status: 'locked',
      requiredZoneId: 'zone_ban_cau',
      targetCoords: { x: 450, y: 460 },
      rewardXp: 5000,
      rewardItemIds: ['item_danh_hieu_binh_lieu_vuong_vi_dai'],
      auditStatus: 'hoàn thành'
    }
  ]
};

export const ARC_11_AUDIT_TABLE: ArcAuditEntry[] = [
  {
    eventCode: 'A11-E001',
    sourceLoreSummary: 'Đêm đông 2068 lúc 3h sáng, Chu Mạnh Hiếu rút về Trường Mầm Non Bản Cáu bao vây bắt giữ 20 đứa trẻ làm con tin hút vía; Khôi và Dư đột kích cổng trường dẹp sạch trinh sát tà môn.',
    inGameImplementationLocation: 'Zone Trường Mầm Non 3H Sáng (`zone_mam_non_midnight`): Tiêu diệt 3 Trinh Sát Tà Môn (`do_tham_ta_mon`), tương tác Rào Chắn Cổng Trường (`rao_chan_cong_mam_non`), đoạt Chìa Khóa Cổng Trường (`item_chia_khoa_cong_mam_non`).',
    status: 'hoàn thành',
    notes: 'Khởi đầu trận cuối với không khí tuyết đêm 3h sáng, người chơi trực tiếp chiến đấu và giải phóng cổng rào chắn.'
  },
  {
    eventCode: 'A11-E002',
    sourceLoreSummary: 'Lục Triều Dư nẹp lưng kim loại, dùng 108 sợi cáp thép giăng giữa hai cột trụ xích đu và giật sập giàn xích đu tạo bẫy khống chế cánh tay thép của Hiếu.',
    inGameImplementationLocation: 'Zone Trường Mầm Non: Tương tác Cột Trụ Xích Đu (`cot_tru_xich_du_giang_cap`), giăng cáp thép và kích hoạt hiệu ứng sập xích đu, nhận Dây Cáp Khóa Thép (`item_day_cap_khoa_thep`).',
    status: 'hoàn thành',
    notes: 'Thể hiện vai trò thực tế của phe Kéo — Dư giật dây cáp bẫy xích đu, tạo thế gọng kìm phối hợp cùng Khôi.'
  },
  {
    eventCode: 'A11-E003',
    sourceLoreSummary: 'Chu Mạnh Hiếu Dạng 1 mang mặt Tài Dog và tay thép cơ khí của Thảo gõ 108 nhịp; Dư kéo dây cáp khóa tay, Khôi vung Liềm Tử Thần chém gãy cánh tay thép cơ khí.',
    inGameImplementationLocation: 'Zone Trường Mầm Non: Đấu Boss Chu Mạnh Hiếu Dạng 1 (`boss_chu_manh_hieu`), né đòn đấm thép 108 nhịp, phá giáp và chém gãy tay thép, nhặt Mảnh Tay Thép Gãy Vụn (`item_tay_thep_gay_vun`).',
    status: 'hoàn thành',
    notes: 'AI Boss vung đòn đấm thép và chấn động đất; Dư tham gia kéo cáp; hiệu ứng mảnh thép vỡ nổ tung.'
  },
  {
    eventCode: 'A11-E004',
    sourceLoreSummary: 'Tay thép gãy, Hiếu xé áo ngoài lộ áo sát nách thầy Huỳnh và sẹo tia sét Nữ Thánh Rắn; bộc lộ Dạng 2: Chu Hiếu Què (chân ngắn hơn 2cm), đứng một chân tung Lôi Ảnh Thủ và đòn vật cởi áo cân ba.',
    inGameImplementationLocation: 'Zone Trường Mầm Non: Kích hoạt đối thoại biến thân `dialog_boss_phase_2_transform`, đấu Boss Phase 2 Lôi Ảnh Thủ phóng sét xanh ngọc và lao cởi áo cân ba, thu giữ Áo Sát Nách Thầy Huỳnh (`item_ao_sat_nach_thay_huynh`).',
    status: 'hoàn thành',
    notes: 'Tái hiện 100% hình ảnh Chu Hiếu Què bản khuyết tật trong lore, AI biến đổi tốc độ cao và phóng tia sét liên tục.'
  },
  {
    eventCode: 'A11-E005',
    sourceLoreSummary: 'Khôi vung liềm đoạt mạng nhưng dừng lại cách cổ Hiếu đúng một tấc; triết lý “Mạnh nhất là lúc dừng lại được” hóa giải hoàn toàn oán hận; Hiếu khuỵu chân nhận thua.',
    inGameImplementationLocation: 'Zone Trường Mầm Non: Tương tác Điểm Dừng Liềm Cuối (`diem_dung_liem_cuoi`), thi triển đòn DỪNG cứu sống Hiếu, nhận Dấu Ấn Chữ DỪNG Thành Tựu (`item_dau_an_chu_dung_thanh_tuu`).',
    status: 'hoàn thành',
    notes: 'Hiện thực hóa triết lý tối cao xuyên suốt cả 11 Arc: Khôi không sát sinh, dừng lại để cứu chuộc một tâm hồn lầm lỡ.'
  },
  {
    eventCode: 'A11-E006',
    sourceLoreSummary: 'Mở cửa phòng học giải thoát 20 đứa trẻ an toàn tuyệt đối; linh hồn Tài Dog hiện về mỉm cười thanh thản cảm ơn cậu Khôi và siêu thoát vào đất mẹ.',
    inGameImplementationLocation: 'Zone Trường Mầm Non: Tương tác Cửa Phòng Học Mầm Non (`cua_phong_hoc_20_tre_em`), giải thoát 20 đứa trẻ, đối thoại xúc động cùng Hồn Tài Dog (`dialog_boss_victory`), nhận Kỷ Vật Hồn Tài Siêu Thoát (`item_hon_tai_sieu_thoat`).',
    status: 'hoàn thành',
    notes: 'Đem lại cái kết ấm áp tình nghĩa, không còn nỗi đau hoán não, đứa trẻ 17 tuổi được yên nghỉ vĩnh hằng.'
  },
  {
    eventCode: 'A11-E007',
    sourceLoreSummary: 'Khôi và Dư trở về ngồi canh cổng đình Lục Nà; tuyết ngừng rơi, bình minh 2068 ló rạng; 4 người 4 nhánh: Cần giữ, Thọ bình, Khôi dừng, Dư kéo vĩnh hằng bảo vệ Bình Liêu.',
    inGameImplementationLocation: 'Zone Bản Cáu (`zone_ban_cau`): Tương tác Thềm Đá Cổng Đình (`them_da_hai_thang_canh_cong_ending`), kích hoạt màn hình Đại Kết Cục Bình Liêu Vương, nhận Danh Hiệu Bình Liêu Vương Vĩ Đại (`item_danh_hieu_binh_lieu_vuong_vi_dai`).',
    status: 'hoàn thành',
    notes: 'Đoạn kết trọn vẹn và hoàn mỹ cho toàn bộ tác phẩm; hiển thị màn hình chúc mừng hoàn thành game và mở khóa tự do khám phá.'
  }
];






