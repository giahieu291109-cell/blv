/**
 * Main 2D Game Engine for BÌNH LIÊU VƯƠNG
 * Platformer physics, 60fps game loop, hitbox combat, particle systems, enemy AI, and camera.
 */

import { sound } from './audio';
import { INITIAL_INVENTORY, INITIAL_QUESTS, LORE_ENTRIES } from './loreData';
import { ZONES } from './mapData';
import { PixelRenderer } from './sprites';
import { arcManager } from './arcManager';
import {
  DamageNumber,
  Direction,
  DroppedItem,
  Enemy,
  GameScreen,
  InputState,
  InteractiveObject,
  InventoryItem,
  NPC,
  Particle,
  Platform,
  PlayerActionState,
  PlayerStats,
  Quest,
  SavedGameState,
  Zone,
  ZonePortal
} from './types';

export interface GameEngineCallbacks {
  onStatsChange?: (stats: PlayerStats) => void;
  onZoneChange?: (zone: Zone) => void;
  onDialogTrigger?: (dialogId: string) => void;
  onQuestUpdate?: (quests: Quest[]) => void;
  onGameOver?: () => void;
  onVictory?: () => void;
  onLoreUnlocked?: (loreId: string, title: string) => void;
  onInteractPrompt?: (prompt: string | null) => void;
  onOpenArcPortalModal?: () => void;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private isRunning: boolean = false;
  private lastTime: number = 0;
  private animTimer: number = 0;

  // Viewport / Camera
  public cameraX: number = 0;
  public cameraY: number = 0;
  public screenWidth: number = 800;
  public screenHeight: number = 450;
  private screenShakeTime: number = 0;
  private screenShakeIntensity: number = 0;
  private hitstopTimer: number = 0;

  // Game World
  public currentZone: Zone;
  public zones: Record<string, Zone>;
  public activeScreen: GameScreen = 'title';

  // Player Entity
  public player = {
    x: 100,
    y: 440,
    w: 24,
    h: 46,
    vx: 0,
    vy: 0,
    direction: 1 as Direction,
    state: 'idle' as PlayerActionState,
    stateTimer: 0,
    isGrounded: false,
    jumpCount: 0,
    maxJumps: 4, // Quadruple Jump (Nhảy 4 lần)
    coyoteTimer: 0,
    jumpBufferTimer: 0,
    isDashing: false,
    dashTimer: 0,
    invincibleTimer: 0,
    comboCounter: 0,
    comboResetTimer: 0,
    atkBuffTimer: 0, // Thời gian tăng sức mạnh từ Đan Dược
  };

  public stats: PlayerStats = {
    level: 1,
    xp: 0,
    maxXp: 100,
    hp: 150,
    maxHp: 150,
    qi: 100,
    maxQi: 100,
    attackPower: 35,
    defense: 8,
    // Trang bị 6 ô đồ (Hotbar: Vũ khí, Mũ giáp, Giáp thân, Giáp quần, Giáp chân, Đồ hồi máu)
    equippedWeapon: 'than_vu_giai',
    equippedHelmet: 'Mũ Giáp Thần Vũ',
    equippedChest: 'Giáp Thân Thần Vũ',
    equippedPants: 'Giáp Quần Chí Tôn',
    equippedBoots: 'Giáp Chân Phong Lôi',
    equippedHealing: 'Đại Hoàn Đan',
    hotbarSlots: [
      { id: 'hotbar_weapon', name: 'Thần Vũ Giải (Kamutoke)', type: 'weapon', icon: '⚡', equipped: true },
      { id: 'hotbar_helmet', name: 'Mũ Giáp Thần Vũ', type: 'helmet', icon: '👑', equipped: true },
      { id: 'hotbar_chest', name: 'Giáp Thân Thần Vũ', type: 'chest', icon: '🥋', equipped: true },
      { id: 'hotbar_pants', name: 'Giáp Quần Chí Tôn', type: 'pants', icon: '👖', equipped: true },
      { id: 'hotbar_boots', name: 'Giáp Chân Phong Lôi', type: 'boots', icon: '👢', equipped: true },
      { id: 'hotbar_healing', name: 'Đại Hoàn Đan', type: 'healing', icon: '💊', count: 99 },
    ],
    // Hắc Thiểm & Trạng thái Thức Tỉnh (120% tiềm năng)
    isAwakened: false,
    awakenedTimer: 0,
    hpRegenTimer: 0,
    // Giáp và Độ bền giáp người chơi
    armor: 400,
    maxArmor: 400,
    armorDurability: 100,
    maxArmorDurability: 100,
    equippedArmorName: 'Chiến Giáp Tuyết Biên Phòng',
    // Tiến trình 12 Arc chính thức theo lore
    currentArc: 1,
    arcTitle: 'Arc 1: Nguồn Gốc Của Những Người Giữ Làng',
    // Bạo kích 75% (50% đến 100%)
    critRate: 0.75,
    critDamageMultiplier: 2.5,
    // Rèn & Ghép hiệu ứng vũ khí
    weaponLevel: 1,
    weaponElement: 'ice',
    upgradeShards: 5,
    // Hệ thống Đợt quái (5 đợt, 100 quái mỗi arc)
    waveNumber: 1,
    totalWaves: 5,
    monstersRemainingInArc: 100,
    totalMonstersPerArc: 100,
    noStacks: 0,
    hasBangGiap: false,
    stillTimer: 0,
    isHoiQuangActive: false,
    hoiQuangTimer: 0,
    hasUsedTuyếtTrắng: false,
    isSealedInIce: false,
    iceTombTimer: 0,
    ngucMonTimer: 0,
    hasButBang: false,
    killCount: 0,
    neonBuffTimer: 0,
    killQuote: null,
    killQuoteTimer: 0,
    sealWarningText: null,
    sealWarningTimer: 0,
    objectiveTitle: 'A01-E001: Đứa Trẻ Mồ Côi Bản Cáu (1977)',
    objectiveDetail: 'Gió tuyết rét buốt! Hãy nhặt 3 bó củi khô rừng Lục Nà (0/3) để nhóm bếp than sưởi ấm chòi lá.',
    woodCount: 0,
    isHearthLit: false,
    beastsDefeated: 0,
    totalBeasts: 4,
    dummyHits: 0,
    maxDummyHits: 20,
    isFeverRecovered: false,
    bulliesDefeated: 0,
    totalBullies: 3,
    hasSparedBully: false,
    hasBrokenStaff: false,
    isStaffPreserved: false,
    mathClassVisited: false,
    arc3Completed: false,
    // Arc 6: Chiến Binh Thác Khe Vằn (2029)
    hasLookedIntoWater: false,
    kheVanBeastsDefeated: 0,
    totalKheVanBeasts: 4,
    cableDuelCompleted: false,
    treoMinhProgress: 0,
    isTreoMinhCompleted: false,
    tamMaDefeated: false,
    isKheVanTramMastered: false,
    arc6Completed: false,
    // Arc 7: Tài Dog và Cái "Giữ" Cuối Cùng (2030 – 2065)
    hasCaredForTai: false,
    hasCutBambooGift: false,
    hasWitnessedTaiTrangTroi: false,
    hasLockedScytheInSafe: false,
    hasSavedDomAtGrave: false,
    taMonDefeated: 0,
    totalTaMon: 4,
    arc7Completed: false,
    // Arc 8: Rubik Ngục Môn Cương — Ba Chú Linh (2065 – 2068)
    hasDiscoveredRubikMatrix: false,
    tuanDefeated: false,
    hasPurifiedBlackSalt: false,
    tayDefeated: false,
    hasQuenchedEvilCoal: false,
    hungDefeated: false,
    hasObtainedRubikKey: false,
    hasReceivedGingerPorridge: false,
    hasEnteredRubikCube: false,
    arc8Completed: false,
    // Arc 9 tracking
    hasInvestigatedDesecratedGrave: false,
    cluesFoundCount: 0,
    taSuDefeated: 0,
    totalTaSu: 5,
    hasDestroyedOperatingTable: false,
    hieuAvatarDefeated: false,
    hasTriggeredBrainRejection: false,
    hasMetLucTrieuDuArc9: false,
    arc9Completed: false,
    // Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại (2068)
    cableAnchorsCount: 0,
    hacDaoDefeated: 0,
    totalHacDao: 4,
    bossDaoThuDefeated: false,
    rubik108BeatsTriggered: false,
    hasReceivedAoPhaoDenRach: false,
    doThamTaMonDefeated: 0,
    totalDoThamTaMon: 3,
    hasCompletedTwoGatekeepersTrial: false,
    arc10Completed: false,
    // Arc 11: Trận Cuối Ở Trường Mầm Non (2068)
    mamNonGuardsDefeated: 0,
    totalMamNonGuards: 3,
    hasPulledSwingCableTrap: false,
    bossHieuPhase1Defeated: false,
    bossHieuPhase2Defeated: false,
    hasSparedChuHieuEnding: false,
    hasRescued20Children: false,
    arc11Completed: false,
    gameCompleted: false,
    skillCooldowns: {
      dismantle: 0,
      cleave: 0,
      kamino: 0,
      shrine: 0,
      worldSlash: 0,
      kamutoke: 0,
      tuthanDotKich: 0,
      kheVanTram: 0,
      neonGay: 0,
      coiCuuThuong: 0,
      hoiQuang: 0,
      cuonTranh: 0,
      dash: 0,
    },
  };

  public inventory: InventoryItem[] = [...INITIAL_INVENTORY];
  public quests: Quest[] = [...INITIAL_QUESTS];
  public unlockedLore: string[] = LORE_ENTRIES.filter(e => e.unlockedByDefault).map(e => e.id);

  // Entities & Effects
  public droppedItems: DroppedItem[] = [];
  public particles: Particle[] = [];
  public damageNumbers: DamageNumber[] = [];
  public currentPrompt: string | null = null;
  public activeNearObject: InteractiveObject | NPC | ZonePortal | null = null;
  public waveTimer: number = 0;
  public waveAnnouncement: string | null = null;
  public waveAnnouncementTimer: number = 0;
  public playerSpeechBubble?: string;
  public playerSpeechTimer: number = 0;

  // Jujutsu Kaisen: Malevolent Shrine & World Cutting Slash State
  public isMalevolentShrineActive: boolean = false;
  public malevolentShrineTimer: number = 0;
  public malevolentShrineX: number = 0;
  public malevolentShrineY: number = 0;
  public malevolentShrineTickTimer: number = 0;
  public worldSlashEffectTimer: number = 0;

  // 2D Side-Scrolling Terraria Anime Ryomen Sukuna: Techniques & Open Domain Simulation
  public dismantleSlashes: Array<{ x1: number; y1: number; x2: number; y2: number; life: number; maxLife: number; angle: number }> = [];
  public cleaveImpacts: Array<{ x: number; y: number; w: number; h: number; life: number; maxLife: number; scale: number }> = [];
  public fugaProjectiles: Array<{ x: number; y: number; vx: number; vy: number; life: number; maxLife: number; targetX: number; targetY: number }> = [];
  public fugaThermalBlasts: Array<{ x: number; y: number; currentRadius: number; maxRadius: number; life: number; maxLife: number }> = [];
  public domainMicroSlashes: Array<{ x1: number; y1: number; x2: number; y2: number; life: number; maxLife: number; color: string; width: number }> = [];
  public domainRadius: number = 880; // Bán kính cực lớn vì lãnh địa mở không bị giới hạn bởi tường


  // Input State
  public input: InputState = {
    left: false,
    right: false,
    up: false,
    down: false,
    jump: false,
    justJumped: false,
    attack: false,
    justAttacked: false,
    dash: false,
    justDashed: false,
    skill1: false,
    justSkill1: false,
    skill2: false,
    justSkill2: false,
    skillHoiQuang: false,
    justSkillHoiQuang: false,
    skillCuonTranh: false,
    justSkillCuonTranh: false,
    skillDismantle: false,
    justSkillDismantle: false,
    skillCleave: false,
    justSkillCleave: false,
    skillKamino: false,
    justSkillKamino: false,
    skillShrine: false,
    justSkillShrine: false,
    skillWorldSlash: false,
    justSkillWorldSlash: false,
    skillKamutoke: false,
    justSkillKamutoke: false,
    useQuickHeal: false,
    justUseQuickHeal: false,
    tearScroll: false,
    justTearScroll: false,
    interact: false,
    justInteracted: false,
    joystickX: 0,
    joystickY: 0,
  };

  private callbacks: GameEngineCallbacks = {};

  constructor(canvas: HTMLCanvasElement, callbacks?: GameEngineCallbacks) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Failed to get 2D canvas context');
    this.ctx = context;
    if (callbacks) this.callbacks = callbacks;

    // Deep clone zones so mutations stay local to session
    this.zones = JSON.parse(JSON.stringify(ZONES));
    this.currentZone = this.zones.zone_ban_cau;
    for (const npc of this.currentZone.npcs) {
      npc.y = this.getGroundYAt(npc.x, npc.y);
    }

    this.resizeCanvas();
    this.loadGame();
  }

  public setCallbacks(cb: GameEngineCallbacks) {
    this.callbacks = { ...this.callbacks, ...cb };
  }

  public resizeCanvas() {
    const dpr = window.devicePixelRatio || 1;
    const rect = this.canvas.getBoundingClientRect();
    this.screenWidth = rect.width || window.innerWidth;
    this.screenHeight = rect.height || window.innerHeight;

    this.canvas.width = this.screenWidth * dpr;
    this.canvas.height = this.screenHeight * dpr;
    this.ctx.resetTransform();
    this.ctx.scale(dpr, dpr);
    this.ctx.imageSmoothingEnabled = false;
  }

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = performance.now();
    sound.setBgmTheme(this.currentZone.theme);
    requestAnimationFrame(this.loop.bind(this));
  }

  public stop() {
    this.isRunning = false;
    sound.stopBgm();
  }

  /**
   * Main 60fps Loop
   */
  private loop(currentTime: number) {
    if (!this.isRunning) return;
    const rawDt = (currentTime - this.lastTime) / 1000;
    this.lastTime = currentTime;
    const dt = Math.min(rawDt, 0.05); // Clamp dt to prevent tunneling on frame drop

    this.update(dt);
    this.render();

    requestAnimationFrame(this.loop.bind(this));
  }

  /**
   * Simulation Updates
   */
  private update(dt: number) {
    this.animTimer += dt;

    // Hitstop freeze
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      return;
    }

    // Screen shake decay
    if (this.screenShakeTime > 0) {
      this.screenShakeTime -= dt;
      if (this.screenShakeTime <= 0) this.screenShakeIntensity = 0;
    }

    // Cooldown decays
    if (this.stats.skillCooldowns.dash > 0) this.stats.skillCooldowns.dash -= dt;
    if (this.stats.skillCooldowns.dismantle > 0) this.stats.skillCooldowns.dismantle -= dt;
    if (this.stats.skillCooldowns.cleave > 0) this.stats.skillCooldowns.cleave -= dt;
    if (this.stats.skillCooldowns.kamino > 0) this.stats.skillCooldowns.kamino -= dt;
    if (this.stats.skillCooldowns.shrine > 0) this.stats.skillCooldowns.shrine -= dt;
    if (this.stats.skillCooldowns.worldSlash > 0) this.stats.skillCooldowns.worldSlash -= dt;
    if (this.stats.skillCooldowns.kamutoke > 0) this.stats.skillCooldowns.kamutoke -= dt;
    if (this.stats.skillCooldowns.kheVanTram > 0) this.stats.skillCooldowns.kheVanTram -= dt;
    if (this.stats.skillCooldowns.tuthanDotKich > 0) this.stats.skillCooldowns.tuthanDotKich -= dt;
    if (this.stats.skillCooldowns.neonGay > 0) this.stats.skillCooldowns.neonGay -= dt;
    if (this.stats.skillCooldowns.coiCuuThuong > 0) this.stats.skillCooldowns.coiCuuThuong -= dt;
    if (this.stats.skillCooldowns.hoiQuang > 0) this.stats.skillCooldowns.hoiQuang -= dt;
    if (this.stats.skillCooldowns.cuonTranh > 0) this.stats.skillCooldowns.cuonTranh -= dt;

    // Chant decay for World-Cutting Slash (3-step chant: Long Lân -> Enmaten -> Launch)
    if (this.stats.chantTimer && this.stats.chantTimer > 0) {
      this.stats.chantTimer -= dt;
      if (this.stats.chantTimer <= 0) {
        this.completeWorldSlash();
      }
    }

    if (this.worldSlashEffectTimer > 0) {
      this.worldSlashEffectTimer -= dt;
    }

    // --- UPDATE SUKUNA TECHNIQUES SIMULATION (TERRARIA 2D PIXEL ART) ---
    // 1. Dismantle Slashes Decay
    for (let i = this.dismantleSlashes.length - 1; i >= 0; i--) {
      const s = this.dismantleSlashes[i];
      s.life -= dt;
      if (s.life <= 0) this.dismantleSlashes.splice(i, 1);
    }

    // 2. Cleave Adaptive Impacts Decay & Scaling
    for (let i = this.cleaveImpacts.length - 1; i >= 0; i--) {
      const c = this.cleaveImpacts[i];
      c.life -= dt;
      c.scale = Math.min(1.8, c.scale + dt * 2.2);
      if (c.life <= 0) this.cleaveImpacts.splice(i, 1);
    }

    // 3. Fuga Fire Arrow Projectiles Flight & Thermal Blast Trigger
    for (let i = this.fugaProjectiles.length - 1; i >= 0; i--) {
      const proj = this.fugaProjectiles[i];
      proj.x += proj.vx * dt;
      proj.y += proj.vy * dt;
      proj.life -= dt;

      // Fiery trail particles
      if (Math.random() < 0.6) {
        this.particles.push({
          x: proj.x + (Math.random() - 0.5) * 6,
          y: proj.y + (Math.random() - 0.5) * 6,
          vx: -proj.vx * 0.15 + (Math.random() - 0.5) * 40,
          vy: (Math.random() - 0.5) * 30 - 10,
          life: 0.35,
          maxLife: 0.35,
          size: 3 + Math.random() * 2,
          color: Math.random() > 0.4 ? '#f97316' : '#ea580c',
          alpha: 1.0,
          type: 'fire',
        });
      }

      // Check impact with target or floor or expiry
      const distToTarget = Math.hypot(proj.x - proj.targetX, proj.y - proj.targetY);
      const hitObstacle = distToTarget < 32 || proj.life <= 0;

      if (hitObstacle) {
        // TriggerAreaExplosion: Massive localized thermal blast wave
        this.triggerScreenShake(20, 0.7);
        sound.playExplosion();
        const blastRadius = 380;
        this.fugaThermalBlasts.push({
          x: proj.x,
          y: proj.y,
          currentRadius: 18,
          maxRadius: blastRadius,
          life: 0.75,
          maxLife: 0.75,
        });

        // Fill wide 2D radius with pixelated flames
        for (let pIdx = 0; pIdx < 70; pIdx++) {
          const ang = Math.random() * Math.PI * 2;
          const spd = 60 + Math.random() * 320;
          this.particles.push({
            x: proj.x + Math.cos(ang) * (Math.random() * 40),
            y: proj.y + Math.sin(ang) * (Math.random() * 30),
            vx: Math.cos(ang) * spd,
            vy: Math.sin(ang) * spd - 60,
            life: 0.55 + Math.random() * 0.4,
            maxLife: 0.95,
            size: 4 + Math.random() * 5,
            color: Math.random() > 0.5 ? '#f97316' : Math.random() > 0.3 ? '#ef4444' : '#fef08a',
            alpha: 1.0,
            type: 'fire',
          });
        }

        // Apply thermal blast AoE damage to all targets in radius
        const aoeBox = {
          x: proj.x - blastRadius / 2,
          y: proj.y - blastRadius / 2,
          w: blastRadius,
          h: blastRadius,
        };
        const blastDmg = this.stats.attackPower * (this.stats.isAwakened ? 9.5 : 8.0);
        this.checkPlayerAttackHit(aoeBox, blastDmg, true);

        this.fugaProjectiles.splice(i, 1);
      }
    }

    // 4. Fuga Thermal Blasts Expansion
    for (let i = this.fugaThermalBlasts.length - 1; i >= 0; i--) {
      const blast = this.fugaThermalBlasts[i];
      blast.life -= dt;
      blast.currentRadius += (blast.maxRadius - blast.currentRadius) * (dt * 12);
      if (blast.life <= 0) this.fugaThermalBlasts.splice(i, 1);
    }

    // 5. Malevolent Shrine (Phục Ma Ngự Trù Tử) - Open Domain Simulation
    if (this.isMalevolentShrineActive) {
      this.malevolentShrineTimer -= dt;
      this.malevolentShrineTickTimer -= dt;

      // Spawn high-frequency storm of micro-slashes (SpawnMicroSlashesRoutine)
      for (let sl = 0; sl < 8; sl++) {
        const offset = (Math.random() - 0.5) * this.domainRadius * 1.8;
        const slashCenterX = this.malevolentShrineX + offset;
        const slashCenterY = this.malevolentShrineY - Math.random() * 380;
        const slashLen = 80 + Math.random() * 160;
        const angle = (Math.random() - 0.5) * Math.PI * 0.8;
        this.domainMicroSlashes.push({
          x1: slashCenterX - Math.cos(angle) * slashLen / 2,
          y1: slashCenterY - Math.sin(angle) * slashLen / 2,
          x2: slashCenterX + Math.cos(angle) * slashLen / 2,
          y2: slashCenterY + Math.sin(angle) * slashLen / 2,
          life: 0.12 + Math.random() * 0.08,
          maxLife: 0.2,
          color: Math.random() > 0.4 ? '#ffffff' : Math.random() > 0.2 ? '#ef4444' : '#18181b',
          width: 1.5 + Math.random() * 2,
        });
      }

      // Floating pixel embers drifting upward in oppressive atmosphere
      if (Math.random() < 0.8) {
        this.particles.push({
          x: this.cameraX + Math.random() * this.screenWidth,
          y: this.cameraY + this.screenHeight + 10,
          vx: (Math.random() - 0.5) * 45,
          vy: -60 - Math.random() * 80,
          life: 2.2,
          maxLife: 2.2,
          size: 2 + Math.random() * 2.5,
          color: Math.random() > 0.5 ? '#f87171' : '#dc2626',
          alpha: 0.9,
          type: 'spark',
        });
      }

      // Continuous automatic damage tick to all targets inside open domain radius
      if (this.malevolentShrineTickTimer <= 0) {
        this.malevolentShrineTickTimer = 0.22; // ~4.5 ticks per second
        sound.playCleave();
        this.triggerScreenShake(8, 0.15);

        for (const enemy of this.currentZone.enemies) {
          if (enemy.hp <= 0) continue;
          // Check if enemy is within domain radius (Open Domain: no physical walls)
          const inRange = Math.abs(enemy.x - this.malevolentShrineX) <= this.domainRadius;
          if (!inRange) continue;

          // Continuous Slashes: Kai for inanimate/spirit & Hachi for high curse endurance
          const kaiDamage = Math.max(16000, this.stats.attackPower * 48);
          const hachiDamage = enemy.isBoss ? Math.max(22000000, enemy.maxHp * 0.042) : enemy.maxHp;
          const totalTickDamage = Math.round(kaiDamage + hachiDamage);

          enemy.hp -= totalTickDamage;
          enemy.hurtTimer = 0.18;
          this.addDamageNumber(enemy.x, enemy.y - 30, totalTickDamage, '#ef4444', true);

          for (let s = 0; s < 5; s++) {
            this.particles.push({
              x: enemy.x + (Math.random() - 0.5) * enemy.w,
              y: enemy.y - Math.random() * enemy.h,
              vx: (Math.random() - 0.5) * 480,
              vy: (Math.random() - 0.5) * 480,
              life: 0.25,
              maxLife: 0.25,
              size: 4,
              color: Math.random() > 0.5 ? '#ffffff' : '#dc2626',
              alpha: 1.0,
              type: 'spark',
            });
          }

          if (enemy.hp <= 0) {
            this.handleEnemyDefeated(enemy);
          }
        }
      }

      if (this.malevolentShrineTimer <= 0) {
        this.isMalevolentShrineActive = false;
      }
    }

    // 6. Domain Micro-Slashes Decay
    for (let i = this.domainMicroSlashes.length - 1; i >= 0; i--) {
      const s = this.domainMicroSlashes[i];
      s.life -= dt;
      if (s.life <= 0) this.domainMicroSlashes.splice(i, 1);
    }

    // Passive HP Regeneration: +5 HP mỗi giây (Requirement 22)
    this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + 5 * dt);

    // Trạng thái Thức Tỉnh (Hắc Thiểm - 120% tiềm năng)
    if (this.stats.isAwakened) {
      this.stats.awakenedTimer -= dt;
      if (this.stats.awakenedTimer <= 0) {
        this.stats.isAwakened = false;
      }
    }

    // Hồi Quang 6s countdown
    if (this.stats.isHoiQuangActive) {
      this.stats.hoiQuangTimer -= dt;
      if (this.stats.hoiQuangTimer <= 0) {
        this.stats.isHoiQuangActive = false;
      }
    }

    // Phong Ấn Tuyết Trắng Chôn Tên 5s stasis
    if (this.stats.isSealedInIce) {
      this.stats.iceTombTimer -= dt;
      if (this.stats.iceTombTimer <= 0) {
        this.stats.isSealedInIce = false;
        this.stats.hp = Math.round(this.stats.maxHp * 0.5);
        this.stats.hasButBang = true;
        this.player.state = 'idle';
        sound.playIceFreeze();
        this.spawnIceShatter(this.player.x, this.player.y);
      }
    }

    // Ngục Môn Cương 3s countdown (Nhấn XÉ CUỘN TRANH để phá phong ấn)
    if (this.stats.ngucMonTimer > 0) {
      this.stats.ngucMonTimer -= dt;
      if (this.input.justTearScroll || this.input.tearScroll) {
        this.stats.ngucMonTimer = 0;
        this.stats.hp = Math.round(this.stats.maxHp * 0.3);
        this.stats.noStacks = 0;
        sound.playScrollTear();
        this.triggerScreenShake(8, 0.4);
        this.spawnBloodSparks(this.player.x, this.player.y - 20);
        this.addDamageNumber(this.player.x, this.player.y - 50, 0, '#38bdf8', true);
      } else if (this.stats.ngucMonTimer <= 0) {
        this.player.state = 'dead';
        this.activeScreen = 'gameover';
        if (this.callbacks.onGameOver) this.callbacks.onGameOver();
      }
    }

    // Tuyết Phủ 109: Đứng yên 2s nhận Băng Giáp
    if (Math.abs(this.player.vx) < 5 && this.player.isGrounded && !this.stats.isSealedInIce) {
      this.stats.stillTimer += dt;
      if (this.stats.stillTimer >= 2.0 && !this.stats.hasBangGiap) {
        this.stats.hasBangGiap = true;
        sound.playIceFreeze();
        this.spawnIceShatter(this.player.x, this.player.y, 8);
      }
    } else {
      if (this.stats.hasBangGiap && Math.abs(this.player.vx) > 10) {
        this.stats.stillTimer = 0;
        this.stats.hasBangGiap = false;
      }
    }

    // Qi passive regeneration
    if (this.stats.qi < this.stats.maxQi) {
      this.stats.qi = Math.min(this.stats.maxQi, this.stats.qi + 8 * dt);
    }

    // Seal warning banner timer
    if (this.stats.sealWarningTimer && this.stats.sealWarningTimer > 0) {
      this.stats.sealWarningTimer -= dt;
      if (this.stats.sealWarningTimer <= 0) {
        this.stats.sealWarningText = null;
      }
    }

    // Player dynamic speech bubble timer decay
    if (this.playerSpeechTimer > 0) {
      this.playerSpeechTimer -= dt;
      if (this.playerSpeechTimer <= 0) {
        this.playerSpeechBubble = undefined;
      }
    }

    // Hearth fire warm flame particles in zone_ban_cau
    if (this.currentZone.id === 'zone_ban_cau' && this.stats.isHearthLit && Math.random() < 0.3) {
      this.particles.push({
        x: 200 + (Math.random() - 0.5) * 16 + 16,
        y: 494,
        vx: (Math.random() - 0.5) * 20,
        vy: -Math.random() * 35 - 15,
        life: 0.8,
        maxLife: 0.8,
        size: 3,
        color: Math.random() > 0.5 ? '#f97316' : '#fef08a',
        alpha: 0.9,
        type: 'fire',
      });
    }

    this.updatePlayer(dt);
    this.updateNPCs(dt);
    this.updateEnemies(dt);
    this.updateWaves(dt);
    this.updateDroppedItems(dt);
    this.updateParticles(dt);
    this.updateDamageNumbers(dt);
    this.updateCamera(dt);
    this.checkInteractions();

    // Reset single-frame edge triggers
    this.input.justJumped = false;
    this.input.justAttacked = false;
    this.input.justDashed = false;
    this.input.justSkill1 = false;
    this.input.justSkill2 = false;
    this.input.justSkillHoiQuang = false;
    this.input.justSkillCuonTranh = false;
    this.input.justSkillWorldSlash = false;
    this.input.justTearScroll = false;
    this.input.justInteracted = false;
  }

  /**
   * Update Player Physics and Combat
   */
  private updatePlayer(dt: number) {
    const p = this.player;

    // Invincibility frame countdown
    if (p.invincibleTimer > 0) p.invincibleTimer -= dt;

    // Combo reset timer
    if (p.comboResetTimer > 0) {
      p.comboResetTimer -= dt;
      if (p.comboResetTimer <= 0) p.comboCounter = 0;
    }

    // Atk buff timer countdown
    if (p.atkBuffTimer > 0) p.atkBuffTimer -= dt;

    // Coyote & jump buffer
    if (p.isGrounded) {
      p.coyoteTimer = 0.12;
      p.jumpCount = 0; // Reset triple jump when grounded
    } else if (p.coyoteTimer > 0) p.coyoteTimer -= dt;

    if (this.input.justJumped) p.jumpBufferTimer = 0.12;
    else if (p.jumpBufferTimer > 0) p.jumpBufferTimer -= dt;

    // Movement Input (Key or Joystick)
    let moveX = 0;
    if (this.input.left || this.input.joystickX < -0.2) moveX = -1;
    if (this.input.right || this.input.joystickX > 0.2) moveX = 1;

    // --- DASH ACTION ---
    if ((this.input.justDashed || (this.input.dash && this.stats.skillCooldowns.dash <= 0)) && !p.isDashing && this.stats.skillCooldowns.dash <= 0) {
      p.isDashing = true;
      p.dashTimer = 0.22;
      p.invincibleTimer = 0.25;
      this.stats.skillCooldowns.dash = 0.8;
      p.vx = p.direction * 520;
      p.vy = 0;
      p.state = 'dash';
      sound.playDash();
      this.spawnDashDust(p.x, p.y);
    }

    if (p.isDashing) {
      p.dashTimer -= dt;
      if (p.dashTimer <= 0) {
        p.isDashing = false;
        p.state = p.isGrounded ? 'idle' : 'fall';
      }
    }

    // --- ATTACK & SKILL INPUTS ---
    if (this.stats.isSealedInIce && (this.input.justAttacked || this.input.attack)) {
      this.executeAttack();
    } else if (!p.isDashing && p.state !== 'hurt' && !this.stats.isSealedInIce && this.stats.ngucMonTimer <= 0) {
      if (this.input.justAttacked && !p.state.startsWith('attack') && !p.state.startsWith('skill')) {
        this.executeAttack();
      } else if (this.input.justSkillDismantle || this.input.skillDismantle) {
        if (this.stats.skillCooldowns.dismantle <= 0 && this.stats.qi >= 18) {
          this.executeSkillDismantle();
        }
      } else if (this.input.justSkillCleave || this.input.skillCleave) {
        if (this.stats.skillCooldowns.cleave <= 0 && this.stats.qi >= 22) {
          this.executeSkillCleave();
        }
      } else if (this.input.justSkillKamino || this.input.skillKamino) {
        if (this.stats.skillCooldowns.kamino <= 0 && this.stats.qi >= 35) {
          this.executeSkillKamino();
        }
      } else if (this.input.justSkillShrine || this.input.skillShrine) {
        if (this.stats.skillCooldowns.shrine <= 0 && this.stats.qi >= 50) {
          this.executeSkillShrine();
        }
      } else if (this.input.justSkillWorldSlash || this.input.skillWorldSlash) {
        if (this.stats.skillCooldowns.worldSlash <= 0 && this.stats.qi >= 40) {
          this.executeSkillWorldSlash();
        }
      } else if (this.input.justSkillKamutoke || this.input.skillKamutoke) {
        if (this.stats.skillCooldowns.kamutoke <= 0 && this.stats.qi >= 20) {
          this.executeSkillKamutoke();
        }
      } else if (this.input.justUseQuickHeal || this.input.useQuickHeal) {
        this.useQuickHeal();
      } else if (this.input.justSkill1) {
        // Fallback / Shortcut to Dismantle
        if (this.stats.skillCooldowns.dismantle <= 0 && this.stats.qi >= 18) {
          this.executeSkillDismantle();
        } else if ((this.stats.currentArc >= 6 || this.stats.isKheVanTramMastered) && this.stats.skillCooldowns.kheVanTram <= 0 && this.stats.qi >= 40) {
          this.executeSkillKheVanTram();
        } else if (this.stats.skillCooldowns.neonGay <= 0 && this.stats.qi >= 25) {
          this.executeSkillNeonGay();
        }
      } else if (this.input.justSkill2) {
        // Fallback / Shortcut to Cleave
        if (this.stats.skillCooldowns.cleave <= 0 && this.stats.qi >= 22) {
          this.executeSkillCleave();
        } else if (this.stats.skillCooldowns.coiCuuThuong <= 0 && this.stats.qi >= 35) {
          this.executeSkillCoiCuuThuong();
        }
      } else if (this.input.justSkillHoiQuang) {
        // Fallback / Shortcut to Kamino / Fuga
        if (this.stats.skillCooldowns.kamino <= 0 && this.stats.qi >= 35) {
          this.executeSkillKamino();
        } else if (this.stats.skillCooldowns.hoiQuang <= 0 && this.stats.qi >= 50) {
          this.executeSkillHoiQuang();
        }
      } else if (this.input.justSkillCuonTranh) {
        // Fallback / Shortcut to Shrine
        if (this.stats.skillCooldowns.shrine <= 0 && this.stats.qi >= 50) {
          this.executeSkillShrine();
        } else if (this.stats.skillCooldowns.cuonTranh <= 0 && this.stats.noStacks > 0) {
          this.executeSkillCuonTranh();
        }
      }
    }

    // --- REGULAR MOVEMENT PHYSICS ---
    if (!p.isDashing && !this.stats.isSealedInIce && this.stats.ngucMonTimer <= 0) {
      const speed = this.stats.hasBangGiap ? 175 : 210;
      if (moveX !== 0 && !p.state.startsWith('attack')) {
        p.vx = moveX * speed;
        p.direction = moveX as Direction;
        if (p.isGrounded && !p.state.startsWith('attack')) p.state = 'run';
      } else {
        p.vx *= 0.65; // Horizontal friction
        if (p.isGrounded && !p.state.startsWith('attack') && !p.state.startsWith('skill')) {
          p.state = 'idle';
        }
      }

      // Triple Jump (Nhảy 3 lần)
      if (this.input.justJumped || p.jumpBufferTimer > 0) {
        if (p.isGrounded || p.coyoteTimer > 0) {
          p.jumpCount = 1;
          p.vy = -540;
          p.isGrounded = false;
          p.coyoteTimer = 0;
          p.jumpBufferTimer = 0;
          p.state = 'jump';
          sound.playJump();
          this.spawnDust(p.x, p.y, 8);
        } else if (p.jumpCount >= 1 && p.jumpCount < p.maxJumps) {
          p.jumpCount++;
          p.vy = -510;
          p.jumpBufferTimer = 0;
          p.state = 'jump';
          sound.playJump();
          // Air jump ice / cloud burst
          for (let i = 0; i < 10; i++) {
            this.particles.push({
              x: p.x + (Math.random() - 0.5) * 22,
              y: p.y,
              vx: (Math.random() - 0.5) * 110,
              vy: Math.random() * 50 + 20,
              life: 0.35,
              maxLife: 0.35,
              size: 3 + Math.random() * 3,
              color: p.jumpCount === 3 ? '#38bdf8' : '#e2e8f0',
              alpha: 0.9,
              type: 'ice',
            });
          }
        }
      }

      // Variable jump height cut
      if (!this.input.jump && p.vy < -200) {
        p.vy += 700 * dt;
      }

      // Gravity
      const gravity = 1200;
      p.vy += gravity * dt;
      if (p.vy > 800) p.vy = 800; // Terminal velocity

      if (!p.isGrounded && !p.state.startsWith('attack') && !p.state.startsWith('skill')) {
        p.state = p.vy < 0 ? 'jump' : 'fall';
      }
    }

    // Integrate Position
    p.x += p.vx * dt;
    this.checkPlatformCollisionsX();

    p.y += p.vy * dt;
    this.checkPlatformCollisionsY();

    // Map bounds clamping
    p.x = Math.max(16, Math.min(this.currentZone.width - 16, p.x));
    if (p.y > this.currentZone.height + 80) {
      // Fallen off cliff -> Respawn at start of zone
      this.takePlayerDamage(30);
      p.x = this.currentZone.playerStartX;
      p.y = this.currentZone.playerStartY;
      p.vx = 0;
      p.vy = 0;
    }
  }

  /**
   * Smart Auto-Targeting: Tìm kiếm cụm quái đông nhất hoặc Boss để tự động điều hướng skill (Requirement 26)
   */
  public findBestSkillTarget(): { targetX: number; targetY: number; enemyCount: number } {
    const p = this.player;
    const aliveEnemies = this.currentZone.enemies.filter(e => e.hp > 0);
    if (aliveEnemies.length === 0) {
      return { targetX: p.x + p.direction * 180, targetY: p.y - 25, enemyCount: 0 };
    }

    // 1. Nếu có Boss trong tầm 750px, ưu tiên khóa Boss làm tâm điểm
    const boss = aliveEnemies.find(e => e.isBoss && Math.abs(e.x - p.x) < 750);
    if (boss) {
      p.direction = boss.x >= p.x ? 1 : -1;
      return { targetX: boss.x, targetY: boss.y - boss.h / 2, enemyCount: 1 };
    }

    // 2. Tìm cụm quái có mật độ cao nhất trong phạm vi quét
    let bestX = p.x + p.direction * 180;
    let bestY = p.y - 25;
    let maxClusterCount = 0;

    for (const cand of aliveEnemies) {
      const cluster = aliveEnemies.filter(e => Math.abs(e.x - cand.x) <= 140 && Math.abs(e.y - cand.y) <= 80);
      if (cluster.length > maxClusterCount) {
        maxClusterCount = cluster.length;
        bestX = cand.x;
        bestY = cand.y - cand.h / 2;
      }
    }

    // Tự động xoay mặt người chơi về phía cụm quái
    p.direction = bestX >= p.x ? 1 : -1;
    return { targetX: bestX, targetY: bestY, enemyCount: maxClusterCount };
  }

  /**
   * Execute Primary Attack:
   * - Thần Vũ Giải (Kamutoke): Triệu hồi sấm sét xối xả từ thiên giới
   * - Nắm Đấm Hắc Thiểm (Kokusen): Đòn đấm bóp méo không gian, sét đen tuyền, dmg^2.5, kích hoạt Thức Tỉnh 120%
   * - Liềm Tử Thần: 3-hit combo chém liềm thần tốc
   */
  private executeAttack() {
    const p = this.player;

    // If sealed in ice by Ba Chú Linh, attack hits chip away the ice tomb!
    if (this.stats.isSealedInIce) {
      this.stats.iceTombTimer -= 1.2;
      this.spawnIceShatter(p.x, p.y, 10);
      sound.playHitImpact(false);
      this.triggerScreenShake(3, 0.12);
      this.addDamageNumber(p.x, p.y - 35, 0, '#bae6fd');
      if (this.stats.iceTombTimer <= 0) {
        this.breakIceSeal(false);
      }
      return;
    }

    const speedRatio = this.stats.neonBuffTimer > 0 ? 0.6 : (this.stats.isAwakened ? 0.75 : 1.0);
    const atkBuff = p.atkBuffTimer > 0 ? 40 : 0;
    const baseAtk = (this.stats.attackPower + atkBuff) * (1 + this.stats.weaponLevel * 0.15);
    const awakenedMult = this.stats.isAwakened ? 1.2 : 1.0;

    // --- CASE 1: THẦN VŨ GIẢI (KAMUTOKE) - SẤM SÉT THIÊN GIỚI ---
    if (this.stats.equippedWeapon === 'than_vu_giai') {
      p.state = 'skill_kamutoke_lightning';
      p.stateTimer = 0.28 * speedRatio;
      sound.playKamutokeLightning();
      this.triggerScreenShake(6, 0.25);

      const target = this.findBestSkillTarget();

      // Sét giáng từ đỉnh trời xuống vị trí mục tiêu
      for (let i = 0; i < 35; i++) {
        this.particles.push({
          x: target.targetX + (Math.random() - 0.5) * 60,
          y: Math.random() * (target.targetY + 40),
          vx: (Math.random() - 0.5) * 80,
          vy: 200 + Math.random() * 200,
          life: 0.35,
          maxLife: 0.35,
          size: 3.5,
          color: Math.random() > 0.4 ? '#fef08a' : '#38bdf8',
          alpha: 1.0,
          type: 'spark',
        });
      }

      const lightningBox = {
        x: target.targetX - 90,
        y: target.targetY - 120,
        w: 180,
        h: 220,
      };

      setTimeout(() => {
        this.checkPlayerAttackHit(lightningBox, baseAtk * 2.8 * awakenedMult, true);
      }, 50 * speedRatio);

      setTimeout(() => {
        if (p.state === 'skill_kamutoke_lightning') p.state = p.isGrounded ? 'idle' : 'fall';
      }, 260 * speedRatio);
      return;
    }

    // --- CASE 2: NẮM ĐẤM HẮC THIỂM (KOKUSEN) ---
    if (this.stats.equippedWeapon === 'nam_dam_hac_thiem') {
      p.state = 'attack_kokusen';
      p.stateTimer = 0.3 * speedRatio;

      // Không gian biến dạng, bùng nổ tia sét đen tuyền
      sound.playKokusen();
      this.triggerScreenShake(9, 0.4);

      // Kích hoạt trạng thái Thức Tỉnh (120% tiềm năng trong 8s)
      this.stats.isAwakened = true;
      this.stats.awakenedTimer = 8.0;

      // Tính sát thương Hắc Thiểm lũy thừa 2.5: (baseAtk)^2.5 / 1000 + baseAtk * 8
      const kokusenDamage = Math.round(Math.pow(baseAtk, 2.5) / 1000 + baseAtk * 8);

      // Hạt sét đen viền đỏ bùng nổ dữ dội
      for (let i = 0; i < 40; i++) {
        this.particles.push({
          x: p.x + p.direction * 30 + (Math.random() - 0.5) * 45,
          y: p.y - 25 + (Math.random() - 0.5) * 45,
          vx: p.direction * (180 + Math.random() * 200),
          vy: (Math.random() - 0.5) * 160,
          life: 0.5,
          maxLife: 0.5,
          size: 4 + Math.random() * 3,
          color: Math.random() > 0.4 ? '#09090b' : '#dc2626',
          alpha: 1.0,
          type: 'spark',
        });
      }

      const punchBox = {
        x: p.direction === 1 ? p.x : p.x - 140,
        y: p.y - 50,
        w: 140,
        h: 60,
      };

      p.vx = p.direction * 240;

      setTimeout(() => {
        this.checkPlayerAttackHit(punchBox, kokusenDamage, true);
      }, 60 * speedRatio);

      setTimeout(() => {
        if (p.state === 'attack_kokusen') p.state = p.isGrounded ? 'idle' : 'fall';
      }, 280 * speedRatio);
      return;
    }

    // --- CASE 3: LIỀM TỬ THẦN (COMBO 3 NHÁT) ---
    p.comboCounter = (p.comboCounter % 3) + 1;
    p.comboResetTimer = 0.7 * speedRatio;

    const stateName = `attack${p.comboCounter}` as PlayerActionState;
    p.state = stateName;
    p.stateTimer = 0.25 * speedRatio;

    sound.playSlash();

    if (p.comboCounter === 3) {
      p.vx = p.direction * 180;
    }

    const attackBoxW = p.comboCounter === 3 ? 120 : 85;
    const attackBoxH = p.comboCounter === 3 ? 60 : 48;
    const attackBox = {
      x: p.direction === 1 ? p.x - 10 : p.x - attackBoxW + 10,
      y: p.y - 45,
      w: attackBoxW,
      h: attackBoxH,
    };

    setTimeout(() => {
      this.checkPlayerAttackHit(attackBox, baseAtk * (0.85 + p.comboCounter * 0.35) * awakenedMult, p.comboCounter === 3);
    }, 60 * speedRatio);

    setTimeout(() => {
      if (p.state.startsWith('attack')) p.state = p.isGrounded ? 'idle' : 'fall';
    }, 250 * speedRatio);
  }

  /**
   * Thuật thức Sukuna 1: [GIẢI / BÁT - DISMANTLE]
   * Razor-sharp, nearly invisible distortion slash line cutting through the air with a faint crimson-black particle trail.
   */
  public executeSkillDismantle() {
    const p = this.player;
    this.stats.qi -= 18;
    this.stats.skillCooldowns.dismantle = 1.6;
    p.state = 'skill_dismantle';

    const target = this.findBestSkillTarget();
    sound.playDismantle();
    this.triggerScreenShake(8, 0.25);

    // Spawn razor-sharp distortion line with faint crimson-black trail
    const slashLen = 520;
    const slashAngle = (Math.random() - 0.5) * 0.25;
    const startX = p.x + p.direction * 15;
    const startY = p.y - 25;
    const endX = startX + p.direction * slashLen * Math.cos(slashAngle);
    const endY = startY + slashLen * Math.sin(slashAngle);

    this.dismantleSlashes.push({
      x1: startX,
      y1: startY,
      x2: endX,
      y2: endY,
      life: 0.28,
      maxLife: 0.28,
      angle: slashAngle,
    });

    // Faint crimson-black particle trail cutting through the air
    const stepCount = 28;
    for (let i = 0; i < stepCount; i++) {
      const t = i / stepCount;
      const px = startX + (endX - startX) * t;
      const py = startY + (endY - startY) * t;
      this.particles.push({
        x: px + (Math.random() - 0.5) * 8,
        y: py + (Math.random() - 0.5) * 8,
        vx: -p.direction * (Math.random() * 40 + 10),
        vy: (Math.random() - 0.5) * 50,
        life: 0.35 + Math.random() * 0.2,
        maxLife: 0.55,
        size: 2.5 + Math.random() * 2,
        color: Math.random() > 0.4 ? '#991b1b' : '#09090b',
        alpha: 0.85,
        type: 'spark',
      });
    }

    const slashBox = {
      x: p.direction === 1 ? startX : startX - slashLen,
      y: Math.min(startY, endY) - 35,
      w: slashLen,
      h: Math.abs(endY - startY) + 70,
    };

    const totalAtk = this.stats.attackPower * (this.stats.isAwakened ? 5.8 : 4.8);
    this.checkPlayerAttackHit(slashBox, totalAtk, true);

    this.playerSpeechBubble = "Giải (Dismantle) — Trảm Kích Chia Cắt Không Khí!";
    this.playerSpeechTimer = 2.0;

    setTimeout(() => {
      if (p.state === 'skill_dismantle') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 240);
  }

  /**
   * Thuật thức Sukuna 2: [BÁT - CLEAVE]
   * Heavy, adaptive slashing wave that scales in impact size upon contact with target.
   */
  public executeSkillCleave() {
    const p = this.player;
    this.stats.qi -= 22;
    this.stats.skillCooldowns.cleave = 2.0;
    p.state = 'skill_cleave';

    const target = this.findBestSkillTarget();
    sound.playCleave();
    this.triggerScreenShake(10, 0.35);

    // Find contact enemy to compute adaptive scaling size
    let contactW = 80;
    let contactH = 90;
    let targetEnemy = this.currentZone.enemies.find(
      e => e.hp > 0 && Math.hypot(e.x - target.targetX, e.y - target.targetY) < 120
    );

    if (targetEnemy) {
      contactW = Math.max(80, targetEnemy.w * 1.3);
      contactH = Math.max(90, targetEnemy.h * 1.3);
    }

    // Spawn heavy adaptive slashing wave scaling in impact size
    this.cleaveImpacts.push({
      x: target.targetX,
      y: target.targetY - contactH / 2,
      w: contactW,
      h: contactH,
      life: 0.45,
      maxLife: 0.45,
      scale: 0.7,
    });

    // Adaptive slash particles
    for (let i = 0; i < 40; i++) {
      this.particles.push({
        x: target.targetX + (Math.random() - 0.5) * contactW,
        y: target.targetY - contactH / 2 + (Math.random() - 0.5) * contactH,
        vx: (Math.random() - 0.5) * 260,
        vy: (Math.random() - 0.5) * 220,
        life: 0.4,
        maxLife: 0.4,
        size: 3.5,
        color: Math.random() > 0.5 ? '#e11d48' : '#be123c',
        alpha: 1.0,
        type: 'spark',
      });
    }

    const cleaveBox = {
      x: target.targetX - contactW / 2,
      y: target.targetY - contactH,
      w: contactW,
      h: contactH,
    };

    const totalAtk = this.stats.attackPower * (this.stats.isAwakened ? 6.8 : 5.4);
    this.checkPlayerAttackHit(cleaveBox, totalAtk, true);

    this.playerSpeechBubble = "Bát (Cleave) — Trảm Kích Thích Ứng Cỡ Mục Tiêu!";
    this.playerSpeechTimer = 2.0;

    setTimeout(() => {
      if (p.state === 'skill_cleave') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 280);
  }

  /**
   * Thuật thức Sukuna 3: [TÁO / HỎA DIỆU / KAMINO (FUGA)]
   * Condensed, intensely bright orange-red fire arrow projectile that explodes into a massive localized thermal blast wave upon impact.
   */
  public executeSkillKamino() {
    const p = this.player;
    this.stats.qi -= 35;
    this.stats.skillCooldowns.kamino = 4.5;
    p.state = 'skill_kamino';

    const target = this.findBestSkillTarget();
    sound.playKaminoFireArrow();
    this.triggerScreenShake(12, 0.4);

    const startX = p.x + p.direction * 20;
    const startY = p.y - 25;
    const targetX = target.targetX;
    const targetY = target.targetY - 20;

    const dx = targetX - startX;
    const dy = targetY - startY;
    const dist = Math.hypot(dx, dy) || 1;
    const arrowSpeed = 820;

    // Spawn condensed intensely bright orange-red fire arrow projectile
    this.fugaProjectiles.push({
      x: startX,
      y: startY,
      vx: (dx / dist) * arrowSpeed,
      vy: (dy / dist) * arrowSpeed,
      life: Math.max(0.25, dist / arrowSpeed),
      maxLife: Math.max(0.25, dist / arrowSpeed),
      targetX,
      targetY,
    });

    this.playerSpeechBubble = "■ Khai (Fuga) — Hỏa Diệu Mũi Tên Nhiệt Áp!";
    this.playerSpeechTimer = 2.5;

    setTimeout(() => {
      if (p.state === 'skill_kamino') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 320);
  }

  /**
   * Bành trướng Lãnh địa: [PHỤC MA NGỰ TRÙ TỬ - FUKUMA MIZUSHI]
   * Lãnh địa tự do không kết giới (Open Barrier), bán kính 200 mét lan tỏa toàn bộ Arc!
   * Triệu hồi ngôi đền Phật giáo biến dạng, đế sọ người, cánh cửa hình miệng quỷ khổng lồ.
   * Liên tục phóng Giải (Kai) và Bát (Hachi) tốc độ ánh sáng lên toàn bộ quái và boss trong Arc.
   */
  public executeSkillShrine() {
    const p = this.player;
    this.stats.qi -= 50;
    this.stats.skillCooldowns.shrine = 12.0;
    p.state = 'skill_shrine';
    p.invincibleTimer = 3.0;

    sound.playMalevolentShrine();
    this.triggerScreenShake(20, 1.5);

    // Kích hoạt Thức Tỉnh tối cao (120% tiềm năng)
    this.stats.isAwakened = true;
    this.stats.awakenedTimer = 16.0;

    this.isMalevolentShrineActive = true;
    this.malevolentShrineTimer = 7.0;
    this.malevolentShrineX = p.x;
    this.malevolentShrineY = p.y;
    this.malevolentShrineTickTimer = 0;

    this.playerSpeechBubble = "BÀNH TRƯỚNG LÃNH ĐỊA: PHỤC MA NGỰ TRÙ TỬ (200M TOÀN BỘ ARC)!";
    this.playerSpeechTimer = 4.0;

    setTimeout(() => {
      if (p.state === 'skill_shrine') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 450);
  }

  /**
   * Biến thể tối thượng: [NHÁT CHÉM CẮT ĐỨT THẾ GIAN - WORLD-CUTTING SLASH]
   * Mở rộng mục tiêu cắt đứt toàn bộ không gian, thế giới và vũ trụ.
   * 3 bước: 1. Niệm chú (Long Lân) -> 2. Thủ ấn (Enmaten) -> 3. Chỉ hướng cắt không gian
   */
  public executeSkillWorldSlash() {
    const p = this.player;
    if (this.stats.skillCooldowns.worldSlash > 0 || this.stats.qi < 40) return;
    this.stats.skillCooldowns.worldSlash = 8.0;
    this.stats.qi -= 40;
    p.state = 'skill_world_slash';
    p.invincibleTimer = 1.4;

    this.stats.chantStep = 1;
    this.stats.chantTimer = 0.85;
    this.stats.chantText = "Niệm chú: 「 竜鱗 (Long Lân) • 反発 (Phản Lý) • 番の流星 (Song Tinh) 」";
    this.playerSpeechBubble = "Long Lân... Phản Lý... Song Tinh!";
    this.playerSpeechTimer = 2.0;
    sound.playDismantle();
    this.triggerScreenShake(8, 0.4);

    // Cosmic runes and Enmaten hand sign particles
    for (let i = 0; i < 35; i++) {
      this.particles.push({
        x: p.x + (Math.random() - 0.5) * 60,
        y: p.y - 30 + (Math.random() - 0.5) * 50,
        vx: (Math.random() - 0.5) * 90,
        vy: -Math.random() * 90 - 20,
        life: 0.85,
        maxLife: 0.85,
        size: 3.5,
        color: '#c084fc',
        alpha: 0.95,
        type: 'spark',
      });
    }
  }

  public completeWorldSlash() {
    const p = this.player;
    this.stats.chantStep = 3;
    this.stats.chantTimer = 0;
    this.stats.chantText = null;

    sound.playWorldSlash();
    this.triggerScreenShake(24, 1.4);
    this.worldSlashEffectTimer = 0.75;

    this.playerSpeechBubble = "THẾ GIỚI TRẢM — CHIA CẮT TOÀN BỘ KHÔNG GIAN!";
    this.playerSpeechTimer = 3.0;

    // Sát thương cắt đứt không gian & thế giới: phá hủy hoàn toàn 100% giáp boss và gây 75,000,000 - 180,000,000 sát thương!
    for (const enemy of this.currentZone.enemies) {
      if (enemy.hp <= 0) continue;
      // Nhắm vào toàn bộ không gian
      if (Math.abs(enemy.x - p.x) < 1400) {
        if (enemy.armor) enemy.armor = 0; // Cắt đứt phòng thủ tuyệt đối
        const isCrit = Math.random() < this.stats.critRate;
        const baseDmg = Math.max(75000000, this.stats.attackPower * 75000);
        const finalDmg = Math.round(baseDmg * (isCrit ? this.stats.critDamageMultiplier : 1.0));
        enemy.hp -= finalDmg;
        enemy.hurtTimer = 0.6;
        this.addDamageNumber(enemy.x, enemy.y - 40, finalDmg, '#c084fc', true);

        // Tia nứt vỡ không gian
        for (let i = 0; i < 30; i++) {
          this.particles.push({
            x: enemy.x + (Math.random() - 0.5) * 80,
            y: enemy.y - Math.random() * enemy.h,
            vx: (Math.random() - 0.5) * 500,
            vy: (Math.random() - 0.5) * 500,
            life: 0.6,
            maxLife: 0.6,
            size: 5,
            color: '#a855f7',
            alpha: 1.0,
            type: 'spark',
          });
        }

        if (enemy.hp <= 0) {
          this.handleEnemyDefeated(enemy);
        }
      }
    }

    setTimeout(() => {
      if (p.state === 'skill_world_slash') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 300);
  }

  /**
   * Kỹ năng Sấm Sét Thần Vũ Giải
   */
  public executeSkillKamutoke() {
    this.stats.qi -= 20;
    this.stats.skillCooldowns.kamutoke = 2.5;
    const oldWeapon = this.stats.equippedWeapon;
    this.stats.equippedWeapon = 'than_vu_giai';
    this.executeAttack();
    setTimeout(() => {
      this.stats.equippedWeapon = oldWeapon;
    }, 300);
  }

  /**
   * Hồi Máu Nhanh (Quick Heal) từ Slot 6: Đại Hoàn Đan
   */
  public useQuickHeal() {
    const healAmount = Math.round(this.stats.maxHp * 0.5);
    this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + healAmount);
    sound.playLevelUp();
    this.triggerScreenShake(3, 0.15);
    this.addDamageNumber(this.player.x, this.player.y - 45, healAmount, '#22c55e', true);
    this.stats.sealWarningText = `💊 DÙNG ĐẠI HOÀN ĐAN: HỒI PHỤC +${healAmount} MÁU!`;
    this.stats.sealWarningTimer = 3.0;

    for (let i = 0; i < 20; i++) {
      this.particles.push({
        x: this.player.x + (Math.random() - 0.5) * 30,
        y: this.player.y - 20 + (Math.random() - 0.5) * 30,
        vx: (Math.random() - 0.5) * 90,
        vy: -Math.random() * 80 - 20,
        life: 0.6,
        maxLife: 0.6,
        size: 3.5,
        color: '#4ade80',
        alpha: 1.0,
        type: 'spark',
      });
    }
  }

  /**
   * Chuyển đổi vũ khí trang bị giữa Thần Vũ Giải, Nắm Đấm Hắc Thiểm và Liềm Tử Thần
   */
  public toggleWeapon() {
    if (this.stats.equippedWeapon === 'than_vu_giai') {
      this.stats.equippedWeapon = 'nam_dam_hac_thiem';
      this.stats.sealWarningText = "👊 TRANG BỊ: NẮM ĐẤM HẮC THIỂM (KOKUSEN - SÁT THƯƠNG LŨY THỪA 2.5)!";
      sound.playKokusen();
    } else if (this.stats.equippedWeapon === 'nam_dam_hac_thiem') {
      this.stats.equippedWeapon = 'liem_tu_than';
      this.stats.sealWarningText = "🗡️ TRANG BỊ: LIỀM TỬ THẦN BÌNH LIÊU VƯƠNG!";
      sound.playSlash();
    } else {
      this.stats.equippedWeapon = 'than_vu_giai';
      this.stats.sealWarningText = "⚡ TRANG BỊ: THẦN VŨ GIẢI (KAMUTOKE - SẤM SÉT THIÊN GIỚI)!";
      sound.playKamutokeLightning();
    }
    this.stats.sealWarningTimer = 3.0;
    if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
  }

  /**
   * Tương tác với 6 ô đồ trên Hotbar (Requirement 13 & 14)
   */
  public equipSlotItem(slotIndex: number) {
    if (slotIndex === 0) {
      // Slot 1: Đổi Vũ khí
      this.toggleWeapon();
    } else if (slotIndex === 5) {
      // Slot 6: Hồi máu
      this.useQuickHeal();
    } else {
      // Slots 2, 3, 4, 5: Mũ giáp, Giáp thân, Giáp quần, Giáp chân
      const slot = this.stats.hotbarSlots[slotIndex];
      if (slot) {
        slot.equipped = true;
        this.stats.armor = Math.min(this.stats.maxArmor, this.stats.armor + 150);
        this.stats.armorDurability = 100;
        sound.playItemGet();
        this.stats.sealWarningText = `🛡 ĐÃ TRANG BỊ: ${slot.name.toUpperCase()} (+150 GIÁP)!`;
        this.stats.sealWarningTimer = 3.0;
        this.addDamageNumber(this.player.x, this.player.y - 45, 150, '#38bdf8', true);
      }
    }
    if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
  }

  /**
   * Tuyệt Kỹ Arc 6: [Khe Vằn Trảm] (Đường Liềm Vô Ảnh)
   * Nhát chém nước vô thanh phẳng lì như gương, đứt lìa dòng thác không một tiếng động.
   * Gây sát thương 4.5x Công, đông cứng/khựng địch 1.5s, quét sạch tầm rộng 260px.
   */
  public executeSkillKheVanTram() {
    const p = this.player;
    this.stats.qi -= 40;
    this.stats.skillCooldowns.kheVanTram = 5.0;
    p.state = 'skill_tuthan';
    p.invincibleTimer = 0.5;

    sound.playTuThanDotKich();
    sound.playSlash();
    this.triggerScreenShake(8, 0.4);

    // Lướt chém xuyên thấu
    p.vx = p.direction * 750;
    this.spawnDashDust(p.x, p.y);

    // Bọt nước thác Khe Vằn và sóng chém nước trong suốt
    for (let i = 0; i < 28; i++) {
      this.particles.push({
        x: p.x + p.direction * i * 9,
        y: p.y - 25 + (Math.random() - 0.5) * 40,
        vx: (Math.random() - 0.5) * 80,
        vy: (Math.random() - 0.5) * 140,
        life: 0.7,
        maxLife: 0.7,
        size: 3.5 + Math.random() * 3,
        color: Math.random() > 0.4 ? '#38bdf8' : '#e0f2fe',
        alpha: 0.95,
        type: 'ice',
      });
    }

    const attackBox = {
      x: p.direction === 1 ? p.x : p.x - 260,
      y: p.y - 50,
      w: 260,
      h: 55,
    };

    this.checkPlayerAttackHit(attackBox, this.stats.attackPower * 4.5, true);

    this.playerSpeechBubble = "Khe Vằn Trảm — Đường liềm vô ảnh!";
    this.playerSpeechTimer = 2.5;

    setTimeout(() => {
      if (p.state === 'skill_tuthan') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 350);
  }

  /**
   * Winter Shibuya Skill 1: [Neon Gãy]
   * Bẻ bảng neon rơi, tạo vùng sáng 5m, địch bị [Mù] 1.5s, Khôi tăng 40% tốc đánh
   */
  private executeSkillNeonGay() {
    const p = this.player;
    this.stats.qi -= 25;
    this.stats.skillCooldowns.neonGay = 4.0;
    this.stats.neonBuffTimer = 4.0; // Tăng 40% tốc đánh trong 4s
    p.state = 'skill_neon_gay';

    sound.playNeonShatter();
    this.triggerScreenShake(4, 0.2);

    // Neon field particles
    for (let i = 0; i < 24; i++) {
      this.particles.push({
        x: p.x + (Math.random() - 0.5) * 140,
        y: p.y - 20 + (Math.random() - 0.5) * 60,
        vx: (Math.random() - 0.5) * 120,
        vy: (Math.random() - 0.5) * 100,
        life: 0.8,
        maxLife: 0.8,
        size: 3 + Math.random() * 3,
        color: Math.random() > 0.5 ? '#06b6d4' : '#d946ef',
        alpha: 0.9,
        type: 'neon',
      });
    }

    // Blind and slow all enemies in 180px
    for (const e of this.currentZone.enemies) {
      if (e.hp > 0 && Math.abs(e.x - p.x) < 180) {
        e.hurtTimer = 1.8;
        e.vx = 0;
        this.addDamageNumber(e.x, e.y - 40, 0, '#06b6d4');
      }
    }

    setTimeout(() => {
      if (p.state === 'skill_neon_gay') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 300);
  }

  /**
   * Winter Shibuya Skill 2: [Còi Cứu Thương 3:17AM]
   * Lao thẳng 20m, hất văng địch + vệt [Băng Nứt] đóng băng kẻ thù
   */
  private executeSkillCoiCuuThuong() {
    const p = this.player;
    this.stats.qi -= 35;
    this.stats.skillCooldowns.coiCuuThuong = 5.0;
    p.state = 'skill_coi_cuu_thuong';
    p.invincibleTimer = 0.45;

    sound.playAmbulanceSiren();
    this.triggerScreenShake(5, 0.3);

    // Dash forward 20m
    p.vx = p.direction * 720;

    const attackBox = {
      x: p.direction === 1 ? p.x : p.x - 240,
      y: p.y - 45,
      w: 240,
      h: 50,
    };

    // Spawn Băng Nứt ice particles
    for (let i = 0; i < 22; i++) {
      this.particles.push({
        x: p.x + p.direction * i * 11,
        y: p.y - 2,
        vx: (Math.random() - 0.5) * 40,
        vy: -Math.random() * 80,
        life: 1.2,
        maxLife: 1.2,
        size: 4 + Math.random() * 3,
        color: '#bae6fd',
        alpha: 0.9,
        type: 'ice',
      });
    }

    this.checkPlayerAttackHit(attackBox, this.stats.attackPower * 2.8, true);

    setTimeout(() => {
      if (p.state === 'skill_coi_cuu_thuong') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 350);
  }

  /**
   * Winter Shibuya Ultimate: [Winter Shibuya - Hồi Quang]
   * Tuyết ngừng rơi 6s, bản đồ chuyển trắng đen, Khôi bất tử 1s, hồi 100% Qi, +20% máu đã mất
   */
  public executeSkillHoiQuang() {
    this.stats.qi = this.stats.maxQi;
    this.stats.skillCooldowns.hoiQuang = 15.0;
    this.stats.isHoiQuangActive = true;
    this.stats.hoiQuangTimer = 6.0;
    this.player.invincibleTimer = 1.0;

    sound.playHoiQuang();
    this.triggerScreenShake(6, 0.4);

    this.addDamageNumber(this.player.x, this.player.y - 60, 0, '#ef4444', true);
  }

  /**
   * Skill: [Cuộn Tranh Chưa Giao]
   * Tiêu hao toàn bộ [Nợ] hồi 15% máu + 10% năng lượng cho bản thân và đồng đội
   */
  public executeSkillCuonTranh() {
    if (this.stats.noStacks <= 0) return;
    const healAmt = Math.round(this.stats.maxHp * (this.stats.noStacks * 0.15));
    const qiAmt = Math.round(this.stats.maxQi * (this.stats.noStacks * 0.10));
    this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + healAmt);
    this.stats.qi = Math.min(this.stats.maxQi, this.stats.qi + qiAmt);

    // Also heal nearest NPC
    for (const npc of this.currentZone.npcs) {
      if (Math.abs(npc.x - this.player.x) < 300) {
        npc.hp = Math.min(npc.maxHp || 10000, (npc.hp || 10000) + 1500);
      }
    }

    this.addDamageNumber(this.player.x, this.player.y - 45, healAmt, '#22c55e', true);
    sound.playItemGet();
    this.stats.noStacks = 0;
    this.stats.skillCooldowns.cuonTranh = 6.0;
  }
  /**
   * Skill 2: Tử Thần Đột Kích (Supersonic Dash Slash)
   */
  private executeSkillTuThanDotKich() {
    const p = this.player;
    this.stats.qi -= 40;
    this.stats.skillCooldowns.tuthanDotKich = 5.0;
    p.state = 'skill_tuthan';
    p.invincibleTimer = 0.3;

    sound.playTuThanDotKich();
    this.triggerScreenShake(4, 0.25);

    // Dash forward instantly
    p.vx = p.direction * 650;
    this.spawnDashDust(p.x, p.y);

    const attackBox = {
      x: p.direction === 1 ? p.x : p.x - 140,
      y: p.y - 45,
      w: 140,
      h: 48,
    };

    this.checkPlayerAttackHit(attackBox, this.stats.attackPower * 3.0, true);

    setTimeout(() => {
      if (p.state === 'skill_tuthan') p.state = p.isGrounded ? 'idle' : 'fall';
    }, 300);
  }

  /**
   * Check Player Attack Hitbox against all active enemies (AoE Multi-target, 40-50% Crit, Boss 300k Armor)
   */
  private checkPlayerAttackHit(box: { x: number; y: number; w: number; h: number }, damage: number, isForceCrit: boolean = false) {
    let hitCount = 0;
    let anyCrit = false;

    for (const enemy of this.currentZone.enemies) {
      if (enemy.hp <= 0) continue;
      const enemyBox = { x: enemy.x - enemy.w / 2, y: enemy.y - enemy.h, w: enemy.w, h: enemy.h };

      if (
        box.x < enemyBox.x + enemyBox.w &&
        box.x + box.w > enemyBox.x &&
        box.y < enemyBox.y + enemyBox.h &&
        box.y + box.h > enemyBox.y
      ) {
        hitCount++;

        // Tỉ lệ sát thương chí mạng 40-50% (mặc định 45% + bonus từ cấp vũ khí)
        const isCritical = isForceCrit || Math.random() < this.stats.critRate;
        if (isCritical) anyCrit = true;

        let finalDamage = Math.max(1, Math.round(damage + (Math.random() - 0.5) * 8));
        if (isCritical) {
          finalDamage = Math.round(finalDamage * this.stats.critDamageMultiplier);
        }

        // Winter Shibuya - Hồi Quang bonus damage = 20% target's lost HP
        if (this.stats.isHoiQuangActive) {
          const lostHp = Math.max(0, enemy.maxHp - enemy.hp);
          finalDamage += Math.round(lostHp * 0.20);
        }

        // Bút Băng bonus damage = 30% of Khôi's lost HP
        if (this.stats.hasButBang) {
          const khoiLost = Math.max(0, this.stats.maxHp - this.stats.hp);
          finalDamage += Math.round(khoiLost * 0.30);
        }

        // --- HIỆU ỨNG NGUYÊN TỐ GHÉP VÀO VŨ KHÍ ---
        if (this.stats.weaponElement === 'ice') {
          // 35% tỉ lệ đóng băng kẻ địch 1.2s và làm chậm
          if (Math.random() < 0.35) {
            enemy.hurtTimer = 1.4;
            enemy.vx = 0;
            this.spawnIceShatter(enemy.x, enemy.y, 8);
          }
        } else if (this.stats.weaponElement === 'lightning') {
          // Giật sét lan sang quái xung quanh (AoE Chain Lightning)
          for (const other of this.currentZone.enemies) {
            if (other !== enemy && other.hp > 0 && Math.hypot(other.x - enemy.x, other.y - enemy.y) < 180) {
              const chainDmg = Math.round(finalDamage * 0.35);
              if (other.armor && other.armor > 0) {
                other.armor -= chainDmg;
              } else {
                other.hp -= chainDmg;
              }
              other.hurtTimer = 0.25;
              this.addDamageNumber(other.x, other.y - other.h / 2, chainDmg, '#38bdf8', false);
            }
          }
        } else if (this.stats.weaponElement === 'lifesteal') {
          // Hút máu: Hồi 10% sát thương gây ra thành HP cho Khôi
          const heal = Math.max(2, Math.round(finalDamage * 0.10));
          this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + heal);
          this.addDamageNumber(this.player.x, this.player.y - 45, heal, '#22c55e', false);
        } else if (this.stats.weaponElement === 'neon') {
          // Thiêu đốt Neon liên tục
          finalDamage += 25;
        }

        // --- THỦ PHÁ THANH GIÁP BOSS / QUÁI (300,000 Giáp Boss) ---
        // Người chơi phải phá hết 300,000 giáp thì sát thương mới gây được vào máu!
        if (enemy.armor && enemy.armor > 0) {
          if (finalDamage <= enemy.armor) {
            enemy.armor -= finalDamage;
            this.addDamageNumber(enemy.x, enemy.y - enemy.h / 2 - 12, finalDamage, '#38bdf8', isCritical);
          } else {
            const armorAbsorbed = enemy.armor;
            const remainingDmg = finalDamage - armorAbsorbed;
            enemy.armor = 0;
            enemy.hp -= remainingDmg;
            this.addDamageNumber(enemy.x, enemy.y - enemy.h / 2 - 14, armorAbsorbed, '#38bdf8', isCritical);
            this.addDamageNumber(enemy.x, enemy.y - enemy.h / 2, remainingDmg, isCritical ? '#f97316' : '#ef4444', isCritical);
            sound.playIceFreeze();
          }
        } else {
          // Trừ trực tiếp vào Máu của Boss (1 Triệu Máu) hoặc quái
          enemy.hp -= finalDamage;
          this.addDamageNumber(enemy.x, enemy.y - enemy.h / 2, finalDamage, isCritical ? '#f97316' : '#facc15', isCritical);
        }

        enemy.hurtTimer = 0.3;
        enemy.state = 'hurt';
        enemy.vx = this.player.direction * (isCritical ? 240 : 130);

        this.spawnBloodSparks(enemy.x, enemy.y - enemy.h / 2);
        sound.playHitImpact(isCritical);

        if (enemy.hp <= 0) {
          this.handleEnemyDefeated(enemy);
        }
      }
    }

    if (hitCount > 0) {
      this.hitstopTimer = anyCrit ? 0.06 : 0.035;
      this.triggerScreenShake(anyCrit ? 5 : 2.5, 0.16);
    }
  }

  /**
   * Handle Enemy Defeated / Quest Progression / XP
   */
  private handleEnemyDefeated(enemy: Enemy) {
    // --- CHU MẠNH HIẾU GIAI ĐOẠN 1 BỊ ĐÁNH BẠI -> CHUYỂN DẠNG 2: BẢN KHUYẾT TẬT ---
    if (enemy.type === 'boss_chu_manh_hieu' && !enemy.isPhase2) {
      this.triggerChuManhHieuPhase2(enemy);
      return;
    }

    enemy.state = 'dead';
    this.addXp(enemy.xpReward);
    this.spawnDust(enemy.x, enemy.y, 16);

    // Rơi vật phẩm, kinh nghiệm và giáp (5-7% rơi giáp)
    this.spawnDrops(enemy);

    // Increment kill count and check for iconic Shibuya quote
    this.stats.killCount++;
    if (this.stats.killCount === 5 || this.stats.killCount % 5 === 0) {
      this.stats.killQuote = "“Tuyết rơi phủ hết. Nhưng vết máu này… tao không lau.”";
      this.stats.killQuoteTimer = 5.0;
      sound.playHoiQuang();
    }

    // Gain 1 stack of [Nợ] (max 5)
    if (this.stats.noStacks < 5) {
      this.stats.noStacks++;
      this.addDamageNumber(this.player.x, this.player.y - 45, this.stats.noStacks, '#c084fc', true);
    }

    // --- KIỂM TRA TIÊU DIỆT DÃ THÚ BIÊN GIỚI (A01-E001: ĐỨA TRẺ MỒ CÔI BẢN CÁU) ---
    if (enemy.type === 'wolf_bien_gioi' || enemy.type === 'boar_nanh_bac') {
      this.stats.beastsDefeated = (this.stats.beastsDefeated || 0) + 1;
      const total = this.stats.totalBeasts || 4;
      this.stats.objectiveDetail = `Đánh đuổi dã thú biên giới: ${this.stats.beastsDefeated}/${total} con!`;

      if (this.stats.beastsDefeated >= total) {
        sound.playLevelUp();
        // Bà Mế Bản Cáu reo mừng và trao bát cháo ngô
        const me = this.currentZone.npcs.find(n => n.id === 'npc_me_ban_cau');
        if (me) {
          me.speechBubble = "Thọ giỏi lắm! Con đã đánh đuổi bầy sói dữ bảo vệ chòi lá! Ăn bát cháo ngô nóng này đi con!";
        }

        this.playerSpeechBubble = "Cháu cảm ơn Mế! Lớn lên cháu thề làm thầy thuốc, giữ cho bản mình ai cũng lành lặn!";
        this.playerSpeechTimer = 5.0;

        // Nhận vật phẩm Bát Cháo Ngô Đùm Bọc (1977)
        this.addInventoryItem('item_bat_chao_ngo');
        this.addXp(150);
        this.stats.level = 2;
        this.stats.attackPower += 15;
        this.stats.maxHp += 50;
        this.stats.hp = this.stats.maxHp;

        // Hoàn thành sự kiện A01-E001 trong arcManager
        arcManager.advanceEvent('A01-E001');
        this.stats.sealWarningText = '🏆 HOÀN THÀNH SỰ KIỆN A01-E001: ĐÃ NHẬN BÁT CHÁO NGÔ ĐÙM BỌC (1977)!';
        this.stats.sealWarningTimer = 5.0;

        // Mở sự kiện tiếp theo A01-E002
        this.stats.objectiveTitle = 'A01-E002: Y Thư Nam Dược Thần Hiệu (1982)';
        this.stats.objectiveDetail = 'Bé gái Bản Cáu bị rắn độc cắn! Đi qua cổng bên phải lên Chùa Cổ Nguyệt tìm thuốc trong hang đá!';
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // --- KIỂM TRA ĐÁNH BẠI ĐÁM BẮT NẠT ARC 2 (A02-E001 & A02-E004) ---
    if (enemy.type === 'bully_tiger' || enemy.type === 'bully_minion') {
      this.stats.bulliesDefeated = (this.stats.bulliesDefeated || 0) + 1;

      // 1. Tại Sân Trường & Ngõ Cũ (A02-E001)
      if (this.currentZone.id === 'zone_san_truong_ngo_cu') {
        const remainingBullies = this.currentZone.enemies.filter(e => e.hp > 0).length;
        if (remainingBullies <= 1) {
          this.handleArcStoryEventTrigger('A02-E001');
        }
      }

      // 2. Tại Chòi Lá Ngoại Ô (A02-E004: Trận Chiến Chòi Lá)
      if (this.currentZone.id === 'zone_choi_la_winter') {
        if (enemy.id === 'boss_dat_15') {
          enemy.hp = 1; // Giữ lại không chết, quỳ rạp xin tha
          enemy.state = 'idle';
          enemy.speechBubble = 'Đừng... Khôi ơi tha cho tao! Lưỡi liềm mày bén quá...';
          enemy.speechTimer = 10.0;
          this.stats.sealWarningText = '⚠️ ĐẠT HỔ MUN ĐÃ QUỴ NGÃ! HÃY TIẾN LẠI GẦN BẤM [DỪNG LẠI] THA MẠNG (A02-E004)!';
          this.stats.sealWarningTimer = 5.0;
          this.stats.objectiveDetail = 'Tiến lại gần Đạt Hổ Mun hoặc Bia Đá, bấm [E / Dừng Lại] để tha mạng, kết thúc Arc 2!';
          sound.playLevelUp();
        }
      }
    }

    // --- KIỂM TRA ĐÁNH BẠI TRÚC THÁNH HOÀNG CẦN (ARC 3: A03-E002 & A03-E003) ---
    if (enemy.type === 'boss_hoang_can') {
      enemy.hp = 1; // Giữ lại không chết, Hoàng Cần chấp nhận chịu thua và truyền thừa
      enemy.state = 'idle';
      enemy.vx = 0;
      enemy.speechBubble = 'Gậy gãy rồi... Nhánh "Bình" của con đã vượt qua nhánh "Giữ" của ta! Khôi, con xứng đáng làm Bình Liêu Vương!';
      enemy.speechTimer = 16.0;

      sound.playNeonShatter();
      this.triggerScreenShake(12, 0.6);
      this.spawnIceShatter(enemy.x, enemy.y, 25);

      this.stats.sealWarningText = '⚡ GẬY TRÚC HOÀNG LONG ĐÃ GÃY ĐÔI! HOÀNG CẦN CHẤP NHẬN TRUYỀN THỪA (A03-E003)!';
      this.stats.sealWarningTimer = 6.0;

      // Kích hoạt vật thể gậy gãy để người chơi tương tác nhặt
      const staffObj = this.currentZone.interactiveObjects.find(o => o.id === 'broken_bamboo_staff');
      if (staffObj) {
        staffObj.activated = false;
        staffObj.prompt = 'Nhặt Nửa Gậy Trúc Gãy & Nhận Truyền Thừa [E / Chạm]';
      }

      this.handleArcStoryEventTrigger('A03-E002');
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // --- KIỂM TRA ĐÁNH BẠI TOÁN GIANG HỒ BUÔN LẬU MỐC 1088 (ARC 4: A04-E001) ---
    if (enemy.type === 'bien_gioi_thug') {
      this.stats.thugsDefeated = (this.stats.thugsDefeated || 0) + 1;
      const totalThugs = 4;
      this.stats.objectiveDetail = `Dẹp loạn giang hồ buôn lậu Mốc 1088: ${this.stats.thugsDefeated}/${totalThugs} tên!`;

      if (this.stats.thugsDefeated >= totalThugs) {
        sound.playLevelUp();
        this.stats.sealWarningText = '⚡ TOÁN GIANG HỒ ĐÃ BỎ CHẠY! HÃY TƯƠNG TÁC CỘT MỐC 1088 ĐỂ KHẲNG ĐỊNH CHỮ "DỪNG"!';
        this.stats.sealWarningTimer = 5.0;
        this.playerSpeechBubble = "Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp!";
        this.playerSpeechTimer = 4.0;
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // --- KIỂM TRA SO TÀI 7 ĐÊM CÙNG CHU HIẾU QUÈ (ARC 4: A04-E003) ---
    if (enemy.type === 'boss_chu_hieu_que_young') {
      enemy.hp = 1; // Giữ lại không chết, kết thúc so tài 7 đêm bằng hòa giải và cơm nguội
      enemy.state = 'idle';
      enemy.vx = 0;
      enemy.speechBubble = 'Hộc... hộc... Đánh suốt 7 đêm mà liềm của anh chặn hết đòn Lôi Ảnh Thủ của em...';
      enemy.speechTimer = 16.0;

      sound.playLevelUp();
      this.triggerScreenShake(8, 0.4);
      this.stats.sevenNightsDuelCompleted = true;
      this.stats.sealWarningText = '🤝 KẾT THÚC 7 ĐÊM SO TÀI! HÃY TƯƠNG TÁC SÀN ĐẤU ĐỂ ĂN CƠM NGUỘI VÀ KẾT NGHĨA (A04-E003)!';
      this.stats.sealWarningTimer = 6.0;

      const duelObj = this.currentZone.interactiveObjects.find(o => o.id === 'san_dau_7_dem');
      if (duelObj) {
        duelObj.prompt = 'Ngồi Ăn Cơm Nguội & Kết Nghĩa Cùng Chu Hiếu Què [E / Chạm]';
      }

      this.handleArcStoryEventTrigger('A04-E003');
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // --- KIỂM TRA ĐÁNH BẠI ĐAO THỦ HUYẾT TRÚC TOKYO (ARC 5: A05-E003) ---
    if (enemy.type === 'huyet_truc_tokyo_scout' || enemy.type === 'huyet_truc_tokyo_enforcer') {
      this.stats.shibuyaEnemiesDefeated = (this.stats.shibuyaEnemiesDefeated || 0) + 1;
      const totalEnemies = 6;
      this.stats.objectiveDetail = `Đánh gục toán đao thủ Huyết Trúc trên Cầu Vượt: ${this.stats.shibuyaEnemiesDefeated}/${totalEnemies} tên!`;

      if (this.stats.shibuyaEnemiesDefeated >= totalEnemies) {
        sound.playLevelUp();
        this.stats.sealWarningText = '⚡ ĐÃ ĐÁNH GỤC TOÀN BỘ ĐAO THỦ TRONG 7 PHÚT! TIẾN LÊN ĐỈNH CẦU VƯỢT ĐỐI ĐẦU THỦ LĨNH (A05-E004)!';
        this.stats.sealWarningTimer = 5.5;
        this.playerSpeechBubble = "Liềm của tao không chém người vô tội. Bảng neon gãy soi sáng đường về cho đồng bào tao!";
        this.playerSpeechTimer = 4.0;
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // --- KIỂM TRA ĐÁNH BẠI BOSS THỦ LĨNH HUYẾT TRÚC TOKYO (ARC 5: A05-E004) ---
    if (enemy.type === 'boss_huyet_truc_tokyo_leader') {
      enemy.hp = 1;
      enemy.state = 'idle';
      enemy.vx = 0;
      enemy.speechBubble = 'Không thể nào... Tốc độ liềm 7 đường một giây... Tuyết Trắng Chôn Tên...';
      enemy.speechTimer = 16.0;

      sound.playNeonShatter();
      this.triggerScreenShake(12, 0.6);
      this.spawnIceShatter(enemy.x, enemy.y, 30);
      this.stats.shibuyaBossDefeated = true;
      this.stats.sealWarningText = '❄️ THỦ LĨNH HUYẾT TRÚC ĐÃ BỊ TƯỚC VŨ KHÍ! TƯƠNG TÁC BÀN PHONG ẤN CUỘN TRANH (A05-E004)!';
      this.stats.sealWarningTimer = 6.0;

      const altarObj = this.currentZone.interactiveObjects.find(o => o.id === 'cuon_tranh_phong_an_altar');
      if (altarObj) {
        altarObj.prompt = 'Đâm Cuộn Tranh Giải Phóng Phong Ấn Băng Tuyết & Cứu Con Tin [E / Chạm]';
      }

      this.handleArcStoryEventTrigger('A05-E004');
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // --- KIỂM TRA ĐÁNH BẠI BÁO HOA MAI VÁCH ĐÁ KHE VẰN (ARC 6: A06-E002) ---
    if (enemy.type === 'bao_hoa_mai_khe_van' || enemy.type === 'thuy_quai_khe_van') {
      this.stats.kheVanBeastsDefeated = (this.stats.kheVanBeastsDefeated || 0) + 1;
      const totalBeasts = this.stats.totalKheVanBeasts || 4;
      this.stats.objectiveDetail = `Dọn dẹp bầy báo hoa mai săn mồi vách đá Khe Vằn: ${this.stats.kheVanBeastsDefeated}/${totalBeasts} con!`;

      if (this.stats.kheVanBeastsDefeated >= totalBeasts) {
        sound.playLevelUp();
        this.stats.sealWarningText = '⚡ ĐÃ DỌN DẸP BÃI ĐÁ! HÃY TƯƠNG TÁC DÂY CÁP THÉP 100 TẦNG CÙNG LỤC TRIỀU DƯ (A06-E002)!';
        this.stats.sealWarningTimer = 5.5;
        this.playerSpeechBubble = "Vách đá đã an toàn. Đến lúc kiểm tra phản xạ giằng cáp thép cùng anh Dư!";
        this.playerSpeechTimer = 4.0;

        const du = this.currentZone.npcs.find(n => n.id === 'npc_luc_trieu_du_arc6');
        if (du) {
          du.speechBubble = "Khôi! Đu dây cáp thép lên tầng thác cao nhất! Để tao xem thân pháp mày còn bén không!";
          du.speechTimer = 5.0;
        }
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // --- KIỂM TRA ĐÁNH BẠI BOSS TÂM MA SHIBUYA (ARC 6: A06-E003) ---
    if (enemy.type === 'boss_tam_ma_shibuya') {
      enemy.hp = 1;
      enemy.state = 'idle';
      enemy.vx = 0;
      enemy.speechBubble = 'Tâm ma tan rã... Nước thác 100 tầng đã cuốn trôi tia máu... Mày đã thật sự trở về, Khôi!';
      enemy.speechTimer = 16.0;

      sound.playNeonShatter();
      this.triggerScreenShake(14, 0.7);
      this.spawnIceShatter(enemy.x, enemy.y, 35);
      this.stats.tamMaDefeated = true;
      this.stats.sealWarningText = '🌊 TÂM MA SHIBUYA ĐÃ TAN BIẾN! TIẾN LẠI TẢNG ĐÁ NGỘ TUYỆT KỸ KHE VẰN TRẢM (A06-E004)!';
      this.stats.sealWarningTimer = 6.0;

      const tangDaObj = this.currentZone.interactiveObjects.find(o => o.id === 'tang_da_khe_van_tram');
      if (tangDaObj) {
        tangDaObj.prompt = 'Vung Liềm Chém Thử Phiến Đá — Ngộ Tuyệt Kỹ "Khe Vằn Trảm" [E / Chạm]';
      }

      this.handleArcStoryEventTrigger('A06-E003');
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // Check Boss Victory Chu Mạnh Hiếu (Arc 11: Phase 1 & Phase 2)
    if (enemy.type === 'boss_chu_manh_hieu') {
      if (!enemy.isPhase2) {
        // Phase 1: Phá vỡ tay thép cơ khí 108 nhịp!
        sound.playNeonShatter();
        sound.playHitImpact(true);
        this.triggerScreenShake(14, 0.7);
        this.stats.bossHieuPhase1Defeated = true;
        this.stats.objectiveDetail = 'Đã chém gãy tay thép của Thảo! Chu Mạnh Hiếu đang cuồng loạn xé áo bộc lộ Dạng 2 Bản Khuyết Tật!';
        this.playerSpeechBubble = "Tay thép của Thảo đã vỡ vụn! Hiếu, dừng tay lại!";
        this.playerSpeechTimer = 4.0;
        this.stats.sealWarningText = '⚡ ĐÃ CHÉM GÃY TAY THÉP! CHU MẠNH HIẾU CHUYỂN DẠNG 2 (A11-E003)!';
        this.stats.sealWarningTimer = 7.0;
        this.handleArcStoryEventTrigger('A11-E003');
        this.triggerChuManhHieuPhase2(enemy);
        if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
        return;
      } else {
        // Phase 2: Đã đánh bại Chu Hiếu Què (Lôi Ảnh Thủ)
        enemy.hp = 1;
        enemy.state = 'idle';
        enemy.vx = 0;
        enemy.speechBubble = 'Mày chém trúng rồi... Đòn Dừng... của cụ Thọ... quả nhiên lợi hại...';
        enemy.speechTimer = 25.0;
        sound.playLevelUp();
        this.triggerScreenShake(10, 0.5);
        this.stats.bossHieuPhase2Defeated = true;
        this.unlockLoreEntry('char_hieu');
        this.unlockLoreEntry('char_hieu_khuyet_tat');
        this.stats.objectiveDetail = 'Chu Hiếu Què đã kiệt sức khuỵu chân xuống tuyết! Hãy tương tác Điểm Dừng Liềm Cuối (diem_dung_liem_cuoi) để thực thi nhát chém DỪNG LẠI!';
        this.playerSpeechBubble = "Khôi dừng người! Tao sẽ không lấy mạng mày, Hiếu!";
        this.playerSpeechTimer = 4.5;
        this.stats.sealWarningText = '🗡️ HIẾU ĐÃ KHUỴU CHÂN! HÃY TƯƠNG TÁC ĐIỂM DỪNG LIỀM CUỐI (A11-E005)!';
        this.stats.sealWarningTimer = 8.0;
        this.handleArcStoryEventTrigger('A11-E004');
        if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
        return;
      }
    }
    // Check Chapter 2 quest (Huyết trúc)
    if (enemy.type === 'huyet_truc_scout' || enemy.type === 'huyet_truc_elite') {
      const activeQuest = this.quests.find(q => q.id === 'quest_2' && q.active && !q.completed);
      if (activeQuest) {
        const remaining = this.currentZone.enemies.filter(e => e.hp > 0 && e.type.startsWith('huyet_truc')).length;
        if (remaining === 0) {
          this.completeQuest('quest_2');
          this.activateQuest('quest_3');
          this.unlockLoreEntry('loc_khe_van');
        }
      }
    }

    // Check Chapter 3 quest (Ba Chú Linh)
    if (enemy.type === 'spirit_tuan' || enemy.type === 'spirit_tay' || enemy.type === 'spirit_hung') {
      const spiritsAlive = this.currentZone.enemies.filter(e => e.hp > 0 && e.type.startsWith('spirit_')).length;
      if (spiritsAlive === 0) {
        this.completeQuest('quest_3');
        this.activateQuest('quest_4');
        this.unlockLoreEntry('three_spirits');
        this.unlockLoreEntry('char_du');
      }
    }

    // Check Arc 7: 4 Đao Thủ Tà Môn Móng Cái rình trộm mộ Tài Dog (A07-E005)
    if (enemy.type === 'ta_mon_dao_thu' || enemy.type === 'hac_dao_sat_thu') {
      this.stats.taMonDefeated = (this.stats.taMonDefeated || 0) + 1;
      const total = this.stats.totalTaMon || 4;
      this.stats.objectiveDetail = `Đẩy lui Tà Môn Móng Cái rình đồi mộ: ${this.stats.taMonDefeated}/${total} tên!`;
      if (this.stats.taMonDefeated >= total) {
        sound.playLevelUp();
        this.playerSpeechBubble = "Cậu Tài nằm xuống rồi, không ai được đụng đến mộ cậu! Cứ giữ lấy sự bình yên này!";
        this.playerSpeechTimer = 5.0;
        this.stats.sealWarningText = '🛡️ ĐÃ ĐẨY LUI TOÀN BỘ TÀ MÔN MÓNG CÁI! HÃY TƯƠNG TÁC CHIẾN TUYẾN BẢO VỆ ĐỒI MỘ!';
        this.stats.sealWarningTimer = 6.0;
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // Check Arc 8: Ba Chú Linh bị đánh bại trong Ma Trận Rubik Ngục Môn Cương
    if (this.stats.currentArc === 8 || this.currentZone.id === 'zone_nguc_mon_cuong') {
      if (enemy.type === 'spirit_tuan') {
        this.stats.tuanDefeated = true;
        this.stats.objectiveDetail = 'Đã khuất phục Đinh Quốc Tuấn! Tiến lại Bàn Thờ Bùa Muối Đen (altar_muoi_den) để hóa giải bùa muối và thu hồi Sổ Đỏ!';
        this.playerSpeechBubble = "Cán quét rải muối cứu người năm xưa... con đã hóa giải bùa muối đen rồi chú Tuấn!";
        this.playerSpeechTimer = 4.5;
        this.stats.sealWarningText = '🧂 ĐÃ HÓA GIẢI ĐINH QUỐC TUẤN! TƯƠNG TÁC BÀN THỜ BÙA MUỐI ĐEN (A08-E002)!';
        this.stats.sealWarningTimer = 5.0;
        sound.playLevelUp();
        if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      } else if (enemy.type === 'spirit_tay') {
        this.stats.tayDefeated = true;
        this.stats.objectiveDetail = 'Đã dập tắt ngọn lửa tà hỏa của Ông Táy! Tiến lại Vạc Than Tà Khí (altar_lo_than) để giải phóng Mặt Bùa 2!';
        this.playerSpeechBubble = "Bác Táy! Tà hỏa đã tắt rồi, bánh mì lò than của bác không còn bị vấy bẩn!";
        this.playerSpeechTimer = 4.5;
        this.stats.sealWarningText = '🔥 ĐÃ DẬP TẮT LÒ THAN TÀ KHÍ ÔNG TÁY! TƯƠNG TÁC VẠC THAN (A08-E003)!';
        this.stats.sealWarningTimer = 5.0;
        sound.playLevelUp();
        if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      } else if (enemy.type === 'spirit_hung') {
        this.stats.hungDefeated = true;
        this.stats.objectiveDetail = 'Đã tước vũ khí của Hùng Đỏ! Tiến lại Ổ Khóa Dao Đỏ (altar_dao_hung) để thu hồi Chìa Khóa Ngục Môn Cương!';
        this.playerSpeechBubble = "Hùng Đỏ, chiếc áo đỏ này là để che chắn đồng hương! Đưa chìa khóa Rubik cho tao!";
        this.playerSpeechTimer = 4.5;
        this.stats.sealWarningText = '🗝️ ĐÃ TƯỚC ĐAO HÙNG ĐỎ! TƯƠNG TÁC Ổ KHÓA DAO ĐỎ THU HỒI CHÌA KHÓA (A08-E004)!';
        this.stats.sealWarningTimer = 5.0;
        sound.playLevelUp();
        if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      }
    }

    // Check Arc 9: Tà Sư Mổ Sọ Hoán Não Lạng Sơn (A09-E002)
    if (enemy.type === 'ta_su_hoan_nao') {
      this.stats.taSuDefeated = (this.stats.taSuDefeated || 0) + 1;
      const total = this.stats.totalTaSu || 5;
      this.stats.objectiveDetail = `Tiêu diệt Tà Sư Hoán Não Lạng Sơn: ${this.stats.taSuDefeated}/${total} tên! Sau đó phá hủy Bàn Mổ Hoán Não!`;
      if (this.stats.taSuDefeated >= total) {
        sound.playLevelUp();
        this.playerSpeechBubble = "Đám tà sư mổ sọ đã bị khuất phục! Mau phá hủy Bàn Mổ Hoán Não!";
        this.playerSpeechTimer = 4.5;
        this.stats.sealWarningText = '🗡️ ĐÃ DIỆT SẠCH 5 TÀ SƯ! HÃY TƯƠNG TÁC PHÁ HỦY BÀN MỔ HOÁN NÃO (A09-E002)!';
        this.stats.sealWarningTimer = 6.0;
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // Check Arc 9: Boss Chu Mạnh Hiếu Avatar (Hoán Não Tay Thép) (A09-E003)
    if (enemy.type === 'boss_chu_manh_hieu_avatar') {
      enemy.hp = 1;
      enemy.state = 'idle';
      enemy.vx = 0;
      enemy.speechBubble = 'Tay thép bị gãy... Đầu tao nứt ra rồi... Khôi... Mày không thắng được đâu...';
      enemy.speechTimer = 16.0;
      sound.playNeonShatter();
      this.triggerScreenShake(14, 0.6);
      this.stats.hieuAvatarDefeated = true;
      this.stats.objectiveDetail = 'Đã đánh bại Avatar Chu Mạnh Hiếu! Tiến lại Đài Tế Hút Vía (dai_te_hut_via) để đập tan đài tế và thu giữ Mảnh Tay Thép!';
      this.playerSpeechBubble = "Cánh tay thép của Thảo không cứu nổi mày đâu Hiếu! Đài tế này phải bị phá hủy!";
      this.playerSpeechTimer = 4.5;
      this.stats.sealWarningText = '⚡ ĐÃ ĐÁNH BẠI AVATAR CHU MẠNH HIẾU! TƯƠNG TÁC ĐÀI TẾ HÚT VÍA (A09-E003)!';
      this.stats.sealWarningTimer = 6.0;
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // Check Arc 10: Đao Thủ Hắc Đạo Phong Tỏa Mốc 1088 (A10-E001)
    if (enemy.type === 'hac_dao_phong_toa') {
      this.stats.hacDaoDefeated = (this.stats.hacDaoDefeated || 0) + 1;
      const total = this.stats.totalHacDao || 4;
      this.stats.objectiveDetail = `Tiêu diệt Đao Thủ Hắc Đạo: ${this.stats.hacDaoDefeated}/${total}! Sau đó cắm 3 Mỏ Neo Cáp Thép vào vách đá!`;
      if (this.stats.hacDaoDefeated >= total) {
        sound.playLevelUp();
        this.playerSpeechBubble = "Đám đao thủ phong tỏa đã bị dẹp tan! Mau cắm 3 Mỏ Neo Cáp Thép giăng giàn cáp!";
        this.playerSpeechTimer = 4.5;
        this.stats.sealWarningText = '🧗 ĐÃ DIỆT 4 ĐAO THỦ! HÃY CẮM 3 MỎ NEO CÁP THÉP TRÊN VÁCH ĐÁ (A10-E001)!';
        this.stats.sealWarningTimer = 6.0;
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // Check Arc 10: Boss Trùm Đao Thủ Hắc Đạo Canh Ngục Rubik (A10-E002)
    if (enemy.type === 'boss_trum_dao_thu_hac_dao') {
      enemy.hp = 1;
      enemy.state = 'idle';
      enemy.vx = 0;
      enemy.speechBubble = 'Khặc... Cáp thép siết nát cổ tay tao... Chu Mạnh Hiếu... đang ở trường mầm non...';
      enemy.speechTimer = 16.0;
      sound.playNeonShatter();
      this.triggerScreenShake(14, 0.6);
      this.stats.bossDaoThuDefeated = true;
      this.stats.objectiveDetail = 'Đã đánh bại Trùm Đao Thủ Canh Ngục! Khóa Căng Cáp Thép đã rơi ra! Tiến lại Khối Đá Rubik 1m³ (rubik_nguc_mon_cuong_108) để gõ 108 nhịp mở ngục!';
      this.playerSpeechBubble = "Khóa căng cáp thép đã về tay ta! Dư ơi, gõ 108 nhịp phá vỡ Rubik thôi!";
      this.playerSpeechTimer = 4.5;
      this.stats.sealWarningText = '🗡️ ĐÃ HẠ TRÙM ĐAO THỦ! THU HỒI KHÓA CÁP! TƯƠNG TÁC RUBIK 108 NHỊP (A10-E002)!';
      this.stats.sealWarningTimer = 6.0;
      this.handleArcStoryEventTrigger('A10-E002');
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }

    // Check Arc 10 & Arc 11: Trinh Sát Tà Môn
    if (enemy.type === 'do_tham_ta_mon') {
      if (this.currentZone.id === 'zone_mam_non_midnight') {
        // Arc 11: Lính gác cổng trường mầm non (A11-E001)
        this.stats.mamNonGuardsDefeated = (this.stats.mamNonGuardsDefeated || 0) + 1;
        const total = this.stats.totalMamNonGuards || 3;
        this.stats.objectiveDetail = `Dẹp sạch lính gác cổng trường mầm non: ${this.stats.mamNonGuardsDefeated}/${total}! Sau đó mở Rào Chắn Cổng Trường (rao_chan_cong_mam_non)!`;
        if (this.stats.mamNonGuardsDefeated >= total) {
          sound.playLevelUp();
          this.playerSpeechBubble = "Đã dẹp sạch lính gác cổng trường! Mau mở khóa Rào Chắn Cổng Trường vào trong cứu lũ trẻ!";
          this.playerSpeechTimer = 4.5;
          this.stats.sealWarningText = '🏫 ĐÃ DIỆT 3 LÍNH GÁC! HÃY TƯƠNG TÁC RÀO CHẮN CỔNG TRƯỜNG (A11-E001)!';
          this.stats.sealWarningTimer = 6.0;
        }
      } else {
        // Arc 10: Trinh Sát Tà Môn Bản Cáu (A10-E005)
        this.stats.doThamTaMonDefeated = (this.stats.doThamTaMonDefeated || 0) + 1;
        const total = this.stats.totalDoThamTaMon || 3;
        this.stats.objectiveDetail = `Dẹp toán trinh sát tà môn rình rập Bản Cáu: ${this.stats.doThamTaMonDefeated}/${total}! Sau đó gặp Lục Triều Dư tại Cổng Đình!`;
        if (this.stats.doThamTaMonDefeated >= total) {
          sound.playLevelUp();
          this.playerSpeechBubble = "Toán trinh sát đã bị tiêu diệt! Mau ra Cổng Đình Lục Nà hội ngộ cùng anh Dư!";
          this.playerSpeechTimer = 4.5;
          this.stats.sealWarningText = '🏫 ĐÃ DẸP SẠCH TOÁN DO THÁM! TƯƠNG TÁC CỔNG ĐÌNH LỤC NÀ (A10-E005)!';
          this.stats.sealWarningTimer = 6.0;
        }
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }
  }

  /**
   * Kích hoạt Chu Mạnh Hiếu Dạng 2 — Bản Khuyết Tật (Chu Hiếu Què · Lôi Ảnh Thủ)
   */
  private triggerChuManhHieuPhase2(enemy: Enemy) {
    enemy.isTransforming = true;
    enemy.transformTimer = 3.5;
    enemy.state = 'idle';
    enemy.vx = 0;
    enemy.vy = -180;
    this.triggerScreenShake(12, 1.2);
    sound.playLevelUp();
    sound.playNeonShatter();

    // Hào quang sấm sét nổ tung & khói nọc độc Nữ Thánh Rắn bốc lên
    for (let i = 0; i < 45; i++) {
      this.particles.push({
        x: enemy.x + (Math.random() - 0.5) * 80,
        y: enemy.y - 30 + (Math.random() - 0.5) * 60,
        vx: (Math.random() - 0.5) * 260,
        vy: -Math.random() * 220 - 40,
        life: 1.0,
        maxLife: 1.0,
        size: 5,
        color: Math.random() > 0.5 ? '#10b981' : '#facc15',
        alpha: 0.95,
        type: 'seal',
      });
    }

    // Thiết lập Dạng 2: Bản Khuyết Tật
    enemy.isPhase2 = true;
    enemy.phase = 2;
    enemy.name = 'Chu Mạnh Hiếu (Bản Khuyết Tật - Lôi Ảnh Thủ)';
    // 1 triệu máu & 300 nghìn giáp Dạng 2
    enemy.hp = 1000000;
    enemy.maxHp = 1000000;
    enemy.armor = 300000;
    enemy.maxArmor = 300000;
    enemy.damage = 115;
    enemy.detectionRange = 580;
    enemy.attackRange = 115;
    enemy.maxAttackCooldown = 1.1;
    enemy.attackCooldown = 2.0;
    enemy.skillType = 'loi_anh_thu';
    enemy.maxSkillCooldown = 3.8;
    enemy.skillCooldown = 2.0;

    // Thoại hiển thị trên đầu
    enemy.speechBubble = 'CÁI GÌ KHÔNG GIẾT ĐƯỢC TAO THÌ LÀM TAO MẠNH HƠN!';
    enemy.speechTimer = 5.0;

    // Kích hoạt Cutscene chuyển dạng chính thức giữa Khôi, Dư và Hiếu Què
    if (this.callbacks.onDialogTrigger) {
      this.callbacks.onDialogTrigger('dialog_boss_phase_2_transform');
    }

    setTimeout(() => {
      enemy.isTransforming = false;
    }, 3500);
  }

  /**
   * Spawn Drops on Enemy Defeat: EXP Orbs, Potions, Shards, and Armor (5-7% chance)
   */
  private spawnDrops(enemy: Enemy) {
    // 1. EXP Orbs (luôn rơi ra từ quái và boss)
    const orbCount = enemy.isBoss ? 16 : 4;
    for (let i = 0; i < orbCount; i++) {
      this.droppedItems.push({
        id: `exp_${Date.now()}_${Math.random()}`,
        type: 'exp_orb',
        name: 'Linh Khí EXP',
        x: enemy.x + (Math.random() - 0.5) * 20,
        y: enemy.y - enemy.h / 2,
        vx: (Math.random() - 0.5) * 160,
        vy: -Math.random() * 150 - 50,
        value: Math.max(15, Math.round(enemy.xpReward / orbCount)),
        life: 30.0,
        maxLife: 30.0,
      });
    }

    // 2. Armor drop: 5% đến 7% tỉ lệ rơi giáp (Boss rơi 100%)
    const armorChance = enemy.isBoss ? 1.0 : 0.065;
    if (Math.random() < armorChance) {
      this.droppedItems.push({
        id: `armor_${Date.now()}_${Math.random()}`,
        type: 'armor_drop',
        name: enemy.isBoss ? 'Chiến Giáp Tuyết Hoàng Gia' : 'Chiến Giáp Tuyết Biên Phòng',
        x: enemy.x,
        y: enemy.y - 25,
        vx: (Math.random() - 0.5) * 70,
        vy: -160,
        value: enemy.isBoss ? 600 : 400,
        life: 40.0,
        maxLife: 40.0,
      });
    }

    // 3. Mảnh Rèn Thần Binh (28% quái thường, Boss rơi 5 mảnh)
    if (enemy.isBoss || Math.random() < 0.28) {
      this.droppedItems.push({
        id: `shard_${Date.now()}_${Math.random()}`,
        type: 'upgrade_shard',
        name: 'Mảnh Rèn Thần Binh',
        x: enemy.x + (Math.random() - 0.5) * 15,
        y: enemy.y - 25,
        vx: (Math.random() - 0.5) * 80,
        vy: -140,
        value: enemy.isBoss ? 5 : 1,
        life: 40.0,
        maxLife: 40.0,
      });
    }

    // 4. Bánh mì / Thuốc hồi phục (35% rơi)
    if (enemy.isBoss || Math.random() < 0.35) {
      const isBread = Math.random() > 0.5;
      this.droppedItems.push({
        id: `item_${Date.now()}_${Math.random()}`,
        type: isBread ? 'bread' : 'potion_hp',
        name: isBread ? 'Bánh Mì Nóng 24/7' : 'Bình Thuốc Nam',
        x: enemy.x + (Math.random() - 0.5) * 15,
        y: enemy.y - 25,
        vx: (Math.random() - 0.5) * 80,
        vy: -130,
        value: isBread ? 800 : 400,
        life: 40.0,
        maxLife: 40.0,
      });
    }
  }

  /**
   * Update Dropped Items Physics & Magnetic Collection
   */
  private updateDroppedItems(dt: number) {
    const p = this.player;
    for (let i = this.droppedItems.length - 1; i >= 0; i--) {
      const item = this.droppedItems[i];
      item.life -= dt;
      if (item.life <= 0) {
        this.droppedItems.splice(i, 1);
        continue;
      }

      // Gravity & movement
      item.vy += 800 * dt;
      if (item.vy > 600) item.vy = 600;
      item.x += item.vx * dt;
      item.y += item.vy * dt;
      item.vx *= 0.95;

      // Platform collision
      for (const plat of this.currentZone.platforms) {
        if (
          item.x >= plat.x &&
          item.x <= plat.x + plat.w &&
          item.y >= plat.y &&
          item.y - item.vy * dt <= plat.y + 12
        ) {
          item.y = plat.y;
          item.vy = 0;
          break;
        }
      }

      // Magnet draw to player
      const dist = Math.hypot(p.x - item.x, (p.y - 25) - item.y);
      if (dist < 130) {
        const angle = Math.atan2((p.y - 25) - item.y, p.x - item.x);
        item.x += Math.cos(angle) * 360 * dt;
        item.y += Math.sin(angle) * 360 * dt;
      }

      // Collect pickup
      if (dist < 34) {
        if (item.type === 'exp_orb') {
          this.addXp(item.value);
          sound.playItemGet();
        } else if (item.type === 'armor_drop') {
          this.stats.armor = Math.min(this.stats.maxArmor, this.stats.armor + item.value);
          this.stats.armorDurability = 100;
          this.stats.equippedArmorName = item.name;
          this.stats.sealWarningText = `🛡 TRANG BỊ: ${item.name.toUpperCase()} (+${item.value} GIÁP, 100% ĐỘ BỀN)!`;
          this.stats.sealWarningTimer = 3.2;
          this.addDamageNumber(p.x, p.y - 45, item.value, '#38bdf8', true);
          sound.playLevelUp();
        } else if (item.type === 'upgrade_shard') {
          this.stats.upgradeShards += item.value;
          this.stats.sealWarningText = `✨ NHẶT ĐƯỢC: +${item.value} MẢNH RÈN THẦN BINH! (Tổng: ${this.stats.upgradeShards})`;
          this.stats.sealWarningTimer = 2.8;
          this.addDamageNumber(p.x, p.y - 45, item.value, '#facc15', true);
          sound.playItemGet();
        } else if (item.type === 'potion_hp' || item.type === 'bread') {
          const targetId = item.type === 'bread' ? 'item_banh_mi_ong_tay' : 'item_com_trung';
          const invItem = this.inventory.find(inv => inv.id === targetId);
          if (invItem) {
            invItem.quantity++;
          }
          this.stats.sealWarningText = `🎒 NHẶT ĐƯỢC: ${item.name}!`;
          this.stats.sealWarningTimer = 2.5;
          sound.playItemGet();
        }

        if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
        this.droppedItems.splice(i, 1);
      }
    }
  }

  /**
   * Wave Spawner: 5 Đợt quái, 20 quái mỗi đợt (Tổng 100 quái mỗi arc) - Requirement 6
   */
  private updateWaves(dt: number) {
    if (this.currentZone.id === 'zone_ban_cau') return; // Trừ ải đầu tiên ra

    this.waveTimer += dt;
    const aliveMinions = this.currentZone.enemies.filter(e => e.hp > 0 && !e.isBoss);

    // Khi dọn sạch đợt quái hoặc qua 20 giây, triệu hồi đợt quái tiếp theo (5 đợt tối đa)
    if ((aliveMinions.length === 0 || this.waveTimer >= 20.0) && this.stats.waveNumber < 5) {
      this.stats.waveNumber++;
      this.waveTimer = 0;

      // Spawn đúng 20 quái cho mỗi đợt để đạt 100 quái trong 5 đợt
      const spawnCount = 20;
      const waveHp = Math.round(55000 + this.stats.waveNumber * 15000);
      const waveDmg = Math.round(85 + this.stats.waveNumber * 25);

      for (let i = 0; i < spawnCount; i++) {
        const spawnX = 180 + Math.random() * (this.currentZone.width - 360);
        const newEnemy: Enemy = {
          id: `wave_mob_${this.stats.waveNumber}_${i}_${Date.now()}`,
          type: this.currentZone.id === 'zone_thac_khe_van' ? 'spirit_hung' : 'huyet_truc_elite',
          name: this.currentZone.id === 'zone_thac_khe_van' ? `Hắc Ảnh Tiên Phong #${i + 1}` : `Huyết Trúc Đột Kích #${i + 1}`,
          x: spawnX,
          y: 440,
          w: 28,
          h: 46,
          vx: 0,
          vy: 0,
          hp: waveHp,
          maxHp: waveHp,
          direction: Math.random() > 0.5 ? 1 : -1,
          state: 'chase',
          patrolMinX: Math.max(50, spawnX - 250),
          patrolMaxX: Math.min(this.currentZone.width - 50, spawnX + 250),
          detectionRange: 600,
          attackRange: 55,
          attackCooldown: 0.5,
          maxAttackCooldown: 1.2,
          hurtTimer: 0,
          attackTimer: 0,
          damage: waveDmg,
          xpReward: Math.round(200 + this.stats.waveNumber * 30),
          skillCooldown: 3.0,
          maxSkillCooldown: 4.0,
          skillType: Math.random() > 0.5 ? 'dash_strike' : 'ground_slam',
          canJump: true,
          jumpCount: 0,
        };

        this.currentZone.enemies.push(newEnemy);
        this.spawnDust(spawnX, 440, 10);
      }

      const remainingMobs = this.currentZone.enemies.filter(e => e.hp > 0 && !e.isBoss).length;
      this.stats.monstersRemainingInArc = remainingMobs;
      this.stats.sealWarningText = `⚔️ ĐỢT QUÁI ${this.stats.waveNumber} / 5 XUẤT HIỆN (+20 QUÁI)! CÒN ${remainingMobs}/100 QUÁI TRONG ARC!`;
      this.stats.sealWarningTimer = 4.0;
      sound.playLevelUp();
      this.triggerScreenShake(5, 0.3);
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    }
  }

  /**
   * Update Combat Companion NPCs (Lục Triều Dư, Cụ Thọ, La Thanh, Tài Dog) - Requirement 7, 9, 20, 27
   */
  private updateNPCs(dt: number) {
    for (const npc of this.currentZone.npcs) {
      if (!npc.maxJumps) npc.maxJumps = npc.id.includes('du') ? 2 : 1;
      if (npc.jumpCount === undefined) npc.jumpCount = 0;
      if (npc.jumpCooldown === undefined) npc.jumpCooldown = 0;
      if (npc.jumpCooldown > 0) npc.jumpCooldown -= dt;

      // Handle vertical gravity and jumping physics for NPC
      if (npc.vy === undefined) npc.vy = 0;
      npc.vy += 1100 * dt;
      if (npc.vy > 750) npc.vy = 750;

      const groundY = this.getGroundYAt(npc.x, npc.y);
      npc.y += npc.vy * dt;
      if (npc.y >= groundY) {
        npc.y = groundY;
        npc.vy = 0;
        npc.jumpCount = 0; // Reset jump on landing
      }

      // Check obstacle ahead -> Jump over walls/platforms (Single jump for normal NPC, Double jump for Lục Triều Dư)
      const lookAheadX = npc.x + (npc.direction || 1) * 35;
      const groundAheadY = this.getGroundYAt(lookAheadX, npc.y);
      if (groundAheadY < npc.y - 25 && npc.jumpCooldown <= 0 && npc.jumpCount < npc.maxJumps) {
        npc.vy = -480;
        npc.jumpCount++;
        npc.jumpCooldown = 1.0;
        sound.playJump();
        this.spawnDust(npc.x, npc.y, 6);
      }

      if (npc.speechTimer && npc.speechTimer > 0) {
        npc.speechTimer -= dt;
        if (npc.speechTimer <= 0) {
          npc.speechBubble = undefined;
        }
      }

      if (npc.attackCooldown && npc.attackCooldown > 0) {
        npc.attackCooldown -= dt;
      }

      // --- LỤC TRIỀU DƯ COMBAT LOGIC ---
      if (npc.isCombatant) {
        // Priority 1: If Khôi is sealed in ice, rush to Khôi and break the seal!
        if (this.stats.isSealedInIce) {
          const distToKhoi = Math.abs(this.player.x - npc.x);
          npc.direction = this.player.x > npc.x ? 1 : -1;
          if (distToKhoi > 45) {
            npc.x += (npc.direction || 1) * 220 * dt;
            npc.state = 'support';
          } else {
            // Cut the seal with wire!
            npc.state = 'cable_strike';
            npc.speechBubble = "Khôi! Tao phá phong ấn cho mày rồi, lên đi!";
            npc.speechTimer = 2.5;
            sound.playCableStrike();
            this.breakIceSeal(true);
            setTimeout(() => {
              npc.state = 'idle';
            }, 300);
          }
          npc.x = Math.max(24, Math.min(this.currentZone.width - 24, npc.x));
          continue;
        }

        // Priority 2: Find Boss first, or closest hostile enemy
        let target: Enemy | null = null;
        let boss = this.currentZone.enemies.find(e => e.hp > 0 && e.isBoss);
        if (boss) {
          target = boss;
        } else {
          let minDist = 9999;
          for (const e of this.currentZone.enemies) {
            if (e.hp > 0) {
              const dist = Math.abs(e.x - npc.x);
              if (dist < minDist) {
                minDist = dist;
                target = e;
              }
            }
          }
        }

        if (target) {
          const distToTarget = Math.abs(target.x - npc.x);
          npc.direction = target.x > npc.x ? 1 : -1;

          // Wire swing or double jump to close gap
          if (distToTarget > 280 && npc.jumpCooldown <= 0 && npc.jumpCount < npc.maxJumps) {
            npc.vy = -510;
            npc.jumpCount++;
            npc.jumpCooldown = 1.2;
            sound.playCableStrike();
            npc.state = 'jump';
          }

          if (distToTarget > 110) {
            npc.x += (npc.direction || 1) * 190 * dt;
            npc.state = 'support';
          } else {
            // In attack range -> unleash Hỏa Long Katana & Cáp Thép Giật!
            if (!npc.attackCooldown || npc.attackCooldown <= 0) {
              npc.state = 'cable_strike';
              npc.attackCooldown = 1.2;
              sound.playFireDragonKatana();
              sound.playCableStrike();
              this.triggerScreenShake(5, 0.25);

              // Dragon fire particles from Hỏa Long Katana
              for (let i = 0; i < 30; i++) {
                this.particles.push({
                  x: npc.x + (npc.direction || 1) * (30 + i * 5),
                  y: npc.y - 25 + (Math.random() - 0.5) * 35,
                  vx: (npc.direction || 1) * (200 + Math.random() * 150),
                  vy: (Math.random() - 0.5) * 120,
                  life: 0.6,
                  maxLife: 0.6,
                  size: 4 + Math.random() * 3,
                  color: Math.random() > 0.4 ? '#f97316' : '#ef4444',
                  alpha: 1.0,
                  type: 'fire',
                });
              }

              // Companion dialogue
              const duQuotes = [
                "HỎA LONG KATANA — Long Hống Liệt Diễm!",
                "Khôi, lao vào đi! Cáp thép 108 nhịp trói chặt nó rồi!",
                "Dù sấm sét hay tà thuật, phe Kéo bọn tao không lùi bước!",
                "Roi cáp xé gió, kiếm rồng chém rực trời!",
              ];
              npc.speechBubble = duQuotes[Math.floor(Math.random() * duQuotes.length)];
              setTimeout(() => {
                npc.speechBubble = undefined;
              }, 2600);

              // AoE Multi-Target Sweep: Hit ALL enemies in 220px radius around Dư!
              for (const hitEnemy of this.currentZone.enemies) {
                if (hitEnemy.hp <= 0) continue;
                if (Math.abs(hitEnemy.x - npc.x) < 220 && Math.abs(hitEnemy.y - npc.y) < 90) {
                  const isCrit = Math.random() < 0.6;
                  let dmg = Math.round((npc.damage || 450) * (isCrit ? 2.5 : 1.0));

                  if (hitEnemy.armor && hitEnemy.armor > 0) {
                    if (dmg <= hitEnemy.armor) {
                      hitEnemy.armor -= dmg;
                      this.addDamageNumber(hitEnemy.x, hitEnemy.y - hitEnemy.h / 2 - 12, dmg, '#38bdf8', isCrit);
                    } else {
                      const rem = dmg - hitEnemy.armor;
                      hitEnemy.armor = 0;
                      hitEnemy.hp -= rem;
                      this.addDamageNumber(hitEnemy.x, hitEnemy.y - hitEnemy.h / 2, rem, '#f97316', isCrit);
                    }
                  } else {
                    hitEnemy.hp -= dmg;
                    this.addDamageNumber(hitEnemy.x, hitEnemy.y - hitEnemy.h / 2, dmg, isCrit ? '#f97316' : '#ea580c', isCrit);
                  }

                  hitEnemy.hurtTimer = 0.5;
                  hitEnemy.state = 'hurt';
                  hitEnemy.vx = (npc.direction || 1) * 180;
                  this.spawnBloodSparks(hitEnemy.x, hitEnemy.y - hitEnemy.h / 2);

                  if (hitEnemy.hp <= 0) {
                    this.handleEnemyDefeated(hitEnemy);
                  }
                }
              }

              setTimeout(() => {
                npc.state = 'idle';
              }, 400);
            }
          }
        } else {
          npc.state = 'idle';
        }
      } else {
        // --- CÁC NPC KHÁC (CỤ THỌ, LA THANH, TÀI DOG) ĐÁNH TRẢ VÀ DI CHUYỂN BẢO VỆ BẢN ---
        for (const e of this.currentZone.enemies) {
          if (e.hp > 0 && Math.abs(e.x - npc.x) < 130 && Math.abs(e.y - npc.y) < 70) {
            npc.direction = e.x >= npc.x ? 1 : -1;
            if (!npc.attackCooldown || npc.attackCooldown <= 0) {
              npc.attackCooldown = 1.6;
              npc.state = 'attack';
              sound.playHitImpact(false);

              if (npc.id === 'npc_cu_tho') {
                npc.speechBubble = "Gậy Trúc Hoàng Long 108 rãnh — Trừ gian diệt tà!";
                e.hp -= 350;
                e.vx = (npc.direction || 1) * 220;
                this.addDamageNumber(e.x, e.y - 30, 350, '#fbbf24', true);
              } else if (npc.id === 'npc_la_thanh') {
                npc.speechBubble = "Phi kim phong tỏa huyệt đạo tà ma!";
                e.hp -= 280;
                e.hurtTimer = 1.2;
                this.addDamageNumber(e.x, e.y - 30, 280, '#34d399', false);
              } else if (npc.id === 'npc_tai_dog') {
                npc.speechBubble = "Đốm! Cắn xé nó bảo vệ cổng bản!";
                e.hp -= 300;
                this.addDamageNumber(e.x, e.y - 30, 300, '#f97316', true);
              }

              if (e.hp <= 0) {
                this.handleEnemyDefeated(e);
              }

              setTimeout(() => {
                npc.state = 'idle';
                setTimeout(() => { npc.speechBubble = undefined; }, 2000);
              }, 400);
            }
          }
        }
      }

      // Ghim chặt NPC không bao giờ văng ra khỏi map (Requirement 2)
      npc.x = Math.max(24, Math.min(this.currentZone.width - 24, npc.x));
    }
  }

  /**
   * Update Enemy AI
   */
  private updateEnemies(dt: number) {
    const p = this.player;

    for (const enemy of this.currentZone.enemies) {
      if (enemy.hp <= 0) continue;

      // Boss có 700 Triệu Máu (700,000,000 HP)
      if (enemy.isBoss && enemy.maxHp < 700000000) {
        enemy.maxHp = 700000000;
        enemy.hp = 700000000;
        enemy.damage = Math.max(220, enemy.damage * 2.2);
      }

      // Quái và Boss nhảy 1 lần để vượt chướng ngại vật/tường (Requirement 9 & 20)
      if (enemy.jumpCount === undefined) enemy.jumpCount = 0;
      if (enemy.jumpCooldown === undefined) enemy.jumpCooldown = 0;
      if (enemy.jumpCooldown > 0) enemy.jumpCooldown -= dt;

      // Enemy gravity physics
      if (enemy.vy === undefined) enemy.vy = 0;
      enemy.vy += 1100 * dt;
      if (enemy.vy > 750) enemy.vy = 750;

      const groundY = this.getGroundYAt(enemy.x, enemy.y);
      enemy.y += enemy.vy * dt;
      if (enemy.y >= groundY) {
        enemy.y = groundY;
        enemy.vy = 0;
        enemy.jumpCount = 0; // Tiếp đất reset lượt nhảy
      }

      // Kiểm tra chướng ngại vật phía trước hoặc mục tiêu ở trên cao hoặc Boss nhảy linh hoạt né đòn
      const lookAheadX = enemy.x + enemy.direction * 32;
      const groundAheadY = this.getGroundYAt(lookAheadX, enemy.y);
      const isTargetHigher = p.y < enemy.y - 35;
      const shouldBossJump = enemy.isBoss && Math.random() < 0.08 && Math.abs(p.x - enemy.x) < 420;
      if ((groundAheadY < enemy.y - 25 || isTargetHigher || shouldBossJump) && enemy.jumpCooldown <= 0 && enemy.jumpCount < 1) {
        enemy.vy = enemy.isBoss ? -520 : -480;
        enemy.jumpCount = 1;
        enemy.jumpCooldown = enemy.isBoss ? 0.9 : 1.4;
        sound.playJump();
        this.spawnDust(enemy.x, enemy.y, 6);
      }

      // Đang trong hoạt ảnh biến hình Dạng 2: Miễn nhiễm và đứng bất động
      if (enemy.isTransforming) {
        enemy.vx = 0;
        if (enemy.transformTimer && enemy.transformTimer > 0) {
          enemy.transformTimer -= dt;
          if (enemy.transformTimer <= 0) enemy.isTransforming = false;
        }
        continue;
      }

      if (enemy.hurtTimer > 0) {
        enemy.hurtTimer -= dt;
        enemy.vx *= 0.8;
      } else {
        const distToPlayer = Math.abs(p.x - enemy.x);
        const yDist = Math.abs(p.y - enemy.y);

        // Training dummies don't move or attack
        if (enemy.type === 'dummy') {
          enemy.vx = 0;
          continue;
        }

        // Speech timer decrement
        if (enemy.speechTimer && enemy.speechTimer > 0) {
          enemy.speechTimer -= dt;
          if (enemy.speechTimer <= 0) enemy.speechBubble = undefined;
        }

        // --- BA CHÚ LINH THI TRIỂN PHONG ẤN KHÔI ---
        if (enemy.type === 'spirit_tuan' || enemy.type === 'spirit_tay' || enemy.type === 'spirit_hung') {
          if (enemy.sealCooldown === undefined) {
            enemy.sealCooldown = 4.0 + Math.random() * 4.0;
          }
          if (enemy.sealCooldown > 0) {
            enemy.sealCooldown -= dt;
          }

          if (enemy.sealCooldown <= 0 && enemy.hp > 0 && distToPlayer < 260 && !this.stats.isSealedInIce) {
            enemy.sealCooldown = 11.0 + Math.random() * 4.0;
            const chantMap: Record<string, string> = {
              spirit_tuan: 'QUÉT ĐƯỜNG SINH TỬ — PHONG BĂNG!',
              spirit_tay: 'BÙA PHONG THÂN KHAI — KHÓA HỒN!',
              spirit_hung: 'ĐẠI TRẬN TAM LINH — KHÓA NGỤC MÔN!',
            };
            enemy.speechBubble = chantMap[enemy.type] || 'PHONG ẤN BĂNG TUYẾT!';
            enemy.speechTimer = 3.0;
            this.triggerThreeSpiritsSeal(enemy);
          }
        }

        // --- AI ĐÁNH GIÁ MỤC TIÊU (Người chơi Khôi hoặc Đồng minh NPC như Dư) ---
        let targetX = p.x;
        let targetY = p.y;
        let targetIsPlayer = true;
        let targetNpc: NPC | null = null;
        let effectiveDist = distToPlayer;

        // Tìm NPC đồng minh gần nhất
        for (const npc of this.currentZone.npcs) {
          if (npc.hp > 0) {
            const distNpc = Math.abs(npc.x - enemy.x);
            if (distNpc < effectiveDist && distNpc < enemy.detectionRange) {
              effectiveDist = distNpc;
              targetX = npc.x;
              targetY = npc.y;
              targetIsPlayer = false;
              targetNpc = npc;
            }
          }
        }

        // --- KỸ NĂNG CỦA QUÁI THƯỜNG VÀ BOSS ---
        if (enemy.skillCooldown === undefined) {
          enemy.skillCooldown = enemy.maxSkillCooldown || 4.0;
        }
        if (enemy.skillCooldown > 0) enemy.skillCooldown -= dt;

        // BOSS SKILL ROTATION: Thuật thức bẩm sinh HỎA HOẠN & BÀNH TRƯỚNG LÃNH ĐỊA của JOGO (Chú Thuật Hồi Chiến)
        if (enemy.isBoss && enemy.skillCooldown <= 0 && effectiveDist < 750) {
          enemy.skillCooldown = 2.8 + Math.random() * 1.5; // Dùng skill nhiều hơn và liên tục

          const bossSkillRoll = Math.random();
          if (bossSkillRoll < 0.25) {
            // 1. [BÀNH TRƯỚNG LÃNH ĐỊA: CÁI QUAN THIẾT VI SƠN - GAIKAN TECCHISEN]
            enemy.isGaikanTecchisenActive = true;
            enemy.domainTimer = 5.0;
            enemy.speechBubble = "BÀNH TRƯỚNG LÃNH ĐỊA: CÁI QUAN THIẾT VI SƠN!";
            enemy.speechTimer = 3.5;
            sound.playGaikanTecchisen();
            this.triggerScreenShake(16, 1.2);

            for (let i = 0; i < 60; i++) {
              this.particles.push({
                x: this.cameraX + Math.random() * this.screenWidth,
                y: this.cameraY + Math.random() * 60,
                vx: (Math.random() - 0.5) * 160,
                vy: 240 + Math.random() * 220,
                life: 0.9,
                maxLife: 0.9,
                size: 5 + Math.random() * 4,
                color: Math.random() > 0.4 ? '#dc2626' : '#ea580c',
                alpha: 1.0,
                type: 'fire',
              });
            }

            setTimeout(() => {
              if (enemy.hp > 0) {
                this.takePlayerDamage(Math.round(enemy.damage * 1.8));
                for (const n of this.currentZone.npcs) {
                  if (n.hp > 0) {
                    n.hp -= Math.round(enemy.damage * 1.5);
                    n.state = 'hurt';
                    this.addDamageNumber(n.x, n.y - 40, Math.round(enemy.damage * 1.5), '#dc2626', true);
                  }
                }
              }
            }, 300);
          } else if (bossSkillRoll < 0.48) {
            // 2. [CỰC PHIÊN: VẪN - MAXIMUM: METEOR] (Triệu hồi thiên thạch rực lửa khổng lồ từ trời rơi xuống)
            enemy.isMaximumMeteorCasting = true;
            enemy.meteorTimer = 1.6;
            enemy.meteorX = p.x;
            enemy.meteorY = p.y;
            enemy.speechBubble = "CỰC PHIÊN: VẪN (MAXIMUM: METEOR) — THIÊN THẠCH HỦY DIỆT!";
            enemy.speechTimer = 3.5;
            sound.playMaximumMeteor();
            this.triggerScreenShake(12, 0.7);

            // Vòng tròn cảnh báo mục tiêu mặt đất
            for (let i = 0; i < 30; i++) {
              this.particles.push({
                x: p.x + (Math.random() - 0.5) * 160,
                y: p.y - 4,
                vx: (Math.random() - 0.5) * 60,
                vy: -Math.random() * 40,
                life: 1.4,
                maxLife: 1.4,
                size: 4,
                color: '#f97316',
                alpha: 0.9,
                type: 'fire',
              });
            }

            setTimeout(() => {
              if (enemy.hp > 0) {
                this.triggerScreenShake(22, 1.2);
                sound.playExplosion();
                enemy.isMaximumMeteorCasting = false;

                for (let i = 0; i < 60; i++) {
                  this.particles.push({
                    x: (enemy.meteorX || p.x) + (Math.random() - 0.5) * 260,
                    y: (enemy.meteorY || p.y) + (Math.random() - 0.5) * 180,
                    vx: (Math.random() - 0.5) * 450,
                    vy: -Math.random() * 350 - 40,
                    life: 0.8,
                    maxLife: 0.8,
                    size: 6 + Math.random() * 5,
                    color: Math.random() > 0.4 ? '#ef4444' : '#f59e0b',
                    alpha: 1.0,
                    type: 'fire',
                  });
                }

                if (Math.abs(p.x - (enemy.meteorX || p.x)) < 260) {
                  this.takePlayerDamage(Math.round(enemy.damage * 2.3));
                  p.vy = -380;
                  p.vx = (p.x > enemy.x ? 1 : -1) * 350;
                }
                for (const n of this.currentZone.npcs) {
                  if (Math.abs(n.x - (enemy.meteorX || p.x)) < 260) {
                    n.hp -= Math.round(enemy.damage * 2.0);
                    n.state = 'hurt';
                    this.addDamageNumber(n.x, n.y - 40, Math.round(enemy.damage * 2.0), '#f97316', true);
                  }
                }
              }
            }, 1200);
          } else if (bossSkillRoll < 0.68) {
            // 3. [HỎA LỊCH TRÙNG - EMBER INSECTS] (Bầy côn trùng lửa bám nổ)
            enemy.speechBubble = "HỎA LỊCH TRÙNG — BẦY BỌ LỬA NỔ TUNG!";
            enemy.speechTimer = 2.8;
            sound.playEmberInsects();
            this.triggerScreenShake(8, 0.4);

            for (let k = 0; k < 6; k++) {
              setTimeout(() => {
                if (enemy.hp > 0) {
                  const insectX = enemy.x + (enemy.direction * 30);
                  const insectY = enemy.y - 30;
                  this.particles.push({
                    x: insectX,
                    y: insectY,
                    vx: enemy.direction * (220 + Math.random() * 160),
                    vy: (Math.random() - 0.5) * 140,
                    life: 0.7,
                    maxLife: 0.7,
                    size: 5,
                    color: '#ea580c',
                    alpha: 1.0,
                    type: 'spark',
                  });
                  if (Math.abs(p.x - enemy.x) < 240) {
                    this.takePlayerDamage(Math.round(enemy.damage * 0.45));
                  }
                }
              }, k * 120);
            }
          } else if (bossSkillRoll < 0.85) {
            // 4. [HỎA CHÙY / PHUN LỬA - FIRE WAVE]
            enemy.speechBubble = "HỎA CHÙY — SÓNG LỬA THIÊU ĐỐT!";
            enemy.speechTimer = 2.5;
            sound.playFireWave();
            this.triggerScreenShake(9, 0.5);

            for (let i = 0; i < 40; i++) {
              this.particles.push({
                x: enemy.x + enemy.direction * (i * 9),
                y: enemy.y - 25 + (Math.random() - 0.5) * 35,
                vx: enemy.direction * (280 + Math.random() * 180),
                vy: (Math.random() - 0.5) * 80,
                life: 0.6,
                maxLife: 0.6,
                size: 5,
                color: Math.random() > 0.4 ? '#dc2626' : '#f59e0b',
                alpha: 1.0,
                type: 'fire',
              });
            }

            if (Math.abs(p.x - enemy.x) < 320 && (enemy.direction === 1 ? p.x > enemy.x : p.x < enemy.x)) {
              this.takePlayerDamage(Math.round(enemy.damage * 1.5));
              p.vx = enemy.direction * 220;
            }
          } else {
            // 5. [LÃNH ĐỊA TRIỂN DUYÊN - DOMAIN AMPLIFICATION] (Trung hòa thuật thức, giảm 60% sát thương)
            enemy.isDomainAmplificationActive = true;
            enemy.domainAmplificationTimer = 4.5;
            enemy.speechBubble = "LÃNH ĐỊA TRIỂN DUYÊN — VÔ HIỆU HÓA THUẬT THỨC!";
            enemy.speechTimer = 3.2;
            sound.playDomainAmplification();
            this.triggerScreenShake(6, 0.3);

            for (let i = 0; i < 30; i++) {
              this.particles.push({
                x: enemy.x + (Math.random() - 0.5) * 60,
                y: enemy.y - 25 + (Math.random() - 0.5) * 60,
                vx: (Math.random() - 0.5) * 100,
                vy: (Math.random() - 0.5) * 100,
                life: 0.8,
                maxLife: 0.8,
                size: 4,
                color: '#fbbf24',
                alpha: 0.95,
                type: 'seal',
              });
            }
          }
        } else if (enemy.skillCooldown <= 0 && effectiveDist < 220 && Math.abs(targetY - enemy.y) < 70) {
          enemy.skillCooldown = (enemy.maxSkillCooldown || 4.5) + Math.random() * 2.0;

          if (enemy.skillType === 'dash_strike') {
            // Lướt chém thần tốc
            enemy.vx = enemy.direction * 360;
            this.spawnDashDust(enemy.x, enemy.y);
            sound.playSlash();
            setTimeout(() => {
              if (enemy.hp > 0) {
                if (targetIsPlayer && Math.abs(this.player.x - enemy.x) < 75) {
                  this.takePlayerDamage(Math.round(enemy.damage * 1.3));
                } else if (targetNpc && Math.abs(targetNpc.x - enemy.x) < 75) {
                  targetNpc.hp -= Math.round(enemy.damage * 1.3);
                  targetNpc.state = 'hurt';
                  this.addDamageNumber(targetNpc.x, targetNpc.y - 30, Math.round(enemy.damage * 1.3), '#ef4444', true);
                }
              }
            }, 180);
          } else if (enemy.skillType === 'ground_slam') {
            // Dậm đất tạo sóng xung kích AoE
            this.triggerScreenShake(4, 0.25);
            for (let i = 0; i < 14; i++) {
              this.particles.push({
                x: enemy.x + (Math.random() - 0.5) * 90,
                y: enemy.y,
                vx: (Math.random() - 0.5) * 130,
                vy: -Math.random() * 90,
                life: 0.45,
                maxLife: 0.45,
                size: 3,
                color: '#e2e8f0',
                alpha: 0.9,
                type: 'dust',
              });
            }
            if (targetIsPlayer && Math.abs(this.player.x - enemy.x) < 110) {
              this.takePlayerDamage(Math.round(enemy.damage * 1.4));
              p.vy = -220;
            } else if (targetNpc && Math.abs(targetNpc.x - enemy.x) < 110) {
              targetNpc.hp -= Math.round(enemy.damage * 1.4);
              this.addDamageNumber(targetNpc.x, targetNpc.y - 30, Math.round(enemy.damage * 1.4), '#ef4444', true);
            }
          } else if (enemy.type === 'boss_chu_manh_hieu' && enemy.isPhase2) {
            // =========================================================================
            // --- CHU MẠNH HIẾU DẠNG 2: BẢN KHUYẾT TẬT (Chu Hiếu Què · Lôi Ảnh Thủ) ---
            // =========================================================================
            if (enemy.skillType === 'loi_anh_thu' || !enemy.skillType) {
              // 1. [Lôi Ảnh Thủ - Đứng Một Chân Đấm Gãy Xương]
              enemy.vx = 0;
              this.triggerScreenShake(8, 0.45);
              sound.playHitImpact(true);
              sound.playNeonShatter();
              enemy.speechBubble = "LÔI ẢNH THỦ — ĐỨNG MỘT CHÂN ĐẤM GÃY XƯƠNG!";
              enemy.speechTimer = 3.0;

              // Tia chớp sấm sét tỏa ra từ nắm tay Lôi Ảnh Thủ
              for (let i = 0; i < 28; i++) {
                this.particles.push({
                  x: enemy.x + (enemy.direction * 25) + (Math.random() - 0.5) * 50,
                  y: enemy.y - 25 + (Math.random() - 0.5) * 40,
                  vx: enemy.direction * (180 + Math.random() * 140),
                  vy: (Math.random() - 0.5) * 120,
                  life: 0.6,
                  maxLife: 0.6,
                  size: 4,
                  color: Math.random() > 0.4 ? '#38bdf8' : '#fef08a',
                  alpha: 0.95,
                  type: 'spark',
                });
              }

              if (Math.abs(p.x - enemy.x) < 200) {
                this.takePlayerDamage(Math.round(enemy.damage * 1.6));
                p.vy = -260;
                p.vx = enemy.direction * 320;
              }
              for (const n of this.currentZone.npcs) {
                if (Math.abs(n.x - enemy.x) < 200) {
                  n.hp -= Math.round(enemy.damage * 1.5);
                  n.state = 'hurt';
                  this.addDamageNumber(n.x, n.y - 40, Math.round(enemy.damage * 1.5), '#38bdf8', true);
                }
              }
              enemy.skillType = 'noc_ran_mong_cai';
            } else if (enemy.skillType === 'noc_ran_mong_cai') {
              // 2. [Nọc Nữ Thánh Rắn Móng Cái - Lôi Xà Cuồng Nộ]
              this.triggerScreenShake(10, 0.5);
              sound.playIceFreeze();
              enemy.speechBubble = "NỌC NỮ THÁNH RẮN MÓNG CÁI — ĐẠI XÀ LÔI ĐIỆN!";
              enemy.speechTimer = 3.2;

              // Quét đại xà xanh ngọc lôi điện toàn diện rộng
              for (let i = 0; i < 35; i++) {
                this.particles.push({
                  x: enemy.x + (Math.random() - 0.5) * 260,
                  y: enemy.y - 25 + (Math.random() - 0.5) * 50,
                  vx: enemy.direction * (140 + Math.random() * 180),
                  vy: -Math.random() * 100,
                  life: 0.8,
                  maxLife: 0.8,
                  size: 5,
                  color: Math.random() > 0.3 ? '#10b981' : '#34d399',
                  alpha: 0.95,
                  type: 'seal',
                });
              }

              if (Math.abs(p.x - enemy.x) < 280) {
                this.takePlayerDamage(Math.round(enemy.damage * 1.5));
              }
              for (const n of this.currentZone.npcs) {
                if (Math.abs(n.x - enemy.x) < 280) {
                  n.hp -= Math.round(enemy.damage * 1.4);
                  n.state = 'hurt';
                  this.addDamageNumber(n.x, n.y - 40, Math.round(enemy.damage * 1.4), '#10b981', true);
                }
              }
              enemy.skillType = 'coi_ao_can_3';
            } else if (enemy.skillType === 'coi_ao_can_3') {
              // 3. [Cởi Áo Cân 3 Lớp — Thầy Huỳnh Thần Quyền]
              this.triggerScreenShake(9, 0.4);
              sound.playSlash();
              enemy.speechBubble = "CỞI ÁO CÂN 3 — THẦY HUỲNH BẢO TAO SẼ LÀM ANH HÙNG!";
              enemy.speechTimer = 3.0;
              enemy.vx = enemy.direction * 420;
              this.spawnDashDust(enemy.x, enemy.y);

              setTimeout(() => {
                if (enemy.hp > 0) {
                  if (Math.abs(this.player.x - enemy.x) < 140) {
                    this.takePlayerDamage(Math.round(enemy.damage * 1.7));
                    this.triggerScreenShake(11, 0.3);
                  }
                  for (const n of this.currentZone.npcs) {
                    if (Math.abs(n.x - enemy.x) < 140) {
                      n.hp -= Math.round(enemy.damage * 1.6);
                      n.state = 'hurt';
                      this.addDamageNumber(n.x, n.y - 40, Math.round(enemy.damage * 1.6), '#ef4444', true);
                    }
                  }
                }
              }, 220);
              enemy.skillType = 'kiem_muoi_hoi_mau';
            } else if (enemy.skillType === 'kiem_muoi_hoi_mau') {
              // 4. [Liếm Muối Băng Huyết — Cái Gì Không Giết Được Tao Thì Làm Tao Mạnh Hơn]
              sound.playLevelUp();
              this.triggerScreenShake(7, 0.3);
              enemy.speechBubble = "CÁI GÌ KHÔNG GIẾT ĐƯỢC TAO THÌ LÀM TAO MẠNH HƠN!";
              enemy.speechTimer = 3.5;

              // Hồi phục 50,000 Giáp và tăng sức mạnh
              if (enemy.armor !== undefined) {
                enemy.armor = Math.min(enemy.maxArmor || 300000, enemy.armor + 50000);
                this.addDamageNumber(enemy.x, enemy.y - 60, 50000, '#38bdf8', true);
              }
              enemy.damage += 10;

              for (let i = 0; i < 30; i++) {
                this.particles.push({
                  x: enemy.x + (Math.random() - 0.5) * 90,
                  y: enemy.y - 30 + (Math.random() - 0.5) * 50,
                  vx: (Math.random() - 0.5) * 160,
                  vy: -Math.random() * 120,
                  life: 0.7,
                  maxLife: 0.7,
                  size: 4,
                  color: '#facc15',
                  alpha: 0.9,
                  type: 'spark',
                });
              }
              enemy.skillType = 'loi_anh_thu';
            }
          } else if (enemy.skillType === 'dark_wave' || enemy.type === 'boss_chu_manh_hieu') {
            // Chu Mạnh Hiếu Dạng 1: Tà Thuật Hoán Não Sóng Não AoE
            this.triggerScreenShake(7, 0.35);
            sound.playNeonShatter();
            enemy.speechBubble = "HOÁN ĐỔI LINH HỒN — VẠN KIẾP BẤT PHỤC!";
            enemy.speechTimer = 2.5;
            for (let i = 0; i < 22; i++) {
              this.particles.push({
                x: enemy.x + (Math.random() - 0.5) * 180,
                y: enemy.y - 30 + (Math.random() - 0.5) * 60,
                vx: (Math.random() - 0.5) * 160,
                vy: -Math.random() * 110,
                life: 0.7,
                maxLife: 0.7,
                size: 4,
                color: '#dc2626',
                alpha: 0.9,
                type: 'seal',
              });
            }
            if (Math.abs(p.x - enemy.x) < 220) {
              this.takePlayerDamage(Math.round(enemy.damage * 1.5));
            }
            for (const n of this.currentZone.npcs) {
              if (Math.abs(n.x - enemy.x) < 220) {
                n.hp -= 320;
                n.state = 'hurt';
                this.addDamageNumber(n.x, n.y - 40, 320, '#ef4444', true);
              }
            }
          } else if (enemy.type === 'boss_hoang_can' || enemy.skillType === 'hoang_long_tran_dia' || enemy.skillType === 'truc_phong_tram') {
            // =========================================================================
            // --- TRÚC THÁNH HOÀNG CẦN (ĐẠI CHIẾN NÓC CHỢ BÌNH LIÊU ARC 3) ---
            // =========================================================================
            if (enemy.skillType === 'hoang_long_tran_dia' || !enemy.skillType) {
              // 1. [Hoàng Long Trấn Địa — Gậy Trúc 108 Rãnh Dộng Xuống Mái Ngói]
              enemy.vx = 0;
              this.triggerScreenShake(9, 0.45);
              sound.playHitImpact(true);
              sound.playNeonShatter();
              enemy.speechBubble = "HOÀNG LONG TRẤN ĐỊA — GẬY TRÚC 108 RÃNH!";
              enemy.speechTimer = 3.0;

              // Sóng chấn động vàng kim lan tỏa trên mái ngói
              for (let i = 0; i < 28; i++) {
                this.particles.push({
                  x: enemy.x + (Math.random() - 0.5) * 220,
                  y: enemy.y,
                  vx: (Math.random() - 0.5) * 180,
                  vy: -Math.random() * 120,
                  life: 0.65,
                  maxLife: 0.65,
                  size: 4,
                  color: Math.random() > 0.4 ? '#fbbf24' : '#f59e0b',
                  alpha: 0.9,
                  type: 'spark',
                });
              }

              if (Math.abs(p.x - enemy.x) < 190) {
                this.takePlayerDamage(Math.round(enemy.damage * 1.5));
                p.vy = -260;
                p.vx = (p.x > enemy.x ? 1 : -1) * 220;
              }
              for (const n of this.currentZone.npcs) {
                if (Math.abs(n.x - enemy.x) < 190) {
                  n.hp -= Math.round(enemy.damage * 1.3);
                  n.state = 'hurt';
                  this.addDamageNumber(n.x, n.y - 40, Math.round(enemy.damage * 1.3), '#fbbf24', true);
                }
              }
              enemy.skillType = 'truc_phong_tram';
            } else if (enemy.skillType === 'truc_phong_tram') {
              // 2. [Trúc Phong Trảm — Quét Ngang Gió Rít Xanh Lục Xé Rách Màn Mưa]
              this.triggerScreenShake(7, 0.35);
              sound.playSlash();
              enemy.speechBubble = "TRÚC PHONG TRẢM — TÂM BẤT ĐỘNG, TRÚC BẤT LÙI!";
              enemy.speechTimer = 3.0;
              enemy.vx = enemy.direction * 380;
              this.spawnDashDust(enemy.x, enemy.y);

              for (let i = 0; i < 25; i++) {
                this.particles.push({
                  x: enemy.x + (Math.random() - 0.5) * 140,
                  y: enemy.y - 25 + (Math.random() - 0.5) * 40,
                  vx: enemy.direction * (160 + Math.random() * 140),
                  vy: (Math.random() - 0.5) * 90,
                  life: 0.5,
                  maxLife: 0.5,
                  size: 3.5,
                  color: '#22c55e',
                  alpha: 0.85,
                  type: 'spark',
                });
              }

              setTimeout(() => {
                if (enemy.hp > 0) {
                  if (Math.abs(this.player.x - enemy.x) < 140) {
                    this.takePlayerDamage(Math.round(enemy.damage * 1.4));
                    this.triggerScreenShake(7, 0.25);
                  }
                  for (const n of this.currentZone.npcs) {
                    if (Math.abs(n.x - enemy.x) < 140) {
                      n.hp -= Math.round(enemy.damage * 1.3);
                      n.state = 'hurt';
                      this.addDamageNumber(n.x, n.y - 40, Math.round(enemy.damage * 1.3), '#22c55e', true);
                    }
                  }
                }
              }, 180);
              enemy.skillType = 'hoang_long_tran_dia';
            }
          } else if (enemy.type === 'boss_chu_hieu_que_young' || enemy.skillType === 'loi_anh_thu_young' || enemy.skillType === 'coi_ao_can_ba') {
            // =========================================================================
            // --- CHU HIẾU QUÈ 16 TUỔI (SO TÀI 7 ĐÊM SÂN ĐÌNH LỤC NÀ ARC 4) ---
            // =========================================================================
            if (enemy.skillType === 'loi_anh_thu_young' || !enemy.skillType) {
              // 1. [Lôi Ảnh Thủ 16 Tuổi — Đứng Một Chân Đấm Thẳng Phóng Tia Sét]
              enemy.vx = 0;
              this.triggerScreenShake(6, 0.3);
              sound.playHitImpact(true);
              enemy.speechBubble = "LÔI ẢNH THỦ! ĐỨNG MỘT CHÂN ĐẤM GÃY XƯƠNG!";
              enemy.speechTimer = 2.8;

              // Tia sét xanh ngọc Nữ Thánh Rắn & vàng
              for (let i = 0; i < 22; i++) {
                this.particles.push({
                  x: enemy.x + (enemy.direction * 20) + (Math.random() - 0.5) * 40,
                  y: enemy.y - 25 + (Math.random() - 0.5) * 30,
                  vx: enemy.direction * (160 + Math.random() * 120),
                  vy: (Math.random() - 0.5) * 90,
                  life: 0.5,
                  maxLife: 0.5,
                  size: 3.5,
                  color: Math.random() > 0.4 ? '#10b981' : '#facc15',
                  alpha: 0.9,
                  type: 'spark',
                });
              }

              if (Math.abs(p.x - enemy.x) < 160) {
                this.takePlayerDamage(Math.round(enemy.damage * 1.35));
                p.vx = enemy.direction * 200;
              }
              enemy.skillType = 'coi_ao_can_ba';
            } else if (enemy.skillType === 'coi_ao_can_ba') {
              // 2. [Cởi Áo Cân Ba — Thầy Huỳnh Bảo Sẽ Làm Anh Hùng]
              this.triggerScreenShake(7, 0.3);
              sound.playSlash();
              enemy.speechBubble = "CỞI ÁO CÂN 3! THẦY HUỲNH BẢO TAO SẼ LÀM ANH HÙNG!";
              enemy.speechTimer = 2.8;
              enemy.vx = enemy.direction * 360;
              this.spawnDashDust(enemy.x, enemy.y);

              setTimeout(() => {
                if (enemy.hp > 0 && Math.abs(this.player.x - enemy.x) < 120) {
                  this.takePlayerDamage(Math.round(enemy.damage * 1.4));
                  this.triggerScreenShake(6, 0.2);
                }
              }, 180);
              enemy.skillType = 'loi_anh_thu_young';
            }
          } else if (enemy.type === 'boss_huyet_truc_tokyo_leader' || enemy.skillType === 'huyet_dao_cuong_sat') {
            // =========================================================================
            // --- THỦ LĨNH HUYẾT TRÚC TOKYO (HUYẾT ĐAO CUỒNG SÁT — ARC 5 BOSS) ---
            // =========================================================================
            this.triggerScreenShake(8, 0.4);
            sound.playSlash();
            sound.playHitImpact(true);
            enemy.speechBubble = "HUYẾT ĐAO CUỒNG SÁT — KHÔNG ĐỂ MỘT AI SỐNG SÓT!";
            enemy.speechTimer = 2.8;
            enemy.vx = enemy.direction * 380;
            this.spawnDashDust(enemy.x, enemy.y);

            // Sóng huyết khí đỏ rực bắn ra theo hướng chém
            for (let i = 0; i < 24; i++) {
              this.particles.push({
                x: enemy.x + (enemy.direction * 30) + (Math.random() - 0.5) * 40,
                y: enemy.y - 25 + (Math.random() - 0.5) * 30,
                vx: enemy.direction * (180 + Math.random() * 140),
                vy: (Math.random() - 0.5) * 80,
                life: 0.55,
                maxLife: 0.55,
                size: 4,
                color: Math.random() > 0.4 ? '#dc2626' : '#7f1d1d',
                alpha: 0.9,
                type: 'spark',
              });
            }

            setTimeout(() => {
              if (enemy.hp > 0 && Math.abs(this.player.x - enemy.x) < 150) {
                this.takePlayerDamage(Math.round(enemy.damage * 1.5));
                this.triggerScreenShake(7, 0.3);
              }
            }, 180);
          }
        }

        // Detection & Patrol AI
        if (effectiveDist < enemy.detectionRange && Math.abs(targetY - enemy.y) < 80) {
          enemy.state = 'chase';
          enemy.direction = targetX > enemy.x ? 1 : -1;

          if (effectiveDist <= enemy.attackRange) {
            enemy.state = 'attack';
            if (enemy.type === 'wolf_bien_gioi') {
              // Wolf pounces forward with claws & fangs
              enemy.vx = enemy.direction * 140;
            } else {
              enemy.vx = 0;
            }
            if (enemy.attackCooldown <= 0) {
              enemy.attackCooldown = enemy.maxAttackCooldown;
              // Telegraph & strike target
              setTimeout(() => {
                if (enemy.hp > 0) {
                  if (targetIsPlayer && Math.abs(this.player.x - enemy.x) <= enemy.attackRange + 25) {
                    this.takePlayerDamage(enemy.damage);
                    if (enemy.type === 'wolf_bien_gioi') sound.playSlash();
                    else if (enemy.type === 'boar_nanh_bac') sound.playHitImpact(true);

                    // 3 chú linh Đinh Quốc Tuấn ,ông Táy ,Hùng đỏ: 5-10% cơ chế phong ấn người chơi
                    if (enemy.type === 'spirit_tuan' || enemy.type === 'spirit_tay' || enemy.type === 'spirit_hung') {
                      if (Math.random() < 0.08) {
                        this.triggerThreeSpiritsSeal(enemy);
                      }
                    }
                  } else if (targetNpc && Math.abs(targetNpc.x - enemy.x) <= enemy.attackRange + 25) {
                    targetNpc.hp -= enemy.damage;
                    targetNpc.state = 'hurt';
                    this.addDamageNumber(targetNpc.x, targetNpc.y - 30, enemy.damage, '#ef4444');
                    this.spawnBloodSparks(targetNpc.x, targetNpc.y - 20);
                  }
                }
              }, 220);
            }
          } else {
            const chaseSpeed = enemy.isBoss ? 165 : enemy.type === 'wolf_bien_gioi' ? 140 : enemy.type === 'boar_nanh_bac' ? 115 : 85;
            enemy.vx = enemy.direction * chaseSpeed;
          }
        } else {
          // Patrol mode
          enemy.state = 'patrol';
          if (enemy.x <= enemy.patrolMinX) enemy.direction = 1;
          else if (enemy.x >= enemy.patrolMaxX) enemy.direction = -1;
          enemy.vx = enemy.direction * (enemy.isBoss ? 65 : 40);
        }

        if (enemy.attackCooldown > 0) enemy.attackCooldown -= dt;
      }

      // Quái thường và boss không được phép đi xuyên qua tường và đi ra khỏi rìa map
      // Khi gặp chướng ngại vật/tường thì nhảy lên để né chứ không đi xuyên qua tường (Requirement 20)
      const nextX = enemy.x + enemy.vx * dt;
      let blockedByWall = false;
      for (const plat of this.currentZone.platforms) {
        if (plat.type === 'solid' || (!plat.type && plat.h > 24)) {
          const enemyTop = enemy.y - enemy.h;
          const enemyBottom = enemy.y;
          const platTop = plat.y;
          const platBottom = plat.y + plat.h;
          if (enemyBottom > platTop + 4 && enemyTop < platBottom) {
            if (enemy.vx > 0 && nextX + enemy.w / 2 >= plat.x && enemy.x + enemy.w / 2 <= plat.x + 14) {
              enemy.x = plat.x - enemy.w / 2;
              enemy.vx = 0;
              blockedByWall = true;
              break;
            } else if (enemy.vx < 0 && nextX - enemy.w / 2 <= plat.x + plat.w && enemy.x - enemy.w / 2 >= plat.x + plat.w - 14) {
              enemy.x = plat.x + plat.w + enemy.w / 2;
              enemy.vx = 0;
              blockedByWall = true;
              break;
            }
          }
        }
      }

      if (blockedByWall && enemy.jumpCooldown <= 0 && enemy.jumpCount < 1) {
        enemy.vy = -480;
        enemy.jumpCount = 1;
        enemy.jumpCooldown = 1.0;
        sound.playJump();
        this.spawnDust(enemy.x, enemy.y, 6);
      } else if (!blockedByWall) {
        enemy.x = nextX;
      }

      enemy.x = Math.max(24, Math.min(this.currentZone.width - 24, enemy.x));
      enemy.y = this.getGroundYAt(enemy.x, enemy.y);
    }
  }

  /**
   * Player Takes Damage
   */
  public takePlayerDamage(damage: number) {
    const p = this.player;
    if (p.invincibleTimer > 0 || p.state === 'dead' || this.stats.isSealedInIce) return;

    // Băng Giáp reduction: -25% damage
    let finalDamage = damage;
    if (this.stats.hasBangGiap) {
      finalDamage *= 0.75;
    }

    const actualDamage = Math.max(1, Math.round(finalDamage - this.stats.defense));

    // Cơ chế mặc giáp và độ bền giáp của người chơi
    if (this.stats.armor > 0 && this.stats.armorDurability > 0) {
      // Giáp hấp thụ 75% sát thương
      const absorbed = Math.min(this.stats.armor, Math.round(actualDamage * 0.75));
      const unabsorbed = actualDamage - absorbed;
      this.stats.armor -= absorbed;
      this.stats.hp = Math.max(0, this.stats.hp - unabsorbed);

      // Độ bền giáp giảm 2 mỗi đòn đỡ
      this.stats.armorDurability -= 2;
      this.addDamageNumber(p.x, p.y - 45, absorbed, '#38bdf8', false);
      if (unabsorbed > 0) {
        this.addDamageNumber(p.x, p.y - 25, unabsorbed, '#ef4444', false);
      }

      // Kiểm tra giáp hỏng khi độ bền về 0
      if (this.stats.armorDurability <= 0) {
        this.stats.armorDurability = 0;
        this.stats.armor = 0;
        this.stats.equippedArmorName = null;
        this.stats.sealWarningText = "⚠ CHIẾN GIÁP ĐÃ BỊ VỠ HỎNG! [Armor Broken]";
        this.stats.sealWarningTimer = 3.0;
        sound.playIceFreeze();
        this.spawnIceShatter(p.x, p.y, 16);
      }
    } else {
      this.stats.hp = Math.max(0, this.stats.hp - actualDamage);
      this.addDamageNumber(p.x, p.y - 30, actualDamage, '#ef4444');
    }

    p.invincibleTimer = 0.8;
    p.state = 'hurt';
    p.vx = -p.direction * 180;
    p.vy = -120;

    this.triggerScreenShake(5, 0.2);
    sound.playHitImpact(true);

    if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);

    if (this.stats.hp <= 0) {
      if (!this.stats.hasUsedTuyếtTrắng) {
        // Trigger [Phong Ấn: Tuyết Trắng Chôn Tên]!
        this.triggerTuyetTrangChonTen();
        return;
      } else if (this.stats.ngucMonTimer <= 0) {
        // Trigger [Ngục Môn Cương: Cửa Tuyết Không Mở Lại]!
        this.triggerNgucMonCuong();
        return;
      }

      p.state = 'dead';
      this.activeScreen = 'gameover';
      if (this.callbacks.onGameOver) this.callbacks.onGameOver();
    }
  }

  /**
   * Trigger [Phong Ấn: Tuyết Trắng Chôn Tên]
   */
  public triggerTuyetTrangChonTen() {
    this.stats.hasUsedTuyếtTrắng = true;
    this.stats.isSealedInIce = true;
    this.stats.iceTombTimer = 5.0;
    this.player.state = 'sealed_tuyet_trang';
    this.player.vx = 0;
    this.player.vy = 0;

    sound.playIceFreeze();
    this.triggerScreenShake(7, 0.4);

    // Freeze all enemies within 260px
    for (const e of this.currentZone.enemies) {
      if (e.hp > 0 && Math.abs(e.x - this.player.x) < 260) {
        e.hurtTimer = 5.0;
        e.vx = 0;
      }
    }

    // Allies get [Hồi Quang]: +40% HP
    for (const npc of this.currentZone.npcs) {
      npc.hp = Math.min(npc.maxHp || 10000, (npc.hp || 10000) + 4000);
    }
  }

  /**
   * Trigger [Ngục Môn Cương: Cửa Tuyết Không Mở Lại]
   */
  public triggerNgucMonCuong() {
    this.stats.ngucMonTimer = 3.0;
    this.player.state = 'sealed_nguc_mon';
    this.player.vx = 0;
    this.player.vy = 0;
    sound.playBambooClack();
    this.triggerScreenShake(8, 0.5);
  }

  public spawnIceShatter(x: number, y: number, count: number = 18) {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: x + (Math.random() - 0.5) * 30,
        y: y - 25 + (Math.random() - 0.5) * 40,
        vx: (Math.random() - 0.5) * 220,
        vy: -Math.random() * 180,
        life: 0.6,
        maxLife: 0.6,
        size: 3 + Math.random() * 4,
        color: '#bae6fd',
        alpha: 0.9,
        type: 'ice',
      });
    }
  }

  /**
   * Three Spirits (Ba Chú Linh) coordinate their ultimate seal on Khôi
   */
  public triggerThreeSpiritsSeal(caster: Enemy) {
    if (this.stats.isSealedInIce || this.player.invincibleTimer > 0) return;

    this.stats.isSealedInIce = true;
    this.stats.iceTombTimer = 4.0;
    this.player.state = 'sealed_tuyet_trang';
    this.player.vx = 0;
    this.player.vy = 0;

    this.stats.sealWarningText = `⚠ ${caster.name.toUpperCase()} THI TRIỂN ĐẠI TRẬN PHONG ẤN! [NHẤN TẤN CÔNG / PHÁ BĂNG]`;
    this.stats.sealWarningTimer = 3.5;

    sound.playIceFreeze();
    this.triggerScreenShake(7, 0.4);

    // Spawn talisman & seal particles swarming Khôi
    for (let i = 0; i < 24; i++) {
      this.particles.push({
        x: this.player.x + (Math.random() - 0.5) * 60,
        y: this.player.y - 25 + (Math.random() - 0.5) * 50,
        vx: (Math.random() - 0.5) * 160,
        vy: -Math.random() * 120,
        life: 1.0,
        maxLife: 1.0,
        size: 4 + Math.random() * 3,
        color: Math.random() > 0.5 ? '#a855f7' : '#bae6fd',
        alpha: 0.9,
        type: 'seal',
      });
    }

    // Check if Lục Triều Dư is in the zone to assist
    const duNpc = this.currentZone.npcs.find(n => n.id.includes('du'));
    if (duNpc) {
      duNpc.speechBubble = "Khôi! Giữ vững, tao giật cáp thép phá giải trận đồ!";
      setTimeout(() => {
        if (this.stats.isSealedInIce) {
          sound.playCableStrike();
          this.breakIceSeal(true);
          duNpc.speechBubble = "Trận đồ đã nứt! Lên đi Khôi!";
          setTimeout(() => {
            duNpc.speechBubble = undefined;
          }, 2500);
        }
      }, 1500);
    }
  }

  /**
   * Break the Ice Seal (either by tapping attack / button or Dư assisting)
   */
  public breakIceSeal(fromAlly: boolean = false) {
    this.stats.isSealedInIce = false;
    this.stats.iceTombTimer = 0;
    this.player.state = 'idle';
    this.spawnIceShatter(this.player.x, this.player.y, 25);
    sound.playBambooClack();
    this.triggerScreenShake(5, 0.25);
    this.addDamageNumber(this.player.x, this.player.y - 40, 0, fromAlly ? '#38bdf8' : '#34d399', true);
  }

  /**
   * Use an item from inventory
   */
  public useItem(itemId: string) {
    const item = this.inventory.find(i => i.id === itemId);
    if (!item || item.quantity <= 0) return;

    if (itemId === 'item_lo_than_ong_tay') {
      this.stats.hp = this.stats.maxHp;
      this.stats.armor = this.stats.maxArmor;
      this.stats.hasBangGiap = true;
      item.quantity--;
      sound.playLevelUp();
      this.addDamageNumber(this.player.x, this.player.y - 45, this.stats.maxHp, '#38bdf8', true);
      this.stats.sealWarningText = '🔥 Lò Than Giữ Nhiệt Ông Táy: Hồi Phục 100% Máu & Băng Giáp (-25% Sát Thương)!';
      this.stats.sealWarningTimer = 4.0;
    } else if (itemId === 'item_ve_may_bay_tokyo') {
      sound.playLevelUp();
      this.stats.sealWarningText = '✈️ Vé Máy Bay Tokyo → Vân Đồn: Trở về Bình Liêu, hướng về Thác Khe Vằn 100 Tầng!';
      this.stats.sealWarningTimer = 4.0;
      this.switchZone('zone_thac_khe_van', 100, 440);
      return;
    } else if (item.effect === 'heal' && item.value) {
      this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + item.value);
      // Nếu là bánh mì nóng Ông Táy: hồi thêm 150 giáp và 25 độ bền
      if (item.id === 'item_banh_mi_ong_tay') {
        this.stats.armor = Math.min(this.stats.maxArmor, this.stats.armor + 150);
        this.stats.armorDurability = Math.min(100, this.stats.armorDurability + 25);
      }
      item.quantity--;
      sound.playItemGet();
      this.addDamageNumber(this.player.x, this.player.y - 40, item.value, '#22c55e', true);
    } else if (item.effect === 'qi' && item.value) {
      this.stats.qi = Math.min(this.stats.maxQi, this.stats.qi + item.value);
      item.quantity--;
      sound.playItemGet();
      this.addDamageNumber(this.player.x, this.player.y - 40, item.value, '#38bdf8', true);
    } else if (item.effect === 'buff') {
      this.player.atkBuffTimer = 45;
      item.quantity--;
      sound.playLevelUp();
      this.stats.sealWarningText = `🔥 KÍCH HOẠT ĐAN DƯỢC: +40 SÁT THƯƠNG TRONG 45 GIÂY!`;
      this.stats.sealWarningTimer = 3.5;
      this.addDamageNumber(this.player.x, this.player.y - 40, 40, '#f97316', true);
    } else if (item.effect === 'armor') {
      this.stats.armor = Math.min(this.stats.maxArmor, this.stats.armor + (item.value || 400));
      this.stats.armorDurability = 100;
      this.stats.equippedArmorName = item.name;
      item.quantity--;
      sound.playLevelUp();
      this.stats.sealWarningText = `🛡 TRANG BỊ CHIẾN GIÁP: +${item.value || 400} GIÁP, 100% ĐỘ BỀN!`;
      this.stats.sealWarningTimer = 3.5;
      this.addDamageNumber(this.player.x, this.player.y - 40, item.value || 400, '#38bdf8', true);
    } else if (item.effect === 'upgrade') {
      this.stats.upgradeShards += (item.value || 1);
      item.quantity--;
      this.upgradeWeapon();
    }

    if (item.quantity <= 0) {
      this.inventory = this.inventory.filter(i => i.id !== itemId);
    }

    if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    this.saveGame();
  }

  public upgradeWeapon(): boolean {
    if (this.stats.upgradeShards >= 2 && this.stats.weaponLevel < 10) {
      this.stats.upgradeShards -= 2;
      this.stats.weaponLevel++;
      this.stats.attackPower += 25;
      this.stats.critRate = Math.min(0.60, this.stats.critRate + 0.02);
      sound.playLevelUp();
      this.stats.sealWarningText = `⚔️ NÂNG CẤP VŨ KHÍ CẤP +${this.stats.weaponLevel}! (+25 CÔNG, +2% BẠO KÍCH)`;
      this.stats.sealWarningTimer = 3.5;
      this.triggerScreenShake(4, 0.2);
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      this.saveGame();
      return true;
    } else if (this.stats.upgradeShards < 2) {
      this.stats.sealWarningText = "⚠ CẦN TỐI THIỂU 2 MẢNH RÈN ĐỂ NÂNG CẤP VŨ KHÍ!";
      this.stats.sealWarningTimer = 2.5;
      return false;
    }
    return false;
  }

  public setWeaponElement(element: 'none' | 'ice' | 'neon' | 'lightning' | 'lifesteal') {
    this.stats.weaponElement = element;
    sound.playNeonShatter();
    const names = {
      none: 'Thuần Khiết (Không)',
      ice: 'Băng Hàn (Đóng Băng)',
      neon: 'Neon Rực Cháy (Thiêu Đốt)',
      lightning: 'Lôi Điện (Giật Sét Lan)',
      lifesteal: 'Huyết Sắc (Hút Máu 10%)',
    };
    this.stats.sealWarningText = `💎 GHÉP NGUYÊN TỐ: ${names[element].toUpperCase()}!`;
    this.stats.sealWarningTimer = 3.5;
    if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
    this.saveGame();
  }

  /**
   * Tính toán tọa độ Y mặt đất / platform chính xác dưới chân thực thể tại hoành độ x.
   * Ngăn chặn 100% lỗi NPC, quái vật hoặc vật thể bị lơ lửng trên không.
   */
  public getGroundYAt(x: number, currentY: number = 500): number {
    const margin = 6;
    const candidates = this.currentZone.platforms.filter(
      p => x >= p.x - margin && x <= p.x + p.w + margin
    );

    if (candidates.length === 0) {
      return 500;
    }

    // Ưu tiên các platform nằm ngay dưới hoặc ngang tầm chân (dung sai leo 35px)
    const under = candidates.filter(p => p.y >= currentY - 35);
    if (under.length > 0) {
      // Chọn platform có mặt phẳng cao nhất (p.y nhỏ nhất) nằm dưới thực thể
      under.sort((a, b) => a.y - b.y);
      return under[0].y;
    }

    // Nếu thực thể ở quá thấp dưới tất cả platform, lấy platform gần nhất
    candidates.sort((a, b) => Math.abs(a.y - currentY) - Math.abs(b.y - currentY));
    return candidates[0].y;
  }

  /**
   * Platform Physics Collisions (Separated X and Y)
   */
  private checkPlatformCollisionsX() {
    const p = this.player;
    for (const plat of this.currentZone.platforms) {
      if (plat.type === 'one-way') continue; // One-way platforms allow horizontal pass-through

      if (
        p.x + p.w / 2 > plat.x &&
        p.x - p.w / 2 < plat.x + plat.w &&
        p.y > plat.y + 10 &&
        p.y - p.h < plat.y + plat.h
      ) {
        if (p.vx > 0) p.x = plat.x - p.w / 2;
        else if (p.vx < 0) p.x = plat.x + plat.w + p.w / 2;
        p.vx = 0;
      }
    }
  }

  private checkPlatformCollisionsY() {
    const p = this.player;
    p.isGrounded = false;

    for (const plat of this.currentZone.platforms) {
      // One-way platforms check
      if (plat.type === 'one-way') {
        if (
          p.vy >= 0 &&
          p.x + p.w / 4 > plat.x &&
          p.x - p.w / 4 < plat.x + plat.w &&
          p.y >= plat.y &&
          p.y - p.vy * 0.05 <= plat.y + 12
        ) {
          p.y = plat.y;
          p.vy = 0;
          p.isGrounded = true;
        }
        continue;
      }

      // Solid platform check
      if (
        p.x + p.w / 4 > plat.x &&
        p.x - p.w / 4 < plat.x + plat.w &&
        p.y >= plat.y &&
        p.y - p.h <= plat.y + plat.h
      ) {
        if (p.vy > 0 && p.y - p.vy * 0.05 <= plat.y + 12) {
          p.y = plat.y;
          p.vy = 0;
          p.isGrounded = true;
        } else if (p.vy < 0) {
          p.y = plat.y + plat.h + p.h;
          p.vy = 0;
        }
      }
    }
  }

  /**
   * Check Interactive Triggers & NPCs Nearby
   */
  private checkInteractions() {
    const p = this.player;
    let foundNear: InteractiveObject | NPC | ZonePortal | null = null;
    let promptMsg: string | null = null;

    // 1. Check Portals
    for (const portal of this.currentZone.portals) {
      if (
        p.x > portal.x &&
        p.x < portal.x + portal.w &&
        p.y > portal.y &&
        p.y < portal.y + portal.h + 20
      ) {
        foundNear = portal;
        promptMsg = portal.promptText;
        if (this.input.justInteracted) {
          this.switchZone(portal.targetZoneId, portal.targetX, portal.targetY);
          return;
        }
      }
    }

    // 2. Check NPCs
    if (!foundNear) {
      for (const npc of this.currentZone.npcs) {
        const dist = Math.hypot(p.x - npc.x, p.y - npc.y);
        if (dist < 48) {
          foundNear = npc;
          promptMsg = `Trò chuyện cùng ${npc.name} [E / Nhấn]`;
          if (this.input.justInteracted) {
            // Hiển thị Speech Bubble trực tiếp ngay trong thế giới game thời gian thực (Zero intrusive modal!)
            sound.playBambooClack();
            if (npc.id === 'npc_me_ban_cau') {
              if (!this.stats.isHearthLit) {
                npc.speechBubble = "Lạnh buốt quá Thọ ơi! Mau đi nhặt 3 bó củi khô về nhóm bếp sưởi ấm chòi lá đi con!";
                this.playerSpeechBubble = "Vâng mế, cháu đi nhặt củi khô ven suối ngay đây!";
              } else if ((this.stats.beastsDefeated || 0) < (this.stats.totalBeasts || 4)) {
                npc.speechBubble = "Bầy sói đói từ rừng Lục Nà tràn xuống rồi! Thọ ơi cầm chắc gậy tre cẩn thận!";
                this.playerSpeechBubble = "Mế lùi lại sau chòi lá, để cháu đuổi bầy sói dữ!";
              } else {
                npc.speechBubble = "Ăn bát cháo ngô nóng này đi con. Cả bản Bản Cáu này là người nhà của con!";
                this.playerSpeechBubble = "Cháu cảm ơn mế và bà con! Lớn lên cháu nhất định làm thầy thuốc cứu dân!";
              }
              npc.speechTimer = 4.0;
              this.playerSpeechTimer = 4.0;
              return;
            } else if (npc.id === 'npc_cu_tho') {
              npc.speechBubble = "Mày không giết người. Mày bình người. Cần giữ người, Thọ bình người!";
              npc.speechTimer = 4.0;
              return;
            } else if (npc.id === 'npc_la_thanh') {
              npc.speechBubble = "Khôi à! Ăn bát cơm nguội trứng luộc này rồi hẵng ra tập liềm!";
              npc.speechTimer = 4.0;
              return;
            } else if (npc.id === 'npc_tai_dog') {
              npc.speechBubble = "Gâu gâu! (Đốm sủa vang canh cổng bản)";
              npc.speechTimer = 3.0;
              return;
            } else if (npc.id === 'npc_thay_huynh') {
              npc.speechBubble = "Thằng Hiếu nó lì lắm, Khôi nương tay uốn nắn nó nhé!";
              npc.speechTimer = 4.0;
              this.handleArcStoryEventTrigger('A04-E002');
              return;
            } else if (npc.id === 'npc_ong_tay_shibuya' || npc.id === 'npc_dinh_quoc_tuan_shibuya' || npc.id === 'npc_hung_do_shibuya') {
              this.handleArcStoryEventTrigger('A05-E002');
              return;
            } else if (npc.id === 'npc_ba_man') {
              npc.speechBubble = "Khôi ơi... uống bát cháo gừng nóng cho ấm bụng con nhé!";
              npc.speechTimer = 4.0;
              this.handleArcStoryEventTrigger('A08-E005');
              return;
            } else if (npc.id === 'npc_tuan_redemption') {
              npc.speechBubble = "Khôi ơi... tao sai rồi... sổ đỏ phù chú đây!";
              npc.speechTimer = 4.0;
              this.handleArcStoryEventTrigger('A08-E002');
              return;
            } else if (npc.id === 'npc_tay_redemption') {
              npc.speechBubble = "Tà hỏa tắt rồi... Khôi tha thứ cho bác nhé!";
              npc.speechTimer = 4.0;
              this.handleArcStoryEventTrigger('A08-E003');
              return;
            } else if (npc.id === 'npc_hung_redemption') {
              npc.speechBubble = "Anh Khôi... chìa khóa Rubik đây... em lạy anh!";
              npc.speechTimer = 4.0;
              this.handleArcStoryEventTrigger('A08-E004');
              return;
            } else if (npc.id === 'npc_luc_trieu_du_arc9') {
              npc.speechBubble = "Khôi! 3 năm qua mày phong ấn bảo hộ não Tài, giờ tế bào đã mục rã! Cầm cuộn cáp thép 108 nhịp này nào!";
              npc.speechTimer = 5.0;
              this.handleArcStoryEventTrigger('A09-E005');
              return;
            } else if (npc.id === 'npc_cho_dom_lang_son') {
              npc.speechBubble = "Ẳng... Gâu gâu! (Đốm ngửi thấy mùi tà khí sặc sụa dẫn sâu vào hang đá)";
              npc.speechTimer = 4.0;
              return;
            } else if (npc.id === 'npc_luc_trieu_du_nguc_mon') {
              npc.speechBubble = "Vách đá Mốc 1088 rét thấu xương... Khôi ơi, tao đã đem cáp thép 108 sợi lên kéo mày ra!";
              npc.speechTimer = 5.0;
              this.handleArcStoryEventTrigger('A10-E001');
              return;
            }

            if (this.callbacks.onDialogTrigger) {
              this.callbacks.onDialogTrigger(npc.dialogId);
            }
            return;
          }
        }
      }
    }

    // 3. Check Interactive Objects
    if (!foundNear) {
      for (const obj of this.currentZone.interactiveObjects) {
        const dist = Math.hypot(p.x - (obj.x + obj.w / 2), p.y - (obj.y - obj.h / 2));
        if (dist < 45) {
          foundNear = obj;
          promptMsg = obj.prompt;
          if (this.input.justInteracted) {
            sound.playBambooClack();
            this.handleObjectInteraction(obj);
            return;
          }
        }
      }
    }

    this.activeNearObject = foundNear;
    this.currentPrompt = promptMsg;
    if (this.callbacks.onInteractPrompt) {
      this.callbacks.onInteractPrompt(promptMsg);
    }
  }

  /**
   * Handle Shrines / Chests / Rubik / Arc 1 Story interactions
   */
  private handleObjectInteraction(obj: InteractiveObject) {
    if (obj.type === 'cong_luan_hoi_12_arc') {
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.3);
      this.playerSpeechBubble = "Cổng Luân Hồi 12 Arc — Chọn chương hồi định mệnh!";
      this.playerSpeechTimer = 4.0;
      if (this.callbacks.onOpenArcPortalModal) {
        this.callbacks.onOpenArcPortalModal();
      }
      return;
    }

    if (obj.type === 'shrine') {
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      sound.playLevelUp();
      this.addDamageNumber(this.player.x, this.player.y - 40, 100, '#4ade80');
      this.saveGame();
      return;
    }

    if (obj.type === 'rubik_gate') {
      sound.playBambooClack();
      this.triggerScreenShake(4, 0.3);
      this.unlockLoreEntry('three_spirits');
      return;
    }

    // 1. Nhặt Củi Khô Rừng Lục Nà (Gameplay tương tác thu thập A01-E001)
    if (obj.type === 'dry_wood') {
      sound.playItemGet();
      this.stats.woodCount = (this.stats.woodCount || 0) + 1;
      this.addXp(25);
      this.addDamageNumber(obj.x + 10, obj.y - 20, 25, '#facc15', true);
      // Xóa bó củi khỏi danh sách trên bản đồ để biến mất
      this.currentZone.interactiveObjects = this.currentZone.interactiveObjects.filter(o => o.id !== obj.id);

      if (this.stats.woodCount < 3) {
        this.stats.objectiveDetail = `Đã nhặt ${this.stats.woodCount}/3 bó củi khô rừng Lục Nà. Hãy tìm tiếp ven suối!`;
        this.playerSpeechBubble = "Gió bấc buốt quá... phải tìm đủ 3 bó củi về nhóm bếp than!";
        this.playerSpeechTimer = 2.8;
      } else {
        this.stats.objectiveDetail = 'Đủ 3 bó củi khô! Chạy ngay về Chòi Lá Ven Suối châm Bếp Lửa sưởi ấm!';
        this.playerSpeechBubble = "Đủ 3 bó củi rồi! Về nhóm bếp lửa sưởi ấm chòi lá thôi!";
        this.playerSpeechTimer = 3.2;
        sound.playLevelUp();
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // 2. Châm Bếp Lửa Sưởi Ấm Chòi Lá 1977
    if (obj.type === 'hearth_fire') {
      if ((this.stats.woodCount || 0) < 3) {
        this.stats.sealWarningText = '⚠️ BẾP THAN ĐANG TẮT LỊM! CẦN THU THẬP ĐỦ 3 BÓ CỦI KHÔ VEN SUỐI!';
        this.stats.sealWarningTimer = 3.0;
        this.playerSpeechBubble = "Chưa đủ củi khô, gió thổi tắt mất... phải nhặt đủ 3 bó củi!";
        this.playerSpeechTimer = 2.8;
        return;
      }

      if (!this.stats.isHearthLit) {
        this.stats.isHearthLit = true;
        obj.activated = true;
        obj.prompt = 'Bếp Lửa Đang Cháy Rực Ấm Áp 🔥';
        sound.playLevelUp();
        sound.playHoiQuang();
        this.triggerScreenShake(6, 0.35);

        // Hồi máu đầy bình
        this.stats.hp = this.stats.maxHp;
        this.addDamageNumber(this.player.x, this.player.y - 45, this.stats.maxHp, '#22c55e', true);

        // Hạt lửa bùng lên
        for (let i = 0; i < 30; i++) {
          this.particles.push({
            x: obj.x + 16,
            y: obj.y - 8,
            vx: (Math.random() - 0.5) * 80,
            vy: -Math.random() * 120 - 20,
            life: 1.0,
            maxLife: 1.0,
            size: 4,
            color: Math.random() > 0.4 ? '#f97316' : '#fef08a',
            alpha: 1,
            type: 'fire',
          });
        }

        this.playerSpeechBubble = "Lửa bùng cháy rồi! Thơm mùi khói ấm xua tan giá rét!";
        this.playerSpeechTimer = 3.5;

        // Bà Mế Bản Cáu tiếp cận và cất tiếng gọi
        const me = this.currentZone.npcs.find(n => n.id === 'npc_me_ban_cau');
        if (me) {
          me.speechBubble = "Thọ à! Khói bếp lên rồi, mế bưng bát cháo ngô nóng sang cho con đây!";
        }

        // Bầy sói và lợn rừng bị kích động mùi khói và cháo ngô, lập tức phục kích
        for (const e of this.currentZone.enemies) {
          if (e.type === 'wolf_bien_gioi' || e.type === 'boar_nanh_bac') {
            e.detectionRange = 2500;
            e.state = 'chase';
            e.speechBubble = e.type === 'wolf_bien_gioi' ? 'GRÀOOO! (Đánh hơi thấy khói)' : 'ỦN ỈN! (Lợn rừng lao tới)';
            e.speechTimer = 3.0;
          }
        }

        this.stats.objectiveTitle = 'A01-E001: Bảo Vệ Chòi Lá & Bà Mế (1977)';
        this.stats.objectiveDetail = 'BẦY DÃ THÚ BIÊN GIỚI TẬP KÍCH! Dùng Gậy Tre đánh đuổi bầy sói đói và lợn rừng (0/4)!';
        this.stats.beastsDefeated = 0;
        this.stats.totalBeasts = 4;
        this.stats.sealWarningText = '⚔️ BẦY DÃ THÚ BIÊN GIỚI ĐÃ TẬP KÍCH! HÃY CHIẾN ĐẤU BẢO VỆ CHÒI LÁ!';
        this.stats.sealWarningTimer = 4.0;
        if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
        return;
      } else {
        // Đã thắp bếp lửa rồi, sưởi ấm hồi máu
        this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + 50);
        this.addDamageNumber(this.player.x, this.player.y - 40, 50, '#22c55e');
        this.playerSpeechBubble = "Bếp lửa sưởi ấm làm hồi phục sinh lực!";
        this.playerSpeechTimer = 2.0;
        return;
      }
    }

    // 3. Mộc Nhân Tre (Luyện 500 nhát liềm - A02-E002)
    if (obj.type === 'bamboo_dummy') {
      this.stats.dummyHits = (this.stats.dummyHits || 0) + 1;
      sound.playSlash();
      this.triggerScreenShake(3, 0.15);
      this.spawnDust(obj.x + 16, obj.y - 20, 6);
      this.addDamageNumber(obj.x + 16, obj.y - 30, 35, '#84cc16');

      const currentHits = this.stats.dummyHits;
      if (currentHits < 20) {
        this.stats.objectiveDetail = `Đang khổ luyện liềm (Winter Arc 1.0): ${currentHits}/20 nhát chém!`;
        this.playerSpeechBubble = `Nhát thứ ${currentHits}/20! Tay tao sẽ không run nữa!`;
        this.playerSpeechTimer = 1.8;
      } else if (!obj.activated) {
        obj.activated = true;
        this.handleArcStoryEventTrigger('A02-E002', obj);
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // 4. Gói Cơm Nguội & Trứng Luộc 5H Sáng (A02-E003)
    if (obj.type === 'lunch_basket') {
      sound.playItemGet();
      this.addInventoryItem('item_com_trung', 2);
      this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + 250);
      this.addDamageNumber(this.player.x, this.player.y - 40, 250, '#22c55e');
      this.playerSpeechBubble = "Cơm nguội và 2 quả trứng luộc... Thanh mang tới lúc 5h sáng.";
      this.playerSpeechTimer = 3.0;
      this.currentZone.interactiveObjects = this.currentZone.interactiveObjects.filter(o => o.id !== obj.id);
      if (!this.stats.isFeverRecovered) {
        this.handleArcStoryEventTrigger('A02-E003', obj);
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // 5. Nồi Nước Lá Tía Tô Ngải Cứu Hạ Sốt 40 Độ (A02-E003)
    if (obj.type === 'medicine_pot') {
      sound.playItemGet();
      this.addInventoryItem('item_nuoc_la_tia_to', 2);
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.addDamageNumber(this.player.x, this.player.y - 40, this.stats.maxHp, '#22c55e', true);
      this.playerSpeechBubble = "Uống bát nước lá tía tô ngải cứu nóng... cơn sốt 40 độ tan biến!";
      this.playerSpeechTimer = 3.5;
      obj.activated = true;
      if (!this.stats.isFeverRecovered) {
        this.handleArcStoryEventTrigger('A02-E003', obj);
      }
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // 6. Quyết Định Dừng Lại (A02-E004)
    if (obj.type === 'sparing_choice') {
      const boss = this.currentZone.enemies.find(e => e.id === 'boss_dat_15');
      if (boss && boss.hp > 10) {
        this.stats.sealWarningText = '⚠️ HÃY ĐÁNH BẠI ĐẠT HỔ MUN TRƯỚC KHI ĐƯA RA QUYẾT ĐỊNH DỪNG LẠI!';
        this.stats.sealWarningTimer = 3.0;
        this.playerSpeechBubble = "Phải đánh bại Đạt Hổ Mun trước!";
        this.playerSpeechTimer = 2.0;
        return;
      }
      this.handleArcStoryEventTrigger('A02-E004', obj);
      return;
    }

    // 7. Nhặt Gậy Trúc Gãy Đôi (A03-E003)
    if (obj.type === 'broken_bamboo_staff') {
      const boss = this.currentZone.enemies.find(e => e.type === 'boss_hoang_can');
      if (boss && boss.hp > 1) {
        this.stats.sealWarningText = '⚠️ HÃY VƯỢT QUA TRÚC THÁNH HOÀNG CẦN TRƯỚC KHI TIẾP NHẬN TRUYỀN THỪA!';
        this.stats.sealWarningTimer = 3.0;
        this.playerSpeechBubble = "Hoàng Long Trấn Địa còn quá mạnh mẽ... Phải chém gãy gậy trong trận chiến trước!";
        this.playerSpeechTimer = 3.0;
        return;
      }
      this.handleArcStoryEventTrigger('A03-E003', obj);
      return;
    }

    // 8. Cột Mốc Biên Cương 1088 (A04-E001)
    if (obj.type === 'moc_da_1088') {
      const thugsAlive = this.currentZone.enemies.filter(e => e.type === 'bien_gioi_thug' && e.hp > 0).length;
      if (thugsAlive > 0) {
        this.stats.sealWarningText = `⚠️ CÒN ${thugsAlive} TÊN GIANG HỒ BUÔN LẬU! HÃY ĐÁNH LÙI CHÚNG BẰNG CHỮ "DỪNG"!`;
        this.stats.sealWarningTimer = 3.5;
        this.playerSpeechBubble = "Phải dẹp sạch toán buôn lậu vượt biên trước!";
        this.playerSpeechTimer = 2.5;
        return;
      }
      this.handleArcStoryEventTrigger('A04-E001', obj);
      return;
    }

    // 9. Sàn Đấu 7 Đêm Đình Lục Nà (A04-E003)
    if (obj.type === 'san_dau_7_dem') {
      const bossHiếu = this.currentZone.enemies.find(e => e.type === 'boss_chu_hieu_que_young');
      if (bossHiếu && bossHiếu.hp > 1) {
        this.stats.sealWarningText = '⚠️ CHU HIẾU QUÈ ĐANG HIẾU CHIẾN! HÃY SO TÀI LÔI ẢNH THỦ TRƯỚC KHI ĂN CƠM NGUỘI!';
        this.stats.sealWarningTimer = 3.5;
        this.playerSpeechBubble = "Hiếu đang thi triển Lôi Ảnh Thủ! Phải đỡ đòn của nó trước!";
        this.playerSpeechTimer = 2.5;
        return;
      }
      this.handleArcStoryEventTrigger('A04-E003', obj);
      return;
    }

    // 10. Dây Cáp Thép Treo Vách Đá Khe Vằn (A04-E004)
    if (obj.type === 'day_cap_khe_van') {
      this.handleArcStoryEventTrigger('A04-E004', obj);
      return;
    }

    // 11. Bàn Nhận Cuộn Tranh Chưa Giao (A04-E005)
    if (obj.type === 'cuon_tranh_altar') {
      this.handleArcStoryEventTrigger('A04-E005', obj);
      return;
    }

    // =========================================================================
    // --- ARC 5: WINTER SHIBUYA INCIDENT (2028) INTERACTIVE OBJECTS ---
    // =========================================================================

    // 12. Xe Cứu Thương 3:17AM & Vệt Băng Nứt (A05-E001)
    if (obj.type === 'xe_cuu_thuong_317') {
      sound.playNeonShatter();
      this.triggerScreenShake(6, 0.3);
      this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + 200);
      this.stats.qi = Math.min(this.stats.maxQi, this.stats.qi + 100);
      this.addDamageNumber(this.player.x, this.player.y - 40, 200, '#38bdf8');
      this.playerSpeechBubble = "Còi cứu thương 3:17 sáng... Băng Huyết Trúc đang vây bắt đồng hương!";
      this.playerSpeechTimer = 3.5;
      this.handleArcStoryEventTrigger('A05-E001', obj);
      return;
    }

    // 13. Xe Bánh Mì Lò Than Nóng Của Ông Táy (A05-E002)
    if (obj.type === 'xe_banh_mi_ong_tay') {
      sound.playItemGet();
      this.addInventoryItem('item_banh_mi_ong_tay', 2);
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.addDamageNumber(this.player.x, this.player.y - 40, this.stats.maxHp, '#f59e0b', true);
      this.playerSpeechBubble = "Bánh mì nóng hổi từ lò than của Ông Táy... Hơi ấm xua tan băng giá Tokyo!";
      this.playerSpeechTimer = 3.5;
      this.handleArcStoryEventTrigger('A05-E002', obj);
      return;
    }

    // 14. Đống Muối Tuyết Của Đinh Quốc Tuấn (A05-E002)
    if (obj.type === 'dong_muoi_dinh_quoc_tuan') {
      sound.playIceFreeze();
      this.stats.isSealedInIce = false;
      this.stats.armor = Math.min(this.stats.maxArmor, this.stats.armor + 300);
      this.addDamageNumber(this.player.x, this.player.y - 40, 300, '#38bdf8');
      this.playerSpeechBubble = "Muối tuyết của chú Tuấn rải đường sinh tử, tan sạch lớp băng đóng!";
      this.playerSpeechTimer = 3.5;
      this.handleArcStoryEventTrigger('A05-E002', obj);
      return;
    }

    // 15. Bảng Đèn Neon Gãy 109 (A05-E003)
    if (obj.type === 'bang_neon_gay_109') {
      sound.playNeonShatter();
      this.triggerScreenShake(9, 0.45);
      this.stats.neonBuffTimer = 8.0;
      this.stats.hasUsedNeonSign = true;
      this.stats.sealWarningText = '✨ BẺ BẢNG NEON 109! ĐỊCH BỊ MÙ 1.5S, KHÔI TĂNG 40% TỐC ĐÁNH!';
      this.stats.sealWarningTimer = 4.0;
      this.playerSpeechBubble = "Bảng neon gãy soi sáng đường về cho đồng bào tao!";
      this.playerSpeechTimer = 3.0;

      // Làm mù và khựng tất cả quái Huyết Trúc trong phạm vi 260px
      for (const e of this.currentZone.enemies) {
        if (e.hp > 0 && Math.abs(e.x - this.player.x) < 260) {
          e.hurtTimer = 1.5;
          this.addDamageNumber(e.x, e.y - 30, 0, '#ec4899', true);
        }
      }

      this.handleArcStoryEventTrigger('A05-E003', obj);
      return;
    }

    // 16. Điểm Bão Tuyết Phủ 109 (A05-E003)
    if (obj.type === 'tuyet_phu_109_anchor') {
      sound.playIceFreeze();
      this.stats.hasBangGiap = true;
      this.stats.stillTimer = 3.0;
      this.stats.armor = Math.min(this.stats.maxArmor, this.stats.armor + 400);
      this.stats.sealWarningText = '❄️ KÍCH HOẠT TUYẾT PHỦ 109: NHẬN BĂNG GIÁP (-25% SÁT THƯƠNG NHẬN VÀO)!';
      this.stats.sealWarningTimer = 4.0;
      this.playerSpeechBubble = "Đứng càng lâu càng lạnh, nhưng lạnh thì không ai đọc được mắt tao!";
      this.playerSpeechTimer = 3.5;
      return;
    }

    // 17. Bàn Phong Ấn Cuộn Tranh Chưa Giao (A05-E004)
    if (obj.type === 'cuon_tranh_phong_an_altar') {
      const boss = this.currentZone.enemies.find(e => e.type === 'boss_huyet_truc_tokyo_leader');
      if (boss && boss.hp > 1) {
        this.stats.sealWarningText = '⚠️ THỦ LĨNH HUYẾT TRÚC ĐANG CUỒNG SÁT! HÃY ĐÁNH BẠI HẮN TRƯỚC KHI KÍCH HOẠT PHONG BĂNG!';
        this.stats.sealWarningTimer = 3.5;
        this.playerSpeechBubble = "Phải tước vũ khí Thủ Lĩnh Huyết Trúc trước!";
        this.playerSpeechTimer = 2.5;
        return;
      }
      this.handleArcStoryEventTrigger('A05-E004', obj);
      return;
    }

    // 18. Vé Máy Bay Hồi Hương Về Thác Khe Vằn (A05-E005)
    if (obj.type === 've_may_bay_ve_khe_van') {
      this.handleArcStoryEventTrigger('A05-E005', obj);
      return;
    }

    // =========================================================================
    // --- ARC 6: CHIẾN BINH THÁC KHE VẰN (2029) INTERACTIVE OBJECTS ---
    // =========================================================================

    // 19. Hồ Nước Chân Thác Khe Vằn (A06-E001)
    if (obj.type === 'ho_nuoc_chan_thac') {
      sound.playLevelUp();
      this.triggerScreenShake(5, 0.3);
      this.stats.hasLookedIntoWater = true;
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.addDamageNumber(this.player.x, this.player.y - 45, this.stats.maxHp, '#38bdf8', true);
      this.playerSpeechBubble = "Tuyết rơi phủ hết. Nhưng vết máu này... tao không lau.";
      this.playerSpeechTimer = 4.0;
      this.handleArcStoryEventTrigger('A06-E001', obj);
      return;
    }

    // 20. Dây Cáp Thép Thác 100 Tầng Lục Triều Dư (A06-E002)
    if (obj.type === 'day_cap_thac_100_tang') {
      const remainingBeasts = this.currentZone.enemies.filter(e => (e.type === 'bao_hoa_mai_khe_van' || e.type === 'thuy_quai_khe_van') && e.hp > 0).length;
      if (remainingBeasts > 0) {
        this.stats.sealWarningText = `⚠️ CÒN ${remainingBeasts} CON BÁO HOA MAI RÌNH RẬP! HÃY DỌN SẠCH TRƯỚC KHI ĐU CÁP!`;
        this.stats.sealWarningTimer = 3.5;
        this.playerSpeechBubble = "Phải dọn sạch bầy báo hoa mai vách đá trước khi đu dây cáp thép!";
        this.playerSpeechTimer = 2.5;
        return;
      }
      sound.playCableStrike();
      this.triggerScreenShake(7, 0.35);
      this.player.vx = 450;
      this.player.vy = -350;
      this.stats.cableDuelCompleted = true;
      this.playerSpeechBubble = "Cáp thép giằng gió núi! Phe Kéo của anh Dư... kéo người ta lùi lại một bước!";
      this.playerSpeechTimer = 3.5;
      this.handleArcStoryEventTrigger('A06-E002', obj);
      return;
    }

    // 21. Điểm Treo Mình 6 Tháng Dưới Nghìn Roi Nước Đổ (A06-E003)
    if (obj.type === 'diem_treo_minh_6_thang') {
      const boss = this.currentZone.enemies.find(e => e.type === 'boss_tam_ma_shibuya');
      if (boss && boss.hp > 1) {
        boss.state = 'chase';
        boss.detectionRange = 1500;
        this.stats.sealWarningText = '⚠️ TÂM MA SHIBUYA HIỆN HÌNH! HÃY ĐÁNH BẠI ẢO ẢNH SÁT KHÍ ĐỂ TẨY RỬA TÂM TRÍ!';
        this.stats.sealWarningTimer = 4.5;
        this.playerSpeechBubble = "Tâm ma Shibuya... ảo ảnh của vết máu 2028 hiện hình! Tao sẽ chém tan mày!";
        this.playerSpeechTimer = 3.5;
        return;
      }
      this.handleArcStoryEventTrigger('A06-E003', obj);
      return;
    }

    // 22. Tảng Đá Thử Kiếm — Ngộ Khe Vằn Trảm (A06-E004)
    if (obj.type === 'tang_da_khe_van_tram') {
      if (!this.stats.tamMaDefeated) {
        this.stats.sealWarningText = '⚠️ CHƯA VƯỢT QUA 6 THÁNG TREO MÌNH VÀ TÂM MA SHIBUYA! HÃY TẨY RỬA SÁT KHÍ TRƯỚC!';
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Tâm trí chưa tịnh, nhát chém vẫn còn vướng tiếng động và sát khí...";
        this.playerSpeechTimer = 2.5;
        return;
      }
      this.handleArcStoryEventTrigger('A06-E004', obj);
      return;
    }

    // 23. Cổng Đình Bản Cáu (Tài Dog & Chó Đốm - A06-E005)
    if (obj.type === 'cong_dinh_ban_cau_arc6') {
      if (!this.stats.isKheVanTramMastered) {
        this.stats.sealWarningText = '⚠️ CHƯA NGỘ TUYỆT KỸ KHE VẰN TRẢM! HÃY LÊN THÁC KHE VẰN 100 TẦNG LUYỆN TẬP!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A06-E005', obj);
      return;
    }

    // 24. Bát Thuốc Nam Dưỡng Tim (Arc 7 - A07-E001)
    if (obj.type === 'thuoc_nam_duong_tim') {
      this.handleArcStoryEventTrigger('A07-E001', obj);
      return;
    }

    // 25. Khóm Trúc Non Tặng Tài (Arc 7 - A07-E002)
    if (obj.type === 'cay_truc_non_tang_tai') {
      if (!this.stats.hasCaredForTai) {
        this.stats.sealWarningText = '⚠️ HÃY SẮC BÁT THUỐC NAM DƯỠNG TIM CỨU TỈNH TÀI DOG Ở BẢN CÁU TRƯỚC (A07-E001)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A07-E002', obj);
      return;
    }

    // 26. Giường Bệnh Chòi Lá Mùa Đông 2065 (Arc 7 - A07-E003)
    if (obj.type === 'giuong_benh_tai_dog') {
      if (!this.stats.hasCutBambooGift) {
        this.stats.sealWarningText = '⚠️ HÃY LÊN CHÙA CỔ NGUYỆT CHẶT CÂY GẬY TRÚC NON TẶNG TÀI DOG TRƯỚC (A07-E002)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A07-E003', obj);
      return;
    }

    // 27. Két Sắt Khóa Liềm Tử Thần (Arc 7 - A07-E004)
    if (obj.type === 'ket_sat_khoa_liem') {
      if (!this.stats.hasWitnessedTaiTrangTroi) {
        this.stats.sealWarningText = '⚠️ HÃY Ở BÊN GIƯỜNG BỆNH LẮNG NGHE LỜI DẶN "CỨ GIỮ THÔI" CỦA TÀI TRƯỚC (A07-E003)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.stats.hasLockedScytheInSafe = true;
      this.stats.sealWarningText = '🔒 ĐÃ KHÓA LIỀM VÀO KÉT SẮT — THỀ NGỪNG BÌNH! HÃY QUA CỔNG LÊN ĐỒI MỘ DỖ CHÓ ĐỐM!';
      this.stats.sealWarningTimer = 5.0;
      this.playerSpeechBubble = "Cậu cất liềm rồi Tài ơi. Từ nay cậu chỉ là thằng Khôi ở Bản Cáu...";
      this.playerSpeechTimer = 4.0;
      sound.playLevelUp();
      if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
      return;
    }

    // 28. Bia Mộ Đất Tài Dog & Bát Cháo Nóng (Arc 7 - A07-E004)
    if (obj.type === 'bia_mo_tai_dog') {
      if (!this.stats.hasLockedScytheInSafe) {
        this.stats.sealWarningText = '⚠️ HÃY KHÓA LIỀM VÀO KÉT SẮT Ở ĐÌNH LỤC NÀ ĐỂ THỰC HIỆN LỜI THỀ TRƯỚC (A07-E004)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A07-E004', obj);
      return;
    }

    // 29. Chiến Tuyến Bảo Vệ Đồi Mộ (Arc 7 - A07-E005)
    if (obj.type === 'cong_dinh_canh_mo_arc7') {
      if (!this.stats.hasSavedDomAtGrave) {
        this.stats.sealWarningText = '⚠️ HÃY DỖ CHÚ CHÓ ĐỐM VÀ DÂNG BÁT CHÁO BÊN BIA MỘ TÀI TRƯỚC (A07-E004)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      const defeated = this.stats.taMonDefeated || 0;
      const total = this.stats.totalTaMon || 4;
      if (defeated < total) {
        this.stats.sealWarningText = `⚠️ CÒN ${total - defeated} TÊN ĐAO THỦ TÀ MÔN RÌNH MỘ! HÃY DÙNG QUYỀN CƯỚC ĐẨY LUI CHÚNG!`;
        this.stats.sealWarningTimer = 4.5;
        this.playerSpeechBubble = "Chúng mày dám bén mảng đến mộ cháu tao? Đừng trách tao tay không cũng bẻ gãy đao!";
        this.playerSpeechTimer = 3.5;
        return;
      }
      this.handleArcStoryEventTrigger('A07-E005', obj);
      return;
    }

    // 30. Khối Đá Rubik Ngục Môn Cương 1m³ (Arc 8 - A08-E001 & A08-E006)
    if (obj.type === 'rubik_cube_center') {
      sound.playBambooClack();
      this.triggerScreenShake(5, 0.3);
      const activeEv = arcManager.getActiveEvent();
      if (activeEv && activeEv.id === 'A08-E001') {
        this.handleArcStoryEventTrigger('A08-E001', obj);
        return;
      }
      if (activeEv && activeEv.id === 'A08-E006') {
        this.handleArcStoryEventTrigger('A08-E006', obj);
        return;
      }
      this.stats.sealWarningText = '🔔 KHỐI ĐÁ RUBIK 1M³ NGỤC MÔN CƯƠNG ĐANG GÕ 108 NHỊP! HÃY HÓA GIẢI 3 MẶT BÙA TRƯỚC!';
      this.stats.sealWarningTimer = 4.0;
      this.playerSpeechBubble = "Tiếng gõ 108 nhịp của Ngục Môn Cương... Cửa này mở một lần, vào rồi không ai kéo ra được trừ phi có duyên kỳ ngộ!";
      this.playerSpeechTimer = 4.0;
      return;
    }

    // 31. Bàn Thờ Bùa Muối Đen Đinh Quốc Tuấn (Arc 8 - A08-E002)
    if (obj.type === 'altar_muoi_den') {
      this.handleArcStoryEventTrigger('A08-E002', obj);
      return;
    }

    // 32. Vạc Than Tà Khí Ông Táy (Arc 8 - A08-E003)
    if (obj.type === 'altar_lo_than') {
      this.handleArcStoryEventTrigger('A08-E003', obj);
      return;
    }

    // 33. Ổ Khóa Dao Đỏ Hùng Đỏ (Arc 8 - A08-E004)
    if (obj.type === 'altar_dao_hung') {
      this.handleArcStoryEventTrigger('A08-E004', obj);
      return;
    }

    // 34. Bếp Than Cháo Gừng Bà Mận (Arc 8 - A08-E005)
    if (obj.type === 'bep_chao_gung') {
      this.handleArcStoryEventTrigger('A08-E005', obj);
      return;
    }

    // 35. Nấm Mộ Tài Dog Bị Đào Xới (Arc 9 - A09-E001)
    if (obj.type === 'mo_tai_bi_dao') {
      this.handleArcStoryEventTrigger('A09-E001', obj);
      return;
    }

    // 36. Bàn Mổ Hoán Não Dã Man (Arc 9 - A09-E002)
    if (obj.type === 'ban_mo_hoan_nao') {
      const defeated = this.stats.taSuDefeated || 0;
      const total = this.stats.totalTaSu || 5;
      if (defeated < total) {
        this.stats.sealWarningText = `⚠️ CÒN ${total - defeated} TÀ SƯ HOÁN NÃO BẢO VỆ! HÃY TIÊU DIỆT CHÚNG TRƯỚC!`;
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Phải quét sạch đám tà sư mổ sọ canh gác trước!";
        this.playerSpeechTimer = 3.0;
        return;
      }
      this.handleArcStoryEventTrigger('A09-E002', obj);
      return;
    }

    // 37. Đài Tế Hút Vía Tay Thép (Arc 9 - A09-E003)
    if (obj.type === 'dai_te_hut_via') {
      if (!this.stats.hieuAvatarDefeated) {
        this.stats.sealWarningText = '⚠️ HÃY ĐÁNH BẠI AVATAR CHU MẠNH HIẾU (boss_chu_manh_hieu_avatar) TRƯỚC KHI ĐẬP TAN ĐÀI TẾ!';
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Chu Mạnh Hiếu đang dùng tay thép gõ 108 nhịp bảo vệ đài tế! Phải hạ hắn trước!";
        this.playerSpeechTimer = 3.5;
        return;
      }
      this.handleArcStoryEventTrigger('A09-E003', obj);
      return;
    }

    // 38. Bàn Ký Ức Não Tài (Arc 9 - A09-E004)
    if (obj.type === 'ky_uc_nao_tai') {
      if (!this.stats.hasDestroyedOperatingTable) {
        this.stats.sealWarningText = '⚠️ HÃY PHÁ HỦY ĐÀI TẾ HÚT VÍA VÀ TƯỚC MẢNH TAY THÉP TRƯỚC (A09-E003)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A09-E004', obj);
      return;
    }

    // 39. Điểm Hẹn Cáp Thép Lục Triều Dư (Arc 9 - A09-E005)
    if (obj.type === 'diem_hen_luc_trieu_du') {
      if (!this.stats.hasTriggeredBrainRejection) {
        this.stats.sealWarningText = '⚠️ HÃY KÍCH HOẠT PHẢN PHỆ NÃO TÀI TẠI BÀN KÝ ỨC TRƯỚC (A09-E004)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A09-E005', obj);
      return;
    }

    // 40. Mỏ Neo Cáp Thép Mốc 1088 (Arc 10 - A10-E001)
    if (obj.type === 'neo_cap_thep_1' || obj.type === 'neo_cap_thep_2' || obj.type === 'neo_cap_thep_3') {
      const remainingHacDao = this.currentZone.enemies.filter(e => e.type === 'hac_dao_phong_toa' && e.hp > 0).length;
      if (remainingHacDao > 0) {
        this.stats.sealWarningText = `⚠️ CÒN ${remainingHacDao} ĐAO THỦ PHONG TỎA! HÃY TIÊU DIỆT CHÚNG TRƯỚC KHI CẮM NEO!`;
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Phải dẹp sạch đám đao thủ phục kích trước khi cắm mỏ neo cáp thép!";
        this.playerSpeechTimer = 3.0;
        return;
      }
      if (!obj.activated) {
        obj.activated = true;
        sound.playCableStrike();
        this.triggerScreenShake(6, 0.3);
        this.stats.cableAnchorsCount = (this.stats.cableAnchorsCount || 0) + 1;
        this.stats.sealWarningText = `🧗 ĐÃ CẮM MỎ NEO CÁP THÉP (${this.stats.cableAnchorsCount}/3)!`;
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = `Mỏ neo thứ ${this.stats.cableAnchorsCount} đã cắm sâu vào vách đá! Cáp thép đã căng!`;
        this.playerSpeechTimer = 3.5;
        if (this.stats.cableAnchorsCount >= 3) {
          this.handleArcStoryEventTrigger('A10-E001', obj);
        }
      }
      return;
    }

    // 41. Khối Đá Rubik 1m³ Ngục Môn Cương — 108 Nhịp (Arc 10 - A10-E003)
    if (obj.type === 'rubik_nguc_mon_cuong_108') {
      if (!this.stats.bossDaoThuDefeated) {
        this.stats.sealWarningText = '⚠️ HÃY TIÊU DIỆT TRÙM ĐAO THỦ CANH NGỤC ĐỂ ĐOẠT KHÓA CĂNG CÁP TRƯỚC (A10-E002)!';
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Trùm đao thủ đang giữ khóa căng cáp! Phải hạ gục hắn trước!";
        this.playerSpeechTimer = 3.5;
        return;
      }
      sound.playBambooClack();
      sound.playNeonShatter();
      this.triggerScreenShake(14, 0.7);
      this.stats.rubik108BeatsTriggered = true;
      this.handleArcStoryEventTrigger('A10-E003', obj);
      return;
    }

    // 42. Bình Đài Giải Thoát Khôi & Áo Phao Đen Rách (Arc 10 - A10-E004)
    if (obj.type === 'khung_khoi_phuc_sinh_luc') {
      if (!this.stats.rubik108BeatsTriggered) {
        this.stats.sealWarningText = '⚠️ HÃY GÕ ĐỦ 108 NHỊP PHÁ VỠ KHỐI ĐÁ RUBIK 1M³ TRƯỚC (A10-E003)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A10-E004', obj);
      return;
    }

    // 43. Cổng Đình Lục Nà — Hai Thằng Canh Cổng (Arc 10 - A10-E005)
    if (obj.type === 'cong_dinh_hai_thang_canh_cong') {
      const remainingDoTham = this.currentZone.enemies.filter(e => e.type === 'do_tham_ta_mon' && e.hp > 0).length;
      if (remainingDoTham > 0) {
        this.stats.sealWarningText = `⚠️ CÒN ${remainingDoTham} TRINH SÁT TÀ MÔN RÌNH MẬP! HÃY QUÉT SẠCH TRƯỚC!`;
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Toán trinh sát đang rình rập quanh đình! Phải dẹp chúng trước!";
        this.playerSpeechTimer = 3.0;
        return;
      }
      this.handleArcStoryEventTrigger('A10-E005', obj);
      return;
    }

    // 44. Rào Chắn Cổng Trường Mầm Non (Arc 11 - A11-E001)
    if (obj.type === 'rao_chan_cong_mam_non') {
      const remainingGuards = this.currentZone.enemies.filter(e => e.type === 'do_tham_ta_mon' && e.hp > 0).length;
      if (remainingGuards > 0) {
        this.stats.sealWarningText = `⚠️ CÒN ${remainingGuards} LÍNH GÁC PHONG TỎA CỔNG TRƯỜNG! HÃY DẸP CHÚNG TRƯỚC!`;
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Phải diệt sạch lính gác cổng trường trước khi phá rào chắn!";
        this.playerSpeechTimer = 3.0;
        return;
      }
      this.handleArcStoryEventTrigger('A11-E001', obj);
      return;
    }

    // 45. Cột Trụ Xích Đu Giăng Cáp Thép (Arc 11 - A11-E002)
    if (obj.type === 'cot_tru_xich_du_giang_cap') {
      if (!this.stats.mamNonGuardsDefeated || this.stats.mamNonGuardsDefeated < 3) {
        this.stats.sealWarningText = '⚠️ HÃY MỞ KHÓA RÀO CHẮN CỔNG TRƯỜNG MẦM NON TRƯỚC (A11-E001)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A11-E002', obj);
      return;
    }

    // 46. Điểm Dừng Liềm Cuối — Triết Lý DỪNG LẠI (Arc 11 - A11-E005)
    if (obj.type === 'diem_dung_liem_cuoi') {
      if (!this.stats.bossHieuPhase2Defeated) {
        this.stats.sealWarningText = '⚠️ HÃY CHIẾN ĐẤU ĐÁNH BẠI CHU HIẾU QUÈ DẠNG 2 (BẢN KHUYẾT TẬT) TRƯỚC (A11-E004)!';
        this.stats.sealWarningTimer = 4.0;
        this.playerSpeechBubble = "Chu Hiếu vẫn đang điên cuồng phóng lôi điện! Phải khuất phục hắn trước!";
        this.playerSpeechTimer = 3.5;
        return;
      }
      this.handleArcStoryEventTrigger('A11-E005', obj);
      return;
    }

    // 47. Cửa Phòng Học 20 Đứa Trẻ & Hồn Tài (Arc 11 - A11-E006)
    if (obj.type === 'cua_phong_hoc_20_tre_em') {
      if (!this.stats.hasSparedChuHieuEnding) {
        this.stats.sealWarningText = '⚠️ HÃY THỰC THI NHÁT LIỀM DỪNG LẠI TẠI ĐIỂM DỪNG LIỀM CUỐI TRƯỚC (A11-E005)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A11-E006', obj);
      return;
    }

    // 48. Thềm Đá Đình Lục Nà — Hai Thằng Canh Cổng Đón Bình Minh (Arc 11 - A11-E007)
    if (obj.type === 'them_da_hai_thang_canh_cong_ending') {
      if (!this.stats.hasRescued20Children) {
        this.stats.sealWarningText = '⚠️ HÃY GIẢI CỨU 20 ĐỨA TRẺ TẠI TRƯỜNG MẦM NON TRƯỚC KHI TRỞ VỀ ĐÌNH (A11-E006)!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      this.handleArcStoryEventTrigger('A11-E007', obj);
      return;
    }

    // --- ARC 1, ARC 2, ARC 3, ARC 4 & ARC 5 CANONICAL STORY EVENTS INTERACTION ---
    if (obj.arcEventId) {
      this.handleArcStoryEventTrigger(obj.arcEventId, obj);
      return;
    }

    // Dược thảo rừng (Ngải cứu / Tía tô)
    if (obj.type === 'herb_node') {
      sound.playItemGet();
      this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + 120);
      this.stats.qi = Math.min(this.stats.maxQi, this.stats.qi + 60);
      this.addDamageNumber(this.player.x, this.player.y - 40, 120, '#4ade80');
      this.stats.sealWarningText = '🌿 THU HÁI NGẢI CỨU RỪNG GIẢI ĐỘC (+120 MÁU, +60 NỘI LỰC)';
      this.stats.sealWarningTimer = 3.0;
      obj.activated = true;
      for (let i = 0; i < 16; i++) {
        this.particles.push({
          x: obj.x + 12,
          y: obj.y - 12,
          vx: (Math.random() - 0.5) * 80,
          vy: -Math.random() * 80,
          life: 0.6,
          maxLife: 0.6,
          size: 3,
          color: '#4ade80',
          alpha: 1,
          type: 'leaf'
        });
      }
      return;
    }

    // Mìn râu tôm dã chiến Mốc 1305
    if (obj.type === 'mine') {
      sound.playNeonShatter();
      this.triggerScreenShake(6, 0.35);
      this.stats.hp = Math.max(1, this.stats.hp - 35);
      this.addDamageNumber(this.player.x, this.player.y - 40, 35, '#ef4444', true);
      this.stats.sealWarningText = '⚠️ GIẪM PHẢI MÌN RÂU TÔM DÃ CHIẾN! (-35 MÁU)';
      this.stats.sealWarningTimer = 3.0;
      for (let i = 0; i < 20; i++) {
        this.particles.push({
          x: obj.x + 8,
          y: obj.y - 6,
          vx: (Math.random() - 0.5) * 140,
          vy: -Math.random() * 120,
          life: 0.5,
          maxLife: 0.5,
          size: 4,
          color: '#ef4444',
          alpha: 1,
          type: 'fire'
        });
      }
      return;
    }

    // Chiến sĩ biên phòng bị thương tại Mốc 1305
    if (obj.type === 'wounded_soldier') {
      if (!obj.activated) {
        obj.activated = true;
        obj.prompt = '✓ Đã đưa vào hầm an toàn';
        sound.playLevelUp();
        this.addXp(60);
        this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + 150);
        this.addDamageNumber(obj.x + 10, obj.y - 30, 60, '#facc15', true);
        this.stats.sealWarningText = '🎖 ĐÃ BĂNG BÓ VÀ ĐƯA THƯƠNG BINH VÀO HẦM AN TOÀN (+60 EXP)!';
        this.stats.sealWarningTimer = 2.8;
      }
      return;
    }
  }

  /**
   * Kích hoạt và xử lý sự kiện Arc 1 (Đối chiếu mã sự kiện A01-E001 -> A01-E005)
   */
  public handleArcStoryEventTrigger(eventId: string, obj?: InteractiveObject) {
    const ev = arcManager.getEvent(eventId);
    if (!ev) return;

    if (eventId === 'A01-E001') {
      // Đứa trẻ mồ côi Bản Cáu (1970 - 1977)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a01_e001');
      arcManager.advanceEvent('A01-E001');
      this.addXp(120);
      this.addInventoryItem('item_bat_chao_ngo');
      this.stats.sealWarningText = '📜 HOÀN THÀNH SỰ KIỆN [A01-E001]: ĐỨA TRẺ MỒ CÔI BẢN CÁU (+120 EXP)!';
      this.stats.sealWarningTimer = 4.0;
      sound.playLevelUp();
      if (obj) obj.activated = true;
    } else if (eventId === 'A01-E002') {
      // Cơ duyên y thư Nam Dược Thần Hiệu (1982)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a01_e002');
      arcManager.advanceEvent('A01-E002');
      this.addXp(180);
      this.addInventoryItem('item_nam_duoc_than_hieu');
      this.addInventoryItem('item_la_ngai_cuu');
      this.stats.sealWarningText = '📜 HOÀN THÀNH SỰ KIỆN [A01-E002]: Y THƯ NAM DƯỢC THẦN HIỆU (+180 EXP)!';
      this.stats.sealWarningTimer = 4.0;
      sound.playLevelUp();
      if (obj) obj.activated = true;
    } else if (eventId === 'A01-E003') {
      // Chiến hào Mốc 1305 & Mất chân trái (1987)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a01_e003_finish');
      arcManager.advanceEvent('A01-E003');
      this.addXp(300);
      this.addInventoryItem('item_hom_thuoc_moc_1305');
      this.stats.sealWarningText = '📜 HOÀN THÀNH SỰ KIỆN [A01-E003]: HÒM THUỐC DÃ CHIẾN MỐC 1305 (+300 EXP)!';
      this.stats.sealWarningTimer = 4.0;
      sound.playLevelUp();
      if (obj) obj.activated = true;
    } else if (eventId === 'A01-E004') {
      // Lều tre Đình Lục Nà & Gậy 108 Rãnh (1995)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a01_e004');
      arcManager.advanceEvent('A01-E004');
      this.addXp(350);
      this.addInventoryItem('item_gay_108_ranh');
      this.stats.sealWarningText = '📜 HOÀN THÀNH SỰ KIỆN [A01-E004]: HOÀNG CẦN TRAO GẬY 108 RÃNH (+350 EXP)!';
      this.stats.sealWarningTimer = 4.0;
      sound.playLevelUp();
      if (obj) obj.activated = true;
    } else if (eventId === 'A01-E005') {
      // Rửa máu nước lá tía tô & Khai sinh chữ Bình (Kết thúc Arc 1 -> Mở khóa Arc 2)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a01_e005');
      arcManager.advanceEvent('A01-E005');
      this.completeQuest('quest_arc1');
      this.activateQuest('quest_arc2');
      arcManager.advanceArc(2);
      this.stats.currentArc = 2;
      this.stats.arcTitle = 'Arc 2: Thằng Nhóc Bị Bắt Nạt (Winter Arc 1.0)';
      this.stats.objectiveTitle = 'A02-E001: Bị Bắt Nạt Tại Sân Trường & Ngõ Cũ (2012)';
      this.stats.objectiveDetail = 'Khôi 12 tuổi bị đám Đạt Hổ Mun chặn đường đòi tiền và đánh gãy sống mũi. Hãy tiến vào Cổng Ngõ Cũ chiến đấu!';
      this.addXp(500);
      this.addInventoryItem('item_nuoc_la_tia_to');
      this.unlockLoreEntry('char_tho');
      this.unlockLoreEntry('char_can');
      this.unlockLoreEntry('loc_ban_cau');
      this.stats.sealWarningText = '🏆 HOÀN THÀNH ARC 1 → MỞ KHÓA ARC 2: THẰNG NHÓC BỊ BẮT NẠT (WINTER ARC 1.0)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A02-E001') {
      // Bị bắt nạt tại sân trường & ngõ cũ (2012)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a02_e001');
      arcManager.advanceEvent('A02-E001');
      this.addXp(200);
      this.stats.sealWarningText = '📜 HOÀN THÀNH SỰ KIỆN [A02-E001]: BỊ BẮT NẠT TẠI NGÕ CŨ (+200 EXP)!';
      this.stats.sealWarningTimer = 4.0;
      this.stats.objectiveTitle = 'A02-E002: Dựng Chòi Lá & 500 Nhát Liềm (Winter Arc 1.0)';
      this.stats.objectiveDetail = 'Chạy qua cổng bên phải tới Chòi Lá Ngoại Ô, tương tác Mộc Nhân Tre và chém đủ 20 nhát luyện liềm!';
      sound.playLevelUp();
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A02-E002') {
      // Dựng chòi lá & 500 nhát liềm khổ luyện
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a02_e002');
      arcManager.advanceEvent('A02-E002');
      this.addXp(300);
      this.stats.attackPower += 20;
      this.stats.critRate = Math.min(0.60, this.stats.critRate + 0.05);
      this.addInventoryItem('item_dan_duoc_tang_luc');
      this.stats.sealWarningText = '⚔️ HOÀN THÀNH [A02-E002]: 500 NHÁT LIỀM KHỔ LUYỆN (+300 EXP, +20 CÔNG)!';
      this.stats.sealWarningTimer = 4.5;
      this.stats.objectiveTitle = 'A02-E003: Cơm Nguội 5H Sáng & Đêm Mưa Sốt 40 Độ';
      this.stats.objectiveDetail = 'Khôi kiệt sức sốt 40 độ trong đêm mưa! Hãy tương tác La Thanh hoặc Nồi Thuốc uống nước lá tía tô hạ sốt!';
      sound.playLevelUp();
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A02-E003') {
      // Cơm nguội 5h sáng & Đêm mưa sốt 40 độ
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a02_e003');
      arcManager.advanceEvent('A02-E003');
      this.addXp(350);
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.stats.isFeverRecovered = true;
      this.addInventoryItem('item_com_trung', 2);
      this.addInventoryItem('item_nuoc_la_tia_to', 2);
      this.stats.sealWarningText = '🌿 HOÀN THÀNH [A02-E003]: LA THANH NẤU NƯỚC LÁ TÍA TÔ CỨU SỐT 40 ĐỘ (+350 EXP)!';
      this.stats.sealWarningTimer = 4.5;
      this.stats.objectiveTitle = 'A02-E004: Trận Chiến Chòi Lá — Quyết Định Dừng Lại';
      this.stats.objectiveDetail = 'Đám Đạt Hổ Mun 15 tuổi kéo tới phá chòi! Đánh bại Đạt Hổ Mun và đưa ra quyết định DỪNG LẠI!';
      sound.playLevelUp();
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A02-E004') {
      // Quyết định Dừng Lại (Khởi sinh Bình Liêu Vương) -> Hoàn thành Arc 2 và MỞ KHÓA ARC 3!
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a02_e004_win');
      arcManager.advanceEvent('A02-E004');
      this.completeQuest('quest_arc2');
      this.activateQuest('quest_arc3');
      arcManager.advanceArc(3);
      this.stats.currentArc = 3;
      this.stats.arcTitle = 'Arc 3: Trận Thầy Trò / Đêm Giết Thầy (2017)';
      this.stats.objectiveTitle = 'A03-E001: Lời Mời Lên Nóc Chợ Bình Liêu (2017)';
      this.stats.objectiveDetail = 'Vào lúc nửa đêm mưa to gió bão tháng 11/2017, Khôi 17 tuổi cầm liềm leo lên Nóc Chợ Bình Liêu đối mặt Trúc Thánh Hoàng Cần!';
      this.addXp(500);
      this.stats.hasSparedBully = true;
      this.addInventoryItem('item_liem_tu_than');
      this.unlockLoreEntry('char_khoi');
      this.unlockLoreEntry('char_thanh');
      this.stats.sealWarningText = '🏆 HOÀN THÀNH ARC 2 → MỞ KHÓA ARC 3: TRẬN THẦY TRÒ / ĐÊM GIẾT THẦY!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A03-E001') {
      // Lời mời lên Nóc Chợ Bình Liêu (Tháng 11/2017 - Nửa đêm giông bão)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a03_e001');
      arcManager.advanceEvent('A03-E001');
      this.addXp(350);
      this.stats.objectiveTitle = 'A03-E002: Trận Chiến Nóc Chợ Giông Bão';
      this.stats.objectiveDetail = 'Gậy Trúc Hoàng Long vs Liềm Tử Thần! Vượt qua các chiêu thức Hoàng Long Trấn Địa và Trúc Phong Trảm của Hoàng Cần!';
      this.stats.sealWarningText = '⚡ TRẬN CHIẾN THƯỢNG ĐỈNH BẮT ĐẦU: TRÚC THÁNH HOÀNG CẦN VS HOÀNG MINH KHÔI!';
      this.stats.sealWarningTimer = 5.0;
      sound.playNeonShatter();
      this.triggerScreenShake(8, 0.45);

      // Đánh thức Hoàng Cần vào trạng thái chiến đấu
      const boss = this.currentZone.enemies.find(e => e.type === 'boss_hoang_can');
      if (boss) {
        boss.state = 'chase';
        boss.detectionRange = 3000;
        boss.speechBubble = 'Vào trận đi Khôi! Để ta xem 500 nhát liềm mỗi ngày của con sắc bén đến đâu!';
        boss.speechTimer = 5.0;
      }
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A03-E002') {
      // Trận chiến Nóc Chợ giông bão — Đã hạ gục Hoàng Cần
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a03_e002');
      arcManager.advanceEvent('A03-E002');
      this.addXp(500);
      this.stats.objectiveTitle = 'A03-E003: Chém Gãy Gậy Trúc Hoàng Long';
      this.stats.objectiveDetail = 'Tiến lại gần nhặt hai đoạn Gậy Trúc gãy đôi trên mái ngói Nóc Chợ để tiếp nhận truyền thừa nhánh Bình!';
      this.stats.sealWarningText = '🎋 HOÀNG CẦN ĐÃ HẠ GẬY! HÃY NHẶT NỬA GẬY TRÚC GÃY ĐÔI (A03-E003)!';
      this.stats.sealWarningTimer = 5.0;
      sound.playLevelUp();
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A03-E003') {
      // Chém gãy gậy trúc Hoàng Long (Lưỡi liềm sứt mẻ 1 vết nhỏ)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a03_e003');
      arcManager.advanceEvent('A03-E003');
      this.addXp(600);
      this.stats.hasBrokenStaff = true;
      this.addInventoryItem('item_manh_gay_truc_hoang_long');
      this.stats.objectiveTitle = 'A03-E004: Mộ Trúc 7 Cây & Nước Tía Tô Rửa Máu';
      this.stats.objectiveDetail = 'Đi qua cổng bên phải tới Chùa Cổ Nguyệt, viếng Mộ Trúc 7 Cây để Cụ Thọ dùng nước tía tô rửa máu khai sinh Bình Liêu Vương!';
      this.stats.sealWarningText = '🎋 ĐÃ THU NHẬN NỬA GẬY TRÚC GÃY ĐÔI! TIẾN VỀ CHÙA CỔ NGUYỆT (A03-E004)!';
      this.stats.sealWarningTimer = 5.5;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.35);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A03-E004') {
      // Rửa máu bằng nước lá tía tô & Khai sinh "Bình Liêu Vương"
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a03_e004');
      arcManager.advanceEvent('A03-E004');
      this.addXp(800);
      this.stats.isStaffPreserved = true;
      this.addInventoryItem('item_vai_do_boc_gay');
      this.unlockLoreEntry('char_can');
      this.unlockLoreEntry('char_tho');
      this.stats.objectiveTitle = 'A03-E005: Tiết Toán Lớp 12A2 — Chữ "DỪNG" Tuổi 18';
      this.stats.objectiveDetail = 'Sáng hôm sau, qua cổng phía đông về lớp 12A2 trường THPT Bình Liêu, ngồi vào bàn học tiết Toán hoàn thành Arc 3!';
      this.stats.sealWarningText = '👑 KHAI SINH HOÀNG MINH BÌNH KHÔI — BÌNH LIÊU VƯƠNG! VỀ LỚP HỌC 12A2 (A03-E005)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A03-E005') {
      // Tiết Toán lớp 12A2 sáng hôm sau (Vị vua trẻ tuổi ngủ gật trên bàn học)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a03_e005');
      arcManager.advanceEvent('A03-E005');
      this.completeQuest('quest_arc3');
      this.stats.mathClassVisited = true;
      this.stats.arc3Completed = true;
      this.addInventoryItem('item_so_tay_toan_12a2');
      this.addXp(1000);
      this.unlockLoreEntry('char_khoi');
      this.unlockLoreEntry('char_can');
      this.unlockLoreEntry('loc_chua_co_nguyet');

      // Mở khóa chuẩn bị Arc 4 (Cai quản trật tự biên giới tuổi 18)
      arcManager.advanceArc(4);
      this.stats.currentArc = 4;
      this.stats.arcTitle = 'Arc 4: Bình Liêu Vương Tuổi 18 (Biên Giới Trật Tự)';
      this.stats.objectiveTitle = 'A04-E001: Tuần Tra Mốc 1088 — Chữ "DỪNG" Tuổi 18';
      this.stats.objectiveDetail = 'Tiến lên đỉnh Mốc Biên Cương 1088, đánh bại 4 tên giang hồ biên giới và tương tác Mốc Đá 1088 để khẳng định chữ DỪNG!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 3: TRẬN THẦY TRÒ / ĐÊM GIẾT THẦY → BƯỚC SANG ARC 4!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.5);
      if (obj) obj.activated = true;
      this.activateQuest('quest_arc4');
      this.saveGame();
    } else if (eventId === 'A04-E001') {
      // Tuần tra Mốc 1088, chặn đứng toán giang hồ bằng chữ DỪNG
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a04_e001');
      arcManager.advanceEvent('A04-E001');
      this.addXp(400);
      this.addInventoryItem('item_khan_trang_lau_liem');
      this.stats.objectiveTitle = 'A04-E002: Thầy Huỳnh Dẫn Chu Hiếu Què Xuống Bản Cáu';
      this.stats.objectiveDetail = 'Rời Mốc 1088 qua cổng bên phải tới Sân Đình Lục Nà gặp Thầy Huỳnh và thiếu niên Chu Mạnh Hiếu 16 tuổi!';
      this.stats.sealWarningText = '⚔️ ĐÃ KHẲNG ĐỊNH CHỮ "DỪNG" TẠI MỐC 1088! VỀ SÂN ĐÌNH LỤC NÀ (A04-E002)!';
      this.stats.sealWarningTimer = 5.5;
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.35);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A04-E002') {
      // Thầy Huỳnh đưa Chu Hiếu Què 16 tuổi xuống Bản Cáu gặp Cụ Thọ
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a04_e002');
      arcManager.advanceEvent('A04-E002');
      this.addXp(450);
      this.addInventoryItem('item_ao_sat_nach_thay_huynh');
      // Đánh thức boss Hiếu Què vào trạng thái khiêu chiến
      const bossHiếu = this.currentZone.enemies.find(e => e.type === 'boss_chu_hieu_que_young');
      if (bossHiếu) {
        bossHiếu.state = 'chase';
        bossHiếu.speechBubble = 'LÔI ẢNH THỦ! ĐỨNG MỘT CHÂN ĐẤM GÃY XƯƠNG! XÔNG VÀO ĐÂY ANH KHÔI!';
        bossHiếu.speechTimer = 5.0;
      }
      this.stats.objectiveTitle = 'A04-E003: Trận So Tài 7 Đêm Tại Sân Đình (Khôi vs Chu Hiếu Què)';
      this.stats.objectiveDetail = 'Giao đấu thực tế cùng Boss Chu Hiếu Què (Lôi Ảnh Thủ) trên sân đình, đánh đến khi Hiếu phục rồi tương tác Sàn Đấu 7 Đêm!';
      this.stats.sealWarningText = '⚡ CHU HIẾU QUÈ KHIÊU CHIẾN! VÀO SÀN ĐẤU SO TÀI 7 ĐÊM (A04-E003)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A04-E003') {
      // Kết thúc 7 đêm so tài, ngồi ăn cơm nguội trứng luộc và tâm sự
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a04_e003');
      arcManager.advanceEvent('A04-E003');
      this.addXp(600);
      this.addInventoryItem('item_com_trung', 3);
      this.unlockLoreEntry('char_hieu');
      this.stats.sevenNightsDuelCompleted = true;
      this.stats.objectiveTitle = 'A04-E004: Vách Đá Thác Khe Vằn & Thằng Treo Dây Lục Triều Dư';
      this.stats.objectiveDetail = 'Rời Sân Đình Lục Nà, qua cổng phía đông lên Thác Khe Vằn (Mốc 1088), tương tác Dây Cáp Thép cùng Lục Triều Dư!';
      this.stats.sealWarningText = '🍚 ĐÃ KẾT NGHĨA ANH EM CÙNG HIẾU QUÈ! TIẾN LÊN VÁCH ĐÁ KHE VẰN (A04-E004)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A04-E004') {
      // Vách đá Khe Vằn: Thằng Treo Dây Lục Triều Dư rèn thân pháp & triết lý phe Kéo
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a04_e004');
      arcManager.advanceEvent('A04-E004');
      this.addXp(500);
      this.unlockLoreEntry('char_du');
      this.stats.cableClimbMastered = true;
      this.stats.objectiveTitle = 'A04-E005: Nhận Mệnh "Cuộn Tranh Chưa Giao" — Khởi Hành Đi Shibuya';
      this.stats.objectiveDetail = 'Trở về Bản Cáu, tới Bàn Nhận Tranh gặp Cụ Thọ và La Thanh nhận Cuộn Tranh Chưa Giao trước giờ lên đường!';
      this.stats.sealWarningText = '🧗 VƯỢT THỬ THÁCH ĐU DÂY KHE VẰN CÙNG LỤC TRIỀU DƯ! VỀ BẢN CÁU NHẬN TRANH (A04-E005)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A04-E005') {
      // Cụ Thọ và La Thanh trao "Cuộn Tranh Chưa Giao" — Khởi hành đi Shibuya (Arc 5)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a04_e005');
      arcManager.advanceEvent('A04-E005');
      this.completeQuest('quest_arc4');
      this.stats.hasCuonTranhChuaGiao = true;
      this.stats.arc4Completed = true;
      this.addInventoryItem('item_cuon_tranh_chua_giao');
      this.addXp(1000);
      this.unlockLoreEntry('char_khoi');
      this.unlockLoreEntry('char_tho');
      this.unlockLoreEntry('char_thanh');

      // Chuyển giao sang Arc 5: Winter Shibuya Incident (2028)
      arcManager.advanceArc(5);
      this.stats.currentArc = 5;
      this.stats.arcTitle = 'Arc 5: Winter Shibuya Incident (2028)';
      this.stats.objectiveTitle = 'A05-E001: Ngã Tư Shibuya 109 — Tuyết Trắng & Tiếng Còi 3:17AM';
      this.stats.objectiveDetail = 'Tiến vào Ngã Tư Shibuya 109, tiếp cận hiện trường Xe Cứu Thương 3:17AM để nắm bắt tình hình bạo loạn của băng Huyết Trúc!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 4: BÌNH LIÊU VƯƠNG TUỔI 18 → MỞ KHÓA ARC 5: WINTER SHIBUYA INCIDENT (2028)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(9, 0.5);
      if (obj) obj.activated = true;
      this.activateQuest('quest_arc5');
      this.switchZone('zone_shibuya_crosswalk_109', 100, 440);
      this.saveGame();
    } else if (eventId === 'A05-E001') {
      // Ngã Tư Shibuya 109 — Tuyết Trắng & Tiếng Còi 3:17AM
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a05_e001');
      arcManager.advanceEvent('A05-E001');
      this.addXp(400);
      this.stats.hasVisitedAmbulance = true;
      this.stats.objectiveTitle = 'A05-E002: Ba Chú Linh Tokyo — Bánh Mì Lò Than & Xe Quét Muối';
      this.stats.objectiveDetail = 'Gặp gỡ Ba Chú Linh (Đinh Quốc Tuấn, Ông Táy, Hùng Đỏ) tại góc phố đi bộ, tiếp nhận bánh mì nóng và muối tuyết!';
      this.stats.sealWarningText = '🚑 TIẾP CẬN XE CỨU THƯƠNG 3:17AM! GẶP BA CHÚ LINH TIẾP TẾ (A05-E002)!';
      this.stats.sealWarningTimer = 5.5;
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.35);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A05-E002') {
      // Ba Chú Linh Tokyo: Đinh Quốc Tuấn, Ông Táy, Hùng Đỏ tiếp tế
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a05_e002');
      arcManager.advanceEvent('A05-E002');
      this.addXp(450);
      this.addInventoryItem('item_lo_than_ong_tay', 2);
      this.addInventoryItem('item_banh_mi_ong_tay', 2);
      this.unlockLoreEntry('three_spirits');
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.stats.objectiveTitle = 'A05-E003: Trận Chiến Cầu Vượt Đêm 25/12 — Băng Dưới Đèn Neon';
      this.stats.objectiveDetail = 'Qua cổng phía đông lên Cầu Vượt Shibuya, bẻ Bảng Neon Gãy và đánh gục 6 tên đao thủ Huyết Trúc trong 7 phút!';
      this.stats.sealWarningText = '🥖 ĐÃ NHẬN TIẾP TẾ BA CHÚ LINH! LÊN CẦU VƯỢT DẸP BĂNG HUYẾT TRÚC (A05-E003)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A05-E003') {
      // Trận Chiến Cầu Vượt Đêm 25/12 — Băng Dưới Đèn Neon
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a05_e003');
      arcManager.advanceEvent('A05-E003');
      this.addXp(650);
      this.stats.hasUsedNeonSign = true;
      this.stats.neonBuffTimer = 10.0;
      this.stats.hasBangGiap = true;
      this.stats.objectiveTitle = 'A05-E004: Đại Chiến Thủ Lĩnh Huyết Trúc & Tuyết Trắng Chôn Tên';
      this.stats.objectiveDetail = 'Tiến lên đỉnh Cầu Vượt Shibuya, đánh bại Boss Thủ Lĩnh Huyết Trúc và đâm Cuộn Tranh kích hoạt Tuyết Trắng Chôn Tên!';
      this.stats.sealWarningText = '✨ NEON GÃY SOI SÁNG BÃI TUYẾT! ĐỐI ĐẦU BOSS THỦ LĨNH HUYẾT TRÚC (A05-E004)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A05-E004') {
      // Đại Chiến Thủ Lĩnh Huyết Trúc & Tuyết Trắng Chôn Tên
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a05_e004');
      arcManager.advanceEvent('A05-E004');
      this.addXp(850);
      this.unlockLoreEntry('seal_tuyet_trang');
      this.unlockLoreEntry('shibuya_arc');
      this.triggerTuyetTrangChonTen();
      this.stats.shibuyaBossDefeated = true;
      this.stats.hasButBang = true;
      this.stats.objectiveTitle = 'A05-E005: Biệt Danh "Khe Vằn Tử Thần" — Hồi Hương Về Thác 100 Tầng';
      this.stats.objectiveDetail = 'Giải cứu thành công toàn bộ con tin! Nhận vé máy bay và vali hồi hương trở về Bình Liêu lên Thác Khe Vằn (Arc 6)!';
      this.stats.sealWarningText = '❄️ ĐÃ KÍCH HOẠT TUYẾT TRẮNG CHÔN TÊN! GIẢI CỨU CON TIN & HỒI HƯƠNG (A05-E005)!';
      this.stats.sealWarningTimer = 6.5;
      sound.playLevelUp();
      this.triggerScreenShake(9, 0.5);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A05-E005') {
      // Biệt Danh "Khe Vằn Tử Thần" — Hồi Hương Về Thác 100 Tầng (Mở Đầu Arc 6)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a05_e005');
      arcManager.advanceEvent('A05-E005');
      this.completeQuest('quest_arc5');
      this.stats.hasReceivedShibuyaTitle = true;
      this.stats.arc5Completed = true;
      this.addInventoryItem('item_ve_may_bay_tokyo');
      this.addXp(1000);
      this.unlockLoreEntry('loc_khe_van');

      // Chuyển giao sang Arc 6: Chiến Binh Thác Khe Vằn
      arcManager.advanceArc(6);
      this.stats.currentArc = 6;
      this.stats.arcTitle = 'Arc 6: Chiến Binh Thác Khe Vằn (Tẩy Rửa Sát Khí)';
      this.stats.objectiveTitle = 'A06-E001: Hồi Hương Thác Khe Vằn — Vệt Máu Trong Mắt (2029)';
      this.stats.objectiveDetail = 'Khôi trở về Bình Liêu, tiến lên Thác Khe Vằn 100 tầng, soi bóng đáy hồ chân thác để đối diện tia máu trong mắt!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 5: WINTER SHIBUYA INCIDENT (2028) → MỞ KHÓA ARC 6: CHIẾN BINH THÁC KHE VẰN!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(9, 0.5);
      if (obj) obj.activated = true;
      this.activateQuest('quest_arc6');
      this.switchZone('zone_thac_khe_van', 100, 440);
      this.saveGame();
    } else if (eventId === 'A06-E001') {
      // Hồi Hương Thác Khe Vằn — Vệt Máu Trong Mắt (2029)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a06_e001');
      arcManager.advanceEvent('A06-E001');
      this.addXp(500);
      this.stats.hasLookedIntoWater = true;
      this.stats.objectiveTitle = 'A06-E002: Vách Đá 100 Tầng — Thử Thách Cáp Thép Cùng Lục Triều Dư';
      this.stats.objectiveDetail = 'Dọn dẹp bầy báo hoa mai vách đá (0/4), tiến lại giàn Cáp Thép 100 Tầng so tài giằng cáp cùng Lục Triều Dư!';
      this.stats.sealWarningText = '🌊 ĐỐI DIỆN VẾT MÁU SHIBUYA DƯỚI LÒNG HỒ! LÊN VÁCH ĐÁ 100 TẦNG GẶP ANH DƯ (A06-E002)!';
      this.stats.sealWarningTimer = 5.5;
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.35);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A06-E002') {
      // Vách Đá 100 Tầng — Thử Thách Cáp Thép Cùng Lục Triều Dư
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a06_e002');
      arcManager.advanceEvent('A06-E002');
      this.addXp(600);
      this.stats.cableDuelCompleted = true;
      this.unlockLoreEntry('char_du');
      this.stats.objectiveTitle = 'A06-E003: 6 Tháng Treo Mình Dưới Nghìn Roi Nước Đổ — Quyết Đấu Tâm Ma Shibuya';
      this.stats.objectiveDetail = 'Tiến vào Điểm Treo Mình giữa thác nước gầm thét, đánh bại Boss Tâm Ma Shibuya để gột sạch sát khí tâm can!';
      this.stats.sealWarningText = '🧗 ĐÃ VƯỢT THỬ THÁCH CÁP THÉP! TREO MÌNH DƯỚI NGHÌN ROI NƯỚC ĐỔ ĐÁNH TÂM MA (A06-E003)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A06-E003') {
      // 6 Tháng Treo Mình Dưới Nghìn Roi Nước Đổ — Quyết Đấu Tâm Ma Shibuya
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a06_e003');
      arcManager.advanceEvent('A06-E003');
      this.addXp(800);
      this.stats.isTreoMinhCompleted = true;
      this.stats.tamMaDefeated = true;
      this.stats.objectiveTitle = 'A06-E004: Ngộ Ra Tuyệt Kỹ "Khe Vằn Trảm" (Đường Liềm Vô Ảnh)';
      this.stats.objectiveDetail = 'Tiến lại Tảng Đá Khe Vằn Trảm phẳng lì giữa dòng suối, vung liềm chém đôi tảng đá không tiếng động để ngộ tuyệt kỹ!';
      this.stats.sealWarningText = '✨ TÂM MA SHIBUYA ĐÃ TAN RÃ! MẮT ĐÃ TRONG LẠI! TIẾN ĐẾN TẢNG ĐÁ NGỘ KHE VẰN TRẢM (A06-E004)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A06-E004') {
      // Ngộ Ra Tuyệt Kỹ "Khe Vằn Trảm" (Đường Liềm Vô Ảnh)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a06_e004');
      arcManager.advanceEvent('A06-E004');
      this.addXp(1000);
      this.stats.isKheVanTramMastered = true;
      this.stats.attackPower += 35;
      this.stats.critRate = Math.min(0.65, this.stats.critRate + 0.05);
      this.stats.objectiveTitle = 'A06-E005: Hạ Sơn Về Cổng Đình — Chữ Bình & Lời Dặn Của Tài Dog (Mở Đầu Arc 7)';
      this.stats.objectiveDetail = 'Qua cổng hạ sơn trở về Bản Cáu & Đình Lục Nà, gặp cháu trai Lài Phúc Tài (Tài Dog) và chú chó Đốm canh cổng!';
      this.stats.sealWarningText = '⚔️ ĐÃ LĨNH NGỘ TUYỆT KỸ KHE VẰN TRẢM! HẠ SƠN VỀ ĐÌNH LỤC NÀ GẶP TÀI DOG (A06-E005)!';
      this.stats.sealWarningTimer = 6.5;
      sound.playLevelUp();
      this.triggerScreenShake(9, 0.5);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A06-E005') {
      // Hạ Sơn Về Cổng Đình — Chữ Bình & Lời Dặn Của Tài Dog (Mở Đầu Arc 7)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a06_e005');
      arcManager.advanceEvent('A06-E005');
      this.completeQuest('quest_arc6');
      this.stats.arc6Completed = true;
      this.addXp(1500);
      this.unlockLoreEntry('char_khoi');
      this.unlockLoreEntry('loc_khe_van');

      // Chuyển giao sang Arc 7 theo đúng canon lore
      arcManager.advanceArc(7);
      this.stats.currentArc = 7;
      this.stats.arcTitle = 'Arc 7: Tài Dog và Cái "Giữ" Cuối Cùng (2030 – 2065)';
      this.stats.objectiveTitle = 'A07-E001: Lời Hứa Cổng Đình — Chú Chó Què Đốm (2030)';
      this.stats.objectiveDetail = 'Khôi 22 tuổi gác liềm về Bản Cáu; Tài Dog ngất xỉu bên thềm đình. Hãy tương tác Bát Thuốc Nam Dưỡng Tim sắc thuốc cứu tỉnh Tài!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 6: CHIẾN BINH THÁC KHE VẰN → MỞ KHÓA ARC 7: TÀI DOG VÀ CÁI "GIỮ" CUỐI CÙNG!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(10, 0.5);
      if (obj) obj.activated = true;
      this.activateQuest('quest_arc7');
      this.switchZone('zone_ban_cau', 100, 440);
      this.saveGame();
    } else if (eventId === 'A07-E001') {
      // A07-E001: Lời Hứa Cổng Đình — Chú Chó Què Đốm (2030)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a07_e001');
      arcManager.advanceEvent('A07-E001');
      this.addXp(500);
      this.stats.hasCaredForTai = true;
      this.addInventoryItem('item_thuoc_nam_duong_tim');
      this.stats.objectiveTitle = 'A07-E002: Những Cây Gậy Trúc Không Tập Võ (2035 – 2050)';
      this.stats.objectiveDetail = 'Qua cổng phía đông lên Chùa Cổ Nguyệt, chặt Khóm Trúc Non nhẵn mịn không gai góc mang về tặng sinh nhật Tài Dog!';
      this.stats.sealWarningText = '🌿 BÁT THUỐC NAM ĐÃ CỨU TỈNH TÀI DOG! LÊN CHÙA CỔ NGUYỆT CHẶT GẬY TRÚC TẶNG TÀI (A07-E002)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(6, 0.35);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A07-E002') {
      // A07-E002: Những Cây Gậy Trúc Không Tập Võ (2035 – 2050)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a07_e002');
      arcManager.advanceEvent('A07-E002');
      this.addXp(600);
      this.stats.hasCutBambooGift = true;
      this.addInventoryItem('item_gay_truc_non');
      this.stats.objectiveTitle = 'A07-E003: Đêm Đông 2065 — Cơn Bộc Phát Tim & Lời Dặn "Cứ Giữ Thôi"';
      this.stats.objectiveDetail = 'Mùa đông 2065 rét thấu xương. Về chòi lá Bản Cáu, đến bên Giường Bệnh chòi lá nắm tay Tài Dog nghe lời trăn trối!';
      this.stats.sealWarningText = '🎋 ĐÃ CHẶT GẬY TRÚC NON NHẴN MỊN! VỀ CHÒI LÁ BÊN GIƯỜNG BỆNH TÀI DOG (A07-E003)!';
      this.stats.sealWarningTimer = 6.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A07-E003') {
      // A07-E003: Đêm Đông 2065 — Cơn Bộc Phát Tim & Lời Dặn "Cứ Giữ Thôi"
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a07_e003');
      arcManager.advanceEvent('A07-E003');
      this.addXp(800);
      this.stats.hasWitnessedTaiTrangTroi = true;
      this.addInventoryItem('item_loi_trang_troi_tai_dog');
      this.stats.objectiveTitle = 'A07-E004: Treo Liềm Két Sắt — Chó Đốm 3 Ngày Bên Mộ (2065)';
      this.stats.objectiveDetail = 'Vào Đình Lục Nà tương tác Két Sắt khóa Liềm Tử Thần, rồi qua cổng lên Đồi Mộ Bản Cáu dâng cháo dỗ chó Đốm nằm 3 ngày bên mộ!';
      this.stats.sealWarningText = '🕯️ "CẬU ƠI ĐỪNG BÌNH NỮA, CỨ GIỮ THÔI..."! VÀO ĐÌNH KHÓA LIỀM VÀO KÉT SẮT & LÊN ĐỒI MỘ (A07-E004)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A07-E004') {
      // A07-E004: Treo Liềm Két Sắt — Chó Đốm 3 Ngày Bên Mộ (2065)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a07_e004');
      arcManager.advanceEvent('A07-E004');
      this.addXp(900);
      this.stats.hasSavedDomAtGrave = true;
      this.addInventoryItem('item_bat_chao_canh_mo');
      this.unlockLoreEntry('char_tai_dog');
      this.stats.objectiveTitle = 'A07-E005: Bóng Đêm Hoán Não — Điềm Báo Mở Đầu Arc 8 (2065 – 2068)';
      this.stats.objectiveDetail = 'Chu Mạnh Hiếu sai 4 Đao Thủ Tà Môn Móng Cái rình đào mộ hoán não! Dùng quyền cước và gậy trúc đẩy lui chúng (0/4), rồi chốt giữ chiến tuyến!';
      this.stats.sealWarningText = '🐕 CHÓ ĐỐM ĐÃ CHỊU ĂN CHÁO VÀ THEO VỀ CỔNG ĐÌNH! ĐẨY LUI 4 ĐAO THỦ TÀ MÔN RÌNH MỘ (A07-E005)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A07-E005') {
      // A07-E005: Bóng Đêm Hoán Não — Điềm Báo Mở Đầu Arc 8 (2065 – 2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a07_e005');
      arcManager.advanceEvent('A07-E005');
      this.completeQuest('quest_arc7');
      this.stats.arc7Completed = true;
      this.addInventoryItem('item_nhan_tin_nguc_mon_cuong');
      this.addXp(1500);
      this.unlockLoreEntry('char_khoi');

      // Chuyển giao sang Arc 8: Rubik Ngục Môn Cương / Ba chú linh theo đúng lore
      arcManager.advanceArc(8);
      this.stats.currentArc = 8;
      this.stats.arcTitle = 'Arc 8: Rubik Ngục Môn Cương / Ba Chú Linh';
      this.stats.objectiveTitle = 'Arc 8: Khởi Điểm Ngục Môn Cương — Chuẩn Bị Bước Vào Ma Trận Rubik';
      this.stats.objectiveDetail = 'Bình Liêu Vương thề giữ vững sự bình yên cho nấm mộ Tài Dog và chuẩn bị đối đầu âm mưu hoán não của Chu Mạnh Hiếu tại Ngục Môn Cương!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 7: TÀI DOG VÀ CÁI "GIỮ" CUỐI CÙNG (2030 – 2065) → MỞ RA ĐIỀM BÁO ARC 8!';
      this.stats.sealWarningTimer = 8.5;
      sound.playLevelUp();
      this.triggerScreenShake(10, 0.5);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A08-E001') {
      // A08-E001: Tiếng Gõ 108 Nhịp & Trận Đồ Biên Giới (2065)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a08_e001');
      arcManager.advanceEvent('A08-E001');
      this.activateQuest('quest_arc8');
      this.addXp(800);
      this.stats.hasDiscoveredRubikMatrix = true;
      this.stats.objectiveTitle = 'A08-E002: Đinh Quốc Tuấn — Muối Đen Phong Lộ & Cuốn Sổ Đỏ';
      this.stats.objectiveDetail = 'Tiến sang bình đài phía tây, đánh bại hình bóng Đinh Quốc Tuấn (spirit_tuan) và hóa giải Bàn Thờ Bùa Muối Đen (altar_muoi_den)!';
      this.stats.sealWarningText = '🔔 KHỐI ĐÁ RUBIK 1M³ PHÁT TIẾNG GÕ 108 NHỊP! HÓA GIẢI BÙA MUỐI ĐEN CỦA TUẤN (A08-E002)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A08-E002') {
      // A08-E002: Đinh Quốc Tuấn — Muối Đen Phong Lộ & Cuốn Sổ Đỏ
      if (!this.stats.tuanDefeated) {
        this.stats.sealWarningText = '⚠️ HÃY ĐÁNH BẠI HÌNH BÓNG ĐINH QUỐC TUẤN (spirit_tuan) TRƯỚC KHI HÓA GIẢI BÀN THỜ!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a08_e002');
      arcManager.advanceEvent('A08-E002');
      this.addXp(1000);
      this.stats.hasPurifiedBlackSalt = true;
      this.addInventoryItem('item_so_do_dinh_quoc_tuan');
      this.stats.objectiveTitle = 'A08-E003: Ông Táy — Lò Than Tà Khí & Mặt Nứt 6 Vết';
      this.stats.objectiveDetail = 'Tiến sang bình đài phía đông, đánh bại Ông Táy (spirit_tay) và dập tắt Vạc Than Tà Khí (altar_lo_than)!';
      this.stats.sealWarningText = '🧂 ĐÃ TẨY SẠCH BÙA MUỐI ĐEN! THU HỒI SỔ ĐỎ! TIẾP TỤC ĐỐI ĐẦU ÔNG TÁY (A08-E003)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.35);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A08-E003') {
      // A08-E003: Ông Táy — Lò Than Tà Khí & Mặt Nứt 6 Vết
      if (!this.stats.tayDefeated) {
        this.stats.sealWarningText = '⚠️ HÃY ĐÁNH BẠI ÔNG TÁY (spirit_tay) ĐỂ DẬP TẮT TÀ HỎA TRƯỚC KHI TƯƠNG TÁC VẠC THAN!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a08_e003');
      arcManager.advanceEvent('A08-E003');
      this.addXp(1100);
      this.stats.hasQuenchedEvilCoal = true;
      this.addInventoryItem('item_manh_bua_ong_tay');
      this.stats.objectiveTitle = 'A08-E004: Hùng Đỏ — Nhát Dao Phản Bội & Chìa Khóa Ngục Môn';
      this.stats.objectiveDetail = 'Đến cầu đá trung tâm, đối đầu Hùng Đỏ (spirit_hung) và tước đoạt Chìa Khóa Ngục Môn Cương (altar_dao_hung)!';
      this.stats.sealWarningText = '🔥 ĐÃ DẬP TẮT VẠC THAN ÔNG TÁY! NHẬN MẢNH BÙA LÒ THAN! ĐỐI MẶT HÙNG ĐỎ (A08-E004)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.35);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A08-E004') {
      // A08-E004: Hùng Đỏ — Nhát Dao Phản Bội & Chìa Khóa Ngục Môn
      if (!this.stats.hungDefeated) {
        this.stats.sealWarningText = '⚠️ HÃY HÓA GIẢI ĐÒN TẤN CÔNG CỦA HÙNG ĐỎ (spirit_hung) TRƯỚC KHI THU HỒI CHÌA KHÓA!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a08_e004');
      arcManager.advanceEvent('A08-E004');
      this.addXp(1200);
      this.stats.hasObtainedRubikKey = true;
      this.addInventoryItem('item_chia_khoa_hung_do');
      this.stats.objectiveTitle = 'A08-E005: Bà Mận — Bát Cháo Gừng Tình Người & Lòng Trắc Ẩn';
      this.stats.objectiveDetail = 'Gặp gỡ Bà Mận bên bếp than (bep_chao_gung), đón nhận Bát Cháo Gừng Ấm Tình Người và tha thứ cho Ba Chú Linh!';
      this.stats.sealWarningText = '🗝️ ĐÃ THU HỒI CHÌA KHÓA NGỤC MÔN CƯƠNG! GẶP BÀ MẬN ĐÓN NHẬN BÁT CHÁO GỪNG (A08-E005)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A08-E005') {
      // A08-E005: Bà Mận — Bát Cháo Gừng Tình Người & Lòng Trắc Ẩn
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a08_e005');
      arcManager.advanceEvent('A08-E005');
      this.addXp(1300);
      this.stats.hasReceivedGingerPorridge = true;
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.addInventoryItem('item_bat_chao_gung_ba_man');
      this.unlockLoreEntry('char_ba_man');
      this.stats.objectiveTitle = 'A08-E006: Khối Đá Rubik 1m³ — Khôi Tự Nguyện Ở Lại 3 Năm (2065 – 2068)';
      this.stats.objectiveDetail = 'Tiến lại Khối Đá Rubik 1m³ (rubik_cube_center), tra chìa khóa kích hoạt 6 mặt bùa và tự nguyện bước vào phong ấn!';
      this.stats.sealWarningText = '🍲 BÁT CHÁO GỪNG BÀ MẬN ẤM TÌNH NGƯỜI (+100% MÁU & NỘI LỰC)! BƯỚC VÀO RUBIK 1M³ (A08-E006)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A08-E006') {
      // A08-E006: Khối Đá Rubik 1m³ — Khôi Tự Nguyện Ở Lại & Định Mệnh 3 Năm (2065 – 2068)
      if (!this.stats.hasReceivedGingerPorridge || !this.stats.hasObtainedRubikKey) {
        this.stats.sealWarningText = '⚠️ CẦN THU HỒI CHÌA KHÓA VÀ NHẬN BÁT CHÁO GỪNG BÀ MẬN TRƯỚC KHI MỞ KHỐI RUBIK!';
        this.stats.sealWarningTimer = 4.0;
        return;
      }
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a08_e006');
      arcManager.advanceEvent('A08-E006');
      this.completeQuest('quest_arc8');
      this.stats.arc8Completed = true;
      this.stats.hasEnteredRubikCube = true;
      this.addInventoryItem('item_khoi_rubik_1m');
      this.addXp(2000);
      this.unlockLoreEntry('rubik_matrix_box');
      this.unlockLoreEntry('char_du');

      // Chuyển giao sang Arc 9: Chu Mạnh Hiếu và Thuật Thức Hoán Não (2065 – 2068)
      arcManager.advanceArc(9);
      this.stats.currentArc = 9;
      this.stats.arcTitle = 'Arc 9: Chu Mạnh Hiếu và Thuật Thức Hoán Não (2065 – 2068)';
      this.stats.objectiveTitle = 'A09-E001: Dấu Vết Đào Mộ & Nấm Mồ Trống Rỗng (2065)';
      this.stats.objectiveDetail = 'Khám nghiệm nấm mộ Tài Dog bị đào xới tại Đồi Mộ Bản Cáu (zone_doi_mo_tai_dog), thu thập 3 manh mối!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 8 → MỞ KHÓA ARC 9: CHU MẠNH HIẾU VÀ THUẬT THỨC HOÁN NÃO!';
      this.stats.sealWarningTimer = 10.0;
      sound.playLevelUp();
      this.triggerScreenShake(12, 0.6);
      if (obj) obj.activated = true;
      this.activateQuest('quest_arc9');
      this.saveGame();
    } else if (eventId === 'A09-E001') {
      // A09-E001: Dấu Vết Đào Mộ & Nấm Mồ Trống Rỗng (2065)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a09_e001');
      arcManager.advanceEvent('A09-E001');
      this.addXp(900);
      this.addInventoryItem('item_dao_mo_ta_mon');
      this.addInventoryItem('item_manh_ao_sat_nach_hieu');
      this.addInventoryItem('item_dau_tay_thep_thao');
      this.stats.hasInvestigatedDesecratedGrave = true;
      this.stats.cluesFoundCount = 3;
      this.stats.objectiveTitle = 'A09-E002: Sào Huyệt Hang Đá Lạng Sơn — Lò Luyện Sọ Tà Môn (2066)';
      this.stats.objectiveDetail = 'Qua cổng dịch chuyển sang Hang Đá Lạng Sơn (zone_hang_da_lang_son), tiêu diệt 5 Tà Sư Hoán Não và phá hủy Bàn Mổ Hoán Não!';
      this.stats.sealWarningText = '🔍 ĐÃ THU THẬP 3 MANH MỐI TẠI MỘ TÀI DOG! TIẾN VÀO HANG ĐÁ LẠNG SƠN (A09-E002)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A09-E002') {
      // A09-E002: Sào Huyệt Hang Đá Lạng Sơn — Lò Luyện Sọ Tà Môn (2066)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a09_e002');
      arcManager.advanceEvent('A09-E002');
      this.addXp(1100);
      this.addInventoryItem('item_ho_so_hoan_nao');
      this.stats.hasDestroyedOperatingTable = true;
      this.stats.objectiveTitle = 'A09-E003: Đài Tế Hút Vía & Đại Chiến Avatar Chu Mạnh Hiếu (2066 – 2067)';
      this.stats.objectiveDetail = 'Tiến sâu vào hang đá, đánh bại Boss Avatar Chu Mạnh Hiếu (boss_chu_manh_hieu_avatar) và phá hủy Đài Tế Hút Vía!';
      this.stats.sealWarningText = '📜 ĐÃ PHÁ BÀN MỔ & THU HỒI HỒ SƠ HOÁN NÃO! ĐỐI ĐẦU CHU MẠNH HIẾU TẠI ĐÀI TẾ (A09-E003)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A09-E003') {
      // A09-E003: Đài Tế Hút Vía & Đại Chiến Avatar Chu Mạnh Hiếu (2066 – 2067)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a09_e003');
      arcManager.advanceEvent('A09-E003');
      this.addXp(1400);
      this.addInventoryItem('item_manh_tay_thep_thao');
      this.stats.objectiveTitle = 'A09-E004: Sự Phản Phệ Của Não Tài — Huyết Lệ Trong Đêm (2067)';
      this.stats.objectiveDetail = 'Tiến lại Bàn Ký Ức Não Tài (ky_uc_nao_tai), dùng gậy trúc kích hoạt phản phệ tế bào não khiến Hiếu khóc chảy huyết lệ!';
      this.stats.sealWarningText = '💥 ĐÃ ĐẬP TAN ĐÀI TẾ HÚT VÍA! NHẬN MẢNH TAY THÉP! ĐẾN BÀN KÝ ỨC NÃO TÀI (A09-E004)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A09-E004') {
      // A09-E004: Sự Phản Phệ Của Não Tài — Huyết Lệ Trong Đêm (2067)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a09_e004');
      arcManager.advanceEvent('A09-E004');
      this.addXp(1500);
      this.addInventoryItem('item_nuoc_mat_tai_dog', 3);
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.stats.hasTriggeredBrainRejection = true;
      this.stats.objectiveTitle = 'A09-E005: Điểm Hẹn Cáp Thép — Lục Triều Dư Xuất Hiện (2068)';
      this.stats.objectiveDetail = 'Tiến ra vách đá cửa hang Lạng Sơn, gặp gỡ Lục Triều Dư (diem_hen_luc_trieu_du) để nhận Cuộn Cáp Thép chuẩn bị sang Arc 10!';
      this.stats.sealWarningText = '💧 NÃO TÀI PHẢN PHỆ — HIẾU CHẢY HUYẾT LỆ TỰ SỤP ĐỔ! GẶP LỤC TRIỀU DƯ (A09-E005)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A09-E005') {
      // A09-E005: Điểm Hẹn Cáp Thép — Lục Triều Dư Xuất Hiện (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a09_e005');
      arcManager.advanceEvent('A09-E005');
      this.completeQuest('quest_arc9');
      this.stats.hasMetLucTrieuDuArc9 = true;
      this.stats.arc9Completed = true;
      this.addInventoryItem('item_cuon_cap_thep_du');
      this.addXp(2000);
      this.unlockLoreEntry('char_du');
      this.stats.arcTitle = 'Arc 9: Chu Mạnh Hiếu và Thuật Hoán Não — Hoàn Thành (2065 – 2068)';
      this.stats.objectiveTitle = '🏆 HOÀN THÀNH TOÀN BỘ ARC 9: CHU MẠNH HIẾU VÀ THUẬT THỨC HOÁN NÃO!';
      this.stats.objectiveDetail = 'Tà thuật Hoán Não đã bị hủy diệt do não Tài mục rã sau 3 năm; Lục Triều Dư trao cuộn cáp thép 108 nhịp mở đường sang Arc 10: Kéo Khôi Trở Lại!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 9: CHU MẠNH HIẾU & THUẬT HOÁN NÃO! ĐÓN CHÀO ARC 10: LỤC TRIỀU DƯ / KÉO KHÔI TRỞ LẠI!';
      this.stats.sealWarningTimer = 10.0;
      sound.playLevelUp();
      this.triggerScreenShake(12, 0.6);
      if (obj) obj.activated = true;

      // Chuyển giao sang Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại (2068)
      arcManager.advanceArc(10);
      this.stats.currentArc = 10;
      this.stats.arcTitle = 'Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại (2068)';
      this.stats.objectiveTitle = 'A10-E001: Giàn Cáp Thép Mốc 1088 — Phe Kéo Vào Vị Trí (2068)';
      this.stats.objectiveDetail = 'Tiến lên Vách Đá Ngục Môn Cương (zone_nguc_mon_cuong), đánh bại 4 Đao Thủ Hắc Đạo và cắm 3 Mỏ Neo Cáp Thép!';
      this.activateQuest('quest_arc10');
      this.saveGame();
    } else if (eventId === 'A10-E001') {
      // A10-E001: Giàn Cáp Thép Mốc 1088 — Phe Kéo Vào Vị Trí (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a10_e001');
      arcManager.advanceEvent('A10-E001');
      this.addXp(1200);
      this.addInventoryItem('item_moc_neo_cap_thep');
      this.stats.objectiveTitle = 'A10-E002: Đánh Bại Trùm Đao Thủ Canh Giữ Hộp Đá Rubik (2068)';
      this.stats.objectiveDetail = 'Tiến lại đài đá trung tâm vách núi, khiêu chiến và đánh bại Boss Trùm Đao Thủ Canh Ngục để đoạt Khóa Căng Cáp Thép!';
      this.stats.sealWarningText = '🧗 ĐÃ CẮM ĐỦ 3 MỎ NEO CÁP THÉP! ĐỐI ĐẦU TRÙM ĐAO THỦ CANH NGỤC (A10-E002)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(7, 0.4);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A10-E002') {
      // A10-E002: Đánh Bại Trùm Đao Thủ Canh Giữ Hộp Đá Rubik (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a10_e002');
      arcManager.advanceEvent('A10-E002');
      this.addXp(1500);
      this.addInventoryItem('item_khoa_cang_cap');
      this.stats.bossDaoThuDefeated = true;
      this.stats.objectiveTitle = 'A10-E003: Nghi Thức 108 Nhịp Cáp Thép — Phá Khối Đá Rubik 1m³ (2068)';
      this.stats.objectiveDetail = 'Tiến lại Khối Đá Rubik 1m³ (rubik_nguc_mon_cuong_108), móc 108 đầu cáp và gõ đúng 108 nhịp sóng âm rung chấn!';
      this.stats.sealWarningText = '🗡️ ĐÃ ĐOẠT KHÓA CĂNG CÁP! TƯƠNG TÁC KHỐI ĐÁ RUBIK 108 NHỊP (A10-E003)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A10-E003') {
      // A10-E003: Nghi Thức 108 Nhịp Cáp Thép — Phá Khối Đá Rubik 1m³ (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a10_e003');
      arcManager.advanceEvent('A10-E003');
      this.addXp(1800);
      this.addInventoryItem('item_manh_da_rubik_108');
      this.stats.rubik108BeatsTriggered = true;
      this.stats.objectiveTitle = 'A10-E004: Kéo Khôi Trở Lại — Trao Chiếc Áo Phao Đen Rách (2068)';
      this.stats.objectiveDetail = 'Tiến sang Bình Đài Giải Thoát Khôi (khung_khoi_phuc_sinh_luc), khoác Áo Phao Đen Rách và trao Nước Gừng Nóng đưa Khôi trở lại!';
      this.stats.sealWarningText = '🔔 108 NHỊP SÓNG ÂM ĐÃ PHÁ VỠ NGỤC MÔN CƯƠNG! ĐẾN BÌNH ĐÀI SƯỞI ẤM KHÔI (A10-E004)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(12, 0.6);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A10-E004') {
      // A10-E004: Kéo Khôi Trở Lại — Trao Chiếc Áo Phao Đen Rách (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a10_e004');
      arcManager.advanceEvent('A10-E004');
      this.addXp(2000);
      this.addInventoryItem('item_ao_phao_den_rach_du');
      this.addInventoryItem('item_bat_nuoc_gung_nong_1088', 3);
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.stats.hasReceivedAoPhaoDenRach = true;
      this.stats.objectiveTitle = 'A10-E005: Hai Thằng Canh Cổng & Khúc Dạo Đầu Trận Trường Mầm Non (2068)';
      this.stats.objectiveDetail = 'Xuống núi về Bản Cáu (zone_ban_cau), dẹp sạch 3 tên trinh sát tà môn và hội ngộ tại Cổng Đình Lục Nà (cong_dinh_hai_thang_canh_cong)!';
      this.stats.sealWarningText = '🧥 ĐÃ KÉO KHÔI TRỞ LẠI! KHOÁC ÁO PHAO ĐEN RÁCH & VỀ BẢN CÁU BẢO VỆ CỔNG ĐÌNH (A10-E005)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A10-E005') {
      // A10-E005: Hai Thằng Canh Cổng & Khúc Dạo Đầu Trận Trường Mầm Non (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a10_e005');
      arcManager.advanceEvent('A10-E005');
      this.completeQuest('quest_arc10');
      this.stats.hasCompletedTwoGatekeepersTrial = true;
      this.stats.arc10Completed = true;
      this.addInventoryItem('item_chuong_gio_mam_non');
      this.addXp(2500);
      this.stats.arcTitle = 'Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại — Hoàn Thành (2068)';
      this.stats.objectiveTitle = '🏆 HOÀN THÀNH TOÀN BỘ ARC 10: LỤC TRIỀU DƯ / KÉO KHÔI TRỞ LẠI!';
      this.stats.objectiveDetail = 'Đã kéo Bình Liêu Vương trở lại, kết thành Hai Thằng Canh Cổng; sẵn sàng chuyển giao sang Arc 11: Trận Cuối Ở Trường Mầm Non (2068)!';
      this.stats.sealWarningText = '🏆 HOÀN THÀNH TOÀN BỘ ARC 10! ĐÓN CHÀO ARC 11: TRẬN CUỐI Ở TRƯỜNG MẦM NON (2068)!';
      this.stats.sealWarningTimer = 10.0;
      sound.playLevelUp();
      this.triggerScreenShake(12, 0.6);
      if (obj) obj.activated = true;

      // Chuyển giao sang Arc 11: Trận Cuối Ở Trường Mầm Non (2068)
      arcManager.advanceArc(11);
      this.stats.currentArc = 11;
      this.stats.arcTitle = 'Arc 11: Trận Cuối Ở Trường Mầm Non (2068)';
      this.stats.objectiveTitle = 'A11-E001: Đột Kích Cổng Trường Mầm Non Bản Cáu (2068)';
      this.stats.objectiveDetail = 'Tiến vào Trường Mầm Non Trong Đêm Tuyết (zone_mam_non_midnight), hạ gục 3 Đao Thủ Tà Môn và mở Khóa Rào Chắn Cổng!';
      this.activateQuest('quest_arc11');
      this.saveGame();
    } else if (eventId === 'A11-E001') {
      // A11-E001: Đột Kích Cổng Trường Mầm Non Bản Cáu (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a11_e001');
      arcManager.advanceEvent('A11-E001');
      this.addXp(2000);
      this.addInventoryItem('item_chia_khoa_cong_mam_non');
      this.stats.objectiveTitle = 'A11-E002: Bẫy Cáp Xích Đu — Phe Kéo Giăng 108 Sợi Cáp (2068)';
      this.stats.objectiveDetail = 'Tiến lại Cột Trụ Xích Đu (cot_tru_xich_du_giang_cap), giăng 108 sợi cáp thép và kích hoạt bẫy sập khóa chặt tay thép!';
      this.stats.sealWarningText = '🏫 ĐÃ PHÁ RÀO CHẮN CỔNG TRƯỜNG! NHẬN CHÌA KHÓA! GIĂNG CÁP XÍCH ĐU (A11-E002)!';
      this.stats.sealWarningTimer = 7.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A11-E002') {
      // A11-E002: Bẫy Cáp Xích Đu — Phe Kéo Giăng 108 Sợi Cáp (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a11_e002');
      arcManager.advanceEvent('A11-E002');
      this.addXp(2500);
      this.addInventoryItem('item_day_cap_khoa_thep');
      this.stats.hasPulledSwingCableTrap = true;
      this.stats.objectiveTitle = 'A11-E003: Quyết Chiến Chu Mạnh Hiếu Dạng 1 — Phá Vỡ Tay Thép 108 Nhịp (2068)';
      this.stats.objectiveDetail = 'Tiến vào khán đài trung tâm sân trường, phối hợp cùng Lục Triều Dư đánh bại Boss Chu Mạnh Hiếu Dạng 1 và chém gãy cánh tay thép cơ khí!';
      this.stats.sealWarningText = '⛓️ BẪY CÁP THÉP ĐÃ KHÓA GIỮ KHUNG XÍCH ĐU! ĐỐI ĐẦU CHU MẠNH HIẾU DẠNG 1 (A11-E003)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playCableStrike();
      this.triggerScreenShake(12, 0.6);
      if (obj) obj.activated = true;
      const boss = this.currentZone.enemies.find(e => e.type === 'boss_chu_manh_hieu');
      if (boss) {
        boss.detectionRange = 3000;
        boss.state = 'chase';
        boss.speechBubble = 'Lục Triều Dư! Hoàng Minh Khôi! Hai thằng canh cổng các người dám mò tới đây nộp mạng!';
        boss.speechTimer = 5.0;
      }
      this.saveGame();
    } else if (eventId === 'A11-E003') {
      // A11-E003: Quyết Chiến Chu Mạnh Hiếu Dạng 1 — Phá Vỡ Tay Thép 108 Nhịp (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a11_e003');
      arcManager.advanceEvent('A11-E003');
      this.addXp(3000);
      this.addInventoryItem('item_tay_thep_gay_vun');
      this.stats.objectiveTitle = 'A11-E004: Chu Hiếu Què Xé Áo — Bộc Lộ Dạng 2 Bản Khuyết Tật (2068)';
      this.stats.objectiveDetail = 'Né tránh Lôi Ảnh Thủ và đòn vật cởi áo cân ba của Chu Hiếu Què (chân ngắn hơn 2cm, sẹo nọc rắn Móng Cái), đánh bại Boss Phase 2!';
      this.stats.sealWarningText = '🦾 TAY THÉP ĐÃ VỠ VỤN! HIẾU BỘC LỘ BẢN KHUYẾT TẬT ĐỨNG MỘT CHÂN PHÓNG SÉT (A11-E004)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(10, 0.5);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A11-E004') {
      // A11-E004: Chu Hiếu Què Xé Áo — Bộc Lộ Dạng 2 Bản Khuyết Tật (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a11_e004');
      arcManager.advanceEvent('A11-E004');
      this.addXp(3500);
      this.addInventoryItem('item_ao_sat_nach_thay_huynh');
      this.stats.objectiveTitle = 'A11-E005: Nhát Liềm Dừng Lại — Giải Thoát Chu Hiếu Què (2068)';
      this.stats.objectiveDetail = 'Tiến lại thềm đá trước lớp học mầm non (diem_dung_liem_cuoi), vung Liềm Tử Thần nhưng DỪNG LẠI cách cổ 1 tấc để cứu vớt linh hồn Hiếu!';
      this.stats.sealWarningText = '⚡ CHU HIẾU ĐÃ KHUỴU CHÂN TRÊN TUYẾT! TƯƠNG TÁC ĐIỂM DỪNG LIỀM CUỐI (A11-E005)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(8, 0.45);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A11-E005') {
      // A11-E005: Nhát Liềm Dừng Lại — Giải Thoát Chu Hiếu Què (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a11_e005');
      arcManager.advanceEvent('A11-E005');
      this.addXp(4000);
      this.addInventoryItem('item_dau_an_chu_dung_thanh_tuu');
      this.stats.hasSparedChuHieuEnding = true;
      this.stats.hp = this.stats.maxHp;
      this.stats.qi = this.stats.maxQi;
      this.stats.objectiveTitle = 'A11-E006: Giải Cứu 20 Đứa Trẻ & Linh Hồn Tài Siêu Thoát (2068)';
      this.stats.objectiveDetail = 'Tiến lại Cửa Phòng Học Mầm Non (cua_phong_hoc_20_tre_em), mở khóa giải thoát 20 đứa trẻ và tiễn biệt linh hồn Tài Dog siêu thoát!';
      this.stats.sealWarningText = '🛑 ĐÃ THỰC THI NHÁT LIỀM DỪNG LẠI! TÂM MA HÓA GIẢI! ĐẾN CỬA PHÒNG HỌC (A11-E006)!';
      this.stats.sealWarningTimer = 8.0;
      sound.playLevelUp();
      this.triggerScreenShake(12, 0.6);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A11-E006') {
      // A11-E006: Giải Cứu 20 Đứa Trẻ & Linh Hồn Tài Siêu Thoát (2068)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a11_e006');
      arcManager.advanceEvent('A11-E006');
      this.addXp(4500);
      this.addInventoryItem('item_khung_tranh_20_em_nho');
      this.addInventoryItem('item_hon_tai_sieu_thoat');
      this.stats.hasRescued20Children = true;
      this.stats.objectiveTitle = 'A11-E007: Hai Thằng Canh Cổng — Bình Minh Trở Lại Đất Bình Liêu (Đại Kết Cục)';
      this.stats.objectiveDetail = 'Trở về Đình Lục Nà (zone_ban_cau), bước lên Thềm Đá Cổng Đình (them_da_hai_thang_canh_cong_ending) cùng Dư ngắm bình minh 2068!';
      this.stats.sealWarningText = '👶 ĐÃ CỨU 20 ĐỨA TRẺ & HỒN TÀI ĐÃ SIÊU THOÁT! VỀ ĐÌNH LỤC NÀ HOÀN TẤT ĐẠI KẾT CỤC (A11-E007)!';
      this.stats.sealWarningTimer = 9.0;
      sound.playLevelUp();
      this.triggerScreenShake(10, 0.5);
      if (obj) obj.activated = true;
      this.saveGame();
    } else if (eventId === 'A11-E007') {
      // A11-E007: Hai Thằng Canh Cổng — Bình Minh Trở Lại Đất Bình Liêu (Đại Kết Cục)
      if (this.callbacks.onDialogTrigger) this.callbacks.onDialogTrigger('dialog_a11_e007');
      arcManager.advanceEvent('A11-E007');
      this.completeQuest('quest_arc11');
      this.stats.arc11Completed = true;
      this.stats.gameCompleted = true;
      this.addInventoryItem('item_danh_hieu_binh_lieu_vuong_vi_dai');
      this.addXp(5000);
      this.unlockLoreEntry('legend_binh_lieu_vuong');
      this.unlockLoreEntry('char_khoi');
      this.unlockLoreEntry('char_du');
      this.stats.arcTitle = 'Bình Liêu Vương — Đại Kết Cục Hoàn Tất Trọn Vẹn (2068)';
      this.stats.objectiveTitle = '🏆 HUYỀN THOẠI BÌNH LIÊU VƯƠNG: HOÀN THÀNH TOÀN BỘ 11 ARC!';
      this.stats.objectiveDetail = '“Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người.” Khôi và Dư trở thành Hai Thằng Canh Cổng muôn đời bảo vệ Bình Liêu!';
      this.stats.sealWarningText = '🌅 BÌNH MINH 2068 CHIẾU RỌI NON CAO BÌNH LIÊU! CHÚC MỪNG PHÁ ĐẢO TOÀN BỘ TRÒ CHƠI!';
      this.stats.sealWarningTimer = 15.0;
      sound.playLevelUp();
      sound.playHoiQuang();
      this.triggerScreenShake(16, 1.2);
      if (obj) obj.activated = true;
      this.saveGame();

      // Trigger Victory Screen Callback
      if (this.callbacks.onVictory) {
        this.callbacks.onVictory();
      }
    }
  }

  public addInventoryItem(itemId: string, quantity: number = 1) {
    const existing = this.inventory.find(i => i.id === itemId);
    if (existing) {
      existing.quantity += quantity;
    } else {
      const template = INITIAL_INVENTORY.find(i => i.id === itemId);
      if (template) {
        this.inventory.push({ ...template, quantity });
      }
    }
  }

  /**
   * Smooth Camera Tracking with Lookahead
   */
  private updateCamera(dt: number) {
    const targetX = this.player.x - this.screenWidth / 2 + this.player.direction * 40;
    const targetY = this.player.y - this.screenHeight / 2 - 20;

    // Smooth lerp
    this.cameraX += (targetX - this.cameraX) * 8 * dt;
    this.cameraY += (targetY - this.cameraY) * 6 * dt;

    // Clamp camera within map bounds
    this.cameraX = Math.max(0, Math.min(this.currentZone.width - this.screenWidth, this.cameraX));
    this.cameraY = Math.max(0, Math.min(this.currentZone.height - this.screenHeight, this.cameraY));
  }

  /**
   * Switch Active Zone
   */
  public switchZone(zoneId: string, playerX?: number, playerY?: number) {
    if (!this.zones[zoneId]) return;
    this.currentZone = this.zones[zoneId];
    this.player.x = playerX ?? this.currentZone.playerStartX;
    this.player.y = playerY ?? this.currentZone.playerStartY;
    this.player.vx = 0;
    this.player.vy = 0;

    for (const npc of this.currentZone.npcs) {
      npc.y = this.getGroundYAt(npc.x, npc.y);
    }
    for (const enemy of this.currentZone.enemies) {
      enemy.y = this.getGroundYAt(enemy.x, enemy.y);
    }

    sound.setBgmTheme(this.currentZone.theme);
    if (this.callbacks.onZoneChange) this.callbacks.onZoneChange(this.currentZone);
    this.saveGame();
  }

  /**
   * Quests & Progression
   */
  public activateQuest(questId: string) {
    const q = this.quests.find(item => item.id === questId);
    if (q) {
      q.active = true;
      if (this.callbacks.onQuestUpdate) this.callbacks.onQuestUpdate(this.quests);
    }
  }

  public completeQuest(questId: string) {
    const q = this.quests.find(item => item.id === questId);
    if (q && !q.completed) {
      q.completed = true;
      this.addXp(q.rewardXp);
      sound.playLevelUp();
      if (this.callbacks.onQuestUpdate) this.callbacks.onQuestUpdate(this.quests);
      this.saveGame();
    }
  }

  public addXp(amount: number) {
    this.stats.xp += amount;
    while (this.stats.xp >= this.stats.maxXp) {
      this.stats.xp -= this.stats.maxXp;
      this.stats.level++;
      this.stats.maxXp = Math.floor(this.stats.maxXp * 1.4 + 40);
      // Mỗi lần lên level: +150 HP và +150 sát thương (Requirement 17)
      this.stats.maxHp += 150;
      this.stats.hp = this.stats.maxHp;
      this.stats.attackPower += 150;
      this.stats.defense += 15;
      sound.playLevelUp();
      this.triggerScreenShake(5, 0.25);
      this.addDamageNumber(this.player.x, this.player.y - 50, 150, '#facc15', true);
      this.stats.sealWarningText = `🎉 LÊN CẤP ${this.stats.level}! (+150 HP, +150 SÁT THƯƠNG)`;
      this.stats.sealWarningTimer = 3.5;

      // Burst of golden celebratory particles
      for (let i = 0; i < 24; i++) {
        this.particles.push({
          x: this.player.x + (Math.random() - 0.5) * 40,
          y: this.player.y - 20 + (Math.random() - 0.5) * 40,
          vx: (Math.random() - 0.5) * 160,
          vy: -Math.random() * 150 - 50,
          life: 0.8,
          maxLife: 0.8,
          size: 4 + Math.random() * 3,
          color: Math.random() > 0.5 ? '#facc15' : '#fbbf24',
          alpha: 1.0,
          type: 'spark',
        });
      }
    }
    if (this.callbacks.onStatsChange) this.callbacks.onStatsChange(this.stats);
  }

  public unlockLoreEntry(loreId: string) {
    if (!this.unlockedLore.includes(loreId)) {
      this.unlockedLore.push(loreId);
      const entry = LORE_ENTRIES.find(e => e.id === loreId);
      if (entry && this.callbacks.onLoreUnlocked) {
        this.callbacks.onLoreUnlocked(loreId, entry.title);
      }
      this.saveGame();
    }
  }

  /**
   * Particles and Screen Shake
   */
  public triggerScreenShake(intensity: number, duration: number) {
    this.screenShakeIntensity = intensity;
    this.screenShakeTime = duration;
  }

  private addDamageNumber(x: number, y: number, value: number, color: string, isCrit: boolean = false) {
    this.damageNumbers.push({
      x,
      y,
      value,
      color,
      isCrit,
      life: 0.7,
      maxLife: 0.7,
    });
  }

  private updateParticles(dt: number) {
    // Ambient weather particles
    if (this.currentZone.weather === 'falling_leaves' && Math.random() < 0.2) {
      this.particles.push({
        x: this.cameraX + Math.random() * this.screenWidth,
        y: this.cameraY - 10,
        vx: 20 + Math.random() * 30,
        vy: 30 + Math.random() * 20,
        life: 4,
        maxLife: 4,
        size: 3,
        color: '#84cc16',
        alpha: 0.8,
        type: 'leaf',
        rotation: Math.random() * Math.PI,
        vRot: (Math.random() - 0.5) * 4,
      });
    } else if (this.currentZone.weather === 'rain' && Math.random() < 0.4) {
      this.particles.push({
        x: this.cameraX + Math.random() * this.screenWidth,
        y: this.cameraY - 10,
        vx: -60,
        vy: 450,
        life: 0.8,
        maxLife: 0.8,
        size: 2,
        color: '#38bdf8',
        alpha: 0.7,
        type: 'water',
      });
    } else if (this.currentZone.weather === 'snow' && Math.random() < 0.45) {
      this.particles.push({
        x: this.cameraX + Math.random() * this.screenWidth,
        y: this.cameraY - 10,
        vx: -30 + Math.random() * 20,
        vy: 55 + Math.random() * 30,
        life: 5,
        maxLife: 5,
        size: 2 + Math.random() * 2.5,
        color: '#f8fafc',
        alpha: 0.85,
        type: 'ice',
      });
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.rotation !== undefined && p.vRot) p.rotation += p.vRot * dt;
      p.alpha = p.life / p.maxLife;
    }
  }

  private updateDamageNumbers(dt: number) {
    for (let i = this.damageNumbers.length - 1; i >= 0; i--) {
      const d = this.damageNumbers[i];
      d.life -= dt;
      if (d.life <= 0) {
        this.damageNumbers.splice(i, 1);
        continue;
      }
      d.y -= 40 * dt;
    }
  }

  private spawnDust(x: number, y: number, count: number = 6) {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: x + (Math.random() - 0.5) * 16,
        y: y + (Math.random() - 0.5) * 4,
        vx: (Math.random() - 0.5) * 50,
        vy: -Math.random() * 25,
        life: 0.35,
        maxLife: 0.35,
        size: 2 + Math.random() * 3,
        color: '#94a3b8',
        alpha: 0.6,
        type: 'dust',
      });
    }
  }

  private spawnDashDust(x: number, y: number) {
    for (let i = 0; i < 10; i++) {
      this.particles.push({
        x: x + (Math.random() - 0.5) * 10,
        y: y - 10 + (Math.random() - 0.5) * 20,
        vx: -this.player.direction * (60 + Math.random() * 120),
        vy: (Math.random() - 0.5) * 40,
        life: 0.3,
        maxLife: 0.3,
        size: 3,
        color: '#e0f2fe',
        alpha: 0.8,
        type: 'dust',
      });
    }
  }

  private spawnBloodSparks(x: number, y: number) {
    for (let i = 0; i < 8; i++) {
      this.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 180,
        vy: -Math.random() * 120,
        life: 0.25,
        maxLife: 0.25,
        size: 2 + Math.random() * 2,
        color: Math.random() > 0.5 ? '#ef4444' : '#fde047',
        alpha: 1,
        type: 'spark',
      });
    }
  }

  /**
   * Rendering Pipeline
   */
  private render() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.screenWidth, this.screenHeight);

    // Apply Screen Shake
    let shakeX = 0;
    let shakeY = 0;
    if (this.screenShakeIntensity > 0) {
      shakeX = (Math.random() - 0.5) * this.screenShakeIntensity * 2;
      shakeY = (Math.random() - 0.5) * this.screenShakeIntensity * 2;
    }

    ctx.save();
    ctx.translate(Math.floor(-this.cameraX + shakeX), Math.floor(-this.cameraY + shakeY));

    // 1. Parallax Sky & Mountain Layers
    this.renderParallaxBackground(ctx);

    // 2. Platforms & Terrain
    for (const plat of this.currentZone.platforms) {
      ctx.fillStyle = plat.color || '#334155';
      ctx.fillRect(Math.floor(plat.x), Math.floor(plat.y), Math.floor(plat.w), Math.floor(plat.h));

      // Grass / bamboo moss top edge
      ctx.fillStyle = this.currentZone.theme === 'waterfall' ? '#0284c7' : '#15803d';
      ctx.fillRect(Math.floor(plat.x), Math.floor(plat.y), Math.floor(plat.w), 3);
    }

    // 3. Portals
    for (const portal of this.currentZone.portals) {
      const pGlow = Math.sin(this.animTimer * 5) * 0.15 + 0.3;
      ctx.fillStyle = `rgba(56, 189, 248, ${pGlow})`;
      ctx.fillRect(portal.x, portal.y, portal.w, portal.h);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.strokeRect(portal.x, portal.y, portal.w, portal.h);
    }

    // 4. Interactive Objects
    for (const obj of this.currentZone.interactiveObjects) {
      PixelRenderer.renderInteractive(ctx, obj, this.animTimer);
    }

    // 5. NPCs
    for (const npc of this.currentZone.npcs) {
      PixelRenderer.renderNPC(ctx, npc, this.animTimer);
    }

    // 6. Enemies
    for (const enemy of this.currentZone.enemies) {
      if (enemy.hp > 0) {
        PixelRenderer.renderEnemy(ctx, enemy, this.animTimer);
      }
    }

    // 6.5. Dropped Items (EXP Orbs, Potions, Armor, Shards)
    for (const item of this.droppedItems) {
      const bobY = Math.sin(this.animTimer * 5 + item.x) * 3;
      ctx.save();
      ctx.translate(Math.floor(item.x), Math.floor(item.y + bobY));

      if (item.type === 'exp_orb') {
        // Glowing cyan/gold EXP orb
        ctx.fillStyle = 'rgba(250, 204, 21, 0.35)';
        ctx.beginPath();
        ctx.arc(0, -6, 9, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(0, -6, 4.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-1, -7.5, 1.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (item.type === 'armor_drop') {
        // Shield / Armor pickup
        ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.beginPath();
        ctx.arc(0, -10, 13, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.roundRect(-8, -18, 16, 16, 4);
        ctx.fill();

        ctx.font = '10px serif';
        ctx.textAlign = 'center';
        ctx.fillText('🛡', 0, -6);
      } else if (item.type === 'upgrade_shard') {
        // Sparkling Upgrade Shard
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.moveTo(0, -18);
        ctx.lineTo(6, -9);
        ctx.lineTo(0, 0);
        ctx.lineTo(-6, -9);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#f3e8ff';
        ctx.beginPath();
        ctx.arc(0, -9, 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Bread / Potion
        ctx.fillStyle = item.type === 'bread' ? '#ea580c' : '#16a34a';
        ctx.beginPath();
        ctx.roundRect(-6, -14, 12, 12, 3);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = '9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(item.type === 'bread' ? '🍞' : '🧪', 0, -5);
      }

      ctx.restore();
    }

    // 7. Player (Hoàng Minh Bình Khôi / La Thanh Thọ / Ryomen Sukuna 32x32)
    PixelRenderer.renderPlayer(
      ctx,
      this.player.x,
      this.player.y,
      this.player.state,
      this.player.direction,
      this.animTimer,
      this.player.invincibleTimer > 0,
      this.player.isDashing,
      this.playerSpeechBubble,
      this.stats.characterSkin === 'sukuna' || this.stats.isAwakened || this.isMalevolentShrineActive
    );

    // 8. Particles
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      if (p.rotation !== undefined) {
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      } else {
        ctx.fillRect(Math.floor(p.x), Math.floor(p.y), p.size, p.size);
      }
      ctx.restore();
    }

    // 9. Damage Popup Numbers
    for (const d of this.damageNumbers) {
      const alpha = Math.max(0, d.life / d.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.font = d.isCrit ? 'bold 14px monospace' : '11px monospace';
      ctx.fillStyle = d.color;
      ctx.textAlign = 'center';
      ctx.fillText(d.value === 0 ? 'LEVEL UP!' : d.value.toString(), d.x, d.y);
      ctx.restore();
    }

    // 10. Winter Shibuya - Hồi Quang Visual Filter & Neon Borders
    if (this.stats.isHoiQuangActive) {
      ctx.save();
      ctx.fillStyle = 'rgba(15, 23, 42, 0.35)';
      ctx.fillRect(this.cameraX, this.cameraY, this.screenWidth, this.screenHeight);
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 4;
      ctx.strokeRect(this.cameraX + 4, this.cameraY + 4, this.screenWidth - 8, this.screenHeight - 8);
      ctx.restore();
    }

    // 11. Calligraphy text on snow after Tuyết Trắng Chôn Tên
    if (this.stats.hasUsedTuyếtTrắng) {
      ctx.save();
      ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
      ctx.font = 'bold 11px serif';
      ctx.textAlign = 'center';
      ctx.fillText('Minh Khôi — Chưa Giao', this.player.x, this.player.y + 16);
      ctx.restore();
    }

    // 12. Ngục Môn Cương: Cửa Tuyết Không Mở Lại (Black Frozen Gate)
    if (this.stats.ngucMonTimer > 0) {
      ctx.save();
      const gateX = this.player.x - 36;
      const gateY = this.player.y - 130;
      ctx.fillStyle = '#020617';
      ctx.fillRect(gateX, gateY, 72, 130);
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 3;
      ctx.strokeRect(gateX, gateY, 72, 130);

      // Chains
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(gateX, gateY);
      ctx.lineTo(gateX + 72, gateY + 130);
      ctx.moveTo(gateX + 72, gateY);
      ctx.lineTo(gateX, gateY + 130);
      ctx.stroke();

      ctx.fillStyle = '#f87171';
      ctx.font = 'bold 12px "Be Vietnam Pro", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('NGỤC MÔN CƯƠNG', this.player.x, gateY - 18);
      ctx.fillStyle = '#fde047';
      ctx.font = 'bold 11px monospace';
      ctx.fillText(`[XÉ TRANH]: ${this.stats.ngucMonTimer.toFixed(1)}s`, this.player.x, gateY - 4);
      ctx.restore();
    }

    // 13. Dynamic Steel Cable Wires (Lục Triều Dư giăng cáp thép)
    for (const npc of this.currentZone.npcs) {
      if (npc.isCombatant && npc.state === 'cable_strike') {
        const target = this.currentZone.enemies.find(e => e.hp > 0 && Math.abs(e.x - npc.x) < 400);
        if (target) {
          ctx.save();
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2.5;
          ctx.shadowColor = '#0284c7';
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.moveTo(npc.x + (npc.direction || 1) * 12, npc.y - 24);
          ctx.lineTo(target.x, target.y - target.h / 2);
          ctx.stroke();
          ctx.restore();
        }
      }
    }

    // 14. Ice Tomb Visual when Khôi is Sealed by 3 Chú Linh / Tuyết Trắng
    if (this.stats.isSealedInIce) {
      ctx.save();
      const tombX = this.player.x - 22;
      const tombY = this.player.y - 56;
      ctx.fillStyle = 'rgba(186, 230, 253, 0.45)';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(tombX, tombY, 44, 60, 6);
      ctx.fill();
      ctx.stroke();

      // Crystalline runes
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('BĂNG PHONG ẤN', this.player.x, tombY - 8);
      ctx.fillStyle = '#fde047';
      ctx.fillText(`[TẤN CÔNG ĐỂ PHÁ]: ${this.stats.iceTombTimer.toFixed(1)}s`, this.player.x, tombY + 70);
      ctx.restore();
    }

    // 15. Seal Warning Banner (Ba Chú Linh thi triển phong ấn)
    if (this.stats.sealWarningText && this.stats.sealWarningTimer && this.stats.sealWarningTimer > 0) {
      ctx.save();
      const bannerX = this.cameraX + this.screenWidth / 2;
      const bannerY = this.cameraY + 54;
      ctx.font = 'bold 12px "Be Vietnam Pro", sans-serif';
      const textW = ctx.measureText(this.stats.sealWarningText).width + 36;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(bannerX - textW / 2, bannerY - 14, textW, 28, 6);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#fca5a5';
      ctx.textAlign = 'center';
      ctx.fillText(this.stats.sealWarningText, bannerX, bannerY + 4);
      ctx.restore();
    }

    // 16. Kill Quote Banner: “Tuyết rơi phủ hết. Nhưng vết máu này… tao không lau.”
    if (this.stats.killQuote && this.stats.killQuoteTimer && this.stats.killQuoteTimer > 0) {
      ctx.save();
      const bannerX = this.cameraX + this.screenWidth / 2;
      const bannerY = this.cameraY + 92;
      ctx.font = 'italic bold 13px "Be Vietnam Pro", serif';
      const textW = ctx.measureText(this.stats.killQuote).width + 36;
      ctx.fillStyle = 'rgba(2, 6, 23, 0.95)';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(bannerX - textW / 2, bannerY - 14, textW, 30, 6);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#f8fafc';
      ctx.textAlign = 'center';
      ctx.fillText(this.stats.killQuote, bannerX, bannerY + 5);
      ctx.restore();
    }

    // 17. ANIME VISUAL: BÀNH TRƯỚNG LÃNH ĐỊA — PHỤC MA NGỰ TRÙ TỬ (OPEN DOMAIN EXPANSION)
    if (this.isMalevolentShrineActive) {
      ctx.save();
      const sX = this.malevolentShrineX;
      const sY = this.malevolentShrineY;
      const r = this.domainRadius;

      // Atmosphere: Oppressive blood-red lighting casting a wide shadow over entire 2D screen
      const grad = ctx.createRadialGradient(sX, sY - 120, 50, sX, sY - 120, r);
      grad.addColorStop(0, 'rgba(127, 29, 29, 0.45)');
      grad.addColorStop(0.7, 'rgba(69, 10, 10, 0.55)');
      grad.addColorStop(1, 'rgba(15, 5, 8, 0.65)');
      ctx.fillStyle = grad;
      ctx.fillRect(this.cameraX, this.cameraY, this.screenWidth, this.screenHeight);

      // 1. OPEN DOMAIN GROUND PERIMETER: NO PHYSICAL BARRIER DOME OR WALLS!
      // Defined purely by a massive circular radius marked on the ground with glowing demonic runes and skulls
      ctx.save();
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#dc2626';
      ctx.shadowBlur = 12;

      // Glowing crimson radius boundary lines on ground
      ctx.beginPath();
      ctx.moveTo(sX - r, sY + 2);
      ctx.lineTo(sX + r, sY + 2);
      ctx.stroke();

      // Border markers at perimeter ends (sX - r and sX + r)
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(sX - r - 4, sY - 18, 8, 20);
      ctx.fillRect(sX + r - 4, sY - 18, 8, 20);

      // Carved Demonic Runes and Skulls along the terrain
      const skullSpacing = 48;
      const skullCount = Math.floor((r * 2) / skullSpacing);
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';

      for (let i = 0; i < skullCount; i++) {
        const markerX = sX - r + i * skullSpacing + ((i % 2) * 6);
        const markerY = this.getGroundYAt(markerX, sY);

        // Weathered skull carved into terrain
        ctx.fillStyle = '#e2e8f0';
        ctx.beginPath();
        ctx.arc(markerX, markerY - 4, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#450a0a';
        ctx.fillRect(markerX - 1.5, markerY - 5, 1, 1);
        ctx.fillRect(markerX + 0.5, markerY - 5, 1, 1);

        // Demonic Runes glow beneath skulls
        if (i % 2 === 0) {
          ctx.fillStyle = 'rgba(239, 68, 68, 0.7)';
          ctx.fillText('†', markerX, markerY + 9);
        } else {
          ctx.fillStyle = 'rgba(185, 28, 28, 0.7)';
          ctx.fillText('§', markerX, markerY + 9);
        }
      }
      ctx.restore();

      // 2. CENTRAL STRUCTURE: WEATHERED OMINOUS SHRINE MADE OF BONE AND STONE STANDING FREELY
      // Pixel art Terraria style bone pedestal
      ctx.fillStyle = '#f1f5f9';
      for (let i = -80; i <= 80; i += 12) {
        ctx.beginPath();
        ctx.arc(sX + i, sY - 6, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(sX + i - 2, sY - 7, 2, 2);
        ctx.fillRect(sX + i + 1, sY - 7, 2, 2);
        ctx.fillStyle = '#f1f5f9';
      }

      // Bone & stone shrine pillars
      ctx.fillStyle = '#78716c'; // Weathered stone
      ctx.fillRect(sX - 64, sY - 115, 14, 108);
      ctx.fillRect(sX + 50, sY - 115, 14, 108);
      ctx.fillStyle = '#a8a29e'; // Bone highlights
      ctx.fillRect(sX - 32, sY - 115, 10, 108);
      ctx.fillRect(sX + 22, sY - 115, 10, 108);

      // Central cavernous mouth opening
      ctx.fillStyle = '#2b0606';
      ctx.beginPath();
      ctx.ellipse(sX, sY - 52, 40, 32, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Demonic teeth lining the mouth
      ctx.fillStyle = '#f8fafc';
      for (let f = -32; f <= 32; f += 8) {
        // Upper teeth
        ctx.beginPath();
        ctx.moveTo(sX + f - 3, sY - 74);
        ctx.lineTo(sX + f + 3, sY - 74);
        ctx.lineTo(sX + f, sY - 60);
        ctx.closePath();
        ctx.fill();
        // Lower teeth
        ctx.beginPath();
        ctx.moveTo(sX + f - 3, sY - 30);
        ctx.lineTo(sX + f + 3, sY - 30);
        ctx.lineTo(sX + f, sY - 44);
        ctx.closePath();
        ctx.fill();
      }

      // Weathered stone roofs (Terraria stepped style)
      ctx.fillStyle = '#1c1917';
      ctx.beginPath();
      ctx.moveTo(sX - 98, sY - 110);
      ctx.lineTo(sX + 98, sY - 110);
      ctx.lineTo(sX + 76, sY - 130);
      ctx.lineTo(sX - 76, sY - 130);
      ctx.closePath();
      ctx.fill();

      // Second tier roof
      ctx.beginPath();
      ctx.moveTo(sX - 78, sY - 134);
      ctx.lineTo(sX + 78, sY - 134);
      ctx.lineTo(sX + 52, sY - 158);
      ctx.lineTo(sX - 52, sY - 158);
      ctx.closePath();
      ctx.fill();

      // Curved Horns carved from ancient bone
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(sX - 98, sY - 110);
      ctx.quadraticCurveTo(sX - 120, sY - 128, sX - 110, sY - 146);
      ctx.moveTo(sX + 98, sY - 110);
      ctx.quadraticCurveTo(sX + 120, sY - 128, sX + 110, sY - 146);
      ctx.stroke();

      // Biển hiệu Hán tự: 伏魔御厨子 (Open Domain Malevolent Shrine)
      ctx.fillStyle = '#fca5a5';
      ctx.font = 'bold 15px "Be Vietnam Pro", serif';
      ctx.textAlign = 'center';
      ctx.fillText('伏魔御厨子 (PHỤC MA NGỰ TRÙ TỬ - OPEN DOMAIN)', sX, sY - 172);

      // 3. HIGH-FREQUENCY STORM OF HUNDREDS OF OVERLAPPING MICRO-SLASHES OCCURRING SIMULTANEOUSLY
      for (const ms of this.domainMicroSlashes) {
        const slashAlpha = Math.min(1, ms.life / ms.maxLife);
        ctx.save();
        ctx.globalAlpha = slashAlpha;
        ctx.strokeStyle = ms.color;
        ctx.lineWidth = ms.width;
        ctx.beginPath();
        ctx.moveTo(ms.x1, ms.y1);
        ctx.lineTo(ms.x2, ms.y2);
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();
    }

    // --- RENDER SUKUNA TECHNIQUE SIMULATION PARTICLES & WAVEFRONTS ---
    // 17.1. Dismantle (Bát): Razor-sharp distortion slash line + faint crimson-black particle trail
    for (const d of this.dismantleSlashes) {
      const alpha = Math.min(1, d.life / d.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;

      // Faint crimson-black outer distortion glow
      ctx.strokeStyle = 'rgba(220, 38, 38, 0.45)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(d.x1, d.y1);
      ctx.lineTo(d.x2, d.y2);
      ctx.stroke();

      // Razor-sharp near-invisible inner line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(d.x1, d.y1);
      ctx.lineTo(d.x2, d.y2);
      ctx.stroke();

      ctx.restore();
    }

    // 17.2. Cleave (Giải): Heavy adaptive slashing wave scaling in impact size
    for (const c of this.cleaveImpacts) {
      const alpha = Math.min(1, c.life / c.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(c.x, c.y);
      ctx.scale(c.scale, c.scale);

      // Heavy adaptive red arc wave
      ctx.strokeStyle = '#e11d48';
      ctx.lineWidth = 5;
      ctx.shadowColor = '#be123c';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(0, 0, Math.max(c.w, c.h) / 2, -Math.PI * 0.4, Math.PI * 0.4);
      ctx.stroke();

      // Cross cleavage cut
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-c.w / 3, -c.h / 3);
      ctx.lineTo(c.w / 3, c.h / 3);
      ctx.moveTo(c.w / 3, -c.h / 3);
      ctx.lineTo(-c.w / 3, c.h / 3);
      ctx.stroke();

      ctx.restore();
    }

    // 17.3. Fuga (Hỏa / Khai): Condensed intensely bright orange-red fire arrow projectile
    for (const proj of this.fugaProjectiles) {
      ctx.save();
      ctx.translate(proj.x, proj.y);
      const angle = Math.atan2(proj.vy, proj.vx);
      ctx.rotate(angle);

      // Intensely bright fiery arrow core
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-12, -2, 24, 4);

      // Outer thermal glow
      ctx.fillStyle = '#f97316';
      ctx.fillRect(-16, -4, 30, 8);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-20, -6, 36, 12);

      // Arrowhead
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.moveTo(14, 0);
      ctx.lineTo(2, -6);
      ctx.lineTo(2, 6);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }

    // 17.4. Fuga Thermal Blasts: Massive localized thermal blast wave filling wide radius with pixelated flames
    for (const blast of this.fugaThermalBlasts) {
      const alpha = Math.max(0, blast.life / blast.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;

      // Outer thermal shockwave ring
      ctx.strokeStyle = '#f97316';
      ctx.lineWidth = 6;
      ctx.shadowColor = '#ea580c';
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(blast.x, blast.y, blast.currentRadius, 0, Math.PI * 2);
      ctx.stroke();

      // Inner heat wave
      ctx.fillStyle = 'rgba(239, 68, 68, 0.25)';
      ctx.beginPath();
      ctx.arc(blast.x, blast.y, blast.currentRadius * 0.75, 0, Math.PI * 2);
      ctx.fill();

      // Pixelated flame clusters
      ctx.fillStyle = '#fef08a';
      for (let a = 0; a < Math.PI * 2; a += Math.PI / 6) {
        const fx = blast.x + Math.cos(a) * (blast.currentRadius * 0.85);
        const fy = blast.y + Math.sin(a) * (blast.currentRadius * 0.85);
        ctx.fillRect(fx - 4, fy - 4, 8, 8);
      }

      ctx.restore();
    }

    // 18. ANIME VISUAL: NHÁT CHÉM CẮT ĐỨT THẾ GIAN (WORLD-CUTTING SLASH)
    if (this.stats.chantTimer && this.stats.chantTimer > 0) {
      ctx.save();
      const chantAlpha = Math.min(1, this.stats.chantTimer * 2.5);
      ctx.fillStyle = `rgba(216, 180, 254, ${chantAlpha})`;
      ctx.font = 'bold 13px "Be Vietnam Pro", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(this.stats.chantText || 'Niệm chú: [ Long Lân • Phản Lý • Song Tinh ]', this.player.x, this.player.y - 72);

      // Vòng tròn thủ ấn Enmaten phát sáng
      ctx.strokeStyle = `rgba(168, 85, 247, ${chantAlpha})`;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(this.player.x, this.player.y - 30, 26, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    if (this.worldSlashEffectTimer > 0) {
      ctx.save();
      const fractureAlpha = Math.min(1, this.worldSlashEffectTimer * 2);
      // Vết nứt không gian xé toạc màn hình
      ctx.strokeStyle = `rgba(216, 180, 254, ${fractureAlpha})`;
      ctx.lineWidth = 8;
      ctx.shadowColor = '#a855f7';
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.moveTo(this.cameraX, this.cameraY + this.screenHeight);
      ctx.lineTo(this.cameraX + this.screenWidth, this.cameraY);
      ctx.stroke();

      // Lõi hư không đen tuyền bên trong
      ctx.strokeStyle = `rgba(0, 0, 0, ${fractureAlpha})`;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(this.cameraX, this.cameraY + this.screenHeight);
      ctx.lineTo(this.cameraX + this.screenWidth, this.cameraY);
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'black 16px "Be Vietnam Pro", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('世界を断つ斬撃 (NHÁT CHÉM CẮT ĐỨT THẾ GIAN)', this.cameraX + this.screenWidth / 2, this.cameraY + this.screenHeight / 2 - 30);
      ctx.restore();
    }

    // 19. ANIME VISUAL: TÁO (KAMINO) — ■ 開 (FUGA)
    if (this.player.state === 'skill_kamino') {
      ctx.save();
      ctx.fillStyle = '#fde047';
      ctx.font = 'bold 22px serif';
      ctx.textAlign = 'center';
      ctx.shadowColor = '#ea580c';
      ctx.shadowBlur = 15;
      ctx.fillText('■ 開 (FUGA)', this.player.x, this.player.y - 65);
      ctx.restore();
    }

    // 20. ANIME VISUAL: JOGO — CÁI QUAN THIẾT VI SƠN, CỰC PHIÊN VẪN, LÃNH ĐỊA TRIỂN DUYÊN
    for (const enemy of this.currentZone.enemies) {
      if (enemy.hp <= 0) continue;

      // Cái Quan Thiết Vi Sơn (Gaikan Tecchisen)
      if (enemy.isGaikanTecchisenActive) {
        ctx.save();
        ctx.fillStyle = 'rgba(124, 45, 18, 0.35)';
        ctx.fillRect(this.cameraX, this.cameraY, this.screenWidth, this.screenHeight);

        // Vết nứt dung nham nóng đỏ
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3;
        for (let v = 0; v < this.screenWidth; v += 120) {
          ctx.beginPath();
          ctx.moveTo(this.cameraX + v, this.cameraY + this.screenHeight - 12);
          ctx.lineTo(this.cameraX + v + 60, this.cameraY + this.screenHeight - 6);
          ctx.stroke();
        }
        ctx.fillStyle = '#f97316';
        ctx.font = 'bold 14px "Be Vietnam Pro", serif';
        ctx.textAlign = 'center';
        ctx.fillText('蓋棺鉄囲山 (CÁI QUAN THIẾT VI SƠN)', this.cameraX + this.screenWidth / 2, this.cameraY + 36);
        ctx.restore();
      }

      // Cực Phiên: Vẫn (Maximum: Meteor)
      if (enemy.isMaximumMeteorCasting && enemy.meteorX !== undefined && enemy.meteorY !== undefined) {
        ctx.save();
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2.5;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.arc(enemy.meteorX, enemy.meteorY, 70, 0, Math.PI * 2);
        ctx.stroke();

        const progress = 1 - (enemy.meteorTimer || 0) / 1.6;
        const meteorCurrY = (enemy.meteorY - 280) + progress * 280;
        ctx.fillStyle = '#ea580c';
        ctx.beginPath();
        ctx.arc(enemy.meteorX, meteorCurrY, 30, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(enemy.meteorX - 6, meteorCurrY - 6, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Lãnh Địa Triển Duyên (Domain Amplification)
      if (enemy.isDomainAmplificationActive) {
        ctx.save();
        ctx.strokeStyle = 'rgba(250, 204, 21, 0.75)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(enemy.x, enemy.y - enemy.h / 2, enemy.w + 14, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = 'rgba(250, 204, 21, 0.15)';
        ctx.fill();
        ctx.restore();
      }
    }

    ctx.restore();
  }

  /**
   * Render Parallax Background according to Zone Theme
   */
  private renderParallaxBackground(ctx: CanvasRenderingContext2D) {
    const camX = this.cameraX;

    if (this.currentZone.theme === 'village') {
      // Sky
      const skyGrad = ctx.createLinearGradient(0, 0, 0, this.currentZone.height);
      skyGrad.addColorStop(0, '#0f172a');
      skyGrad.addColorStop(0.6, '#1e293b');
      skyGrad.addColorStop(1, '#334155');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(camX, 0, this.screenWidth, this.currentZone.height);

      // Distant mountains (0.2 parallax)
      ctx.fillStyle = '#1e293b';
      for (let i = 0; i < 8; i++) {
        const mx = i * 350 - (camX * 0.2) % 350;
        ctx.beginPath();
        ctx.moveTo(mx, 500);
        ctx.lineTo(mx + 175, 260);
        ctx.lineTo(mx + 350, 500);
        ctx.fill();
      }

      // Bamboo silhouettes (0.5 parallax)
      ctx.fillStyle = '#064e3b';
      for (let i = 0; i < 20; i++) {
        const bx = i * 140 - (camX * 0.5) % 140;
        ctx.fillRect(bx, 320, 6, 200);
        ctx.fillRect(bx - 12, 340, 24, 4);
        ctx.fillRect(bx - 10, 390, 20, 4);
      }
    } else if (this.currentZone.theme === 'mountain') {
      // Misty mountain pass
      ctx.fillStyle = '#090d16';
      ctx.fillRect(camX, 0, this.screenWidth, this.currentZone.height);

      ctx.fillStyle = '#1e1b4b';
      for (let i = 0; i < 7; i++) {
        const mx = i * 400 - (camX * 0.25) % 400;
        ctx.beginPath();
        ctx.moveTo(mx, 500);
        ctx.lineTo(mx + 200, 220);
        ctx.lineTo(mx + 400, 500);
        ctx.fill();
      }
    } else if (this.currentZone.theme === 'waterfall') {
      // Khe Vằn 100-tier waterfall background
      ctx.fillStyle = '#030712';
      ctx.fillRect(camX, 0, this.screenWidth, this.currentZone.height);

      // Water torrent column
      const waterFlow = (this.animTimer * 400) % 60;
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(camX + 300, 0, 160, this.currentZone.height);
      ctx.fillStyle = '#e0f2fe';
      for (let i = 0; i < 15; i++) {
        ctx.fillRect(camX + 320 + (i % 3) * 40, i * 40 + waterFlow, 4, 25);
      }
    } else {
      // Midnight playground (3 AM)
      ctx.fillStyle = '#050505';
      ctx.fillRect(camX, 0, this.screenWidth, this.currentZone.height);

      // Blood moon in background
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.arc(camX + this.screenWidth - 120, 100, 36, 0, Math.PI * 2);
      ctx.fill();

      // Suspended cables of Lục Triều Dư
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(camX, 220);
      ctx.lineTo(camX + this.screenWidth, 280);
      ctx.stroke();
    }
  }

  /**
   * Save & Load LocalStorage Game State
   */
  public saveGame() {
    try {
      const state: SavedGameState = {
        version: 1,
        timestamp: Date.now(),
        currentZoneId: this.currentZone.id,
        playerStats: this.stats,
        inventory: this.inventory,
        quests: this.quests,
        unlockedLore: this.unlockedLore,
        checkpoint: {
          zoneId: this.currentZone.id,
          x: this.player.x,
          y: this.player.y,
        },
      };
      localStorage.setItem('binh_lieu_vuong_save', JSON.stringify(state));
    } catch {
      // localStorage may fail in restricted iframes
    }
  }

  public loadGame(): boolean {
    try {
      const raw = localStorage.getItem('binh_lieu_vuong_save');
      if (!raw) return false;
      const state = JSON.parse(raw) as SavedGameState;
      if (state && state.version === 1) {
        this.stats = state.playerStats;
        this.inventory = state.inventory;
        this.quests = state.quests;
        this.unlockedLore = state.unlockedLore;
        if (this.zones[state.currentZoneId]) {
          this.currentZone = this.zones[state.currentZoneId];
          this.player.x = state.checkpoint.x || this.currentZone.playerStartX;
          this.player.y = state.checkpoint.y || this.currentZone.playerStartY;
          for (const npc of this.currentZone.npcs) {
            npc.y = this.getGroundYAt(npc.x, npc.y);
          }
          for (const enemy of this.currentZone.enemies) {
            enemy.y = this.getGroundYAt(enemy.x, enemy.y);
          }
        }
        return true;
      }
    } catch {
      // Error reading save
    }
    return false;
  }

  public resetGame() {
    localStorage.removeItem('binh_lieu_vuong_save');
    this.zones = JSON.parse(JSON.stringify(ZONES));
    this.currentZone = this.zones.zone_ban_cau;
    for (const npc of this.currentZone.npcs) {
      npc.y = this.getGroundYAt(npc.x, npc.y);
    }
    for (const enemy of this.currentZone.enemies) {
      enemy.y = this.getGroundYAt(enemy.x, enemy.y);
    }
    this.player.x = 100;
    this.player.y = 440;
    this.droppedItems = [];
    this.stats = {
      level: 1,
      xp: 0,
      maxXp: 100,
      hp: 150,
      maxHp: 150,
      qi: 100,
      maxQi: 100,
      attackPower: 35,
      defense: 8,
      armor: 400,
      maxArmor: 400,
      armorDurability: 100,
      maxArmorDurability: 100,
      equippedArmorName: 'Chiến Giáp Tuyết Biên Phòng',
      // Tiến trình 11 Arc chính thức theo lore
      currentArc: 1,
      arcTitle: 'Arc 1: Nguồn Gốc Của Những Người Giữ Làng',
      critRate: 0.75,
      critDamageMultiplier: 2.5,
      weaponLevel: 1,
      weaponElement: 'ice',
      upgradeShards: 5,
      waveNumber: 1,
      totalWaves: 5,
      monstersRemainingInArc: 100,
      totalMonstersPerArc: 100,
      equippedWeapon: 'than_vu_giai',
      equippedHelmet: 'Mũ Giáp Thần Vũ',
      equippedChest: 'Chiến Giáp Thần Vũ',
      equippedPants: 'Giáp Quần Chí Tôn',
      equippedBoots: 'Chiến Hài Phong Lôi',
      equippedHealing: 'Đại Hoàn Đan (Cấp Cứu 100% HP)',
      hotbarSlots: [
        { id: 'hotbar_weapon', name: 'Thần Vũ Giải (Kamutoke)', type: 'weapon', icon: '⚡', equipped: true },
        { id: 'hotbar_helmet', name: 'Mũ Giáp Thần Vũ', type: 'helmet', icon: '👑', equipped: true },
        { id: 'hotbar_chest', name: 'Giáp Thân Thần Vũ', type: 'chest', icon: '🥋', equipped: true },
        { id: 'hotbar_pants', name: 'Giáp Quần Chí Tôn', type: 'pants', icon: '👖', equipped: true },
        { id: 'hotbar_boots', name: 'Giáp Chân Phong Lôi', type: 'boots', icon: '👢', equipped: true },
        { id: 'hotbar_healing', name: 'Đại Hoàn Đan', type: 'healing', icon: '💊', count: 99 },
      ],
      isAwakened: false,
      awakenedTimer: 0,
      hpRegenTimer: 0,
      noStacks: 0,
      hasBangGiap: false,
      stillTimer: 0,
      isHoiQuangActive: false,
      hoiQuangTimer: 0,
      hasUsedTuyếtTrắng: false,
      isSealedInIce: false,
      iceTombTimer: 0,
      ngucMonTimer: 0,
      hasButBang: false,
      killCount: 0,
      neonBuffTimer: 0,
      killQuote: null,
      killQuoteTimer: 0,
      sealWarningText: null,
      sealWarningTimer: 0,
      objectiveTitle: 'A01-E001: Đứa Trẻ Mồ Côi Bản Cáu (1977)',
      objectiveDetail: 'Gió tuyết rét buốt! Hãy nhặt 3 bó củi khô rừng Lục Nà (0/3) để nhóm bếp than sưởi ấm chòi lá.',
      woodCount: 0,
      isHearthLit: false,
      beastsDefeated: 0,
      totalBeasts: 4,
      skillCooldowns: {
        dismantle: 0,
        cleave: 0,
        kamino: 0,
        shrine: 0,
        worldSlash: 0,
        kamutoke: 0,
        tuthanDotKich: 0,
        kheVanTram: 0,
        neonGay: 0,
        coiCuuThuong: 0,
        hoiQuang: 0,
        cuonTranh: 0,
        dash: 0,
      },
    };
    this.inventory = [...INITIAL_INVENTORY];
    this.quests = [...INITIAL_QUESTS];
    this.unlockedLore = LORE_ENTRIES.filter(e => e.unlockedByDefault).map(e => e.id);
  }
}
