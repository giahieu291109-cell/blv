/**
 * Canonical Lore Data for BÌNH LIÊU VƯƠNG
 * Sourced directly from the official lore text.
 */

import { DialogSequence, InventoryItem, Quest } from './types';
import { ARC_1_DIALOG_SEQUENCES, ARC_2_DIALOG_SEQUENCES, ARC_3_DIALOG_SEQUENCES, ARC_4_DIALOG_SEQUENCES, ARC_5_DIALOG_SEQUENCES, ARC_6_DIALOG_SEQUENCES, ARC_7_DIALOG_SEQUENCES, ARC_8_DIALOG_SEQUENCES, ARC_9_DIALOG_SEQUENCES, ARC_10_DIALOG_SEQUENCES, ARC_11_DIALOG_SEQUENCES } from './arcStoryData';

export interface LoreEntry {
  id: string;
  category: 'Nhân Vật' | 'Triết Lý' | 'Địa Danh' | 'Bảo Vật & Kỹ Năng' | 'Sự Kiện';
  title: string;
  subtitle?: string;
  tagline: string;
  description: string[];
  canonicalQuote?: string;
  unlockedByDefault?: boolean;
}

export const LORE_ENTRIES: LoreEntry[] = [
  {
    id: 'char_khoi',
    category: 'Nhân Vật',
    title: 'Hoàng Minh Bình Khôi',
    subtitle: 'Bình Liêu Vương (18-20 tuổi)',
    tagline: 'Vua của sự dừng — kẻ cầm Liềm Tử Thần kết thúc bằng sự bình lặng.',
    description: [
      'Sinh ra trong khu trọ Bình Liêu, bố chạy Grab, mẹ bán quán cơm. Bị bắt nạt thời niên thiếu, tự rèn luyện trong chòi lá từ năm 15 tuổi (Winter Arc 1.0).',
      'Sau trận so tài mưa bão chém gãy gậy trúc của Hoàng Cần, Khôi nhận lấy con đường “Bình” và đổi tên thành Hoàng Minh Bình Khôi.',
      'Đặc điểm: Áo khoác tactical đen bạc vai, dây chuyền bạc đeo mảnh gậy trúc gãy, khăn trắng lau liềm gấp vuông góc. Dị ứng khói thuốc lá, nghe tiếng muỗi cách 3 mét, chém 7 đường trong 1 giây.',
      'Triết lý hành động: “Mạnh nhất là lúc dừng lại được.”'
    ],
    canonicalQuote: '“Mày muốn sống thì dừng. Mày muốn chết thì bước tiếp.”',
    unlockedByDefault: true,
  },
  {
    id: 'char_can',
    category: 'Nhân Vật',
    title: 'Hoàng Cần',
    subtitle: 'Trúc Thánh — Cựu Chưởng Môn Võ Hoàng Môn',
    tagline: 'Biểu tượng của cái mềm thắng cái cứng — người đại diện cho nhánh “Giữ”.',
    description: [
      'Con nhà võ 3 đời, 40 tuổi thắng 108 cao thủ mà không đổ một giọt mồ hôi. Ẩn cư mở quán trà ngoại ô vì tâm nguyện “Võ để giữ người, không phải để giết người”.',
      'Tuyệt kỹ Hoàng Long Trấn Địa: đập gậy làm nứt sân gạch, rung chuyển trời đất.',
      'Chủ động thua Khôi trong đêm giông bão để truyền thừa nhánh Bình và giữ cho môn phái không chia rẽ. Mộ trúc sau chùa Cổ Nguyệt chỉ có khóm trúc 7 cây và tảng đá “Người giữ đường”.'
    ],
    canonicalQuote: '“Võ chia hai nhánh, một nhánh giữ người, một nhánh bình người.”',
    unlockedByDefault: true,
  },
  {
    id: 'char_tho',
    category: 'Nhân Vật',
    title: 'La Thanh Thọ',
    subtitle: 'Cụ Thọ — Trưởng Lão Thôn Bản Cáu (72 tuổi)',
    tagline: 'Chân cụt thì đi bằng gậy. Mắt mờ thì nhìn bằng lòng.',
    description: [
      'Mồ côi từ 7 tuổi, 12 tuổi nhặt được cuốn “Nam Dược Thần Hiệu” rách sau hang chùa Cổ Nguyệt để tự học bốc thuốc cứu bản.',
      '17 tuổi đi lính biên phòng, kéo 9 thương binh tại mốc 1305, mất chân trái do mìn nổ. Dựng lều tre bên Đình Lục Nà sáng dạy chữ, chiều bốc thuốc.',
      'Gậy trúc khắc 108 rãnh, mỗi rãnh tương ứng một sinh mạng được cứu.',
      'Người đã lau vết máu trên tay Khôi và đặt chữ “Bình”: “Mày không giết người. Mày bình người.”'
    ],
    canonicalQuote: '“Cần giữ người, Thọ bình người. Hiếu đập người, Khôi dừng người.”',
    unlockedByDefault: true,
  },
  {
    id: 'char_thanh',
    category: 'Nhân Vật',
    title: 'La Thanh',
    subtitle: 'Con Gái Thầy Lang — Người Giữ Khôi',
    tagline: 'Mày mạnh thì giữ. Tao yếu thì giữ mày.',
    description: [
      'Sinh năm 2008 tại Bản Cáu, cháu gái cụ Thọ. Từ 9 tuổi đã phân biệt ngải cứu và ngải dại, từ chối học bổng thành phố để ở lại chăm sóc ông.',
      'Suốt 3 tháng ròng, mỗi 5h sáng mang cơm nguội và trứng luộc để trước chòi lá của Khôi. Cõng Khôi về chữa sốt 40 độ trong đêm mưa lũ.',
      'Là người duy nhất biết trọn vẹn sự thật về trận Hoàng Cần, giữ sổ tay y tế của cụ Thọ. Cổ tay luôn đeo lá ngải cứu buộc chỉ đỏ: “Cứu người trước, giết người sau.”'
    ],
    canonicalQuote: '“Khóc xong chưa? Khóc xong thì đi học đi. Mai kiểm tra Toán.”',
    unlockedByDefault: true,
  },
  {
    id: 'char_tai_dom',
    category: 'Nhân Vật',
    title: 'Lài Phúc Tài & Chó Đốm',
    subtitle: 'Tài Dog (17 tuổi) — Cái Giữ Cuối Cùng',
    tagline: 'Cậu ơi, đừng bình nữa. Cứ giữ thôi.',
    description: [
      'Người Tày quê Lạng Sơn, cháu trai duy nhất gọi Khôi bằng “cậu”. Bị bệnh tim bẩm sinh, nuôi chú chó cỏ què một chân tên Đốm.',
      'Khôi tặng Tài gậy trúc mỗi năm dù Tài không tập võ: “Vì mày không cần học. Mày chỉ cần sống.”',
      'Năm 2065, Tài qua đời vì bộc phát tim, khiến Khôi đau đớn treo liềm vào két sắt, thề ngừng “bình” và giải tán phe phái.',
      'Sau khi Tài mất, Đốm nằm trước mộ 3 ngày rồi được Khôi đưa về nuôi tại cổng đình canh gác.'
    ],
    canonicalQuote: '“Thế cậu là Wolf, chạy nhanh nhưng cắn chết người.”',
    unlockedByDefault: true,
  },
  {
    id: 'char_du',
    category: 'Nhân Vật',
    title: 'Lục Triều Dư',
    subtitle: 'Thằng Treo Dây — Phe “Kéo” (32 tuổi)',
    tagline: 'Mày không cần bình nữa. Lần này để tao bình mày.',
    description: [
      'Người Nùng, cựu đặc công biên phòng mốc 1088, gãy 3 đốt sống. Thường treo mình trên dây cáp giữa 2 vách đá Khe Vằn rèn cơ lưng.',
      'Đại diện cho phe “Kéo”: không phân tranh Giữ hay Bình, hễ thấy ai chìm xuống vực sâu thì dùng dây kéo lên.',
      'Năm 2068, chính Dư gõ 108 nhịp vào khối đá Rubik Ngục Môn Cương để kéo Khôi trở lại, kề vai tác chiến đối đầu Chu Mạnh Hiếu.'
    ],
    canonicalQuote: '“Giết xong thì về. Ngồi lại ở cổng. Tao canh cho.”',
    unlockedByDefault: false,
  },
  {
    id: 'char_hieu',
    category: 'Nhân Vật',
    title: 'Chu Mạnh Hiếu',
    subtitle: 'Boss Thực Sự — Kẻ Luyện Hoán Não (35 tuổi)',
    tagline: 'Kẻ giật dây 3 chú linh và cướp đoạt thân xác Lài Phúc Tài.',
    description: [
      'Đệ tử tà môn đời thứ 9 của Hoàng Môn, bị trục xuất năm 2049 vì luyện tà thuật Hoán Não (mổ sọ tráo não người chết sang người sống).',
      'Đêm Tài mất, Hiếu đào mộ tráo não Tài vào đầu mình để có huyết thống với Khôi, dùng khuôn mặt Tài để lừa gạt tiền bạc và giật dây 3 chú linh phong ấn Khôi vào Rubik.',
      'Sở hữu “Tay Thép của Thảo” gõ 108 nhịp vào không khí và tà thuật hút vía giữ xác.'
    ],
    canonicalQuote: '“Cậu ơi, cứu cháu đi!... Nhưng não nó vẫn nhớ cậu, nên nó khóc đấy.”',
    unlockedByDefault: false,
  },
  {
    id: 'char_hieu_khuyet_tat',
    category: 'Nhân Vật',
    title: 'Chu Mạnh Hiếu — Bản Khuyết Tật',
    subtitle: 'Boss Dạng 2: Chu Hiếu Què · Lôi Ảnh Thủ (Đứa Con Rắn)',
    tagline: '“Cái gì không giết được tao thì làm tao mạnh hơn.”',
    description: [
      '• Khuyết tật: Sinh ra chân phải ngắn hơn chân trái 2cm, đi hơi khập khiễng. Hồi nhỏ bị bạn gọi là “Hiếu què”. Hiếu không cãi, chỉ tập đứng một chân trên cột điện 30 phút mỗi ngày. Sau này mới thành Lôi Ảnh Thủ — đứng một chân cũng đấm gãy xương được.',
      '• Hâm mộ Nữ Thánh Rắn: Nữ Thánh Rắn là truyền thuyết ở Móng Cái, người mặc áo xanh, nuôi rắn hổ mang, chuyên trị bệnh cho dân nghèo. Hiếu 9 tuổi từng được bả cứu khi bị ong đốt suýt chết. Từ đó treo ảnh bả trong cặp, ai chê bả là Hiếu đấm. Sẹo tay phải hình tia sét là do bả lấy nọc rắn vẽ lên lúc chữa.',
      '• Yêu ông thể dục tên Huỳnh: Thầy Huỳnh dạy thể dục cấp 2, người thấp lùn, bụng bia, nhưng chạy 100m vẫn 11s. Hiếu yêu như kiểu thần tượng. Thầy Huỳnh từng bảo: “Mày què mà chạy nhanh hơn cả tao, sau này làm anh hùng đi”. Hiếu ghi nhớ cả đời. Sau này áo sát nách của Hiếu là do thầy Huỳnh cho.',
      '• Ăn rỉ chim + liếm chân: Cấp 1 Hiếu nghèo, đói quá từng liếm rỉ sắt trên xích cổng trường. Bị bạn thấy, gọi là “thằng ăn rỉ chim”. Hiếu mặc kệ, còn liếm luôn chân mình sau khi đá bóng về vì “muối sạch, không bỏ phí”. Thành giai thoại cả lớp: “Cái gì không giết được tao thì làm tao mạnh hơn”.',
      '• Cởi áo ra cân 3 lớp – cấp 1: Lớp 5, ba thằng lớp 6 chặn đường đòi tiền. Hiếu cởi áo ra, để lộ sẹo tia sét, đứng một chân giữa sân. Đánh tay không, quật ngã cả 3 bằng đòn vật do tự xem trên YouTube. Từ đó cả trường gọi là “Hiếu điên”.',
      '• Kết nối với lore Bình Liêu: Thầy Huỳnh đưa Hiếu xuống Bình Liêu gặp cụ Thọ. Cụ Thọ nhìn Hiếu rồi nói: “Mày vừa điên vừa què, nhưng tâm không què. Đi theo ta”. Hiếu theo cụ Thọ học 2 năm, gặp Khôi ở nóc chợ. Hai đứa đánh 7 đêm, rồi Hiếu kể hết mấy chuyện xấu hổ cấp 1. Khôi chỉ cười: “Tao cũng từng liếm chân sau khi chạy 10km. Bình thường”.',
      '• Biệt danh: Dân gọi là Chu Hiếu Què (gọi trước mặt là ăn đấm), Nữ Thánh Rắn thì gọi là “đứa con rắn của ta”.'
    ],
    canonicalQuote: '“Đứng một chân đấm gãy xương. Cái gì không giết được tao thì làm tao mạnh hơn!”',
    unlockedByDefault: false,
  },
  {
    id: 'shibuya_arc',
    category: 'Sự Kiện',
    title: 'Winter Shibuya Incident — Băng Dưới Đèn Neon',
    subtitle: 'Tháng 12, Ngã tư Shibuya 109 phủ tuyết trắng',
    tagline: 'Tuyết rơi không ngừng, phố đèn neon mất điện và tiếng còi xe cứu thương 3:17 sáng.',
    description: [
      '• [Tuyết Phủ 109]: Đứng yên 2s trong tuyết nhận [Băng Giáp] (-25% sát thương vật lý). “Đứng càng lâu càng lạnh, nhưng lạnh thì không ai đọc được mắt mày.”',
      '• [Neon Gãy]: Bẻ bảng neon rơi tạo vùng sáng 5m, địch bị [Mù] 1.5s, Khôi tăng 40% tốc đánh.',
      '• [Cuộn Tranh Chưa Giao]: Tích lũy lớp [Nợ], tiêu hao để cứu chữa đồng đội. “Tao chưa giao được tranh, nên chưa được phép ngã.”',
      '• [Còi Cứu Thương 3:17AM]: Lao thẳng 20m hất văng địch + vệt [Băng Nứt] đóng băng kẻ thù.',
      '• [Winter Shibuya - Hồi Quang]: Chiêu cuối làm bản đồ chuyển trắng đen, Khôi bất tử 1s, hồi 100% năng lượng, đòn đánh gây thêm 20% máu đã mất của mục tiêu.'
    ],
    canonicalQuote: '“Tuyết rơi phủ hết. Nhưng vết máu này… tao không lau.”',
    unlockedByDefault: true,
  },
  {
    id: 'three_spirits',
    category: 'Nhân Vật',
    title: 'Ba Chú Linh — Người Giữ Máu Shibuya',
    subtitle: 'Đinh Quốc Tuấn · Ông Táy · Hùng Đỏ',
    tagline: 'Tuấn quét đường muối, Táy giữ lò than, Hùng Đỏ đỡ đạn.',
    description: [
      '1. Đinh Quốc Tuấn (Kẻ Vác Cán Quét, 60 tuổi): [Quét Đường Sinh Tử] rải muối chống đóng băng; [Thùng Rác Chắn Bão] hút phản đạn 50% sát thương.',
      '2. Ông Táy (Bán Bánh Mì Nóng 24/7): [Lò Than Không Tắt] hồi 2% máu/s + miễn nhiễm đóng băng; [Bánh Mì Nóng] hồi máu tăng tốc; [Than Hồng Ném Cuối] vòng lửa bỏng.',
      '3. Hùng Đỏ (Giang Hồ Đỏ Áo Khoác): [Áo Đỏ Đỡ Đạn] đỡ 60% sát thương cho Khôi; [Dao Găm Neon] 3 nhát chém dấu đỏ; [Chạy Ngược Chiều] bất tử 4s xông pha.'
    ],
    canonicalQuote: '“Đinh Quốc Tuấn quét. Ông Táy giữ lửa. Hùng Đỏ đỡ đạn. Khôi mới có đường sống đến bình minh.”',
    unlockedByDefault: false,
  },
  {
    id: 'char_ba_man',
    category: 'Nhân Vật',
    title: 'Bà Mận',
    subtitle: 'Người Nấu Bát Cháo Gừng Ấm Tình Người',
    tagline: 'Đời người ai chẳng sợ chết, đừng để cái lạnh làm đông cứng tình người.',
    description: [
      'Bà cụ hiền từ thôn Bản Cáu, người chứng kiến bao thăng trầm biên cương từ thời Cụ Thọ dựng đình Lục Nà.',
      'Năm 2065, giữa bão tuyết biên giới nơi ma trận Rubik giăng bẫy, Bà Mận vượt núi mang bát cháo gừng nóng hổi đến cho Khôi.',
      'Bát cháo gừng cay nồng đã sưởi ấm tâm can Khôi, giúp Khôi cởi bỏ hận thù, tha thứ cho sự bội phản của Ba Chú Linh và tự nguyện bước vào khối đá Rubik 1m³.'
    ],
    canonicalQuote: '“Uống đi con... Ngoài này buốt lắm, nhưng cái rét của lòng người còn lạnh hơn.”',
    unlockedByDefault: false,
  },
  {
    id: 'rubik_matrix_box',
    category: 'Bảo Vật & Kỹ Năng',
    title: 'Hộp Đá Rubik 1m³ (Ngục Môn Cương)',
    subtitle: 'Bẫy đá 6 mặt giam giữ nỗi sợ chết (2065 – 2068)',
    tagline: 'Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi tự bước vào là không còn sợ chết.',
    description: [
      'Khối đá lập phương kích thước chuẩn xác 1m x 1m (1m³) với 6 mặt khắc phù chú Tày và Hán cổ, được Ba Chú Linh yểm bùa theo lệnh của Chu Mạnh Hiếu.',
      'Khôi hóa giải bùa muối đen, dập lò than tà khí, tước chìa khóa dao găm đỏ của Hùng Đỏ rồi tự nguyện bước vào ngồi thiền định suốt 3 năm (2065 – 2068).',
      'Mục đích: Canh giữ cho não của Lài Phúc Tài mục rã hoàn toàn, khiến tà thuật Hoán Não của Chu Mạnh Hiếu không thể hoàn tất, chờ ngày Lục Triều Dư gõ 108 nhịp kéo ra.'
    ],
    canonicalQuote: '“Cậu không chạy trốn. Cậu ngồi đây giữ cho não mày mục rã. Ba năm nữa, thằng Dư sẽ kéo cậu dậy!”',
    unlockedByDefault: false,
  },
  {
    id: 'seal_tuyet_trang',
    category: 'Triết Lý',
    title: 'Phong Ấn: Tuyết Trắng Chôn Tên',
    subtitle: 'Đâm cuộn tranh chưa giao — Hoán đổi sinh tử',
    tagline: 'Khi HP Khôi về 0 lần đầu, kích hoạt phong ấn băng tuyết 5 giây.',
    description: [
      'Khôi tự đâm cuộn tranh chưa giao xuống đất, tuyết 15m xung quanh đóng băng lại thành lăng mộ trắng.',
      'Trong 5s: Khôi bất tử trong kén băng, kẻ địch bị [Đóng Băng Tâm], đồng đội được hồi 40% máu [Hồi Quang].',
      'Kết thúc, kén băng vỡ tung! Khôi trồi lên với 50% HP, biến liềm thành [Bút Băng] gây thêm 30% sát thương băng theo máu đã mất. Dưới tuyết lưu lại chữ đỏ: “Minh Khôi - Chưa Giao”.'
    ],
    canonicalQuote: '“Đêm nay, tao chết một lần. Để ngày mai không ai chết thay tao.”',
    unlockedByDefault: true,
  },
  {
    id: 'seal_nguc_mon_cuong',
    category: 'Triết Lý',
    title: 'Ngục Môn Cương: Cửa Tuyết Không Mở Lại',
    subtitle: 'Phong ấn tử — Đóng băng vĩnh viễn nếu thất thủ',
    tagline: 'Tuyết chôn tên, Cửa chôn người. Mày chọn đi, Khôi.',
    description: [
      'Cánh cửa gỗ đen đóng băng của Ngục Môn Cương trồi lên từ nền tuyết nứt nẻ.',
      'Khôi chỉ có 3 giây để tự tay [XÉ CUỘN TRANH CHƯA GIAO] giải phóng phong ấn! Nếu xé kịp, phong ấn nổ tung, Khôi thoát chết nhưng vĩnh viễn mất lớp Nợ.',
      'Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi mở cửa một lần là mất đi nỗi sợ.'
    ],
    canonicalQuote: '“Cửa này mở một lần. Vào rồi, không có ai kéo mày ra.”',
    unlockedByDefault: false,
  },
  {
    id: 'philosophy_keep_calm',
    category: 'Triết Lý',
    title: 'Tư Tưởng: Giữ · Bình · Kéo',
    subtitle: 'Trục cốt lõi của thế giới Bình Liêu',
    tagline: 'Cần giữ người, Thọ bình người. Khôi dừng người, Dư kéo người.',
    description: [
      '• Nhánh “Giữ” (Hoàng Cần): Bảo bọc sinh mạng, giữ tay, không sát sinh.',
      '• Nhánh “Bình” (Bình Khôi): Bình lặng mà dứt điểm; ra tay kết thúc khi mối họa không còn đường thoái lui để cứu lấy trăm người.',
      '• Nhánh “Kéo” (Lục Triều Dư): Trung lập, cứu vớt những linh hồn đang chìm xuống vực thẳm tội lỗi hay thù hận.'
    ],
    unlockedByDefault: true,
  },
  {
    id: 'loc_ban_cau',
    category: 'Địa Danh',
    title: 'Bản Cáu & Đình Lục Nà',
    subtitle: 'Nơi khởi nguồn và bình yên của vùng biên giới',
    tagline: 'Lều tre thầy lang, khóm trúc 108 rãnh và bài vị chén nước lá.',
    description: [
      'Thôn Bản Cáu nằm yên bình bên sườn núi Bình Liêu. Nơi đây có Đình Lục Nà — nơi cụ Thọ từng dạy chữ, bốc thuốc nam cứu dân bản và đặt tên cho Khôi.',
      'Trước đình là chú chó cỏ Đốm nằm canh cổng, bảo vệ dân làng.'
    ],
    unlockedByDefault: true,
  },
  {
    id: 'loc_khe_van',
    category: 'Địa Danh',
    title: 'Thác Khe Vằn (100 Tầng)',
    subtitle: 'Vùng nước thiêng tẩy rửa sát khí',
    tagline: 'Chỉ có dòng nước thác trắng xoá mới rửa được máu trong mắt.',
    description: [
      'Thác nước hùng vĩ 100 tầng gầm thét quanh năm. Nơi Hoàng Cần thời trẻ từng luyện gậy trúc và Khôi treo mình rèn luyện suốt 6 tháng sau Winter Shibuya Incident.',
      'Tại đây Khôi ngộ ra chiêu “Khe Vằn Trảm” — đường liềm lướt theo dòng nước chưa kịp bắn toé.'
    ],
    unlockedByDefault: false,
  },
  {
    id: 'item_liem_tu_than',
    category: 'Bảo Vật & Kỹ Năng',
    title: 'Liềm Tử Thần & Nửa Gậy Trúc',
    subtitle: 'Binh khí gắn liền với Bình Liêu Vương',
    tagline: 'Lưỡi bạc có vết mẻ nhỏ — minh chứng của sự chiến thắng và lòng kiềm giữ.',
    description: [
      'Lưỡi liềm cán gỗ mun quấn băng đen, lưỡi có vết sứt nhỏ nơi chém gãy gậy trúc Hoàng Long của Hoàng Cần.',
      'Khôi luôn mang theo nửa gậy trúc gãy bọc vải đỏ bên mình: “Thắng rồi thì phải giữ”.'
    ],
    unlockedByDefault: true,
  }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: 'item_com_trung',
    name: 'Cơm Nguội & Trứng Luộc',
    category: 'consumable',
    description: 'Bữa sáng giản dị La Thanh chuẩn bị từ 5h sáng mang tới chòi lá. Hồi phục 250 Máu.',
    quantity: 4,
    loreNote: '“Người chưa giết ai thì đáng cứu.” — La Thanh',
    effect: 'heal',
    value: 250,
  },
  {
    id: 'item_bat_chao_ngo',
    name: 'Bát Cháo Ngô Đùm Bọc (1977)',
    category: 'relic',
    description: 'Bát cháo ngô loãng bà con Tày, Dao cưu mang đứa trẻ mồ côi La Thanh Thọ năm 7 tuổi.',
    quantity: 1,
    loreNote: '“Bố mẹ mất rồi, nhưng cả bản này là người nhà của mày.” — A01-E001',
    effect: 'heal',
    value: 200,
  },
  {
    id: 'item_nuoc_la_tia_to',
    name: 'Nước Lá Tía Tô Cụ Thọ',
    category: 'consumable',
    description: 'Bát nước thuốc nam giải độc, hồi phục 100 Nội Lực (Qi) và thanh tâm.',
    quantity: 3,
    loreNote: 'Nấu từ ngải cứu và tía tô hái sau chùa Cổ Nguyệt.',
    effect: 'qi',
    value: 100,
  },
  {
    id: 'item_banh_mi_ong_tay',
    name: 'Bánh Mì Nóng 24/7 (Ông Táy)',
    category: 'consumable',
    description: 'Ổ bánh mì nóng giòn thơm nức từ lò than không tắt. Hồi phục 800 Máu và 150 Điểm Giáp.',
    quantity: 2,
    loreNote: '“Ăn cho ấm bụng đi cháu, tuyết Shibuya lạnh lắm.”',
    effect: 'heal',
    value: 800,
  },
  {
    id: 'item_dan_duoc_tang_luc',
    name: 'Đan Dược Trúc Tinh',
    category: 'consumable',
    description: 'Luyện từ măng trúc ngàn năm, tăng 40 Sức Tấn Công trong 45 giây.',
    quantity: 2,
    loreNote: '“Uống vào khí huyết sôi trào, chém sắt như bùn.”',
    effect: 'buff',
    value: 40,
  },
  {
    id: 'item_chien_giap_tuyet',
    name: 'Chiến Giáp Tuyết Biên Phòng',
    category: 'armor',
    description: 'Bộ giáp dệt từ sợi kevlar gia cố hợp kim tuyết. Hấp thụ 400 Sát Thương với 100 Độ Bền.',
    quantity: 1,
    loreNote: 'Trang bị phòng hộ tiêu chuẩn của người lính giữ mốc 1305.',
    effect: 'armor',
    value: 400,
  },
  {
    id: 'item_manh_ren_than_binh',
    name: 'Mảnh Rèn Thần Binh',
    category: 'material',
    description: 'Mảnh thiên thạch linh khí dùng để nâng cấp cấp độ vũ khí và mở khóa socket nguyên tố.',
    quantity: 5,
    loreNote: 'Rơi ra từ quái vật và thủ lĩnh tà phái.',
    effect: 'upgrade',
    value: 1,
  },
  {
    id: 'item_nua_gay_truc',
    name: 'Mảnh Gậy Trúc Gãy',
    category: 'relic',
    description: 'Một nửa gậy trúc của Hoàng Cần bị chém đứt trong đêm giông bão.',
    quantity: 1,
    loreNote: 'Lời nhắc nhở khắc cốt ghi tâm: “Thắng rồi thì phải giữ”.',
  },
  {
    id: 'item_la_ngai_cuu',
    name: 'Lá Ngải Cứu Buộc Chỉ Đỏ',
    category: 'relic',
    description: 'Vật phẩm La Thanh trao cho Khôi, tượng trưng cho y đức và nhân tính.',
    quantity: 1,
    loreNote: '“Cứu người trước, giết người sau.”',
  },
  {
    id: 'item_nam_duoc_than_hieu',
    name: 'Nam Dược Thần Hiệu (Bản Rách 12 Tuổi)',
    category: 'relic',
    description: 'Cuốn y thư rách nát Cụ Thọ nhặt được trong hang đá sau Chùa Cổ Nguyệt năm 12 tuổi, tự học chữa rắn cắn cứu cả bản.',
    quantity: 1,
    loreNote: '“Không có thầy dạy, tự học chữa cho gà, heo rồi chữa cho người.” — A01-E002',
    effect: 'heal',
    value: 300,
  },
  {
    id: 'item_hom_thuoc_moc_1305',
    name: 'Hòm Thuốc Dã Chiến Mốc 1305',
    category: 'relic',
    description: 'Hòm cứu thương bằng gỗ thông bọc thép Cụ Thọ vác trên lưng lúc 17 tuổi, kéo 9 thương binh về trận mốc biên giới 1305.',
    quantity: 1,
    loreNote: '“Không cầm súng, chỉ vác hòm thuốc chạy sau đội. Kéo 9 người bị thương về.” — A01-E003',
    effect: 'armor',
    value: 200,
  },
  {
    id: 'item_gay_108_ranh',
    name: 'Gậy Trúc 108 Rãnh Hoàng Cần Trao',
    category: 'relic',
    description: 'Cây gậy trúc Hoàng Cần trao cho Thọ năm 40 tuổi: “Khắc 108 rãnh, mỗi rãnh một mạng người mày cứu”.',
    quantity: 1,
    loreNote: '“Chân cụt thì đi bằng gậy. Mắt mờ thì nhìn bằng lòng.” — A01-E005',
  },
  {
    id: 'item_so_tay_toan_12a2',
    name: 'Sổ Tay Hình Học Lớp 12A2',
    category: 'lore',
    description: 'Quyển vở ghi chép công thức hình chóp tứ giác đều và tọa độ không gian Khôi mang trong ba lô. Bên lề có vẽ phác họa đường chém liềm tử thần.',
    quantity: 1,
    loreNote: '“Đi học mà cứ như vừa gánh cả thế giới trên vai thế à?” — Thầy dạy Toán lớp 12A2',
  },
  {
    id: 'item_manh_gay_truc_hoang_long',
    name: 'Nửa Gậy Trúc Hoàng Long Bị Chém Gãy (108 Rãnh)',
    category: 'relic',
    description: 'Nửa gậy trúc Hoàng Long bị liềm tử thần của Khôi chém đứt làm đôi trong đêm giông bão Nóc Chợ Bình Liêu tháng 11/2017.',
    quantity: 1,
    loreNote: '“Thắng rồi thì phải giữ. Đeo nửa gậy này trước ngực để nhắc mình chữ DỪNG.” — Hoàng Cần',
    effect: 'buff',
    value: 50,
  },
  {
    id: 'item_vai_do_boc_gay',
    name: 'Mảnh Vải Đỏ Bọc Gậy Trúc & Liềm Tử Thần',
    category: 'relic',
    description: 'Mảnh vải lụa đỏ thắm Cụ Thọ trao dùng để bọc hai đoạn gậy trúc gãy đôi và lưỡi liềm có vết mẻ nhỏ.',
    quantity: 1,
    loreNote: '“Nước lá tía tô lau sạch máu. Từ nay con là Hoàng Minh Bình Khôi — Bình Liêu Vương!” — Cụ Thọ',
    effect: 'armor',
    value: 300,
  },
  {
    id: 'item_khan_trang_lau_liem',
    name: 'Khăn Trắng Lau Liềm Gấp Vuông Góc',
    category: 'relic',
    description: 'Chiếc khăn vải bông trắng tinh luôn gấp vuông góc trong túi áo tactical của Khôi 18 tuổi. Dùng để lau sạch lưỡi liềm sau mỗi trận can thiệp.',
    quantity: 1,
    loreNote: '“Lưỡi liềm sắc để cứu người, không phải để dính máu.” — Hoàng Minh Bình Khôi 18 tuổi',
    effect: 'buff',
    value: 45,
  },
  {
    id: 'item_ao_sat_nach_thay_huynh',
    name: 'Áo Sát Nách Thầy Huỳnh',
    category: 'relic',
    description: 'Chiếc áo thể thao sát nách thầy Huỳnh tặng Chu Hiếu Què: “Mày què mà chạy nhanh hơn cả tao, sau này làm anh hùng đi”.',
    quantity: 1,
    loreNote: 'Kỷ vật thiêng liêng Hiếu luôn mặc trên người suốt thời niên thiếu.',
    effect: 'armor',
    value: 200,
  },
  {
    id: 'item_cuon_tranh_chua_giao',
    name: 'Cuộn Tranh Chưa Giao (Bảo Vật Tokyo 2028)',
    category: 'relic',
    description: 'Bảo vật chứa phong ấn thượng cổ Cụ Thọ trao cho Khôi 18 tuổi, mang sứ mệnh hộ tống sang Tokyo (Winter Shibuya Incident).',
    quantity: 1,
    loreNote: '“Tao chưa giao được tranh, nên chưa được phép ngã.” — Bình Liêu Vương',
    effect: 'buff',
    value: 100,
  },
  {
    id: 'item_lo_than_ong_tay',
    name: 'Than Hồng Lò Bánh Mì Ông Táy',
    category: 'consumable',
    description: 'Thanh than hồng lấy từ xe bánh mì nóng 24/7 của Ông Táy tại Tokyo. Tỏa hơi ấm xua tan băng giá, hồi phục 100% nội lực và kháng băng trong 15 giây.',
    quantity: 2,
    loreNote: '“Đinh Quốc Tuấn quét muối, Ông Táy giữ than, Hùng Đỏ đỡ đạn.” — Ba Chú Linh Tokyo',
    effect: 'heal',
    value: 450,
  },
  {
    id: 'item_ve_may_bay_tokyo',
    name: 'Vé Máy Bay Hồi Hương (Tokyo ➔ Vân Đồn / Bình Liêu)',
    category: 'relic',
    description: 'Tấm vé một chiều đưa Khôi 20 tuổi rời giông tuyết Shibuya trở về đỉnh Thác Khe Vằn 100 Tầng gột rửa sát khí.',
    quantity: 1,
    loreNote: '“Sát khí trong mắt con đã nổi lên... Con phải về Thác Khe Vằn treo mình rèn tâm thôi.” — Khe Vằn Tử Thần',
    effect: 'buff',
    value: 500,
  },
  {
    id: 'item_thuoc_nam_duong_tim',
    name: 'Bát Thuốc Nam Dưỡng Tim (A07-E001)',
    category: 'consumable',
    description: 'Bát thuốc nam bốc khói ấm sắc từ tía tô, cam thảo và thảo dược Cụ Thọ để lại cứu tỉnh cháu Tài Dog 9 tuổi ngất xỉu bên thềm đình.',
    quantity: 1,
    loreNote: '“Tài ngất bên thềm đình, chú chó Đốm què liếm má thằng nhỏ... Khôi sắc thuốc cứu tỉnh cháu.” — Arc 7',
    effect: 'heal',
    value: 400,
  },
  {
    id: 'item_gay_truc_non',
    name: 'Cây Gậy Trúc Non Tặng Tài (A07-E002)',
    category: 'relic',
    description: 'Cây gậy trúc non nhẵn mịn, không một mắt gai, Khôi tự tay chặt từ Chùa Cổ Nguyệt mang về tặng sinh nhật Tài Dog.',
    quantity: 1,
    loreNote: '“Mày không cần học võ. Mày chỉ cần sống.” — Hoàng Minh Bình Khôi',
    effect: 'buff',
    value: 200,
  },
  {
    id: 'item_loi_trang_troi_tai_dog',
    name: 'Di Huấn "Cứ Giữ Thôi" (Mùa Đông 2065)',
    category: 'relic',
    description: 'Lời trăn trối cuối cùng của Lài Phúc Tài trong đêm đông rét buốt chòi lá trước khi trút hơi thở cuối cùng trên tay Khôi.',
    quantity: 1,
    loreNote: '“Cậu ơi... đừng bình nữa. Cứ giữ thôi...” — Lài Phúc Tài (Tài Dog)',
    effect: 'buff',
    value: 300,
  },
  {
    id: 'item_bat_chao_canh_mo',
    name: 'Bát Cháo Nóng Dỗ Chó Đốm (A07-E004)',
    category: 'consumable',
    description: 'Bát cháo ngô trắng nóng Khôi mang lên đồi mộ Bản Cáu dỗ dành chú chó Đốm nằm phủ phục canh mộ cậu chủ suốt 3 ngày đêm.',
    quantity: 1,
    loreNote: '“Ăn chút cháo đi con... Cậu Tài nằm xuống rồi, về cổng đình với tao.” — Khôi',
    effect: 'heal',
    value: 350,
  },
  {
    id: 'item_nhan_tin_nguc_mon_cuong',
    name: 'Điềm Báo Ngục Môn Cương (A07-E005)',
    category: 'relic',
    description: 'Tín vật tà môn thu được từ đao thủ Móng Cái, hé lộ dã tâm đào mộ hoán não của Chu Mạnh Hiếu trước thềm đại chiến Arc 8.',
    quantity: 1,
    loreNote: '“Chu Mạnh Hiếu lệnh phải mang não thằng nhỏ về mở Ngục Môn Cương bằng mọi giá!” — Arc 7 ➔ Arc 8',
    effect: 'buff',
    value: 500,
  },
  {
    id: 'item_so_do_dinh_quoc_tuan',
    name: 'Cuốn Sổ Đỏ Phù Chú (A08-E002)',
    category: 'relic',
    description: 'Cuốn sổ đỏ Đinh Quốc Tuấn dùng để ghi tên Khôi yểm vào mặt Rubik 1, đã được Khôi hóa giải và tẩy sạch tà khí muối đen.',
    quantity: 1,
    loreNote: '“Tao phải ghi tên mày để cứu cả nhà tao... Tha lỗi cho tao, Khôi ơi!” — Tuấn',
    effect: 'armor',
    value: 200,
  },
  {
    id: 'item_manh_bua_ong_tay',
    name: 'Mảnh Bùa Lò Than Nứt 6 Vết (A08-E003)',
    category: 'relic',
    description: 'Mảnh bùa lò than vỡ ra từ khuôn mặt 6 vết nứt của Ông Táy, mang hơi ấm tình nghĩa đẩy lùi ngọn lửa tà hỏa thiêu đốt.',
    quantity: 1,
    loreNote: '“Bánh mì nóng hổi ngày xưa... nó lấy não thằng Tài rồi Khôi ơi!” — Ông Táy',
    effect: 'heal',
    value: 500,
  },
  {
    id: 'item_chia_khoa_hung_do',
    name: 'Chìa Khóa Ngục Môn Cương (A08-E004)',
    category: 'relic',
    description: 'Chìa khóa ma trận Rubik thu được sau khi tước dao găm đâm sau lưng của Hùng Đỏ, dùng để mở ổ khóa tâm thức khối đá 1m³.',
    quantity: 1,
    loreNote: '“Áo vẫn đỏ, tay vẫn cầm chìa khóa Rubik... Khôi ơi, em là thằng hèn!” — Hùng Đỏ',
    effect: 'buff',
    value: 600,
  },
  {
    id: 'item_bat_chao_gung_ba_man',
    name: 'Bát Cháo Gừng Ấm Tình Người (A08-E005)',
    category: 'consumable',
    description: 'Bát cháo gừng cay nồng ấm áp do Bà Mận tự tay nấu mang lên đỉnh núi buốt giá, hồi phục 100% sinh lực và xua tan mọi nỗi sợ hãi.',
    quantity: 2,
    loreNote: '“Đời người ai chẳng sợ chết, đừng để cái lạnh làm đông cứng tình người.” — Bà Mận',
    effect: 'heal',
    value: 1500,
  },
  {
    id: 'item_khoi_rubik_1m',
    name: 'Lõi Ma Trận Rubik 1m³ (A08-E006)',
    category: 'relic',
    description: 'Tín vật minh chứng Khôi tự nguyện bước vào khối đá Rubik 1m³ suốt 3 năm (2065 – 2068) canh giữ não Tài mục rã, không còn sợ chết.',
    quantity: 1,
    loreNote: '“Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi tự bước vào là không còn sợ chết.”',
    effect: 'buff',
    value: 1000,
  },
  {
    id: 'item_dao_mo_ta_mon',
    name: 'Cuốc Đào Mộ Tà Môn (A09-E001)',
    category: 'relic',
    description: 'Chiếc cuốc tà môn rỉ máu khắc bùa chú dùng để đào xới mộ Tài Dog, thu giữ tại hiện trường Đồi Mộ Bản Cáu.',
    quantity: 1,
    loreNote: 'Manh mối chỉ ra Chu Mạnh Hiếu đã đào trộm mộ Lài Phúc Tài để tráo não.',
    effect: 'upgrade',
    value: 100,
  },
  {
    id: 'item_manh_ao_sat_nach_hieu',
    name: 'Mảnh Áo Sát Nách Chàm Của Hiếu (A09-E001)',
    category: 'relic',
    description: 'Mảnh vải áo sát nách màu chàm quen thuộc mà Thầy Huỳnh từng cho Chu Mạnh Hiếu thuở thiếu thời, vướng lại trên cọc ván mộ.',
    quantity: 1,
    loreNote: '“Mày vừa điên vừa què nhưng tâm không què... Giờ tâm mày què thật rồi, Hiếu ơi!”',
    effect: 'armor',
    value: 150,
  },
  {
    id: 'item_dau_tay_thep_thao',
    name: 'Dấu Vết Tay Thép Thảo (A09-E001)',
    category: 'relic',
    description: 'Vệt ma khí lưu lại trong không khí khi ngón tay thép gõ 108 nhịp tạo dao động sóng não, dẫn đường sang Hang Đá Lạng Sơn.',
    quantity: 1,
    loreNote: 'Gõ 108 nhịp vào hư không để hút vía giữ xác người ghép sọ.',
    effect: 'buff',
    value: 200,
  },
  {
    id: 'item_ho_so_hoan_nao',
    name: 'Hồ Sơ Mổ Sọ Hoán Não (A09-E002)',
    category: 'relic',
    description: 'Cuốn hồ sơ tà môn tịch thu trên bàn mổ đá, ghi chép tường tận giới hạn 3 năm (2065 – 2068) của tế bào não người chết.',
    quantity: 1,
    loreNote: '“Chu Mạnh Hiếu, bị trục xuất 2049 vì luyện Hoán Não... Não Tài sẽ mục rã sau 3 năm!”',
    effect: 'buff',
    value: 500,
  },
  {
    id: 'item_manh_tay_thep_thao',
    name: 'Mảnh Khớp Tay Thép Của Thảo (A09-E003)',
    category: 'material',
    description: 'Mảnh khớp thép rơi ra từ cánh tay cơ khí của Thảo sau khi đánh tan Đài Tế Hút Vía của Avatar Chu Mạnh Hiếu.',
    quantity: 1,
    loreNote: 'Vũ khí cơ khí kết hợp tà thuật hút vía của kẻ cuồng loạn.',
    effect: 'upgrade',
    value: 300,
  },
  {
    id: 'item_nuoc_mat_tai_dog',
    name: 'Giọt Nước Mắt Tài Dog (A09-E004)',
    category: 'consumable',
    description: 'Giọt nước mắt xúc động ngưng tụ từ ký ức thằng Tài khi tiếng gậy trúc 108 rãnh làm thức tỉnh tình cảm gia đình, hồi phục 100% sinh lực.',
    quantity: 3,
    loreNote: '“Cậu ơi, cháu không cho nó hại cậu... Cháu nhớ gậy trúc của cháu!”',
    effect: 'heal',
    value: 2000,
  },
  {
    id: 'item_cuon_cap_thep_du',
    name: 'Cuộn Cáp Thép 108 Sợi Của Dư (A09-E005)',
    category: 'relic',
    description: 'Cuộn cáp thép cứu sinh do Lục Triều Dư trao tặng tại cửa hang đá, chuẩn bị cho chiến dịch gõ 108 nhịp kéo Khôi trở lại trong Arc 10.',
    quantity: 1,
    loreNote: '“Tao sẽ gõ 108 nhịp kéo mày ra khỏi Rubik, đưa Bình Liêu Vương trở lại đỉnh cao!” — Lục Triều Dư',
    effect: 'buff',
    value: 1500,
  },
  {
    id: 'item_moc_neo_cap_thep',
    name: 'Móc Neo Cáp Thép Mốc 1088 (A10-E001)',
    category: 'relic',
    description: 'Chiếc móc neo thép đúc nguyên khối cựu đặc công Lục Triều Dư dùng để găm vào vách đá dựng đứng, neo giữ giàn cáp chịu lực 108 sợi.',
    quantity: 1,
    loreNote: '“Gãy 3 đốt sống mà vẫn neo được cáp qua hẻm núi... Đó là ý chí của người lính biên phòng!” — A10-E001',
    effect: 'armor',
    value: 400,
  },
  {
    id: 'item_khoa_cang_cap',
    name: 'Khóa Căng Cáp Thép (A10-E002)',
    category: 'relic',
    description: 'Bộ khóa ren căng cáp thu giữ từ Trùm Đao Thủ Canh Ngục, dùng để kéo căng 108 đầu cáp nối vào 6 mặt khối đá Rubik 1m³.',
    quantity: 1,
    loreNote: '“Cáp thép siết nát cổ tay tao rồi... nhưng các người không cứu kịp 20 đứa trẻ đâu!” — Trùm Đao Thủ',
    effect: 'upgrade',
    value: 500,
  },
  {
    id: 'item_manh_da_rubik_108',
    name: 'Mảnh Đá Rubik 108 Nhịp (A10-E003)',
    category: 'relic',
    description: 'Mảnh đá vỡ ra từ Ngục Môn Cương sau 108 nhịp gõ sóng âm cộng hưởng của Lục Triều Dư, mang hơi ấm của ngày giải phóng 2068.',
    quantity: 1,
    loreNote: '“Ngục Môn Cương không giữ xác, nó giữ cái sợ chết. Khôi tự bước vào là không còn sợ chết.”',
    effect: 'buff',
    value: 1200,
  },
  {
    id: 'item_ao_phao_den_rach_du',
    name: 'Áo Phao Đen Rách Vai Của Dư (A10-E004)',
    category: 'armor',
    description: 'Chiếc áo phao lông vũ đen dày rách vai của Lục Triều Dư khoác lên người Khôi khi vừa bước ra khỏi khối đá giá buốt. Hấp thụ 1500 Sát Thương.',
    quantity: 1,
    loreNote: '“Mày không cần bình nữa. Lần này để tao bình mày.” — Lục Triều Dư',
    effect: 'armor',
    value: 1500,
  },
  {
    id: 'item_bat_nuoc_gung_nong_1088',
    name: 'Bát Nước Gừng Nóng Mốc 1088 (A10-E004)',
    category: 'consumable',
    description: 'Bát nước gừng già đun sôi giữa bão tuyết đỉnh đèo, hồi phục 100% Máu và xua tan khí hàn tích tụ suốt 3 năm thiền định.',
    quantity: 3,
    loreNote: '“Uống cạn đi Khôi! Hơi ấm này là tình anh em biên giới!” — Lục Triều Dư',
    effect: 'heal',
    value: 2500,
  },
  {
    id: 'item_chuong_gio_mam_non',
    name: 'Chuông Gió Trường Mầm Non Bản Cáu (A10-E005)',
    category: 'relic',
    description: 'Chiếc chuông gió tre do cô trò trường mầm non tự đan, Chó Đốm ngậm chạy lên đỉnh đèo báo tin khẩn cấp mở màn Arc 11.',
    quantity: 1,
    loreNote: '“Chu Mạnh Hiếu bao vây 20 đứa trẻ... Hai Thằng Canh Cổng phải xuống núi ngay!” — A10-E005',
    effect: 'buff',
    value: 2000,
  },
  {
    id: 'item_chia_khoa_cong_mam_non',
    name: 'Chìa Khóa Cổng Mầm Non (A11-E001)',
    category: 'relic',
    description: 'Chìa khóa sắt rỉ mở cổng rào chắn Trường Mầm Non Bản Cáu đoạt được sau khi hạ toán trinh sát tà môn.',
    quantity: 1,
    loreNote: '“Mở cổng cứu 20 đứa trẻ... Đêm nay không được phép chậm trễ!” — A11-E001',
    effect: 'buff',
    value: 500,
  },
  {
    id: 'item_day_cap_khoa_thep',
    name: 'Dây Cáp Khóa Chốt Xích Đu (A11-E002)',
    category: 'relic',
    description: 'Cuộn cáp thép 108 sợi Lục Triều Dư giăng qua hai cột xích đu, tạo bẫy khống chế cánh tay thép của Hiếu.',
    quantity: 1,
    loreNote: '“Tao giật đổ xích đu, mày bổ đứt tà niệm!” — Lục Triều Dư',
    effect: 'armor',
    value: 800,
  },
  {
    id: 'item_tay_thep_gay_vun',
    name: 'Mảnh Tay Thép Gãy Vụn (A11-E003)',
    category: 'material',
    description: 'Mảnh kim loại vụn nát từ cánh tay cơ khí của Thảo sau khi bị Liềm Tử Thần chém gãy trong đêm giông tuyết.',
    quantity: 1,
    loreNote: 'Tà thuật 108 nhịp tay thép chính thức bị phá giải tan tành.',
    effect: 'upgrade',
    value: 1000,
  },
  {
    id: 'item_ao_sat_nach_thay_huynh',
    name: 'Mảnh Áo Sát Nách Thầy Huỳnh (A11-E004)',
    category: 'relic',
    description: 'Mảnh áo sát nách màu chàm Thầy Huỳnh trao cho Chu Hiếu Què từ năm lớp 5, ghi dấu nghị lực của đứa trẻ bất hạnh.',
    quantity: 1,
    loreNote: '“Mày què mà chạy nhanh hơn cả tao, sau này làm anh hùng đi!” — Thầy Huỳnh',
    effect: 'buff',
    value: 1200,
  },
  {
    id: 'item_dau_an_chu_dung_thanh_tuu',
    name: 'Dấu Ấn Chữ DỪNG Vĩ Đại (A11-E005)',
    category: 'relic',
    description: 'Đỉnh cao võ đức của Bình Liêu Vương — nhát liềm dừng lại cách cổ Chu Hiếu đúng một tấc, cứu rỗi một sinh mệnh.',
    quantity: 1,
    loreNote: '“Mạnh nhất là lúc dừng lại được. Mày không giết người, mày bình người.”',
    effect: 'buff',
    value: 3000,
  },
  {
    id: 'item_khung_tranh_20_em_nho',
    name: 'Khung Tranh 20 Em Nhỏ Bản Cáu (A11-E006)',
    category: 'relic',
    description: 'Bức tranh sáp màu do 20 đứa trẻ trường mầm non tự vẽ tặng hai chú canh cổng sau đêm tuyết định mệnh.',
    quantity: 1,
    loreNote: 'Nụ cười hồn nhiên của trẻ thơ nở rộ trên vùng đất biên cương thanh bình.',
    effect: 'heal',
    value: 5000,
  },
  {
    id: 'item_hon_tai_sieu_thoat',
    name: 'Kỷ Vật Hồn Tài Siêu Thoát (A11-E006)',
    category: 'relic',
    description: 'Hạt ngọc ánh sáng ấm áp ngưng tụ từ nụ cười giải thoát của Tài Dog, xua tan vĩnh viễn mọi đau thương mất mát.',
    quantity: 1,
    loreNote: '“Cậu Khôi ơi, cháu thanh thản rồi... Cảm ơn cậu đã giải thoát cho cả hai.” — Tài Dog',
    effect: 'buff',
    value: 4000,
  },
  {
    id: 'item_danh_hieu_binh_lieu_vuong_vi_dai',
    name: 'Huyền Thoại Bình Liêu Vương (A11-E007)',
    category: 'relic',
    description: 'Minh chứng cho người anh hùng bảo vệ dải non sông: Cần giữ, Thọ bình, Khôi dừng, Dư kéo — vĩnh viễn trường tồn.',
    quantity: 1,
    loreNote: '“Về. Nhưng không ngồi nữa. Đứng thẳng!” — Hoàng Minh Bình Khôi',
    effect: 'buff',
    value: 9999,
  },
  {
    id: 'item_than_vu_giai',
    name: 'Thần Vũ Giải (Kamutoke)',
    category: 'relic',
    description: 'Chú cụ đặc cấp thời Heian của Nguyền Vương Ryomen Sukuna, tokkosho chử một lưỡi triệu hồi luồng điện sấm sét xối xả từ thiên giới giáng xuống mục tiêu!',
    quantity: 1,
    loreNote: '“Kamutoke — Tia chớp hủy diệt xé rách bầu trời.”',
    effect: 'buff',
    value: 15000,
  },
  {
    id: 'item_mu_giap_than',
    name: 'Mũ Giáp Chú Thuật (Helmet)',
    category: 'armor',
    description: 'Mũ giáp chiến binh rèn từ hắc thiết biên cương và phù chú gia hộ, tăng 2,000 Giáp và chống choáng.',
    quantity: 1,
    loreNote: 'Bảo vệ đầu trước các đòn chấn động của tà ma.',
    effect: 'armor',
    value: 2000,
  },
  {
    id: 'item_giap_than_than_vu',
    name: 'Giáp Thân Hắc Thiết (Chest Armor)',
    category: 'armor',
    description: 'Chiến giáp thân mình kiên cố, khắc ấn chú thuật giảm 75% sát thương nhận vào, tăng 4,000 Giáp.',
    quantity: 1,
    loreNote: 'Tấm khiên vững chãi bảo vệ tâm mạch người giữ làng.',
    effect: 'armor',
    value: 4000,
  },
  {
    id: 'item_giap_quan_chi_ton',
    name: 'Giáp Quần Sa Trường (Leg Guards)',
    category: 'armor',
    description: 'Giáp quần thiết giáp tăng cường sự linh hoạt, tăng 2,500 Giáp và gia tăng tốc độ di chuyển.',
    quantity: 1,
    loreNote: 'Bước chạy vững chãi trên tuyết trắng Bình Liêu.',
    effect: 'armor',
    value: 2500,
  },
  {
    id: 'item_giap_chan_phong_loi',
    name: 'Giáp Chân Phong Lôi (Boots)',
    category: 'armor',
    description: 'Ủng thiết giáp bọc lôi điện, tăng 1,500 Giáp, cho phép người chơi thực hiện 4 lần nhảy liên hoàn trên không trung.',
    quantity: 1,
    loreNote: 'Đạp gió phi thân như lôi điện.',
    effect: 'armor',
    value: 1500,
  },
  {
    id: 'item_dai_hoan_dan',
    name: 'Đại Hoàn Đan Bổ Huyết (Healing Item)',
    category: 'consumable',
    description: 'Đan dược tối thượng bào chế từ ngải cứu nghìn năm và sâm rừng Khe Vằn, lập tức hồi phục 10,000 Máu và 100% Nội lực.',
    quantity: 10,
    loreNote: 'Khí huyết cuồn cuộn, thương tích tan biến.',
    effect: 'heal',
    value: 10000,
  },
  {
    id: 'item_kiem_hoa_long_katana',
    name: 'Hỏa Long Katana (Kiếm Lục Triều Dư)',
    category: 'relic',
    description: 'Thanh kiếm katana rèn từ dung nham núi lửa và vảy rồng lửa do Lục Triều Dư sử dụng, chém ra ngọn lửa rồng rực cháy thiêu rụi tà ma.',
    quantity: 1,
    loreNote: '“Hỏa Long xuất thế, cáp thép tung hoành!” — Lục Triều Dư',
    effect: 'buff',
    value: 12000,
  }
];

export const INITIAL_QUESTS: Quest[] = [
  {
    id: 'quest_arc1',
    chapter: 'Arc 1: Nguồn Gốc Người Giữ Làng',
    title: 'Hành Trình La Thanh Thọ (1970 - 1995)',
    summary: '[A01-E001 → A01-E005] Từ đứa trẻ mồ côi Bản Cáu, tìm y thư Nam Dược Thần Hiệu 12 tuổi, kéo 9 thương binh tại Mốc 1305, dựng lều Đình Lục Nà và nhận gậy 108 rãnh từ Hoàng Cần.',
    targetObjective: 'Khám phá di huấn Cụ Thọ tại Đình Lục Nà, tiếp nhận Nam Dược Thần Hiệu và gậy trúc 108 rãnh.',
    completed: false,
    active: true,
    rewardXp: 150,
  },
  {
    id: 'quest_arc2',
    chapter: 'Arc 2: Thằng Nhóc Bị Bắt Nạt',
    title: 'Winter Arc 1.0 — Chòi Lá Ngoại Ô',
    summary: '[A02-E001 → A02-E004] Khôi 12-15 tuổi bị đám con nhà võ trêu con tài xế, bị đánh gãy mũi, dựng chòi lá tập 500 nhát liềm/ngày; La Thanh mang cơm và đun lá tía tô cứu sốt.',
    targetObjective: 'Tập luyện với Mộc Nhân, nhận cơm nguội trứng luộc và nước lá tía tô của La Thanh.',
    completed: false,
    active: false,
    rewardXp: 200,
  },
  {
    id: 'quest_arc3',
    chapter: 'Arc 3: Trận Thầy Trò — Đêm Giết Thầy',
    title: 'Đêm Giông Bão Nóc Chợ Bình Liêu',
    summary: '[A03-E001 → A03-E005] Khôi 17 tuổi đối đầu Hoàng Cần; chém gãy gậy trúc Hoàng Long, Cần truyền con đường Bình; sáng hôm sau Khôi ngủ gật trong tiết Toán 12A2.',
    targetObjective: 'Tiến về Chùa Cổ Nguyệt, chiêm bái mộ trúc 7 cây và thấu hiểu truyền thừa nhánh Bình.',
    completed: false,
    active: false,
    rewardXp: 300,
  },
  {
    id: 'quest_arc4',
    chapter: 'Arc 4: Bình Liêu Vương 18 Tuổi',
    title: 'Cai Quản Trật Tự Biên Giới — Chữ "DỪNG" Tuổi 18',
    summary: '[A04-E001 → A04-E005] Khôi 18 tuổi cai quản trật tự Mốc 1088 bằng chữ DỪNG; gặp gỡ Thầy Huỳnh & Chu Hiếu Què 16 tuổi; so tài 7 đêm tại Sân Đình Lục Nà; đu dây rèn cơ vách đá Thác Khe Vằn cùng Lục Triều Dư; tiếp nhận "Cuộn Tranh Chưa Giao" khởi hành đi Tokyo (Winter Shibuya).',
    targetObjective: 'Tuần tra Mốc 1088, so tài 7 đêm tại Đình Lục Nà cùng Hiếu Què, vượt thử thách đu dây Khe Vằn và nhận Cuộn Tranh Chưa Giao.',
    completed: false,
    active: false,
    rewardXp: 500,
  },
  {
    id: 'quest_arc5',
    chapter: 'Arc 5: Winter Shibuya Incident (2028)',
    title: 'Băng Dưới Đèn Neon — Cầu Vượt Đêm 25/12',
    summary: '[A05-E001 → A05-E005] Khôi 20 tuổi mang Cuộn Tranh Chưa Giao đến Tokyo; Ba Chú Linh tiếp tế bánh mì nóng & muối tuyết; kích hoạt Bảng Neon Gãy & Tuyết Phủ 109 đánh bại 12 đao thủ Huyết Trúc trong 7 phút không sát sinh; giải cứu con tin và nhận biệt danh "Khe Vằn Tử Thần".',
    targetObjective: 'Đến Ngã Tư Shibuya 109, tiếp nhận tiếp tế Ba Chú Linh, dẹp tan băng Huyết Trúc trên Cầu Vượt và chuẩn bị hồi hương về Thác Khe Vằn (Arc 6).',
    completed: false,
    active: false,
    rewardXp: 800,
  },
  {
    id: 'quest_arc6',
    chapter: 'Arc 6: Chiến Binh Thác Khe Vằn',
    title: 'Tẩy Sát Khí — Dòng Thác 100 Tầng',
    summary: '[A06-E001 → A06-E005] Khôi 21 tuổi hồi hương sau Shibuya với vệt máu đỏ trong mắt; leo lên Thác Khe Vằn vượt thử thách cáp thép của Lục Triều Dư; treo mình 6 tháng dưới nghìn roi nước đổ đánh bại Tâm Ma Shibuya; ngộ ra tuyệt kỹ Khe Vằn Trảm chém đôi dòng thác và hạ sơn về cổng đình gặp Tài Dog.',
    targetObjective: 'Đến Hồ Nước Chân Thác, vượt giàn cáp thép, treo mình 6 tháng diệt Tâm Ma, lĩnh hội Khe Vằn Trảm và hạ sơn về Bản Cáu.',
    completed: false,
    active: false,
    rewardXp: 850,
  },
  {
    id: 'quest_arc7',
    chapter: 'Arc 7: Tài Dog Và Cái "Giữ" Cuối Cùng',
    title: 'Lời Dặn Của Lài Phúc Tài (2030 – 2065)',
    summary: '[A07-E001 → A07-E005] Khôi bảo bọc Tài Dog và chó què Đốm bên cổng đình; tặng gậy trúc non mỗi năm; chứng kiến Tài qua đời vì bệnh tim năm 2065; khóa Liềm Tử Thần vào két sắt; đưa Đốm bên mộ về đình và đánh lui tà môn Móng Cái.',
    targetObjective: 'Sắc thuốc nam dưỡng tim cho Tài Dog, chặt gậy trúc non, túc trực đêm đông 2065, khóa liềm két sắt và bảo vệ nấm mộ Tài.',
    completed: false,
    active: false,
    rewardXp: 1000,
  },
  {
    id: 'quest_arc8',
    chapter: 'Arc 8: Rubik Ngục Môn Cương — Ba Chú Linh',
    title: 'Bẫy Đá 6 Mặt — Tuấn, Ông Táy, Hùng Đỏ',
    summary: '[A08-E001 → A08-E006] Ba người từng được Khôi cứu quay lưng vì sợ hãi; tạo hộp đá Rubik 1m³ yểm bùa; Khôi tự ở lại vì bát cháo gừng bà Mận.',
    targetObjective: 'Hóa giải bùa trận Rubik của Ba Chú Linh và đối mặt với nỗi sợ phản bội.',
    completed: false,
    active: false,
    rewardXp: 550,
  },
  {
    id: 'quest_arc9',
    chapter: 'Arc 9: Chu Mạnh Hiếu & Thuật Hoán Não',
    title: 'Chu Mạnh Hiếu và Thuật Thức Hoán Não (2065 - 2068)',
    summary: '[A09-E001 → A09-E005] Hiếu đào mộ tráo não Tài, lắp tay thép gõ 108 nhịp hút vía; Khôi khám nghiệm đồi mộ, diệt tà sư Lạng Sơn, phá đài tế, kích hoạt phản phệ não Tài mục rã và hội ngộ Lục Triều Dư.',
    targetObjective: 'Khám phá nấm mộ Tài bị đào xới, đột nhập Hang Đá Lạng Sơn diệt Avatar Chu Mạnh Hiếu và nhận cáp thép từ Lục Triều Dư.',
    completed: false,
    active: false,
    rewardXp: 1500,
  },
  {
    id: 'quest_arc10',
    chapter: 'Arc 10: Lục Triều Dư / Kéo Khôi Trở Lại',
    title: 'Thằng Treo Dây Cáp Thép — Phe Kéo (2068)',
    summary: '[A10-E001 → A10-E005] Dư 32 tuổi cựu đặc công gãy 3 đốt sống, giăng 3 neo cáp thép, hạ Trùm Đao Thủ, gõ 108 nhịp mở Rubik 1m³, khoác Áo Phao Đen Rách kéo Khôi trở lại thành Hai Thằng Canh Cổng.',
    targetObjective: 'Đến Vách Đá Ngục Môn Cương Mốc 1088, hạ quái, gõ 108 nhịp mở Rubik kéo Khôi dậy và về Cổng Đình Bản Cáu bảo vệ 20 đứa trẻ.',
    completed: false,
    active: false,
    rewardXp: 2000,
  },
  {
    id: 'quest_arc11',
    chapter: 'Arc 11: Trận Cuối Ở Trường Mầm Non (2068)',
    title: 'Hai Thằng Canh Cổng & Đại Kết Cục Bình Liêu Vương',
    summary: '[A11-E001 → A11-E007] Đột kích trường mầm non lúc 3h sáng, Dư giăng cáp giật sập xích đu bẫy tay thép, Khôi chém gãy tay thép 108 nhịp; Chu Hiếu Què bộc lộ Dạng 2 Bản Khuyết Tật; nhát liềm DỪNG LẠI hóa giải tâm ma; cứu 20 đứa trẻ, hồn Tài siêu thoát; Khôi và Dư ngồi canh cổng đình đón bình minh!',
    targetObjective: 'Đột kích trường mầm non, đánh bại Chu Mạnh Hiếu Dạng 1 & Dạng 2, thực thi nhát chém DỪNG, cứu 20 đứa trẻ và hoàn tất Đại Kết Cục Bình Liêu Vương.',
    completed: false,
    active: false,
    rewardXp: 5000,
  }
];

export const DIALOG_SCRIPTS: Record<string, DialogSequence> = {
  dialog_cu_tho_intro: {
    id: 'dialog_cu_tho_intro',
    lines: [
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Khôi... Chân cụt thì đi bằng gậy. Mắt mờ thì nhìn bằng lòng. Con cầm liềm, nhưng nhớ lấy lời già: Võ là để giữ người, không phải để giết người.'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Cụ Thọ. Con nhớ. Đêm trước, gậy của thầy gãy... nhưng con đã hạ liềm.'
      },
      {
        speaker: {
          id: 'tho',
          name: 'Cụ Thọ',
          title: 'Trưởng lão Bản Cáu',
          color: '#e2b36f',
          avatarId: 'avatar_tho'
        },
        text: 'Mày không giết người. Mày bình người. Đám Huyết Trúc đang quấy quả trên sườn Chùa Cổ Nguyệt. Cầm lấy thang thuốc của Thanh, cẩn thận lũ người tâm ma.'
      }
    ]
  },
  dialog_la_thanh_intro: {
    id: 'dialog_la_thanh_intro',
    lines: [
      {
        speaker: {
          id: 'thanh',
          name: 'La Thanh',
          title: 'Con gái thầy lang',
          color: '#81c784',
          avatarId: 'avatar_thanh'
        },
        text: 'Khôi! Lại đây. Cơm nguội và trứng luộc tao để trong túi vải đấy. Nhớ ăn no, đừng có nhịn rồi lại sốt li bì như năm 15 tuổi.'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Tao biết rồi. Cảm ơn mày, Thanh.'
      },
      {
        speaker: {
          id: 'thanh',
          name: 'La Thanh',
          title: 'Con gái thầy lang',
          color: '#81c784',
          avatarId: 'avatar_thanh'
        },
        text: 'Mày mạnh thì giữ. Tao yếu thì giữ mày. Nếu một ngày mày đi sai đường... tao sẽ đâm vào tim mày đấy. Nhưng đừng để tao phải đâm.'
      }
    ]
  },
  dialog_tai_and_dom: {
    id: 'dialog_tai_and_dom',
    lines: [
      {
        speaker: {
          id: 'tai',
          name: 'Lài Phúc Tài',
          title: 'Tài Dog',
          color: '#ffb74d',
          avatarId: 'avatar_tai'
        },
        text: 'Cậu Khôi! Đốm lại chạy vòng quanh cổng đình kìa. Nhìn hai đứa cháu què quặt buồn cười lắm đúng không?'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Mày với Đốm đúng là cặp dog, chẳng đứa nào chạy nổi.'
      },
      {
        speaker: {
          id: 'tai',
          name: 'Lài Phúc Tài',
          title: 'Tài Dog',
          color: '#ffb74d',
          avatarId: 'avatar_tai'
        },
        text: 'Thế cậu là Wolf! Chạy nhanh nhưng cắn chết người... Mà cậu ơi, đừng bình nữa nhé. Cứ giữ thôi.'
      }
    ]
  },
  dialog_hoang_can_spirit: {
    id: 'dialog_hoang_can_spirit',
    lines: [
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Chân Ảnh)',
          title: 'Trúc Thánh',
          color: '#a5d6a7',
          avatarId: 'avatar_can'
        },
        text: 'Khôi. Khóm trúc 7 cây ta dặn con trồng, nay đã đâm chồi xanh mướt. Đêm hôm đó, liềm của con bổ đứt gậy trúc, ta đã an lòng.'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Sư phụ... phe Giữ và Huyết Trúc đang trật bánh. Chu Mạnh Hiếu giật dây những kẻ phản bội.'
      },
      {
        speaker: {
          id: 'can',
          name: 'Hoàng Cần (Chân Ảnh)',
          title: 'Trúc Thánh',
          color: '#a5d6a7',
          avatarId: 'avatar_can'
        },
        text: 'Hãy đến thác Khe Vằn. Rửa sạch sát khí trong mắt con. Dòng nước gầm 100 tầng sẽ trao cho con sức mạnh của sự Dừng Lại!'
      }
    ]
  },
  dialog_luc_trieu_du_meet: {
    id: 'dialog_luc_trieu_du_meet',
    lines: [
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây (Phe Kéo)',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! Mày còn thở không? Cầm lấy áo phao đen rách này. Shibuya còn một thằng Hiếu chưa chết!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Dư... Mày lại đu dây từ Khe Vằn xuống à?'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây (Phe Kéo)',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Mày không cần bình nữa. Lần này để tao bình mày! Trường mầm non 3h sáng, tao đã giăng sẵn cáp thép giữa hai vách cột. Tao giật đổ xích đu, mày bổ đứt tà niệm!'
      }
    ]
  },
  dialog_boss_confrontation: {
    id: 'dialog_boss_confrontation',
    lines: [
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Mạnh Hiếu (Mặt Tài)',
          title: 'Tà Sư Hoán Não',
          color: '#ef5350',
          avatarId: 'avatar_hieu'
        },
        text: 'Cậu ơi... Cậu cứu cháu đi! Tay thép đau quá cậu ơi... Haha! Khôi, mày thấy thế nào? Não nó vẫn nhớ mày đấy!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Mày không phải Tài. Tài của tao... chết thanh thản rồi. Mày cướp quyền yên nghỉ của một đứa trẻ 17 tuổi!'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Mạnh Hiếu (Mặt Tài)',
          title: 'Tà Sư Hoán Não',
          color: '#ef5350',
          avatarId: 'avatar_hieu'
        },
        text: 'Để xem cái liềm cùn của Bình Liêu Vương có dám chém vào khuôn mặt đứa cháu ruột này không! 108 Nhịp Tay Thép — Sát Diệt!'
      }
    ]
  },
  dialog_boss_phase_2_transform: {
    id: 'dialog_boss_phase_2_transform',
    lines: [
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Mạnh Hiếu (Xé Áo)',
          title: 'Chu Hiếu Què',
          color: '#ef4444',
          avatarId: 'avatar_hieu'
        },
        text: 'Hahaha! Khôi, mày tưởng bổ gãy tay thép của Thảo là xong à?! Não của Tài... tao đã trả về cho đất mẹ rồi! Giờ là lúc tao đánh bằng bản ngã thật của tao!'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Lôi Ảnh Thủ',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: '(Xé toạc áo ngoài, lộ áo sát nách của Thầy Huỳnh và sẹo tia sét Nữ Thánh Rắn) Nhìn cho kỹ! Chân phải tao ngắn hơn chân trái 2cm! Tụi nó gọi tao là "Hiếu què", là "thằng ăn rỉ chim", "thằng liếm chân"!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Chiếc áo sát nách thầy Huỳnh cho mày... Và vết sẹo nọc rắn Móng Cái. Mày vẫn còn giữ nó sao, Hiếu?'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Đứa Con Rắn',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: 'Thầy Huỳnh từng bảo: "Mày què mà chạy nhanh hơn cả tao, sau này làm anh hùng đi!" Năm lớp 5 tao cởi áo cân 3 lớp bằng đòn vật YouTube! Tao đứng một chân trên cột điện 30 phút mỗi ngày để luyện LÔI ẢNH THỦ!'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Khôi! Thằng này điên thật rồi! Nọc Nữ Thánh Rắn đang bốc khói sấm sét xanh ngọc khắp người nó!'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Lôi Ảnh Thủ (Dạng 2)',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: 'CÁI GÌ KHÔNG GIẾT ĐƯỢC TAO THÌ LÀM TAO MẠNH HƠN! 7 đêm trên nóc chợ Bình Liêu chưa phân thắng bại... ĐÊM NAY ĐỨNG MỘT CHÂN ĐẤM GÃY XƯƠNG MÀY, BÌNH LIÊU VƯƠNG!'
      }
    ]
  },
  dialog_boss_victory: {
    id: 'dialog_boss_victory',
    lines: [
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Lôi Ảnh Thủ',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: '(Khuỵu một chân xuống nền tuyết, mỉm cười nhìn vết sẹo tia sét) Khôi... Mày chém trúng rồi. Đòn Dừng... của cụ Thọ... quả nhiên lợi hại.'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: '(Thu liềm, chìa tay đỡ Hiếu dậy) Hiếu què... Mày què nhưng chạy 100m vẫn 11 giây. Tao cũng từng liếm chân sau khi chạy 10km. Bình thường.'
      },
      {
        speaker: {
          id: 'hieu',
          name: 'Chu Hiếu Què',
          title: 'Đứa Con Rắn',
          color: '#10b981',
          avatarId: 'avatar_hieu_khuyet_tat'
        },
        text: 'Haha... Thầy Huỳnh... con không làm bẩn chiếc áo của thầy chứ? Nữ Thánh Rắn... đứa con rắn của người... đã gặp được một đối thủ xứng đáng.'
      },
      {
        speaker: {
          id: 'tai',
          name: 'Hồn Tài Dog',
          title: 'Lài Phúc Tài',
          color: '#ffb74d',
          avatarId: 'avatar_tai'
        },
        text: 'Cậu Khôi... Chú Hiếu trả lại não cho cháu rồi. Cháu thanh thản rồi cậu ơi... Cảm ơn cậu đã giải thoát cho cả hai.'
      },
      {
        speaker: {
          id: 'du',
          name: 'Lục Triều Dư',
          title: 'Thằng Treo Dây',
          color: '#90caf9',
          avatarId: 'avatar_du'
        },
        text: 'Hai thằng mày đều điên như nhau. Nhưng tâm đều sáng. Dây cáp tao đã giăng, tuyết Shibuya đã ngớt. Về cổng đình thôi Khôi!'
      },
      {
        speaker: {
          id: 'khoi',
          name: 'Bình Khôi',
          title: 'Bình Liêu Vương',
          color: '#4fc3f7',
          avatarId: 'avatar_khoi'
        },
        text: 'Về. Nhưng không ngồi nữa. Đứng thẳng.'
      }
    ]
  },
  ...ARC_1_DIALOG_SEQUENCES,
  ...ARC_2_DIALOG_SEQUENCES,
  ...ARC_3_DIALOG_SEQUENCES,
  ...ARC_4_DIALOG_SEQUENCES,
  ...ARC_5_DIALOG_SEQUENCES,
  ...ARC_6_DIALOG_SEQUENCES,
  ...ARC_7_DIALOG_SEQUENCES,
  ...ARC_8_DIALOG_SEQUENCES,
  ...ARC_9_DIALOG_SEQUENCES,
  ...ARC_10_DIALOG_SEQUENCES,
  ...ARC_11_DIALOG_SEQUENCES
};
