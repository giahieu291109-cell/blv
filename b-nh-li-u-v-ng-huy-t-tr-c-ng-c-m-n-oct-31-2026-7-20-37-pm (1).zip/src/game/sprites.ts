/**
 * Procedural Pixel Art Drawing Engine for BÌNH LIÊU VƯƠNG
 * Renders high-quality pixel characters, animations, and weapon effects with zero external image dependencies.
 */

import { Direction, Enemy, NPC, PlayerActionState } from './types';
import { SukunaSpriteEngine } from './sukunaSprite';

export class PixelRenderer {
  /**
   * Helper to draw a pixel block
   */
  private static pixel(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string) {
    ctx.fillStyle = color;
    ctx.fillRect(Math.floor(x), Math.floor(y), Math.floor(w), Math.floor(h));
  }

  /**
   * Render Player (Hoàng Minh Bình Khôi / Ryomen Sukuna 32x32 Terraria Pixel Art)
   */
  public static renderPlayer(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    state: PlayerActionState,
    direction: Direction,
    animTimer: number,
    isInvincible: boolean,
    isDashing: boolean,
    speechBubble?: string,
    isSukunaMode?: boolean
  ) {
    if (isInvincible && Math.floor(animTimer * 20) % 2 === 0) {
      return; // Flash effect when taking damage
    }

    // Check if Sukuna mode is active or if performing Sukuna's innate cursed techniques
    const isUsingSukunaSkill =
      state === 'skill_dismantle' ||
      state === 'skill_cleave' ||
      state === 'skill_kamino' ||
      state === 'skill_shrine' ||
      state === 'skill_world_slash';

    if (isSukunaMode || isUsingSukunaSkill) {
      // 2D Side-Scrolling 32x32 Pixel Art Terraria-Style Ryomen Sukuna
      SukunaSpriteEngine.renderSukuna(ctx, x, y, state, direction, animTimer, 1.65, isDashing);

      // Dynamic Player Speech Bubble (Hội thoại thế giới thời gian thực)
      if (speechBubble) {
        ctx.save();
        ctx.translate(Math.floor(x), Math.floor(y));
        ctx.font = 'bold 10px "Be Vietnam Pro", sans-serif';
        const bubbleW = ctx.measureText(speechBubble).width + 16;
        ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(-bubbleW / 2, -78, bubbleW, 22, 5);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#fca5a5';
        ctx.textAlign = 'center';
        ctx.fillText(speechBubble, 0, -63);
        ctx.restore();
      }
      return;
    }

    ctx.save();
    ctx.translate(Math.floor(x), Math.floor(y));
    if (direction === -1) {
      ctx.scale(-1, 1);
    }

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, 2, 14, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dash trail effect
    if (isDashing) {
      ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.fillRect(-18, -42, 28, 40);
    }

    // Animation frame calculations
    const walkBob = state === 'run' ? Math.sin(animTimer * 14) * 3 : 0;
    const legOffset = state === 'run' ? Math.sin(animTimer * 14) * 6 : 0;
    const jumpStretch = state === 'jump' ? -3 : state === 'fall' ? 2 : 0;

    const basePosY = walkBob + jumpStretch;

    // --- LEGS / BOOTS ---
    // Left leg
    ctx.fillStyle = '#0f172a'; // Black tactical pants
    ctx.fillRect(-8 + (state === 'run' ? legOffset : 0), -14 + basePosY, 6, 14);
    // Right leg
    ctx.fillRect(2 - (state === 'run' ? legOffset : 0), -14 + basePosY, 6, 14);

    // Bata shoes with torn toe (lore: "giày bata rách mũi")
    ctx.fillStyle = '#334155';
    ctx.fillRect(-9 + (state === 'run' ? legOffset : 0), -4 + basePosY, 7, 4);
    ctx.fillRect(1 - (state === 'run' ? legOffset : 0), -4 + basePosY, 7, 4);
    // Torn toe spot
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(-9 + (state === 'run' ? legOffset : 0), -3 + basePosY, 2, 2);

    // --- TORSO & TACTICAL COAT ---
    // Grey undershirt
    ctx.fillStyle = '#475569';
    ctx.fillRect(-7, -30 + basePosY, 14, 16);

    // Black tactical coat
    ctx.fillStyle = '#1e232a';
    ctx.fillRect(-9, -32 + basePosY, 18, 17);

    // Silver shoulder plates (lore: "áo khoác tactical đen bạc vai")
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(-10, -32 + basePosY, 4, 4);
    ctx.fillRect(6, -32 + basePosY, 4, 4);

    // White scarf dính máu khô (lore: "khăn trắng dính máu khô")
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(-8, -34 + basePosY, 16, 5);
    // Blood speckle on scarf
    ctx.fillStyle = '#881337';
    ctx.fillRect(-2, -33 + basePosY, 3, 2);
    // Scarf tail trailing behind
    const scarfFlap = Math.sin(animTimer * 10) * 4;
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(-12, -32 + basePosY + (state === 'run' ? scarfFlap : 0), 4, 10);

    // Necklace with broken bamboo fragment (lore: "dây chuyền bạc có mảnh gậy trúc gãy")
    ctx.fillStyle = '#cbd5e1'; // Silver chain
    ctx.fillRect(-1, -29 + basePosY, 2, 2);
    ctx.fillStyle = '#16a34a'; // Bamboo fragment
    ctx.fillRect(-1, -27 + basePosY, 3, 3);

    // --- HEAD & FACE ---
    // Head base (tanned skin)
    ctx.fillStyle = '#f6d8b8';
    ctx.fillRect(-6, -44 + basePosY, 12, 10);

    // Monolid red-rimmed eye (lore: "mắt một mí hơi đỏ do thiếu ngủ")
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(1, -41 + basePosY, 3, 2);
    ctx.fillStyle = '#ef4444'; // Red tiredness ring
    ctx.fillRect(0, -40 + basePosY, 4, 1);

    // Cheek scar (lore: "sẹo 3cm ngang gò má trái")
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(-3, -39 + basePosY, 4, 1);

    // Hair: Black cropped, bangs covering half ear (lore: "tóc đen húi, che nửa tai")
    ctx.fillStyle = '#090d16';
    ctx.fillRect(-8, -47 + basePosY, 15, 6);
    ctx.fillRect(-8, -44 + basePosY, 4, 6);
    ctx.fillRect(3, -45 + basePosY, 4, 4);

    // --- BĂNG GIÁP (Tuyết Phủ 109) ---
    // If player has Băng Giáp, render an icy crystalline outline
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(-12, -48 + basePosY, 24, 48);

    // --- WEAPON: LIỀM TỬ THẦN OR BÚT BĂNG & NỬA GẬY TRÚC ---
    if (state === 'attack1' || state === 'attack2' || state === 'attack3') {
      // Swung attack state
      const comboPhase = state === 'attack1' ? 1 : state === 'attack2' ? 2 : 3;
      const swingAngle = Math.PI * (0.2 + comboPhase * 0.35);

      ctx.save();
      ctx.translate(6, -26 + basePosY);
      ctx.rotate(swingAngle);

      // Handle (ebony wood + black grip wrap)
      ctx.fillStyle = '#1e1b18';
      ctx.fillRect(0, -2, 20, 4);
      ctx.fillStyle = '#334155'; // Grip wraps
      ctx.fillRect(4, -2, 2, 4);
      ctx.fillRect(9, -2, 2, 4);

      // Blade: Translucent Cyan Bút Băng or Silver Scythe
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(20, 0, 16, -Math.PI / 2, Math.PI / 4, false);
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#f8fafc';
      ctx.stroke();

      // Blade nick (lore: "vết mẻ nhỏ ở góc")
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(26, -6, 2, 2);

      // Sharp blade glow / motion blur
      ctx.strokeStyle = comboPhase === 3 ? 'rgba(239, 68, 68, 0.8)' : 'rgba(56, 189, 248, 0.7)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(20, 0, 22, -Math.PI / 2, Math.PI / 4, false);
      ctx.stroke();

      ctx.restore();
    } else if (state === 'skill_neon_gay') {
      // Neon Gãy: Crushed neon sign glowing cyan & magenta
      ctx.save();
      ctx.translate(12, -24 + basePosY);
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(-6, -16, 24, 6);
      ctx.fillStyle = '#d946ef';
      ctx.fillRect(0, -20, 16, 4);
      // Electric sparks
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-10, -10);
      ctx.lineTo(20, -30);
      ctx.lineTo(5, -5);
      ctx.stroke();
      ctx.restore();
    } else if (state === 'skill_coi_cuu_thuong') {
      // Còi Cứu Thương 3:17AM: Red & Cyan emergency flashes
      ctx.fillStyle = 'rgba(239, 68, 68, 0.6)';
      ctx.fillRect(-24, -40, 48, 8);
      ctx.fillStyle = 'rgba(56, 189, 248, 0.6)';
      ctx.fillRect(-24, -32, 48, 8);
    } else if (state === 'sealed_tuyet_trang') {
      // Phong Ấn Tuyết Trắng: Ice Tomb
      ctx.fillStyle = 'rgba(224, 242, 254, 0.65)';
      ctx.fillRect(-18, -56, 36, 60);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.strokeRect(-18, -56, 36, 60);
      // Ice spikes
      ctx.fillStyle = '#bae6fd';
      ctx.beginPath();
      ctx.moveTo(-18, -56);
      ctx.lineTo(0, -74);
      ctx.lineTo(18, -56);
      ctx.fill();
    } else if (state === 'skill_khevan') {
      // Khe Vằn Trảm: Dynamic wave slash pose
      ctx.save();
      ctx.translate(10, -26 + basePosY);
      ctx.rotate(Math.PI * 0.4);

      ctx.fillStyle = '#1e1b18';
      ctx.fillRect(0, -2, 22, 4);

      // Water wave arc
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(14, 0, 28, -Math.PI * 0.6, Math.PI * 0.6, false);
      ctx.stroke();

      ctx.strokeStyle = '#e0f2fe';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(14, 0, 32, -Math.PI * 0.6, Math.PI * 0.6, false);
      ctx.stroke();

      ctx.restore();
    } else {
      // Idle / running: Scythe held ready
      ctx.fillStyle = '#1e1b18'; // Mun wood handle
      ctx.fillRect(6, -24 + basePosY, 4, 18);

      // Scythe blade pointing down (lore: "bóng đen cầm liềm hướng xuống đất")
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.arc(8, -6 + basePosY, 10, 0, Math.PI / 2, false);
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#cbd5e1';
      ctx.stroke();

      // Broken bamboo staff in left hand or belt
      ctx.fillStyle = '#15803d'; // Green bamboo
      ctx.fillRect(-10, -26 + basePosY, 3, 14);
      ctx.fillStyle = '#86efac'; // Bamboo node
      ctx.fillRect(-10, -20 + basePosY, 3, 2);
    }

    // Dynamic Player Speech Bubble (Hội thoại thế giới thời gian thực)
    if (speechBubble) {
      ctx.save();
      if (direction === -1) {
        ctx.scale(-1, 1); // Unflip so text reads left-to-right
      }
      ctx.font = 'bold 10px "Be Vietnam Pro", sans-serif';
      const bubbleW = ctx.measureText(speechBubble).width + 16;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(-bubbleW / 2, -78, bubbleW, 22, 5);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#fef08a';
      ctx.textAlign = 'center';
      ctx.fillText(speechBubble, 0, -63);
      ctx.restore();
    }

    ctx.restore();
  }

  /**
   * Render NPC
   */
  public static renderNPC(ctx: CanvasRenderingContext2D, npc: NPC, animTimer: number) {
    ctx.save();
    ctx.translate(Math.floor(npc.x), Math.floor(npc.y));

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.ellipse(0, 0, 14, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    const bob = Math.sin(animTimer * 3 + npc.x) * 1.5;

    if (npc.avatarId === 'avatar_tho') {
      // --- CỤ THỌ (La Thanh Thọ, 72 tuổi, gậy 108 rãnh, mất chân trái) ---
      // Peg leg (left)
      ctx.fillStyle = '#78350f';
      ctx.fillRect(-6, -14, 3, 14);
      // Right leg
      ctx.fillStyle = '#92400e';
      ctx.fillRect(2, -14, 5, 14);

      // Patched brown robe (lore: "áo nâu vá chằng vá đụp")
      ctx.fillStyle = '#78350f';
      ctx.fillRect(-8, -32 + bob, 16, 20);
      // Patches
      ctx.fillStyle = '#9a3412';
      ctx.fillRect(-5, -28 + bob, 5, 5);
      ctx.fillStyle = '#57534e';
      ctx.fillRect(2, -22 + bob, 4, 4);

      // Long white beard down to chest (lore: "râu bạc dài tới ngực")
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-6, -38 + bob, 12, 14);

      // Head & grey hair
      ctx.fillStyle = '#fbd0a1';
      ctx.fillRect(-6, -46 + bob, 12, 10);
      ctx.fillStyle = '#e2e8f0'; // White hair
      ctx.fillRect(-7, -48 + bob, 14, 5);

      // Eyes (lore: "mắt đục nhưng nhìn là biết ai nói dối")
      ctx.fillStyle = '#64748b';
      ctx.fillRect(-2, -43 + bob, 2, 2);
      ctx.fillRect(2, -43 + bob, 2, 2);

      // Bamboo staff with 108 grooves (lore: "gậy trúc khắc 108 rãnh")
      ctx.fillStyle = '#84cc16';
      ctx.fillRect(9, -38, 3, 38);
      ctx.fillStyle = '#facc15'; // Golden carved grooves
      for (let i = 0; i < 6; i++) {
        ctx.fillRect(8, -34 + i * 6, 5, 1);
      }
    } else if (npc.avatarId === 'avatar_me_ban_cau') {
      // --- BÀ MẾ BẢN CÁU (Ký ức 1977 - Bát cháo ngô cưu mang) ---
      // Long indigo ethnic dress reaching the ground
      ctx.fillStyle = '#1e1b4b'; // Dark indigo dress
      ctx.fillRect(-7, -26, 14, 26);
      // Traditional embroidered borders at hem
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-7, -4, 14, 2);
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(-7, -2, 14, 2);
      // Traditional jacket with emerald chest trim
      ctx.fillStyle = '#312e81';
      ctx.fillRect(-8, -34 + bob, 16, 16);
      ctx.fillStyle = '#10b981';
      ctx.fillRect(-2, -32 + bob, 4, 12);
      // Silver collar ring
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, -32 + bob, 5, 0, Math.PI);
      ctx.stroke();
      // Face
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-5, -42 + bob, 10, 9);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-2, -39 + bob, 2, 2);
      ctx.fillRect(2, -39 + bob, 2, 2);
      // Indigo embroidered headdress & red tassel
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(-7, -46 + bob, 14, 6);
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(6, -44 + bob, 3, 5);
      // Piping hot bowl of corn porridge (A01-E001)
      ctx.fillStyle = '#78350f'; // Woven bamboo bowl
      ctx.fillRect(5, -24 + bob, 10, 7);
      ctx.fillStyle = '#facc15'; // Golden corn porridge
      ctx.fillRect(6, -25 + bob, 8, 3);
      // Steam rising
      ctx.fillStyle = 'rgba(254, 240, 138, 0.7)';
      const steamY = Math.sin(animTimer * 6) * 3;
      ctx.fillRect(8, -30 + bob + steamY, 2, 4);
      ctx.fillRect(11, -32 + bob + steamY, 2, 5);
    } else if (npc.avatarId === 'avatar_thanh') {
      // --- LA THANH (Con gái thầy lang, áo blouse trắng, ngải cứu chỉ đỏ) ---
      // Blue scrubs / pants
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(-6, -16, 5, 16);
      ctx.fillRect(1, -16, 5, 16);

      // White medical blouse (lore: "mặc áo blouse trắng")
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-8, -34 + bob, 16, 20);
      ctx.fillStyle = '#e2e8f0'; // Buttons/collar
      ctx.fillRect(-1, -33 + bob, 2, 18);

      // Canvas bag with Cụ Thọ's stethoscope (lore: "túi vải đựng ống nghe")
      ctx.fillStyle = '#d97706';
      ctx.fillRect(-11, -26 + bob, 5, 8);

      // Mugwort leaf with red string on wrist (lore: "lá ngải cứu buộc chỉ đỏ ở cổ tay")
      ctx.fillStyle = '#ef4444'; // Red string
      ctx.fillRect(6, -22 + bob, 4, 2);
      ctx.fillStyle = '#16a34a'; // Mugwort leaf
      ctx.fillRect(8, -24 + bob, 3, 3);

      // Head & face
      ctx.fillStyle = '#ffedd5';
      ctx.fillRect(-5, -44 + bob, 10, 10);
      ctx.fillStyle = '#0f172a'; // Black eyes
      ctx.fillRect(0, -41 + bob, 2, 2);

      // Low ponytail hair (lore: "tóc buộc đuôi ngựa thấp")
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(-6, -47 + bob, 12, 6);
      ctx.fillRect(-8, -44 + bob, 4, 14); // Ponytail
    } else if (npc.avatarId === 'avatar_tai') {
      // --- LÀI PHÚC TÀI (Tài Dog, 17 tuổi) & ĐỐM (Chó cỏ què 1 chân) ---
      // Boy
      ctx.fillStyle = '#3b82f6';
      ctx.fillRect(-4, -14, 4, 14);
      ctx.fillRect(1, -14, 4, 14);
      // Yellow jacket
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(-6, -30 + bob, 13, 16);
      // Face
      ctx.fillStyle = '#fde68a';
      ctx.fillRect(-5, -40 + bob, 10, 10);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, -37 + bob, 2, 2);
      // Hair
      ctx.fillStyle = '#451a03';
      ctx.fillRect(-6, -43 + bob, 12, 5);

      // Đốm: 3-legged dog sitting next to Tài
      ctx.save();
      ctx.translate(14, 0);
      // Dog body (light brown with spots)
      ctx.fillStyle = '#d97706';
      ctx.fillRect(-4, -10, 12, 8);
      // Spots
      ctx.fillStyle = '#78350f';
      ctx.fillRect(0, -9, 4, 4);
      // Head
      ctx.fillRect(6, -14, 6, 6);
      // Ears
      ctx.fillStyle = '#451a03';
      ctx.fillRect(5, -16, 3, 3);
      // 3 legs
      ctx.fillStyle = '#92400e';
      ctx.fillRect(-3, -2, 3, 3);
      ctx.fillRect(3, -2, 3, 3);
      ctx.fillRect(7, -2, 3, 3);
      // Wagging tail
      const tailWag = Math.sin(animTimer * 12) * 4;
      ctx.fillRect(-6, -12 + tailWag, 3, 3);
      ctx.restore();
    } else if (npc.avatarId === 'avatar_can') {
      // --- HOÀNG CẦN (Chân Ảnh Trúc Thánh) ---
      // Glowing ethereal aura
      ctx.fillStyle = 'rgba(74, 222, 128, 0.2)';
      ctx.beginPath();
      ctx.arc(0, -22, 24, 0, Math.PI * 2);
      ctx.fill();

      // Master robe
      ctx.fillStyle = '#312e81';
      ctx.fillRect(-8, -32 + bob, 16, 32);
      // White hair and long beard
      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(-6, -40 + bob, 12, 16);
      // Face
      ctx.fillStyle = '#fcd34d';
      ctx.fillRect(-5, -46 + bob, 10, 9);
      // Bamboo staff
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(-12, -44, 3, 44);
    } else if (npc.avatarId === 'avatar_du') {
      // --- LỤC TRIỀU DƯ (Thằng Treo Dây, cựu đặc công biên phòng) ---
      // Tactical cargo pants & combat boots (chân chạm đất vững chãi)
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-6, -14, 5, 14);
      ctx.fillRect(1, -14, 5, 14);
      ctx.fillStyle = '#0f172a'; // Combat boots
      ctx.fillRect(-7, -4, 6, 4);
      ctx.fillRect(1, -4, 6, 4);

      // Camo / tactical vest
      ctx.fillStyle = '#365314';
      ctx.fillRect(-7, -32 + bob, 14, 18);
      // Steel cables wrapped over shoulders
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(-9, -30 + bob, 3, 16);
      ctx.fillRect(6, -30 + bob, 3, 16);
      // Strong shoulders & face
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-5, -44 + bob, 10, 11);
      ctx.fillStyle = '#1c1917'; // Buzzcut
      ctx.fillRect(-6, -46 + bob, 12, 4);
      // Cable hook on hand
      ctx.fillStyle = '#64748b';
      ctx.fillRect(7, -20 + bob, 5, 5);

      // If Dư is striking, draw cable lines shooting forward
      if (npc.state === 'cable_strike') {
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(10, -20 + bob);
        ctx.lineTo(60 * (npc.direction || 1), -25);
        ctx.stroke();
        // Hook
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(58 * (npc.direction || 1), -28, 6, 6);
      }
    } else if (npc.avatarId === 'avatar_me_ban_cau') {
      // --- BÀ MẾ BẢN CÁU (Ký ức 1977 - Bát cháo ngô cưu mang) ---
      // Legs / Long Indigo Skirt reaching the ground
      ctx.fillStyle = '#1e1b4b'; // Dark indigo ethnic dress
      ctx.fillRect(-7, -26, 14, 26);
      // Traditional patterned border at skirt hem
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-7, -4, 14, 2);
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(-7, -2, 14, 2);
      // Traditional jacket / embroidered shirt
      ctx.fillStyle = '#312e81';
      ctx.fillRect(-8, -34 + bob, 16, 16);
      ctx.fillStyle = '#10b981'; // Embroidered chest trim
      ctx.fillRect(-2, -32 + bob, 4, 12);
      // Silver necklace / collar ring (vòng bạc cổ truyền)
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, -32 + bob, 5, 0, Math.PI);
      ctx.stroke();
      // Face
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-5, -42 + bob, 10, 9);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-2, -39 + bob, 2, 2);
      ctx.fillRect(2, -39 + bob, 2, 2);
      // Indigo embroidered headdress / scarf
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(-7, -46 + bob, 14, 6);
      ctx.fillStyle = '#dc2626'; // Red tassel / fringe
      ctx.fillRect(6, -44 + bob, 3, 5);
      // Bưng bát cháo ngô nóng bốc khói trên tay (lore A01-E001)
      ctx.fillStyle = '#78350f'; // Bamboo woven bowl
      ctx.fillRect(5, -24 + bob, 10, 7);
      ctx.fillStyle = '#facc15'; // Piping hot yellow corn porridge
      ctx.fillRect(6, -25 + bob, 8, 3);
      // Steam / smoke rising from the hot porridge
      ctx.fillStyle = 'rgba(254, 240, 138, 0.7)';
      const steamY = Math.sin(animTimer * 6) * 3;
      ctx.fillRect(8, -30 + bob + steamY, 2, 4);
      ctx.fillRect(11, -32 + bob + steamY, 2, 5);
    } else if (npc.id === 'npc_ba_man') {
      // --- BÀ MẬN (Bát Cháo Gừng Ấm Tình Người — Arc 8 A08-E005) ---
      // Lưng còng, chống gậy tre, áo chàm cổ truyền Bản Cáu
      // Gậy tre chống một bên
      ctx.fillStyle = '#84cc16';
      ctx.fillRect(-12, -28 + bob, 2.5, 28);
      // Áo bà ba chàm sẫm
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(-7, -30 + bob, 14, 18);
      // Chiếc khăn vấn đầu màu chàm truyền thống
      ctx.fillStyle = '#312e81';
      ctx.fillRect(-6, -44 + bob, 12, 6);
      // Tóc bạc búi cao
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(-4, -47 + bob, 8, 4);
      // Khuôn mặt hiền từ nếp nhăn thời gian
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-5, -38 + bob, 10, 8);
      ctx.fillStyle = '#475569';
      ctx.fillRect(-2, -35 + bob, 1.5, 1.5);
      ctx.fillRect(2, -35 + bob, 1.5, 1.5);
      // Rổ mây bưng bát cháo gừng nóng hổi
      ctx.fillStyle = '#a16207';
      ctx.fillRect(4, -22 + bob, 12, 7);
      // Bát sứ cháo gừng thơm cay nồng
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(6, -24 + bob, 8, 3);
      // Làn khói nghi ngút ấm áp xua tan bão tuyết
      ctx.fillStyle = 'rgba(254, 243, 199, 0.8)';
      const steamWave = Math.sin(animTimer * 5) * 3;
      ctx.fillRect(8 + steamWave, -32 + bob, 2, 8);
      ctx.fillRect(11 - steamWave, -35 + bob, 2, 7);
    } else if (npc.id === 'npc_luc_trieu_du_arc9' || npc.id === 'npc_luc_trieu_du_nguc_mon') {
      // --- LỤC TRIỀU DƯ (32 tuổi - Cáp thép mốc 1088 - Arc 9 & Arc 10) ---
      // Quần rằn ri đặc công biên phòng
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-6, -14, 5, 14);
      ctx.fillRect(2, -14, 5, 14);
      // Giày tác chiến cao cổ
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-7, -3, 6, 4);
      ctx.fillRect(1, -3, 6, 4);
      // Áo phao đen dày cộm xé gió
      ctx.fillStyle = '#09090b';
      ctx.fillRect(-10, -36 + bob, 20, 22);
      ctx.fillStyle = '#27272a';
      ctx.fillRect(-8, -34 + bob, 16, 18);
      // Đai đạn và giáp lưng đặc công đỡ 3 đốt sống gãy
      ctx.fillStyle = '#71717a';
      ctx.fillRect(-9, -26 + bob, 18, 4);
      // Cuộn cáp thép 108 sợi bện dày vác chéo vai
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(8, -28 + bob, 9, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(8, -28 + bob, 6, 0, Math.PI * 2);
      ctx.stroke();
      // Khuôn mặt rắn rỏi phong sương người Nùng
      ctx.fillStyle = '#fcd34d';
      ctx.fillRect(-5, -46 + bob, 10, 10);
      // Vết sẹo phong ba đu dây thác Khe Vằn
      ctx.fillStyle = '#b45309';
      ctx.fillRect(-2, -42 + bob, 5, 1.5);
      // Ánh mắt kiên định phe Kéo
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-3, -43 + bob, 2, 2);
      ctx.fillRect(2, -43 + bob, 2, 2);
      // Mũ len ấm màu xám đậm
      ctx.fillStyle = '#18181b';
      ctx.fillRect(-6, -50 + bob, 12, 6);
    }

    // Quest exclamation bubble
    if (npc.hasQuestNotification) {
      const bubbleBob = Math.sin(animTimer * 6) * 3;
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(0, -64 + bubbleBob, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('!', 0, -61 + bubbleBob);
    }

    // NPC 10,000 HP Bar & Name Tag
    const maxHp = npc.maxHp || 10000;
    const hp = npc.hp !== undefined ? npc.hp : maxHp;
    const hpRatio = Math.max(0, Math.min(1, hp / maxHp));

    // HP Bar
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(-22, -56, 44, 4);
    ctx.fillStyle = '#10b981';
    ctx.fillRect(-22, -56, 44 * hpRatio, 4);

    // Floating name tag with 10k HP label
    ctx.font = 'bold 9px "Be Vietnam Pro", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(`${npc.name} (${Math.round(hp / 1000)}k)`, 0, -60);

    // Dynamic combat shout / speech bubble
    if (npc.speechBubble) {
      ctx.font = 'bold 10px "Be Vietnam Pro", sans-serif';
      const bubbleW = ctx.measureText(npc.speechBubble).width + 16;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(-bubbleW / 2, -86, bubbleW, 22, 4);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#7dd3fc';
      ctx.textAlign = 'center';
      ctx.fillText(npc.speechBubble, 0, -71);
    }

    ctx.restore();
  }

  /**
   * Render Enemy
   */
  public static renderEnemy(ctx: CanvasRenderingContext2D, enemy: Enemy, animTimer: number) {
    ctx.save();
    ctx.translate(Math.floor(enemy.x), Math.floor(enemy.y));
    if (enemy.direction === -1) {
      ctx.scale(-1, 1);
    }

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.ellipse(0, 0, enemy.w / 2, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    const bob = enemy.state === 'chase' ? Math.sin(animTimer * 12) * 2 : Math.sin(animTimer * 4);
    const flash = enemy.hurtTimer > 0 && Math.floor(animTimer * 20) % 2 === 0;

    if (enemy.type === 'dummy') {
      // Wood training dummy
      ctx.fillStyle = flash ? '#ffffff' : '#78350f';
      ctx.fillRect(-6, -28, 12, 28);
      ctx.fillStyle = '#92400e';
      ctx.fillRect(-12, -22, 24, 5);
      ctx.fillStyle = '#451a03';
      ctx.fillRect(-4, -36, 8, 8);
    } else if (enemy.type === 'wolf_bien_gioi') {
      // Sói Tuyết Biên Phòng / Dã Thú Biên Giới (A01-E001)
      const legRun = enemy.state === 'chase' ? Math.sin(animTimer * 18) * 6 : 0;
      // Body
      ctx.fillStyle = flash ? '#ffffff' : '#475569';
      ctx.fillRect(-14, -18 + bob, 26, 12);
      // Underbelly / Chest fur
      ctx.fillStyle = flash ? '#ffffff' : '#e2e8f0';
      ctx.fillRect(-12, -12 + bob, 16, 5);
      // Tail
      ctx.fillStyle = '#334155';
      const tailWag = Math.sin(animTimer * 10) * 4;
      ctx.fillRect(-20, -18 + bob + tailWag, 8, 5);
      // Legs (Quadruped)
      ctx.fillStyle = flash ? '#ffffff' : '#1e293b';
      ctx.fillRect(-12 + legRun, -7, 4, 7);
      ctx.fillRect(8 - legRun, -7, 4, 7);
      // Wolf Head & Snout
      ctx.fillStyle = flash ? '#ffffff' : '#334155';
      ctx.fillRect(8, -26 + bob, 14, 11);
      // Snout
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(16, -21 + bob, 8, 6);
      // Sharp white fangs
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(18, -15 + bob, 2, 2);
      ctx.fillRect(21, -15 + bob, 2, 2);
      // Pointed ears
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(10, -31 + bob, 4, 6);
      ctx.fillRect(14, -30 + bob, 3, 5);
      // Fierce glowing red/amber eyes
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(14, -24 + bob, 3, 2);
    } else if (enemy.type === 'boar_nanh_bac') {
      // Lợn Rừng Nanh Bạc Lục Nà (A01-E001)
      const chargeBob = enemy.state === 'attack' ? Math.sin(animTimer * 22) * 3 : bob;
      // Bulky Bristly Body
      ctx.fillStyle = flash ? '#ffffff' : '#3f271d';
      ctx.fillRect(-18, -22 + chargeBob, 32, 17);
      // Dark spiky spine bristles
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(-16, -26 + chargeBob, 26, 5);
      // Thick legs
      ctx.fillStyle = '#27170e';
      ctx.fillRect(-14, -6, 6, 6);
      ctx.fillRect(8, -6, 6, 6);
      // Large Snout
      ctx.fillStyle = '#5c3a21';
      ctx.fillRect(12, -20 + chargeBob, 12, 13);
      ctx.fillStyle = '#ea580c'; // Snout nose
      ctx.fillRect(22, -16 + chargeBob, 4, 5);
      // Giant Curved Silver Tusks (Nanh Bạc)
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(16, -17 + chargeBob, 4, 8);
      ctx.fillRect(19, -21 + chargeBob, 3, 5);
      // Angry red eye
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(12, -22 + chargeBob, 3, 2);
    } else if (enemy.type === 'bandit_bien_gioi') {
      // Sơn Tặc Cướp Lương Biên Giới
      ctx.fillStyle = flash ? '#ffffff' : '#1e293b';
      ctx.fillRect(-6, -14, 4, 14);
      ctx.fillRect(2, -14, 4, 14);
      // Bandit coat
      ctx.fillStyle = flash ? '#ffffff' : '#451a03';
      ctx.fillRect(-8, -32 + bob, 16, 18);
      // Fur collar
      ctx.fillStyle = '#a1a1aa';
      ctx.fillRect(-9, -34 + bob, 18, 5);
      // Cleaver / Machete
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(8, -36 + (enemy.state === 'attack' ? 12 : 0), 4, 28);
      // Face & Mask
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-5, -42 + bob, 10, 10);
      ctx.fillStyle = '#7f1d1d'; // Bandana covering mouth
      ctx.fillRect(-5, -39 + bob, 10, 6);
    } else if (enemy.type === 'bully_tiger') {
      // Đạt "Hổ Mun" - Boss Bắt Nạt Con Nhà Võ (Arc 2)
      // Quần thể thao đen
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.fillRect(-7, -14, 5, 14);
      ctx.fillRect(2, -14, 5, 14);
      // Áo ba lỗ sọc hổ màu cam đen (lore: áo hổ mun con nhà võ)
      ctx.fillStyle = flash ? '#ffffff' : '#ea580c';
      ctx.fillRect(-9, -34 + bob, 18, 20);
      // Sọc vằn hổ mun
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(-7, -30 + bob, 14, 2);
      ctx.fillRect(-7, -24 + bob, 14, 2);
      // Cánh tay cơ bắp & băng quấn tay màu đỏ
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-13, -32 + bob, 4, 16);
      ctx.fillRect(9, -32 + bob, 4, 16);
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(9, -20 + bob, 5, 5);
      // Khuôn mặt hung dữ & tóc đầu đinh nhọn
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-6, -46 + bob, 12, 12);
      ctx.fillStyle = '#18181b';
      ctx.fillRect(-7, -49 + bob, 14, 4);
      ctx.fillStyle = '#b91c1c'; // Mắt trợn trừng
      ctx.fillRect(1, -42 + bob, 2, 2);
      // Nắm đấm tung ra khi tấn công
      if (enemy.state === 'attack') {
        ctx.fillStyle = '#dc2626';
        ctx.fillRect(13, -26 + bob, 12, 8);
      }
    } else if (enemy.type === 'bully_minion') {
      // Tú Rỗ & Kiên Sứt - Côn đồ học đường tay sai
      // Quần bò xanh
      ctx.fillStyle = flash ? '#ffffff' : '#1e3a8a';
      ctx.fillRect(-5, -14, 4, 14);
      ctx.fillRect(1, -14, 4, 14);
      // Áo phông rộng màu xanh rêu
      ctx.fillStyle = flash ? '#ffffff' : '#15803d';
      ctx.fillRect(-7, -30 + bob, 14, 16);
      // Khuôn mặt ngỗ ngược
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-5, -40 + bob, 10, 10);
      ctx.fillStyle = '#78350f'; // Tóc bù xù
      ctx.fillRect(-6, -43 + bob, 12, 4);
      // Cầm gạch / que gỗ trên tay
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(7, -24 + (enemy.state === 'attack' ? 8 : 0) + bob, 5, 5);
    } else if (enemy.type === 'huyet_truc_scout' || enemy.type === 'huyet_truc_elite') {
      // Huyết Trúc / Trúc Đỏ: Rogue disciples in red coats (lore: "Trúc Đỏ, áo phao đen / trúc nhuộm đỏ")
      // Pants
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.fillRect(-6, -14, 4, 14);
      ctx.fillRect(2, -14, 4, 14);

      // Red padded jacket
      ctx.fillStyle = flash ? '#ffffff' : '#b91c1c';
      ctx.fillRect(-8, -32 + bob, 16, 18);

      // Red bamboo staff (lore: "tay cầm trúc nhuộm đỏ")
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(8, -38 + (enemy.state === 'attack' ? 10 : 0), 3, 38);

      // Face & bandana
      ctx.fillStyle = '#fbcfe8';
      ctx.fillRect(-5, -42 + bob, 10, 10);
      ctx.fillStyle = '#991b1b'; // Red headband
      ctx.fillRect(-6, -44 + bob, 12, 4);
    } else if (enemy.type === 'spirit_tuan') {
      // Đinh Quốc Tuấn (Thằng ghi sổ) - Floating phantom with cursed ledger
      const floatY = Math.sin(animTimer * 5) * 6;
      ctx.fillStyle = 'rgba(147, 51, 234, 0.3)';
      ctx.beginPath();
      ctx.arc(0, -24 + floatY, 18, 0, Math.PI * 2);
      ctx.fill();

      // Spectral accountant robe
      ctx.fillStyle = flash ? '#ffffff' : '#581c87';
      ctx.fillRect(-7, -34 + floatY, 14, 24);

      // Cursed Red Ledger (lore: "cầm cuốn sổ đỏ, ghi tên Khôi không ngừng")
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(6, -26 + floatY, 8, 10);
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(8, -24 + floatY, 4, 6);

      // Phantom face
      ctx.fillStyle = '#e9d5ff';
      ctx.fillRect(-5, -44 + floatY, 10, 10);
      ctx.fillStyle = '#7e22ce'; // Purple glowing eyes
      ctx.fillRect(1, -41 + floatY, 2, 2);
    } else if (enemy.type === 'spirit_tay') {
      // Ông Táy (Thằng bỏ bùa) - Cracked face like Rubik, blood chicken talismans
      const floatY = Math.sin(animTimer * 4 + 1) * 5;
      ctx.fillStyle = 'rgba(16, 185, 129, 0.3)';
      ctx.beginPath();
      ctx.arc(0, -24 + floatY, 18, 0, Math.PI * 2);
      ctx.fill();

      // Shaman robe
      ctx.fillStyle = flash ? '#ffffff' : '#064e3b';
      ctx.fillRect(-8, -36 + floatY, 16, 26);

      // Cracked face like 6 Rubik facets (lore: "mặt nứt ra 6 vết như 6 mặt Rubik")
      ctx.fillStyle = '#a7f3d0';
      ctx.fillRect(-6, -46 + floatY, 12, 10);
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(-4, -44 + floatY, 8, 1);
      ctx.fillRect(0, -46 + floatY, 1, 9);

      // Talisman seal "Tù"
      ctx.fillStyle = '#facc15';
      ctx.fillRect(7, -30 + floatY, 7, 12);
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(8, -26 + floatY, 5, 2);
    } else if (enemy.type === 'spirit_hung') {
      // Hùng Đỏ (Thằng đâm sau) - Red cloak, phantom key to Rubik
      const floatY = Math.sin(animTimer * 6) * 4;
      ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
      ctx.beginPath();
      ctx.arc(0, -24 + floatY, 18, 0, Math.PI * 2);
      ctx.fill();

      // Red coat (lore: "áo vẫn đỏ, tay vẫn cầm chìa khóa Rubik")
      ctx.fillStyle = flash ? '#ffffff' : '#991b1b';
      ctx.fillRect(-8, -36 + floatY, 16, 26);

      // Phantom key / dagger
      ctx.fillStyle = '#fde047';
      ctx.fillRect(8, -26 + floatY, 3, 12);
      ctx.fillRect(6, -22 + floatY, 7, 3);

      // Face
      ctx.fillStyle = '#fecaca';
      ctx.fillRect(-5, -46 + floatY, 10, 10);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(1, -43 + floatY, 2, 2);
    } else if (enemy.type === 'boss_chu_manh_hieu') {
      if (enemy.isPhase2) {
        // =========================================================================
        // --- CHU MẠNH HIẾU DẠNG 2: BẢN KHUYẾT TẬT (Chu Hiếu Què · Lôi Ảnh Thủ) ---
        // =========================================================================

        // 1. Aura of Nữ Thánh Rắn Móng Cái (Emerald Green Aura) & Lightning Sparks
        const snakePulse = Math.sin(animTimer * 8) * 4;
        const auraGrad = ctx.createRadialGradient(0, -30 + bob, 10, 0, -30 + bob, 38 + snakePulse);
        auraGrad.addColorStop(0, 'rgba(16, 185, 129, 0.45)');
        auraGrad.addColorStop(0.7, 'rgba(6, 95, 70, 0.25)');
        auraGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = auraGrad;
        ctx.beginPath();
        ctx.arc(0, -30 + bob, 38 + snakePulse, 0, Math.PI * 2);
        ctx.fill();

        // Emerald Cobra ethereal silhouette weaving behind Hiếu
        ctx.strokeStyle = 'rgba(52, 211, 153, 0.6)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-16, -10 + bob);
        ctx.bezierCurveTo(-26, -35 + bob, 18, -45 + bob, 14, -62 + bob);
        ctx.stroke();

        // Cobra flared hood & glowing eyes
        ctx.fillStyle = '#34d399';
        ctx.beginPath();
        ctx.arc(14, -62 + bob, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.fillRect(12, -64 + bob, 2, 2);
        ctx.fillRect(16, -64 + bob, 2, 2);

        // 2. Martial Crane Stance: Đứng một chân trên cột điện (chân phải ngắn hơn 2cm co lên)
        // Chân trái làm trụ thẳng tắp
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-6, -14 + bob, 5, 16);
        ctx.fillStyle = '#0f172a'; // Giày thể dục thầy Huỳnh
        ctx.fillRect(-8, 0, 8, 4);

        // Chân phải ngắn hơn 2cm co ngang đùi (thế đứng Lôi Ảnh Thủ)
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-1, -16 + bob, 12, 5);
        ctx.fillRect(8, -16 + bob, 5, 10);
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(7, -8 + bob, 7, 4);

        // 3. Torso: Áo sát nách thầy Huỳnh cho (màu xanh rêu thể thao, rách vai)
        ctx.fillStyle = flash ? '#ffffff' : '#15803d';
        ctx.fillRect(-9, -38 + bob, 18, 25);
        // Sọc trắng viền cổ & nách áo sát nách
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-9, -38 + bob, 18, 2);
        ctx.fillRect(-8, -36 + bob, 2, 10);
        ctx.fillRect(6, -36 + bob, 2, 10);

        // 4. Cơ bắp cuồn cuộn & Cánh tay phải có SẸO TIA SÉT NỌC RẮN MÓNG CÁI
        // Bắp tay trái
        ctx.fillStyle = '#fbcfe8';
        ctx.fillRect(-15, -34 + bob, 6, 16);
        ctx.fillStyle = '#db2777'; // Băng quấn tay
        ctx.fillRect(-15, -22 + bob, 6, 6);

        // Cánh tay phải — LÔI ẢNH THỦ: Phát sáng lôi điện sấm sét
        ctx.fillStyle = '#fbcfe8';
        ctx.fillRect(9, -36 + bob, 8, 20);

        // Vết sẹo hình tia sét Nữ Thánh Rắn phát sáng vàng/xanh lôi điện
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(11, -34 + bob);
        ctx.lineTo(15, -28 + bob);
        ctx.lineTo(12, -24 + bob);
        ctx.lineTo(16, -18 + bob);
        ctx.stroke();

        // Nắm đấm sấm sét Lôi Ảnh Thủ
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(10, -18 + bob, 8, 8);
        // Tia chớp nhỏ bắn ra từ nắm tay
        if (Math.random() < 0.6) {
          ctx.strokeStyle = '#67e8f9';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(14, -14 + bob);
          ctx.lineTo(14 + (Math.random() - 0.5) * 16, -14 + (Math.random() - 0.5) * 16);
          ctx.stroke();
        }

        // 5. Đầu & Khuôn mặt Chu Hiếu Què (Khuôn mặt thật, ngạo nghễ kiên cường)
        ctx.fillStyle = '#fde68a';
        ctx.fillRect(-7, -51 + bob, 14, 13);

        // Đôi mắt sắc lẹm kiên định (không còn mắt đỏ Hoán Não mà là mắt võ đạo)
        ctx.fillStyle = '#0284c7';
        ctx.fillRect(1, -47 + bob, 3, 3);
        ctx.fillRect(-5, -47 + bob, 3, 3);

        // Tóc rối phong trần & Băng trán
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect(-8, -55 + bob, 16, 5);
        ctx.fillStyle = '#e11d48'; // Băng trán đỏ
        ctx.fillRect(-8, -50 + bob, 16, 2);

        // Nếu đang trong trạng thái biến hình (Transforming flash)
        if (enemy.isTransforming) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.fillRect(-30, -70, 60, 80);
        }
      } else {
        // --- CHU MẠNH HIẾU DẠNG 1 (Hoán Não, mang mặt Tài, áo khoác đen, tay thép Thảo) ---
        // Heavy dark aura
        ctx.fillStyle = 'rgba(220, 38, 38, 0.3)';
        ctx.beginPath();
        ctx.arc(0, -28 + bob, 28, 0, Math.PI * 2);
        ctx.fill();

        // Body (35yo sinister stature, children jacket)
        ctx.fillStyle = flash ? '#ffffff' : '#1e1b4b';
        ctx.fillRect(-10, -38 + bob, 20, 24);

        // Steel arm of Thảo (lore: "dùng tay thép của Thảo chém lại, gõ 108 nhịp")
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(10, -32 + bob, 7, 24);
        ctx.fillStyle = '#e2e8f0'; // Sharp steel claws
        ctx.fillRect(10, -8 + bob, 2, 6);
        ctx.fillRect(13, -8 + bob, 2, 6);
        ctx.fillRect(16, -8 + bob, 2, 6);

        // Head: Shifting face of Tài with bleeding eyes (lore: "giọng Tài, mặt Tài nhưng mắt đỏ như máu")
        ctx.fillStyle = '#fde68a';
        ctx.fillRect(-7, -50 + bob, 14, 12);

        // Blood-red sinister eyes
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(1, -46 + bob, 3, 3);
        ctx.fillRect(-5, -46 + bob, 3, 3);

        // Head scar / Hoán Não surgery line (lore: "mổ sọ tráo não")
        ctx.fillStyle = '#7f1d1d';
        ctx.fillRect(-6, -49 + bob, 12, 1);
      }
    } else if (enemy.type === 'boss_hoang_can') {
      // =========================================================================
      // --- HOÀNG CẦN (TRÚC THÁNH — CỰU CHƯỞNG MÔN VÕ HOÀNG MÔN) ---
      // =========================================================================
      // Golden & Jade Martial Aura
      const auraPulse = Math.sin(animTimer * 6) * 3;
      const canAura = ctx.createRadialGradient(0, -28 + bob, 8, 0, -28 + bob, 32 + auraPulse);
      canAura.addColorStop(0, 'rgba(74, 222, 128, 0.45)');
      canAura.addColorStop(0.6, 'rgba(234, 179, 8, 0.3)');
      canAura.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = canAura;
      ctx.beginPath();
      ctx.arc(0, -28 + bob, 32 + auraPulse, 0, Math.PI * 2);
      ctx.fill();

      // Master martial robe (Dark teal & gold trims)
      ctx.fillStyle = flash ? '#ffffff' : '#064e3b';
      ctx.fillRect(-10, -36 + bob, 20, 24);
      // Gold trim on coat lapel
      ctx.fillStyle = '#facc15';
      ctx.fillRect(-2, -36 + bob, 4, 24);
      ctx.fillRect(-10, -36 + bob, 20, 2);

      // Pants & black kungfu slippers
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-7, -12 + bob, 5, 12);
      ctx.fillRect(2, -12 + bob, 5, 12);
      ctx.fillStyle = '#f8fafc'; // White socks
      ctx.fillRect(-7, -4 + bob, 5, 2);
      ctx.fillRect(2, -4 + bob, 5, 2);

      // Head & serene weathered face
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-6, -48 + bob, 12, 12);

      // Silver white hair bun & jade hairpin
      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(-7, -54 + bob, 14, 7);
      ctx.fillStyle = '#10b981'; // Jade hairpin
      ctx.fillRect(4, -53 + bob, 4, 2);

      // Long flowing silver beard (phiêu dật giữa gió bão)
      const beardWind = Math.sin(animTimer * 8) * 3;
      ctx.fillStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.moveTo(-4, -39 + bob);
      ctx.lineTo(4, -39 + bob);
      ctx.lineTo(2 + beardWind, -24 + bob);
      ctx.lineTo(-2 + beardWind, -24 + bob);
      ctx.fill();

      // Determined sage eyes
      ctx.fillStyle = '#166534';
      ctx.fillRect(1, -44 + bob, 2, 2);
      ctx.fillRect(-4, -44 + bob, 2, 2);

      // --- WEAPON: GẬY TRÚC HOÀNG LONG (108 rãnh tỏa kim quang) ---
      const staffAngle = enemy.state === 'attack' ? -0.4 : 0.15;
      ctx.save();
      ctx.translate(10, -22 + bob);
      ctx.rotate(staffAngle);

      // Bamboo staff shaft
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(-2, -26, 4, 52);
      // Golden notches (108 rãnh)
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(-2, -20, 4, 2);
      ctx.fillRect(-2, -10, 4, 2);
      ctx.fillRect(-2, 0, 4, 2);
      ctx.fillRect(-2, 10, 4, 2);
      ctx.fillRect(-2, 20, 4, 2);

      // Dragon tip glow
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(0, -26, 3.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      // If casting [Hoàng Long Trấn Địa]: shockwave rings on ground
      if (enemy.skillCooldown && enemy.skillCooldown > 3.2) {
        ctx.strokeStyle = 'rgba(250, 204, 21, 0.7)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, 0, 28, 8, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
    } else if (enemy.type === 'bien_gioi_thug') {
      // =========================================================================
      // --- GIANG HỒ BUÔN LẬU BIÊN GIỚI MỐC 1088 (ARC 4) ---
      // =========================================================================
      // Quần túi hộp dù xanh sẫm
      ctx.fillStyle = flash ? '#ffffff' : '#1e293b';
      ctx.fillRect(-6, -14, 4, 14);
      ctx.fillRect(2, -14, 4, 14);

      // Áo khoác rằn ri / dù xanh bộ đội
      ctx.fillStyle = flash ? '#ffffff' : '#166534';
      ctx.fillRect(-8, -32 + bob, 16, 18);
      // Đai đạn / túi đeo chéo
      ctx.fillStyle = '#78350f';
      ctx.fillRect(-8, -30 + bob, 16, 3);

      // Cánh tay cơ bắp & gậy sắt / dao găm
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-11, -30 + bob, 3, 14);
      ctx.fillRect(8, -30 + bob, 3, 14);
      // Gậy sắt / dao
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(8, -28 + (enemy.state === 'attack' ? 10 : 0) + bob, 3, 22);

      // Khuôn mặt sẹo hung hăng
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-5, -42 + bob, 10, 10);
      ctx.fillStyle = '#b91c1c'; // Vết sẹo đỏ chéo mặt
      ctx.fillRect(-3, -40 + bob, 6, 1.5);
      // Tóc đinh / mũ len trùm đầu
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-6, -46 + bob, 12, 5);
    } else if (enemy.type === 'boss_chu_hieu_que_young') {
      // =========================================================================
      // --- CHU MẠNH HIẾU (CHU HIẾU QUÈ 16 TUỔI — LÔI ẢNH THỦ THỜI NIÊN THIẾU) ---
      // =========================================================================
      // Hào quang sấm sét Lôi Ảnh Thủ (xanh ngọc Nữ Thánh Rắn & vàng kim)
      const thunderAura = Math.sin(animTimer * 10) * 4;
      ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
      ctx.beginPath();
      ctx.arc(0, -26 + bob, 26 + thunderAura, 0, Math.PI * 2);
      ctx.fill();

      // Dáng đứng đặc trưng: ĐỨNG MỘT CHÂN (Chân phải ngắn hơn 2cm co nhẹ lên, trụ vững trên chân trái)
      ctx.fillStyle = flash ? '#ffffff' : '#1e1b4b';
      // Chân trái làm trụ đứng thẳng
      ctx.fillRect(-6, -14, 5, 14);
      // Chân phải co nhẹ lên 4px (thế đứng cột điện 5 năm)
      ctx.fillRect(3, -18, 5, 10);
      // Giày thể thao cũ
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-7, -2, 6, 2.5);
      ctx.fillRect(2, -8, 6, 2.5);

      // Áo sát nách màu xám rách vai do Thầy Huỳnh tặng
      ctx.fillStyle = flash ? '#ffffff' : '#475569';
      ctx.fillRect(-8, -34 + bob, 16, 18);
      // Cổ áo khoét sâu để lộ ngực rắn rỏi
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-3, -34 + bob, 6, 6);

      // Cánh tay phải có VẾT SẸO TIA SÉT NỌC NỮ THÁNH RẮN
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-11, -32 + bob, 4, 15);
      ctx.fillRect(8, -32 + bob, 4, 15);

      // Sẹo tia sét xanh ngọc phát sáng trên cánh tay phải
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(10, -30 + bob);
      ctx.lineTo(8, -25 + bob);
      ctx.lineTo(12, -22 + bob);
      ctx.lineTo(9, -17 + bob);
      ctx.stroke();

      // Nắm đấm Lôi Ảnh Thủ bung sấm sét khi tấn công
      if (enemy.state === 'attack') {
        ctx.fillStyle = '#facc15';
        ctx.fillRect(10, -24 + bob, 12, 10);
        // Tia chớp nổ ra
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(22, -19 + bob);
        ctx.lineTo(28, -25 + bob);
        ctx.lineTo(26, -15 + bob);
        ctx.lineTo(34, -18 + bob);
        ctx.stroke();
      }

      // Đầu & Tóc húi cua ngắn 3 phân
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(-6, -46 + bob, 12, 12);
      ctx.fillStyle = '#0f172a'; // Tóc húi cua
      ctx.fillRect(-7, -49 + bob, 14, 4);

      // Khuôn mặt bướng bỉnh, mắt sáng quắc nhưng không có tà niệm (thời 16 tuổi)
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(1, -42 + bob, 2.5, 2.5);
      ctx.fillRect(-4, -42 + bob, 2.5, 2.5);
    } else if (enemy.type === 'huyet_truc_tokyo_scout') {
      // =========================================================================
      // --- ĐAO THỦ / TUẦN THÁM HUYẾT TRÚC TOKYO (ARC 5) ---
      // =========================================================================
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.fillRect(-5, -14, 4, 14);
      ctx.fillRect(1, -14, 4, 14);
      // Áo khoác đen lót đỏ Huyết Trúc
      ctx.fillStyle = flash ? '#ffffff' : '#1e1b4b';
      ctx.fillRect(-7, -32 + bob, 14, 18);
      ctx.fillStyle = '#dc2626'; // Khăn quàng đỏ rủ xuống
      ctx.fillRect(-7, -30 + bob, 14, 3);
      // Đoản đao đỏ rỉ máu
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(7, -30 + (enemy.state === 'attack' ? 8 : 0) + bob, 3, 20);
      // Mặt nạ đen trùm đầu
      ctx.fillStyle = '#18181b';
      ctx.fillRect(-5, -42 + bob, 10, 10);
      ctx.fillStyle = '#ef4444'; // Mắt đỏ
      ctx.fillRect(1, -39 + bob, 2, 2);
    } else if (enemy.type === 'huyet_truc_tokyo_enforcer') {
      // =========================================================================
      // --- VÕ SƯ / ĐAO THỦ HUYẾT TRÚC TOKYO (ARC 5) ---
      // =========================================================================
      ctx.fillStyle = flash ? '#ffffff' : '#020617';
      ctx.fillRect(-6, -15, 5, 15);
      ctx.fillRect(2, -15, 5, 15);
      // Áo hoodie da đen Shibuya
      ctx.fillStyle = flash ? '#ffffff' : '#1e1b4b';
      ctx.fillRect(-9, -35 + bob, 18, 20);
      // Huyết văn đỏ trên ngực áo
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(-5, -30 + bob, 10, 4);
      // Đại đao Huyết Trúc dài 28px
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(9, -40 + (enemy.state === 'attack' ? 12 : 0) + bob, 4, 34);
      ctx.fillStyle = '#f87171'; // Lưỡi đao sắc bén
      ctx.fillRect(13, -36 + (enemy.state === 'attack' ? 12 : 0) + bob, 2, 26);
      // Đầu & Mũ trùm hoodie
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-7, -46 + bob, 14, 12);
      ctx.fillStyle = '#dc2626'; // Mắt đỏ tà đạo
      ctx.fillRect(1, -42 + bob, 2.5, 2.5);
    } else if (enemy.type === 'boss_huyet_truc_tokyo_leader') {
      // =========================================================================
      // --- BOSS THỦ LĨNH HUYẾT TRÚC TOKYO — HUYẾT ĐAO CUỒNG SÁT (ARC 5 BOSS) ---
      // =========================================================================
      // Hào quang tà đạo Huyết Đao Cuồng Sát
      const bloodAura = Math.sin(animTimer * 8) * 5;
      ctx.fillStyle = 'rgba(185, 28, 28, 0.35)';
      ctx.beginPath();
      ctx.arc(0, -28 + bob, 32 + bloodAura, 0, Math.PI * 2);
      ctx.fill();

      // Quần chiến binh samurai đen
      ctx.fillStyle = flash ? '#ffffff' : '#020617';
      ctx.fillRect(-8, -16, 6, 16);
      ctx.fillRect(2, -16, 6, 16);

      // Áo choàng măng-tô da đen tà áo bay phần phật trong bão tuyết
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.fillRect(-12, -40 + bob, 24, 25);
      // Vạt áo choàng xẻ sau bay theo gió
      const windSway = Math.sin(animTimer * 10) * 6;
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(-15, -28 + bob, 6, 20 + windSway);

      // Giáp ngực huyết long đỏ rực
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(-8, -36 + bob, 16, 14);
      ctx.fillStyle = '#f87171';
      ctx.fillRect(-4, -33 + bob, 8, 8);

      // Cánh tay cầm HUYẾT ĐAO CUỒNG SÁT khổng lồ
      ctx.fillStyle = '#374151'; // Găng tay sắt gai
      ctx.fillRect(10, -32 + bob, 6, 18);

      // Lưỡi đao cong hình bán nguyệt đỏ rực sấm sét huyết sắc
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(14, -50 + (enemy.state === 'attack' ? 14 : 0) + bob, 6, 44);
      ctx.fillStyle = '#ef4444'; // Lưỡi đao rực lửa
      ctx.fillRect(20, -46 + (enemy.state === 'attack' ? 14 : 0) + bob, 3, 36);

      // Đầu, Tóc bạc dài & Mặt nạ quỷ Hanya đỏ trắng
      ctx.fillStyle = '#e2e8f0'; // Tóc bạc dài bay trong tuyết
      ctx.fillRect(-10, -56 + bob, 20, 8);
      ctx.fillRect(-12, -50 + bob, 4, 18 + windSway);

      // Mặt nạ quỷ
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(-8, -50 + bob, 16, 14);
      // Mắt quỷ phát sáng vàng kim
      ctx.fillStyle = '#facc15';
      ctx.fillRect(1, -46 + bob, 3, 3);
      ctx.fillRect(-5, -46 + bob, 3, 3);
      // Nanh quỷ trắng
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-3, -40 + bob, 2, 4);
      ctx.fillRect(1, -40 + bob, 2, 4);
    } else if (enemy.type === 'bao_hoa_mai_khe_van') {
      // =========================================================================
      // --- BÁO HOA MAI VÁCH ĐÁ KHE VẰN (ARC 6 - A06-E002) ---
      // =========================================================================
      const runBob = enemy.state === 'chase' ? Math.sin(animTimer * 16) * 4 : bob;
      // Thân báo dẻo dai cơ bắp màu vàng đất điểm hoa mai đen
      ctx.fillStyle = flash ? '#ffffff' : '#d97706';
      ctx.fillRect(-18, -18 + runBob, 32, 13);
      // Đốm hoa mai đen đặc trưng
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(-14, -16 + runBob, 3, 3);
      ctx.fillRect(-8, -13 + runBob, 4, 3);
      ctx.fillRect(-2, -16 + runBob, 3, 3);
      ctx.fillRect(4, -13 + runBob, 4, 3);
      // Bụng dưới lông trắng
      ctx.fillStyle = flash ? '#ffffff' : '#fef3c7';
      ctx.fillRect(-12, -9 + runBob, 20, 4);
      // 4 chân săn mồi móng vuốt sắc
      ctx.fillStyle = flash ? '#ffffff' : '#b45309';
      ctx.fillRect(-14, -6, 5, 7);
      ctx.fillRect(-6, -6, 4, 7);
      ctx.fillRect(4, -6, 4, 7);
      ctx.fillRect(10, -6, 5, 7);
      // Đuôi dài cong vút báo vách đá
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-18, -14 + runBob);
      ctx.quadraticCurveTo(-26, -24 + runBob, -24, -30 + runBob);
      ctx.stroke();
      // Đầu báo & Tai nhọn
      ctx.fillStyle = flash ? '#ffffff' : '#b45309';
      ctx.fillRect(12, -26 + runBob, 12, 12);
      ctx.fillStyle = '#1c1917'; // Tai đen
      ctx.fillRect(13, -30 + runBob, 4, 5);
      ctx.fillRect(20, -30 + runBob, 4, 5);
      // Mắt xanh ngọc sắc lạnh của dã thú săn mồi
      ctx.fillStyle = '#10b981';
      ctx.fillRect(18, -23 + runBob, 3, 3);
      // Nanh vuốt khi vồ mồi
      if (enemy.state === 'attack') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(22, -18 + runBob, 4, 4);
      }
    } else if (enemy.type === 'thuy_quai_khe_van') {
      // =========================================================================
      // --- THỦY QUÁI SUỐI THÁC KHE VẰN (ARC 6) ---
      // =========================================================================
      const swimBob = Math.sin(animTimer * 10) * 4;
      // Vệt nước bọt xoáy dưới chân
      ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 0, 18, 6, 0, 0, Math.PI * 2);
      ctx.fill();
      // Thân rắn nước vảy xanh rêu sẫm
      ctx.fillStyle = flash ? '#ffffff' : '#065f46';
      ctx.fillRect(-14, -20 + swimBob, 28, 14);
      // Vảy lưng lam ngọc phát quang
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(-10, -24 + swimBob, 20, 5);
      // Đuôi quẫy sóng
      ctx.fillStyle = '#047857';
      ctx.fillRect(-22, -16 + swimBob, 10, 8);
      // Đầu thủy quái có sừng mang nước
      ctx.fillStyle = flash ? '#ffffff' : '#064e3b';
      ctx.fillRect(10, -28 + swimBob, 14, 14);
      // Sừng mang nước
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(14, -34 + swimBob, 3, 7);
      ctx.fillRect(19, -32 + swimBob, 3, 5);
      // Mắt vàng lân tinh
      ctx.fillStyle = '#facc15';
      ctx.fillRect(18, -24 + swimBob, 3, 3);
    } else if (enemy.type === 'boss_tam_ma_shibuya') {
      // =========================================================================
      // --- BOSS TÂM MA SHIBUYA (ARC 6 - A06-E003) ---
      // =========================================================================
      // Hào quang huyết sát tâm ma đen đỏ bao trùm
      const darkPulse = Math.sin(animTimer * 7) * 6;
      const auraGrad = ctx.createRadialGradient(0, -30 + bob, 8, 0, -30 + bob, 38 + darkPulse);
      auraGrad.addColorStop(0, 'rgba(220, 38, 38, 0.55)');
      auraGrad.addColorStop(0.6, 'rgba(88, 28, 135, 0.35)');
      auraGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = auraGrad;
      ctx.beginPath();
      ctx.arc(0, -30 + bob, 38 + darkPulse, 0, Math.PI * 2);
      ctx.fill();

      // Bóng đen ma mị hình người tàn tích Shibuya 2028
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      // Chân tà khí lơ lửng không chạm đất
      ctx.fillRect(-7, -14 + bob, 5, 12);
      ctx.fillRect(2, -14 + bob, 5, 12);
      // Áo khoác đen rách tả tơi đầy vệt máu đỏ
      ctx.fillStyle = flash ? '#ffffff' : '#18181b';
      ctx.fillRect(-10, -38 + bob, 20, 26);
      // Tia máu vấy trên ngực áo tâm ma
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(-6, -34 + bob, 12, 5);
      ctx.fillRect(-2, -29 + bob, 4, 12);

      // Cánh tay cầm Huyết Đao Cuồng Nộ ảo ảnh
      ctx.fillStyle = '#3f3f46';
      ctx.fillRect(10, -32 + bob, 5, 18);
      // Lưỡi đao bóng máu rực lửa đen đỏ
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(14, -54 + (enemy.state === 'attack' ? 14 : 0) + bob, 6, 44);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(19, -50 + (enemy.state === 'attack' ? 14 : 0) + bob, 3, 36);

      // Đầu ma quỷ & MẶT NẠ HANYA ĐỎ RỰC TIA MÁU ĐEN
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(-8, -52 + bob, 16, 15);
      // Mắt đỏ rực sát khí Shibuya không tan
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(1, -48 + bob, 3, 3);
      ctx.fillRect(-5, -48 + bob, 3, 3);
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(2, -47 + bob, 1.5, 1.5);
      ctx.fillRect(-4, -47 + bob, 1.5, 1.5);
      // Nanh quỷ Hanya trắng buốt
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-3, -41 + bob, 2, 5);
      ctx.fillRect(2, -41 + bob, 2, 5);
      // Bão tuyết ma quỷ xoay quanh
      ctx.fillStyle = 'rgba(254, 202, 202, 0.4)';
      for (let i = 0; i < 5; i++) {
        const sX = Math.sin(animTimer * 8 + i * 1.5) * 26;
        const sY = -30 + Math.cos(animTimer * 6 + i * 1.2) * 22;
        ctx.fillRect(sX, sY, 3, 3);
      }
    } else if (enemy.type === 'ta_mon_dao_thu' || enemy.type === 'hac_dao_sat_thu') {
      // =========================================================================
      // --- ĐAO THỦ TÀ MÔN MÓNG CÁI (ARC 7 - A07-E005) ---
      // =========================================================================
      const isBoss = !!enemy.isBoss;
      // Chân di chuyển lẩn khuất trong bóng đêm đồi sương
      ctx.fillStyle = flash ? '#ffffff' : '#1e1b4b';
      ctx.fillRect(-6, -12 + bob, 4, 12);
      ctx.fillRect(2, -12 + bob, 4, 12);
      // Giày dạ hành da đen
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-7, -2 + bob, 6, 3);
      ctx.fillRect(1, -2 + bob, 6, 3);

      // Thân áo chẽn đen tím tà môn
      ctx.fillStyle = flash ? '#ffffff' : (isBoss ? '#311042' : '#1e1b4b');
      ctx.fillRect(-8, -32 + bob, 16, 20);
      // Đai lưng vải đỏ thẫm buộc chéo
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(-8, -20 + bob, 16, 3);

      // Cánh tay cầm Đao Tà Môn Móng Cái
      ctx.fillStyle = flash ? '#ffffff' : '#475569';
      ctx.fillRect(8, -26 + bob, 4, 14);
      // Lưỡi đao cong tà môn sắc bén ánh tím độc
      const bladeSwing = enemy.state === 'attack' ? 12 : 0;
      ctx.fillStyle = '#64748b';
      ctx.fillRect(12, -44 + bladeSwing + bob, 4, 28);
      ctx.fillStyle = isBoss ? '#c084fc' : '#a855f7';
      ctx.fillRect(14, -46 + bladeSwing + bob, 2, 26);
      // Cán đao quấn vải tím đen
      ctx.fillStyle = '#312e81';
      ctx.fillRect(11, -16 + bladeSwing + bob, 4, 6);

      // Đầu & Khăn bịt mặt dạ hành đen
      ctx.fillStyle = flash ? '#ffffff' : '#09090b';
      ctx.fillRect(-6, -42 + bob, 12, 11);
      // Mắt quỷ dữ tợn le lói đỏ
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(0, -38 + bob, 3, 2);
      ctx.fillRect(-4, -38 + bob, 3, 2);

      // Hiệu ứng tà khí mờ ảo quanh đao thủ
      if (isBoss) {
        ctx.fillStyle = 'rgba(168, 85, 247, 0.25)';
        ctx.beginPath();
        ctx.arc(0, -24 + bob, 22, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (enemy.type === 'ta_su_hoan_nao') {
      // =========================================================================
      // --- TÀ SƯ MỔ SỌ HOÁN NÃO LẠNG SƠN (ARC 9 - A09-E002) ---
      // =========================================================================
      // Quần đen bó ống & bốt da mổ sọ
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.fillRect(-6, -14, 5, 14);
      ctx.fillRect(2, -14, 5, 14);
      // Áo blouse đen dài nhuốm tà khí tím
      ctx.fillStyle = flash ? '#ffffff' : '#2e1065';
      ctx.fillRect(-8, -34 + bob, 16, 22);
      ctx.fillStyle = '#581c87';
      ctx.fillRect(-6, -32 + bob, 12, 18);
      // Tạp dề da giải phẫu nhuốm vết máu khô
      ctx.fillStyle = '#450a0a';
      ctx.fillRect(-6, -26 + bob, 12, 14);
      // Cánh tay cầm Dao Mổ Sọ sắc lẹm
      ctx.fillStyle = flash ? '#ffffff' : '#334155';
      ctx.fillRect(8, -28 + bob, 4, 14);
      const scalpelSwing = enemy.state === 'attack' ? 10 : 0;
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(11, -38 + scalpelSwing + bob, 3, 16);
      ctx.fillStyle = '#dc2626'; // Vết máu trên mũi dao mổ
      ctx.fillRect(11, -40 + scalpelSwing + bob, 3, 3);
      // Đầu & Khẩu trang y tế đen có thêu bùa sọ
      ctx.fillStyle = flash ? '#ffffff' : '#18181b';
      ctx.fillRect(-6, -44 + bob, 12, 11);
      ctx.fillStyle = '#7c3aed';
      ctx.fillRect(-4, -39 + bob, 8, 5);
      // Mắt tím quỷ dị
      ctx.fillStyle = '#c084fc';
      ctx.fillRect(-3, -41 + bob, 2, 2);
      ctx.fillRect(2, -41 + bob, 2, 2);
    } else if (enemy.type === 'boss_chu_manh_hieu_avatar') {
      // =========================================================================
      // --- BOSS CHU MẠNH HIẾU AVATAR (HOÁN NÃO — TAY THÉP THẢO) (ARC 9 - A09-E003) ---
      // =========================================================================
      // Hào quang hắc ám tím đen & huyết quang ma trận
      const hieuAura = Math.sin(animTimer * 6) * 5;
      const hieuGrad = ctx.createRadialGradient(0, -32 + bob, 6, 0, -32 + bob, 36 + hieuAura);
      hieuGrad.addColorStop(0, 'rgba(124, 58, 237, 0.45)');
      hieuGrad.addColorStop(0.5, 'rgba(239, 68, 68, 0.35)');
      hieuGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = hieuGrad;
      ctx.beginPath();
      ctx.arc(0, -32 + bob, 36 + hieuAura, 0, Math.PI * 2);
      ctx.fill();

      // Chân (một chân ngắn hơn 2cm khập khiễng theo nguyên tác)
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.fillRect(-8, -14, 6, 14);
      ctx.fillRect(2, -12, 6, 12); // Chân phải ngắn hơn 2cm

      // Thân áo sát nách màu chàm quen thuộc của Thầy Huỳnh (rách bươm để lộ sẹo sọ)
      ctx.fillStyle = flash ? '#ffffff' : '#1e1b4b';
      ctx.fillRect(-10, -36 + bob, 20, 24);
      // Sẹo tia sét của Nữ Thánh Rắn thuở nhỏ trên bả vai trái
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(-8, -34 + bob, 3, 8);
      ctx.fillRect(-6, -30 + bob, 3, 5);

      // TAY PHẢI: CÁNH TAY THÉP CỦA THẢO (GÕ 108 NHỊP VÀO HƯ KHÔNG HÚT VÍA)
      ctx.fillStyle = '#64748b';
      ctx.fillRect(9, -34 + bob, 6, 18);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(11, -32 + bob, 4, 14);
      // Khớp cơ khí & dây truyền dẫn sóng não lam ngọc
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(10, -26 + bob, 5, 2);
      ctx.fillRect(10, -20 + bob, 5, 2);
      // Ngón tay thép gõ 108 nhịp vào không khí tạo sóng chấn động
      const tapWave = Math.sin(animTimer * 18) * 3;
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(13, -16 + tapWave + bob, 3, 7);
      ctx.fillRect(16, -15 + tapWave + bob, 3, 6);
      // Vòng sóng âm 108 nhịp lan tỏa từ tay thép
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(15, -13 + tapWave + bob, 8 + Math.abs(tapWave) * 3, 0, Math.PI * 2);
      ctx.stroke();

      // TAY TRÁI: Thi triển Lôi Ảnh Thủ
      ctx.fillStyle = flash ? '#ffffff' : '#fcd34d';
      ctx.fillRect(-14, -32 + bob, 5, 16);
      ctx.fillStyle = '#eab308';
      ctx.fillRect(-15, -18 + bob, 6, 6);

      // ĐẦU & VẾT SẸO MỔ SỌ HOÁN NÃO CHẠY QUANH TRÁN
      ctx.fillStyle = flash ? '#ffffff' : '#fde68a';
      ctx.fillRect(-8, -48 + bob, 16, 14);
      // Đường chỉ khâu mổ sọ ngang trán rỉ máu đỏ
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(-8, -44 + bob, 16, 2);
      // Mũi chỉ khâu chữ thập (x x x)
      ctx.fillStyle = '#18181b';
      for (let i = 0; i < 4; i++) {
        ctx.fillRect(-6 + i * 4, -45 + bob, 1.5, 4);
      }

      // ĐÔI MẮT CHẢY HUYẾT LỆ (DO NÃO TÀI PHẢN PHỆ KHÓC NẤC)
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(-5, -42 + bob, 3, 2);
      ctx.fillRect(2, -42 + bob, 3, 2);
      // Dòng huyết lệ đỏ thẫm tuôn dài xuống cằm
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(-4, -40 + bob, 1.5, 6);
      ctx.fillRect(3, -40 + bob, 1.5, 6);

      // Ảo ảnh linh hồn Tài Dog nức nở mờ ảo phía trên đỉnh đầu
      ctx.fillStyle = 'rgba(56, 189, 248, 0.45)';
      const ghostBob = Math.sin(animTimer * 4) * 3;
      ctx.beginPath();
      ctx.arc(0, -60 + bob + ghostBob, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-3, -61 + bob + ghostBob, 1.5, 1.5);
      ctx.fillRect(2, -61 + bob + ghostBob, 1.5, 1.5);
    } else if (enemy.type === 'hac_dao_phong_toa') {
      // =========================================================================
      // --- ĐAO THỦ HẮC ĐẠO PHONG TỎA MỐC 1088 (ARC 10 - A10-E001) ---
      // =========================================================================
      // Chân ủng tác chiến tuyết
      ctx.fillStyle = flash ? '#ffffff' : '#0f172a';
      ctx.fillRect(-6, -14, 5, 14);
      ctx.fillRect(2, -14, 5, 14);
      // Áo choàng đen viền lông sói xám chống bão tuyết
      ctx.fillStyle = flash ? '#ffffff' : '#18181b';
      ctx.fillRect(-8, -32 + bob, 16, 20);
      ctx.fillStyle = '#52525b';
      ctx.fillRect(-7, -34 + bob, 14, 4);
      // Khăn trùm đầu & kính chống bão tuyết màu đỏ
      ctx.fillStyle = '#27272a';
      ctx.fillRect(-6, -42 + bob, 12, 10);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-4, -38 + bob, 8, 3);
      // Cầm đại đao răng cưa bén nhọn
      ctx.fillStyle = '#64748b';
      ctx.fillRect(6, -28 + bob, 4, 18);
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(9, -32 + bob, 5, 20);
      // Răng cưa trên sống đao
      for (let i = 0; i < 3; i++) {
        ctx.fillRect(14, -28 + i * 5 + bob, 2, 3);
      }
    } else if (enemy.type === 'boss_trum_dao_thu_hac_dao') {
      // =========================================================================
      // --- BOSS TRÙM ĐAO THỦ HẮC ĐẠO CANH NGỤC RUBIK (ARC 10 - A10-E002) ---
      // =========================================================================
      // Hào quang huyết chiến cuồng nộ
      const bossAura = Math.sin(animTimer * 8) * 4;
      ctx.fillStyle = 'rgba(239, 68, 68, 0.25)';
      ctx.beginPath();
      ctx.arc(0, -30 + bob, 32 + bossAura, 0, Math.PI * 2);
      ctx.fill();
      // Thân hình vạm vỡ hộ pháp
      ctx.fillStyle = flash ? '#ffffff' : '#09090b';
      ctx.fillRect(-12, -40 + bob, 24, 28);
      // Giáp vai da gấu xám nạm đinh
      ctx.fillStyle = '#3f3f46';
      ctx.fillRect(-15, -42 + bob, 7, 10);
      ctx.fillRect(8, -42 + bob, 7, 10);
      // Quần giáp da thép & ủng sắt
      ctx.fillStyle = flash ? '#ffffff' : '#18181b';
      ctx.fillRect(-9, -14, 7, 14);
      ctx.fillRect(2, -14, 7, 14);
      // Vết sẹo chém chéo mặt dữ dằn
      ctx.fillStyle = '#fca5a5';
      ctx.fillRect(-7, -54 + bob, 14, 14);
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(-4, -50 + bob, 8, 2);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-5, -49 + bob, 3, 3);
      ctx.fillRect(2, -49 + bob, 3, 3);
      // Đại đao răng cưa khổng lồ tỏa huyết quang
      ctx.fillStyle = '#475569';
      ctx.fillRect(10, -36 + bob, 6, 26);
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(15, -48 + bob, 8, 36);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(16, -46 + bob, 3, 32);
      // Chùm răng cưa sắc lẹm
      for (let i = 0; i < 5; i++) {
        ctx.fillRect(23, -42 + i * 6 + bob, 3, 4);
      }
    } else if (enemy.type === 'do_tham_ta_mon') {
      // =========================================================================
      // --- TRINH SÁT TÀ MÔN TRƯỜNG MẦM NON (ARC 10 - A10-E005) ---
      // =========================================================================
      // Thân hình lắt léo mặc áo tàng hình chàm tím
      ctx.fillStyle = flash ? '#ffffff' : '#2e1065';
      ctx.fillRect(-6, -28 + bob, 12, 18);
      // Ủng da nhanh nhẹn
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-5, -12, 4, 12);
      ctx.fillRect(1, -12, 4, 12);
      // Khăn bịt mặt màu xám đen
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(-5, -38 + bob, 10, 10);
      // Mắt đỏ rình mò cổng làng
      ctx.fillStyle = '#f87171';
      ctx.fillRect(-3, -35 + bob, 2, 2);
      ctx.fillRect(2, -35 + bob, 2, 2);
      // Dao găm đôi tẩm độc tím
      ctx.fillStyle = '#c084fc';
      ctx.fillRect(-9, -20 + bob, 3, 10);
      ctx.fillRect(7, -20 + bob, 3, 10);
    }

    // Unflip context before rendering UI/text so text is NEVER reversed or mirrored
    if (enemy.direction === -1) {
      ctx.scale(-1, 1);
    }

    // Health bar & Armor bar above enemy
    const hpRatio = Math.max(0, enemy.hp / enemy.maxHp);
    const barWidth = enemy.isBoss ? 84 : 28;

    // Nếu có Giáp (như Boss 300,000 Giáp)
    if (enemy.armor !== undefined && enemy.maxArmor !== undefined && enemy.maxArmor > 0) {
      const armorRatio = Math.max(0, enemy.armor / enemy.maxArmor);
      // Background bar
      ctx.fillStyle = 'rgba(0,0,0,0.85)';
      ctx.fillRect(-barWidth / 2, -enemy.h - 22, barWidth, 5);
      // Cyan glowing armor bar
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(-barWidth / 2, -enemy.h - 22, barWidth * armorRatio, 5);
      // Armor label
      if (enemy.isBoss && enemy.armor > 0) {
        ctx.font = 'bold 8px "Be Vietnam Pro", sans-serif';
        ctx.fillStyle = '#bae6fd';
        ctx.textAlign = 'center';
        ctx.fillText(`🛡 GIÁP: ${Math.round(enemy.armor / 1000)}k / ${Math.round(enemy.maxArmor / 1000)}k`, 0, -enemy.h - 24);
      }
    }

    // Health bar
    ctx.fillStyle = 'rgba(0,0,0,0.85)';
    ctx.fillRect(-barWidth / 2, -enemy.h - 14, barWidth, 6);
    ctx.fillStyle = enemy.isBoss ? '#ef4444' : '#22c55e';
    ctx.fillRect(-barWidth / 2, -enemy.h - 14, barWidth * hpRatio, 6);

    // Boss Name (Rendered upright with high legibility drop shadow)
    if (enemy.isBoss) {
      ctx.font = 'bold 11px "Be Vietnam Pro", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#fee2e2';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.95)';
      ctx.shadowBlur = 4;
      ctx.fillText(enemy.name, 0, -enemy.h - 34);
      ctx.shadowBlur = 0;
    }

    // Speech bubble for Enemy / Boss / 3 Chú Linh chants
    if (enemy.speechBubble && enemy.speechTimer && enemy.speechTimer > 0) {
      ctx.font = 'bold 10px "Be Vietnam Pro", sans-serif';
      const bubbleW = ctx.measureText(enemy.speechBubble).width + 16;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
      ctx.strokeStyle = enemy.isBoss ? '#ef4444' : '#a855f7';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(-bubbleW / 2, -enemy.h - 48, bubbleW, 22, 4);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = enemy.isBoss ? '#fecaca' : '#f3e8ff';
      ctx.textAlign = 'center';
      ctx.fillText(enemy.speechBubble, 0, -enemy.h - 33);
    }

    ctx.restore();
  }

  /**
   * Render Interactive Object (Shining Rubik gate, incense burner, tea table)
   */
  public static renderInteractive(ctx: CanvasRenderingContext2D, obj: { x: number; y: number; w: number; h: number; type: string; prompt: string; activated?: boolean }, animTimer: number) {
    ctx.save();
    ctx.translate(Math.floor(obj.x), Math.floor(obj.y));

    if (obj.type === 'rubik_gate') {
      // Rubik Ngục Môn Cương (1m x 1m cube with 6 facets and Tày / Hán runes)
      const glow = Math.sin(animTimer * 4) * 0.2 + 0.8;
      ctx.fillStyle = `rgba(185, 28, 28, ${glow * 0.4})`;
      ctx.fillRect(-2, -obj.h - 2, obj.w + 4, obj.h + 4);

      // Stone Cube
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(0, -obj.h, obj.w, obj.h);

      // 6 Facets grid
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 1;
      ctx.strokeRect(2, -obj.h + 2, obj.w - 4, obj.h - 4);

      // Carved rune "Tù"
      ctx.fillStyle = '#fde047';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('囚', obj.w / 2, -obj.h / 2 + 3);
    } else if (obj.type === 'shrine' || obj.type === 'story_altar') {
      // Cột mốc ký ức lịch sử / Đền thờ linh thiêng
      const glow = Math.sin(animTimer * 4) * 0.3 + 0.7;
      ctx.fillStyle = `rgba(245, 158, 11, ${glow * 0.35})`;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2, obj.w * 0.8, 0, Math.PI * 2);
      ctx.fill();

      // Stone Pillar / Altar
      ctx.fillStyle = '#3f3f46';
      ctx.fillRect(0, -obj.h, obj.w, obj.h);
      ctx.fillStyle = '#d97706';
      ctx.fillRect(2, -obj.h + 2, obj.w - 4, 3);

      // Golden Rune / Sacred Light
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('✦', obj.w / 2, -obj.h / 2 + 3);

      // Incense / Memory smoke
      ctx.fillStyle = 'rgba(254, 240, 138, 0.5)';
      const smokeOffset = Math.sin(animTimer * 3) * 3;
      ctx.fillRect(obj.w / 2 + smokeOffset, -obj.h - 8, 2, 8);
    } else if (obj.type === 'herb_node') {
      // Khóm Dược Thảo Rừng (Ngải Cứu / Tía Tô)
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#4ade80';
      ctx.fillRect(obj.w / 2 - 3, -obj.h + 2, 6, 8);
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(obj.w / 2 - 6, -obj.h / 2, 12, 4);
    } else if (obj.type === 'mine') {
      // Quả mìn râu tôm dã chiến Mốc 1305
      ctx.fillStyle = '#334155';
      ctx.fillRect(0, -obj.h, obj.w, obj.h);
      // Râu tôm kíp nổ nhấp nháy đỏ
      const blink = Math.sin(animTimer * 8) > 0;
      ctx.fillStyle = blink ? '#ef4444' : '#7f1d1d';
      ctx.fillRect(obj.w / 2 - 1, -obj.h - 4, 2, 4);
      ctx.fillRect(obj.w / 2 - 3, -obj.h - 4, 6, 1);
    } else if (obj.type === 'wounded_soldier') {
      // Chiến sĩ biên phòng bị thương tại Mốc 1305
      ctx.fillStyle = '#166534'; // Áo lính biên phòng
      ctx.fillRect(0, -18, 20, 16);
      ctx.fillStyle = '#fbcfe8'; // Khuôn mặt
      ctx.fillRect(4, -26, 10, 9);
      ctx.fillStyle = '#e2e8f0'; // Băng cứu thương quấn đầu
      ctx.fillRect(4, -28, 10, 3);
      ctx.fillStyle = '#ef4444'; // Vết máu
      ctx.fillRect(7, -27, 3, 2);
    } else if (obj.type === 'chest') {
      // Wooden medicine chest
      ctx.fillStyle = '#78350f';
      ctx.fillRect(0, -obj.h, obj.w, obj.h);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(obj.w / 2 - 2, -obj.h + 4, 4, 4);
    } else if (obj.type === 'hearth_fire') {
      // Bếp Than / Bếp Lửa Chòi Lá Mồ Côi 1977
      // Stone hearth circle
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.ellipse(obj.w / 2, -2, obj.w * 0.45, 6, 0, 0, Math.PI * 2);
      ctx.fill();
      // Glowing Embers
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(obj.w / 2 - 8, -6, 16, 5);
      // If fire is lit (has prompt showing lit or activated)
      const flameHeight = Math.sin(animTimer * 12) * 5 + 14;
      const flameWiggle = Math.cos(animTimer * 10) * 3;
      // Warm yellow/orange/red flame
      ctx.fillStyle = 'rgba(249, 115, 22, 0.4)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -12, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#f97316';
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 8, -4);
      ctx.lineTo(obj.w / 2 + flameWiggle, -flameHeight - 4);
      ctx.lineTo(obj.w / 2 + 8, -4);
      ctx.fill();
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 4, -4);
      ctx.lineTo(obj.w / 2 + flameWiggle * 0.5, -flameHeight * 0.65 - 4);
      ctx.lineTo(obj.w / 2 + 4, -4);
      ctx.fill();
    } else if (obj.type === 'dry_wood') {
      // Bó Củi Rừng Lục Nà (Vật phẩm nhặt trên bản đồ)
      const woodBob = Math.sin(animTimer * 4) * 2;
      // Golden pickup glow
      ctx.fillStyle = 'rgba(250, 204, 21, 0.25)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2 + woodBob, 12, 0, Math.PI * 2);
      ctx.fill();
      // Wooden bundle sticks
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 7, -obj.h + 4 + woodBob, 14, 4);
      ctx.fillRect(obj.w / 2 - 8, -obj.h + 8 + woodBob, 16, 4);
      ctx.fillRect(obj.w / 2 - 6, -obj.h + 12 + woodBob, 12, 4);
      // Twine binding rope
      ctx.fillStyle = '#d97706';
      ctx.fillRect(obj.w / 2 - 1, -obj.h + 3 + woodBob, 2, 14);
      // Snow frosting on wood
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(obj.w / 2 - 6, -obj.h + 3 + woodBob, 5, 2);
    } else if (obj.type === 'bamboo_dummy') {
      // Mộc Nhân Tre (Luyện 500 nhát liềm - A02-E002)
      // Thân cọc tre chính
      ctx.fillStyle = '#15803d';
      ctx.fillRect(obj.w / 2 - 4, -obj.h, 8, obj.h);
      // Mắt tre đốt xanh non
      ctx.fillStyle = '#86efac';
      ctx.fillRect(obj.w / 2 - 4, -obj.h + 8, 8, 2);
      ctx.fillRect(obj.w / 2 - 4, -obj.h + 20, 8, 2);
      ctx.fillRect(obj.w / 2 - 4, -obj.h + 32, 8, 2);
      // Rơm rạ và bao bố quấn thân mộc nhân
      ctx.fillStyle = '#d97706';
      ctx.fillRect(obj.w / 2 - 7, -obj.h + 12, 14, 18);
      // Tay gỗ chĩa ngang hai bên
      ctx.fillStyle = '#a16207';
      ctx.fillRect(obj.w / 2 - 14, -obj.h + 16, 28, 4);
      // Vết chém liềm chằng chịt rớm rỉ nhựa
      ctx.fillStyle = '#451a03';
      ctx.fillRect(obj.w / 2 - 3, -obj.h + 18, 6, 2);
      ctx.fillRect(obj.w / 2 - 4, -obj.h + 24, 7, 2);
    } else if (obj.type === 'lunch_basket') {
      // Gói Cơm Nguội & Trứng Luộc bọc lá chuối (A02-E003)
      const bob = Math.sin(animTimer * 4) * 2;
      ctx.fillStyle = 'rgba(74, 222, 128, 0.3)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2 + bob, 12, 0, Math.PI * 2);
      ctx.fill();
      // Lá chuối xanh gói cơm
      ctx.fillStyle = '#16a34a';
      ctx.beginPath();
      ctx.roundRect(obj.w / 2 - 8, -obj.h + bob, 16, 12, 3);
      ctx.fill();
      // Lạt tre vàng buộc chữ thập
      ctx.fillStyle = '#fde047';
      ctx.fillRect(obj.w / 2 - 1, -obj.h + bob, 2, 12);
      // Hai quả trứng gà luộc
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(obj.w / 2 - 3, -obj.h + bob + 3, 3, 0, Math.PI * 2);
      ctx.arc(obj.w / 2 + 3, -obj.h + bob + 3, 3, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'medicine_pot') {
      // Nồi Nước Lá Tía Tô Ngải Cứu hạ sốt 40 độ (A02-E003)
      // Nồi đất nung
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -8, 9, 0, Math.PI);
      ctx.fill();
      ctx.fillRect(obj.w / 2 - 9, -12, 18, 5);
      // Nước thuốc màu tía thơm ngào ngạt
      ctx.fillStyle = '#7e22ce';
      ctx.fillRect(obj.w / 2 - 7, -11, 14, 2);
      // Làn khói thuốc tím nhạt bốc lên
      ctx.fillStyle = 'rgba(216, 180, 254, 0.6)';
      const steamY = Math.sin(animTimer * 5) * 4;
      ctx.fillRect(obj.w / 2 - 3 + steamY * 0.5, -20 - steamY, 2, 6);
      ctx.fillRect(obj.w / 2 + 2 - steamY * 0.5, -24 - steamY, 2, 8);
    } else if (obj.type === 'sparing_choice') {
      // Bia Đá: Quyết Định Dừng Lại (A02-E004)
      const glow = Math.sin(animTimer * 5) * 0.3 + 0.7;
      ctx.fillStyle = `rgba(56, 189, 248, ${glow * 0.4})`;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2, 18, 0, Math.PI * 2);
      ctx.fill();
      // Phiến đá xanh đen
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, -obj.h, obj.w, obj.h);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(0, -obj.h, obj.w, obj.h);
      // Chữ khắc “DỪNG”
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('DỪNG', obj.w / 2, -obj.h / 2 + 4);
    } else if (obj.type === 'noc_cho_shrine') {
      // Điểm Hẹn Ước Nóc Chợ Đêm Giông Bão (A03-E001)
      const flash = Math.sin(animTimer * 8) > 0.6;
      ctx.fillStyle = flash ? 'rgba(254, 240, 138, 0.5)' : 'rgba(56, 189, 248, 0.3)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2, 20, 0, Math.PI * 2);
      ctx.fill();
      // Ngói chợ rêu phong
      ctx.fillStyle = '#334155';
      ctx.fillRect(0, -obj.h, obj.w, obj.h);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(2, -obj.h + 2, obj.w - 4, obj.h - 4);
      // Biểu tượng tia sấm chớp vàng
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 + 2, -obj.h + 4);
      ctx.lineTo(obj.w / 2 - 4, -obj.h / 2);
      ctx.lineTo(obj.w / 2 + 1, -obj.h / 2);
      ctx.lineTo(obj.w / 2 - 3, -4);
      ctx.lineTo(obj.w / 2 + 5, -obj.h / 2 - 2);
      ctx.lineTo(obj.w / 2, -obj.h / 2 - 2);
      ctx.fill();
    } else if (obj.type === 'broken_bamboo_staff') {
      // Nửa Gậy Trúc Hoàng Long Bị Chém Gãy (A03-E003)
      const bob = Math.sin(animTimer * 4) * 2;
      ctx.fillStyle = 'rgba(250, 204, 21, 0.4)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2 + bob, 16, 0, Math.PI * 2);
      ctx.fill();
      // Hai đoạn gậy tre gãy đôi
      ctx.fillStyle = '#16a34a'; // Bamboo green
      ctx.fillRect(obj.w / 2 - 12, -obj.h + 6 + bob, 10, 4);
      ctx.fillRect(obj.w / 2 + 2, -obj.h + 8 + bob, 11, 4);
      // Vết gãy xước tre vàng tưa ra
      ctx.fillStyle = '#fde047';
      ctx.fillRect(obj.w / 2 - 2, -obj.h + 6 + bob, 3, 4);
      // Dải lụa vải đỏ bọc quanh nửa gậy (lore: "nửa gậy trúc bọc vải đỏ")
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(obj.w / 2 + 4, -obj.h + 5 + bob, 4, 6);
      ctx.fillRect(obj.w / 2 + 8, -obj.h + 4 + bob, 3, 2);
    } else if (obj.type === 'mo_truc_7_cay') {
      // Mộ Trúc 7 Cây & Tảng Đá Người Giữ Đường (A03-E004)
      // Tảng đá rêu phong
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.roundRect(obj.w / 2 - 16, -22, 32, 22, 4);
      ctx.fill();
      // Khắc chữ "Người giữ đường"
      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 8px "Cinzel", serif';
      ctx.textAlign = 'center';
      ctx.fillText('GIỮ ĐƯỜNG', obj.w / 2, -10);
      // Khóm trúc 7 cây xanh ngắt phía sau
      ctx.fillStyle = '#16a34a';
      for (let i = 0; i < 7; i++) {
        const h = 24 + (i % 3) * 6;
        const xOffset = -18 + i * 6;
        ctx.fillRect(obj.w / 2 + xOffset, -22 - h, 2.5, h);
        // Lá trúc
        ctx.fillStyle = '#4ade80';
        ctx.fillRect(obj.w / 2 + xOffset - 2, -22 - h, 4, 3);
        ctx.fillStyle = '#16a34a';
      }
      // Chậu đồng nước lá tía tô bốc khói ngát
      ctx.fillStyle = '#b45309';
      ctx.fillRect(obj.w / 2 - 24, -8, 8, 8);
      ctx.fillStyle = '#7e22ce'; // Nước lá tía tô
      ctx.fillRect(obj.w / 2 - 23, -7, 6, 2);
      ctx.fillStyle = 'rgba(216, 180, 254, 0.6)';
      ctx.fillRect(obj.w / 2 - 22, -14, 2, 5);
    } else if (obj.type === 'math_desk_12a2') {
      // Bàn Học Cuối Lớp 12A2 Của Khôi (A03-E005)
      // Bàn gỗ học sinh
      ctx.fillStyle = '#92400e';
      ctx.fillRect(obj.w / 2 - 14, -18, 28, 4);
      ctx.fillStyle = '#78350f'; // Chân bàn sắt
      ctx.fillRect(obj.w / 2 - 12, -14, 3, 14);
      ctx.fillRect(obj.w / 2 + 9, -14, 3, 14);
      // Ba lô học sinh màu đen bạc vai
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(obj.w / 2 - 10, -25, 8, 7);
      // Quyển vở Toán hình học & bút viết
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(obj.w / 2 + 1, -21, 8, 3);
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(obj.w / 2 + 9, -20, 3, 1);
      // Dây chuyền bạc treo nửa gậy trúc lấp lánh dưới nắng sớm
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(obj.w / 2 - 3, -17, 3, 2);
      ctx.fillStyle = '#dc2626'; // Vải đỏ
      ctx.fillRect(obj.w / 2 - 3, -15, 3, 3);
    } else if (obj.type === 'moc_da_1088') {
      // =========================================================================
      // --- CỘT MỐC BIÊN CƯƠNG 1088 (A04-E001) ---
      // =========================================================================
      // Bệ đá granite hoa cương xám vững chắc
      ctx.fillStyle = '#334155';
      ctx.fillRect(obj.w / 2 - 16, -10, 32, 10);
      // Thân cột mốc đá hình lăng trụ
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(obj.w / 2 - 12, -38, 24, 28);
      // Đỉnh chóp cột mốc tam giác
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 12, -38);
      ctx.lineTo(obj.w / 2, -48);
      ctx.lineTo(obj.w / 2 + 12, -38);
      ctx.fill();
      // Khung viền đỏ son thiêng liêng
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(obj.w / 2 - 10, -36, 20, 24);
      // Quốc huy & Số hiệu "1088"
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(obj.w / 2 - 4, -32, 8, 8);
      ctx.fillStyle = '#facc15'; // Ngôi sao vàng
      ctx.fillRect(obj.w / 2 - 2, -30, 4, 4);
      ctx.fillStyle = '#1e293b';
      ctx.font = 'bold 7px "Cinzel", serif';
      ctx.textAlign = 'center';
      ctx.fillText('1088', obj.w / 2, -16);
    } else if (obj.type === 'san_dau_7_dem') {
      // =========================================================================
      // --- SÀN ĐẤU 7 ĐÊM ĐÌNH LỤC NÀ (A04-E003) ---
      // =========================================================================
      // Vòng tròn đấu võ gạch nung cổ
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.ellipse(obj.w / 2, -6, 28, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      // Bó đuốc dầu bốc lửa bập bùng
      ctx.fillStyle = '#451a03';
      ctx.fillRect(obj.w / 2 - 24, -26, 4, 22);
      ctx.fillRect(obj.w / 2 + 20, -26, 4, 22);
      // Ngọn lửa đuốc
      ctx.fillStyle = '#ea580c';
      ctx.beginPath();
      ctx.arc(obj.w / 2 - 22, -28 + Math.sin(animTimer * 12) * 2, 4, 0, Math.PI * 2);
      ctx.arc(obj.w / 2 + 22, -28 + Math.cos(animTimer * 12) * 2, 4, 0, Math.PI * 2);
      ctx.fill();
      // Bát cơm nguội và 2 quả trứng luộc đặt trên lá chuối xanh
      ctx.fillStyle = '#15803d'; // Lá chuối
      ctx.fillRect(obj.w / 2 - 8, -8, 16, 6);
      ctx.fillStyle = '#f8fafc'; // Cơm nguội
      ctx.fillRect(obj.w / 2 - 5, -11, 10, 4);
      ctx.fillStyle = '#fef08a'; // Trứng luộc
      ctx.beginPath();
      ctx.arc(obj.w / 2 - 2, -10, 2.5, 0, Math.PI * 2);
      ctx.arc(obj.w / 2 + 2, -10, 2.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'day_cap_khe_van') {
      // =========================================================================
      // --- DÂY CÁP THÉP TREO VÁCH ĐÁ LỤC TRIỀU DƯ (A04-E004) ---
      // =========================================================================
      // Móc neo thép gắn vào vách đá
      ctx.fillStyle = '#475569';
      ctx.fillRect(obj.w / 2 - 6, -28, 12, 12);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(obj.w / 2 - 3, -25, 6, 6);
      // Dây cáp thép chịu lực dày 2cm buông xuống vực thác
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2, -22);
      ctx.lineTo(obj.w / 2, 18);
      ctx.stroke();
      // Móc khóa carabiner leo núi màu cam
      ctx.strokeStyle = '#ea580c';
      ctx.lineWidth = 2;
      ctx.strokeRect(obj.w / 2 - 3, -4, 6, 10);
      // Bọt nước thác Khe Vằn bay mù mịt quanh móc cáp
      ctx.fillStyle = 'rgba(224, 242, 254, 0.7)';
      for (let i = 0; i < 4; i++) {
        const pX = obj.w / 2 + (Math.sin(animTimer * 10 + i) * 12);
        const pY = -12 + (Math.cos(animTimer * 8 + i) * 10);
        ctx.fillRect(pX, pY, 2.5, 2.5);
      }
    } else if (obj.type === 'cuon_tranh_altar') {
      // =========================================================================
      // --- BÀN NHẬN CUỘN TRANH CHƯA GIAO (A04-E005) ---
      // =========================================================================
      // Bàn gỗ lim cổ đình Lục Nà
      ctx.fillStyle = '#451a03';
      ctx.fillRect(obj.w / 2 - 18, -14, 36, 14);
      // Khăn trải bàn vải đỏ thêu chỉ vàng
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(obj.w / 2 - 16, -15, 32, 4);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(obj.w / 2 - 16, -12, 32, 1.5);
      // CUỘN TRANH CHƯA GIAO (Ống gấm ngọc bích buộc dây tơ đỏ)
      const scrollBob = Math.sin(animTimer * 4) * 2;
      ctx.fillStyle = '#065f46'; // Gấm xanh ngọc
      ctx.fillRect(obj.w / 2 - 12, -22 + scrollBob, 24, 6);
      // Trục lăn bằng gỗ mun hai đầu
      ctx.fillStyle = '#1e1b18';
      ctx.fillRect(obj.w / 2 - 14, -23 + scrollBob, 3, 8);
      ctx.fillRect(obj.w / 2 + 11, -23 + scrollBob, 3, 8);
      // Dây tơ đỏ niêm phong phong ấn
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(obj.w / 2 - 1, -23 + scrollBob, 2, 8);
      // Hào quang phong ấn băng tuyết Tokyo tỏa ra nhẹ nhàng
      ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -19 + scrollBob, 16, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'xe_cuu_thuong_317') {
      // =========================================================================
      // --- XE CỨU THƯƠNG 3:17AM & VỆT BĂNG NỨT SHIBUYA (A05-E001) ---
      // =========================================================================
      // Thân xe cấp cứu trắng
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(obj.w / 2 - 22, -26, 44, 22);
      // Cửa kính xe xanh sẫm
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(obj.w / 2 + 6, -24, 12, 10);
      ctx.fillRect(obj.w / 2 - 16, -24, 18, 8);
      // Dải decal đỏ phản quang cấp cứu
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(obj.w / 2 - 22, -14, 44, 4);
      // Chữ thập đỏ cấp cứu
      ctx.fillRect(obj.w / 2 - 10, -18, 3, 10);
      ctx.fillRect(obj.w / 2 - 14, -14, 11, 3);
      // Bánh xe cao su đen
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(obj.w / 2 - 16, -4, 8, 5);
      ctx.fillRect(obj.w / 2 + 10, -4, 8, 5);
      // Đèn còi ưu tiên chớp nhấp nháy đỏ xanh (3:17AM)
      const strobe = Math.sin(animTimer * 16) > 0;
      ctx.fillStyle = strobe ? '#ef4444' : '#3b82f6';
      ctx.fillRect(obj.w / 2 - 6, -30, 12, 4);
      // Vệt băng nứt dưới bánh xe
      ctx.strokeStyle = '#bae6fd';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 26, -1);
      ctx.lineTo(obj.w / 2 + 28, -1);
      ctx.stroke();
    } else if (obj.type === 'xe_banh_mi_ong_tay') {
      // =========================================================================
      // --- XE BÁNH MÌ LÒ THAN NÓNG 24/7 CỦA ÔNG TÁY (A05-E002) ---
      // =========================================================================
      // Khung xe đẩy tôn màu bạc
      ctx.fillStyle = '#64748b';
      ctx.fillRect(obj.w / 2 - 16, -24, 32, 20);
      // Tủ kính bánh mì bên trên
      ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.fillRect(obj.w / 2 - 14, -34, 28, 10);
      // Những ổ bánh mì vàng ươm xếp hàng
      ctx.fillStyle = '#d97706';
      ctx.fillRect(obj.w / 2 - 12, -30, 7, 4);
      ctx.fillRect(obj.w / 2 - 3, -30, 7, 4);
      ctx.fillRect(obj.w / 2 + 6, -30, 7, 4);
      // Lò than hồng bốc khói ấm áp
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(obj.w / 2 - 10, -12, 20, 6);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(obj.w / 2 - 6, -10, 12, 3);
      // Làn khói than ấm bốc lên
      ctx.fillStyle = 'rgba(254, 240, 138, 0.5)';
      const smokeWiggle = Math.sin(animTimer * 6) * 3;
      ctx.fillRect(obj.w / 2 - 2 + smokeWiggle, -42, 3, 8);
      // Bánh xe đẩy
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(obj.w / 2 - 12, -4, 6, 6);
      ctx.fillRect(obj.w / 2 + 6, -4, 6, 6);
    } else if (obj.type === 'dong_muoi_dinh_quoc_tuan') {
      // =========================================================================
      // --- ĐỐNG MUỐI TUYẾT & CÁN CHỔI ĐINH QUỐC TUẤN (A05-E002) ---
      // =========================================================================
      // Đống muối tuyết trắng hình chóp
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 14, -2);
      ctx.lineTo(obj.w / 2, -18);
      ctx.lineTo(obj.w / 2 + 14, -2);
      ctx.fill();
      // Tinh thể muối lấp lánh tan băng
      ctx.fillStyle = '#7dd3fc';
      ctx.fillRect(obj.w / 2 - 4, -12, 3, 3);
      ctx.fillRect(obj.w / 2 + 3, -8, 2.5, 2.5);
      // Cán chổi quét đường sinh tử dựng cạnh đống muối
      ctx.fillStyle = '#92400e';
      ctx.fillRect(obj.w / 2 + 8, -26, 3, 26);
      // Đầu chổi tre quét tuyết
      ctx.fillStyle = '#facc15';
      ctx.fillRect(obj.w / 2 + 5, -8, 8, 8);
    } else if (obj.type === 'bang_neon_gay_109') {
      // =========================================================================
      // --- BẢNG ĐÈN NEON GÃY 109 — BẺ BẢNG TĂNG 40% TỐC ĐÁNH (A05-E003) ---
      // =========================================================================
      const neonFlicker = Math.sin(animTimer * 20) > -0.2;
      // Khung sắt bảng hiệu bị gãy gập góc 30 độ
      ctx.fillStyle = '#334155';
      ctx.fillRect(obj.w / 2 - 16, -26, 32, 18);
      ctx.strokeStyle = neonFlicker ? '#ec4899' : '#06b6d4';
      ctx.lineWidth = 2;
      ctx.strokeRect(obj.w / 2 - 16, -26, 32, 18);
      // Dòng chữ NEON 109 phát sáng rực rỡ
      ctx.fillStyle = neonFlicker ? '#f472b6' : '#67e8f9';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('109 NEON', obj.w / 2, -14);
      // Tia chớp điện nổ le lói từ chỗ dây điện đứt
      if (Math.random() < 0.4) {
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(obj.w / 2 + 14, -24);
        ctx.lineTo(obj.w / 2 + 22, -28);
        ctx.stroke();
      }
    } else if (obj.type === 'tuyet_phu_109_anchor') {
      // =========================================================================
      // --- BÃO TUYẾT PHỦ 109 — KÍCH HOẠT BĂNG GIÁP (-25% SÁT THƯƠNG) (A05-E003) ---
      // =========================================================================
      const snowSpin = animTimer * 4;
      ctx.fillStyle = 'rgba(186, 230, 253, 0.35)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -16, 20, 0, Math.PI * 2);
      ctx.fill();
      // Tinh thể băng lục giác xoay tròn
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const rad = snowSpin + (i * Math.PI) / 3;
        const x = obj.w / 2 + Math.cos(rad) * 14;
        const y = -16 + Math.sin(rad) * 14;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.stroke();
      // Biểu tượng khiên băng bảo vệ
      ctx.fillStyle = '#bae6fd';
      ctx.fillRect(obj.w / 2 - 5, -20, 10, 8);
    } else if (obj.type === 'cuon_tranh_phong_an_altar') {
      // =========================================================================
      // --- BÀN PHONG ẤN CUỘN TRANH — TUYẾT TRẮNG CHÔN TÊN / HỒI QUANG (A05-E004) ---
      // =========================================================================
      // Bệ đá tuyết Shibuya
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(obj.w / 2 - 18, -12, 36, 12);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(obj.w / 2 - 18, -12, 36, 12);
      // Cuộn Tranh Chưa Giao cắm thẳng xuống mặt tuyết
      ctx.fillStyle = '#065f46';
      ctx.fillRect(obj.w / 2 - 3, -32, 6, 26);
      // Dây tơ đỏ niêm phong phát sáng
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(obj.w / 2 - 4, -24, 8, 3);
      // Hào quang Băng Phong Ấn bao trùm
      const aura = Math.sin(animTimer * 6) * 4;
      ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -20, 18 + aura, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 've_may_bay_ve_khe_van') {
      // =========================================================================
      // --- VÉ MÁY BAY HỒI HƯƠNG VỀ THÁC KHE VẰN (MỞ ĐẦU ARC 6) (A05-E005) ---
      // =========================================================================
      // Vali du lịch bọc vải dù đen
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(obj.w / 2 - 12, -20, 24, 18);
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1;
      ctx.strokeRect(obj.w / 2 - 12, -20, 24, 18);
      // Quai xách vali
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 4, -24, 8, 4);
      // Tấm vé máy bay màu vàng kim phát sáng
      const ticketBob = Math.sin(animTimer * 5) * 2;
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(obj.w / 2 - 8, -32 + ticketBob, 16, 9);
      ctx.fillStyle = '#b45309';
      ctx.fillRect(obj.w / 2 - 6, -29 + ticketBob, 12, 2);
      // Hào quang dẫn đường về Thác Khe Vằn
      ctx.fillStyle = 'rgba(250, 204, 21, 0.35)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -26 + ticketBob, 14, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'ho_nuoc_chan_thac') {
      // =========================================================================
      // --- HỒ NƯỚC CHÂN THÁC KHE VẰN — SOI BÓNG TIA MÁU (ARC 6 - A06-E001) ---
      // =========================================================================
      // Mặt hồ nước trong xanh biếc có sóng gợn
      const ripple = Math.sin(animTimer * 4) * 3;
      ctx.fillStyle = 'rgba(14, 116, 144, 0.6)';
      ctx.beginPath();
      ctx.ellipse(obj.w / 2, -6, 26 + ripple, 9, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Bọt nước trắng xóa từ thác đổ xuống
      ctx.fillStyle = '#f0f9ff';
      for (let i = 0; i < 4; i++) {
        const bubbleX = obj.w / 2 + Math.sin(animTimer * 6 + i) * 16;
        const bubbleY = -8 + Math.cos(animTimer * 5 + i) * 4;
        ctx.fillRect(bubbleX, bubbleY, 2.5, 2.5);
      }

      // Phản chiếu tia máu đỏ trong đáy mắt Khôi (lore A06-E001)
      ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -6, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#fca5a5';
      ctx.lineWidth = 1;
      ctx.stroke();
    } else if (obj.type === 'day_cap_thac_100_tang') {
      // =========================================================================
      // --- DÂY CÁP THÉP VÁCH ĐÁ 100 TẦNG LỤC TRIỀU DƯ (ARC 6 - A06-E002) ---
      // =========================================================================
      // Trụ sắt neo cáp ngập trong đá granit
      ctx.fillStyle = '#334155';
      ctx.fillRect(obj.w / 2 - 8, -28, 16, 16);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(obj.w / 2 - 5, -25, 10, 10);
      // Ròng rọc cáp thép sáng ánh kim
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -18, 6, 0, Math.PI * 2);
      ctx.fill();
      // Dây cáp chịu lực căng ngang vách đá 100 tầng
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2, -18);
      ctx.lineTo(obj.w / 2, 25);
      ctx.stroke();
      // Bọt nước cuộn quanh sợi cáp
      ctx.fillStyle = 'rgba(186, 230, 253, 0.6)';
      const spray = Math.sin(animTimer * 8) * 6;
      ctx.fillRect(obj.w / 2 - 4, -8 + spray, 8, 4);
    } else if (obj.type === 'diem_treo_minh_6_thang') {
      // =========================================================================
      // --- ĐIỂM TREO MÌNH 6 THÁNG DƯỚI NGHÌN ROI NƯỚC ĐỔ (ARC 6 - A06-E003) ---
      // =========================================================================
      // Mỏm đá nhô ra trực diện tâm thác nước
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 16, 0);
      ctx.lineTo(obj.w / 2 - 6, -22);
      ctx.lineTo(obj.w / 2 + 16, -22);
      ctx.lineTo(obj.w / 2 + 18, 0);
      ctx.closePath();
      ctx.fill();
      // Vòng xích / dây thừng bện treo mình
      ctx.strokeStyle = '#92400e';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 4, -22, 7, 0, Math.PI * 2);
      ctx.stroke();
      // Cột nước thác đổ ầm ầm từ trên xuống (nghìn roi sắt)
      const waterFlow = (animTimer * 30) % 20;
      ctx.fillStyle = 'rgba(224, 242, 254, 0.55)';
      ctx.fillRect(obj.w / 2 - 12, -45, 24, 30);
      ctx.fillStyle = 'rgba(56, 189, 248, 0.7)';
      ctx.fillRect(obj.w / 2 - 8, -45 + waterFlow, 16, 8);
      // Hào quang tâm ma thanh lọc
      ctx.fillStyle = 'rgba(244, 63, 94, 0.3)';
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 4, -20, 18, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'tang_da_khe_van_tram') {
      // =========================================================================
      // --- TẢNG ĐÁ THỬ KIẾM — NGỘ KHE VẰN TRẢM (ARC 6 - A06-E004) ---
      // =========================================================================
      // Phiến đá granit khổng lồ nhẵn bóng
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.roundRect(obj.w / 2 - 20, -28, 40, 28, 4);
      ctx.fill();
      // Vết chém nước phẳng lì cắt đôi phiến đá (Khe Vằn Trảm / Đường liềm vô ảnh)
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 22, -26);
      ctx.lineTo(obj.w / 2 + 22, -6);
      ctx.stroke();
      // Ánh sáng vô thanh phát ra từ vết chém
      const slashGlow = Math.sin(animTimer * 8) * 3;
      ctx.fillStyle = 'rgba(56, 189, 248, 0.5)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -16, 14 + slashGlow, 0, Math.PI * 2);
      ctx.fill();
      // Rêu phong và bọt nước suối bao quanh
      ctx.fillStyle = '#065f46';
      ctx.fillRect(obj.w / 2 - 18, -6, 8, 5);
      ctx.fillRect(obj.w / 2 + 10, -6, 9, 5);
    } else if (obj.type === 'cong_dinh_ban_cau_arc6') {
      // =========================================================================
      // --- CỔNG ĐÌNH LỤC NÀ — TÀI DOG & CHÚ CHÓ ĐỐM (ARC 6 - A06-E005) ---
      // =========================================================================
      // Cổng tam quan đình cổ lợp ngói âm dương
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 22, -34, 5, 34);
      ctx.fillRect(obj.w / 2 + 17, -34, 5, 34);
      // Mái ngói đỏ rêu
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(obj.w / 2 - 26, -38, 52, 6);
      ctx.fillStyle = '#166534'; // Rêu xanh trên mái
      ctx.fillRect(obj.w / 2 - 20, -39, 12, 2);
      // Biển gỗ khắc chữ "BÌNH" sơn son thiếp vàng
      ctx.fillStyle = '#451a03';
      ctx.fillRect(obj.w / 2 - 10, -32, 20, 10);
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 8px serif';
      ctx.textAlign = 'center';
      ctx.fillText('BÌNH', obj.w / 2, -24);
      // Chú chó Đốm què ngồi vẫy đuôi cạnh chân cột đình
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(obj.w / 2 - 15, -12, 10, 8);
      // Đốm đen trên lưng
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(obj.w / 2 - 13, -10, 3, 3);
      ctx.fillRect(obj.w / 2 - 9, -11, 2, 2);
      // Đầu chó
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(obj.w / 2 - 17, -16, 5, 5);
      // Đuôi vẫy mừng
      const tailWag = Math.sin(animTimer * 14) * 4;
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 6, -10);
      ctx.lineTo(obj.w / 2 - 3, -14 + tailWag);
      ctx.stroke();
    } else if (obj.type === 'thuoc_nam_duong_tim') {
      // =========================================================================
      // --- BÁT THUỐC NAM DƯỠNG TIM (ARC 7 - A07-E001) ---
      // =========================================================================
      // Bát sứ đất nung màu gạch
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -6, 10, 0, Math.PI);
      ctx.fill();
      ctx.fillRect(obj.w / 2 - 10, -10, 20, 5);
      // Nước thuốc nam dưỡng tim màu nâu đỏ hổ phách
      ctx.fillStyle = '#b45309';
      ctx.fillRect(obj.w / 2 - 8, -9, 16, 3);
      // Làn khói thuốc ấm nóng bốc lên
      const steamY = Math.sin(animTimer * 5) * 4;
      ctx.fillStyle = 'rgba(253, 230, 138, 0.65)';
      ctx.fillRect(obj.w / 2 - 3, -18 - steamY, 2, 6);
      ctx.fillRect(obj.w / 2 + 2, -21 - steamY, 2, 7);
      // Cành lá nam dược đặt cạnh bát thuốc
      ctx.fillStyle = '#16a34a';
      ctx.fillRect(obj.w / 2 - 14, -4, 4, 3);
      ctx.fillRect(obj.w / 2 + 10, -4, 4, 3);
    } else if (obj.type === 'cay_truc_non_tang_tai') {
      // =========================================================================
      // --- KHÓM TRÚC NON TẶNG TÀI (ARC 7 - A07-E002) ---
      // =========================================================================
      // 3 thân trúc non thẳng tắp, nhẵn mịn màu xanh nõn chuối
      ctx.fillStyle = '#4ade80';
      ctx.fillRect(obj.w / 2 - 8, -32, 4, 32);
      ctx.fillRect(obj.w / 2 - 1, -38, 4, 38);
      ctx.fillRect(obj.w / 2 + 6, -30, 3, 30);
      // Khớp lóng trúc màu xanh đậm
      ctx.fillStyle = '#15803d';
      ctx.fillRect(obj.w / 2 - 9, -22, 6, 2);
      ctx.fillRect(obj.w / 2 - 9, -12, 6, 2);
      ctx.fillRect(obj.w / 2 - 2, -26, 6, 2);
      ctx.fillRect(obj.w / 2 - 2, -14, 6, 2);
      ctx.fillRect(obj.w / 2 + 5, -20, 5, 2);
      ctx.fillRect(obj.w / 2 + 5, -10, 5, 2);
      // Lá trúc non rủ xuống mượt mà
      const leafSway = Math.sin(animTimer * 3) * 2;
      ctx.fillStyle = '#86efac';
      ctx.fillRect(obj.w / 2 - 14 + leafSway, -34, 7, 3);
      ctx.fillRect(obj.w / 2 + 4 + leafSway, -40, 8, 3);
      ctx.fillRect(obj.w / 2 + 10 + leafSway, -32, 6, 3);
      // Ánh sáng bình yên tỏa ra từ khóm trúc
      ctx.fillStyle = 'rgba(134, 239, 172, 0.25)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -20, 18, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'giuong_benh_tai_dog') {
      // =========================================================================
      // --- GIƯỜNG BỆNH CHÒI LÁ MÙA ĐÔNG 2065 (ARC 7 - A07-E003) ---
      // =========================================================================
      // Khung chõng tre
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 18, -12, 36, 12);
      // Chân giường tre
      ctx.fillStyle = '#451a03';
      ctx.fillRect(obj.w / 2 - 17, 0, 4, 8);
      ctx.fillRect(obj.w / 2 + 13, 0, 4, 8);
      // Chăn bông mùa đông màu chàm cổ
      ctx.fillStyle = '#1e3a8a';
      ctx.fillRect(obj.w / 2 - 14, -14, 28, 8);
      // Chiếc gối trắng nhạt
      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(obj.w / 2 - 16, -16, 8, 5);
      // Đèn dầu hạt đỗ le lói bên đầu giường
      ctx.fillStyle = '#b45309';
      ctx.fillRect(obj.w / 2 + 15, -16, 5, 6);
      const flame = Math.sin(animTimer * 10) * 1.5;
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 17.5, -19 + flame, 2.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'ket_sat_khoa_liem') {
      // =========================================================================
      // --- KÉT SẮT KHÓA LIỀM TỬ THẦN (ARC 7 - A07-E004) ---
      // =========================================================================
      // Thân két sắt thép đúc kiên cố
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(obj.w / 2 - 16, -30, 32, 30);
      // Viền kim loại gia cường chống cạy phá
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.strokeRect(obj.w / 2 - 15, -29, 30, 28);
      // Ổ khóa xoay kim loại sáng bóng
      ctx.fillStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 4, -15, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(obj.w / 2 + 3, -16, 2, 3);
      // Biểu tượng Liềm Tử Thần bị khóa niêm phong bằng sơn đỏ
      ctx.fillStyle = '#dc2626';
      ctx.font = 'bold 9px serif';
      ctx.textAlign = 'center';
      ctx.fillText('🔒', obj.w / 2 - 6, -12);
      // Dải niêm phong đỏ vắt chéo mặt két
      ctx.fillStyle = 'rgba(220, 38, 38, 0.8)';
      ctx.fillRect(obj.w / 2 - 14, -26, 28, 3);
    } else if (obj.type === 'bia_mo_tai_dog') {
      // =========================================================================
      // --- BIA MỘ ĐẤT TÀI DOG & BÁT CHÁO NÓNG (ARC 7 - A07-E004) ---
      // =========================================================================
      // Nấm mộ đất đắp tròn phủ cỏ xanh
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.ellipse(obj.w / 2, -4, 20, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      // Khóm cỏ xanh trên nấm mộ
      ctx.fillStyle = '#16a34a';
      ctx.fillRect(obj.w / 2 - 12, -10, 24, 6);
      // Bia đá giản dị khắc tên "LÀI PHÚC TÀI"
      ctx.fillStyle = '#64748b';
      ctx.fillRect(obj.w / 2 - 14, -30, 10, 22);
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 7px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('TÀI', obj.w / 2 - 9, -20);
      // Bát hương gốm tỏa khói trầm thanh thản
      ctx.fillStyle = '#d97706';
      ctx.fillRect(obj.w / 2 + 2, -12, 6, 6);
      const incSmoke = Math.sin(animTimer * 4) * 2;
      ctx.fillStyle = 'rgba(254, 243, 199, 0.7)';
      ctx.fillRect(obj.w / 2 + 4 + incSmoke, -22, 2, 9);
      // Bát cháo nóng Khôi mang lên dỗ chó Đốm
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 13, -7, 5, 0, Math.PI);
      ctx.fill();
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(obj.w / 2 + 10, -8, 6, 2);
    } else if (obj.type === 'cong_dinh_canh_mo_arc7') {
      // =========================================================================
      // --- CHIẾN TUYẾN BẢO VỆ ĐỒI MỘ (ARC 7 - A07-E005) ---
      // =========================================================================
      // Cột rào bảo vệ nấm mộ
      ctx.fillStyle = '#475569';
      ctx.fillRect(obj.w / 2 - 18, -34, 4, 34);
      ctx.fillRect(obj.w / 2 + 14, -34, 4, 34);
      // Dây thừng bện lá bùa bình an
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 18, -26);
      ctx.lineTo(obj.w / 2 + 18, -26);
      ctx.stroke();
      // Ngọn đuốc tuần tra bập bùng xua tan tà khí
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 2, -22, 4, 22);
      const torchGlow = Math.sin(animTimer * 9) * 2;
      ctx.fillStyle = '#f97316';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -24 + torchGlow, 5, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'rubik_cube_center') {
      // =========================================================================
      // --- KHỐI ĐÁ RUBIK NGỤC MÔN CƯƠNG 1m³ (ARC 8 - A08-E001 / A08-E006) ---
      // =========================================================================
      // Vòng tròn ma trận ma thuật 108 nhịp xoay tròn
      const rubikPulse = Math.sin(animTimer * 4) * 4;
      const rubikAura = ctx.createRadialGradient(obj.w / 2, -obj.h / 2, 8, obj.w / 2, -obj.h / 2, obj.w + rubikPulse);
      rubikAura.addColorStop(0, 'rgba(168, 85, 247, 0.45)');
      rubikAura.addColorStop(0.5, 'rgba(239, 68, 68, 0.25)');
      rubikAura.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = rubikAura;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2, obj.w + rubikPulse, 0, Math.PI * 2);
      ctx.fill();

      // Vòng tròn phù chú cổ ngữ xoay quanh khối đá
      ctx.strokeStyle = 'rgba(244, 63, 94, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -obj.h / 2, 28, 0, Math.PI * 2);
      ctx.stroke();

      // Khối lập phương đá đen cổ 1m³ (Vẽ theo phối cảnh isometric 3D sắc nét)
      const cx = obj.w / 2;
      const cy = -obj.h / 2;
      const s = 18; // Nửa cạnh khối Rubik

      // Mặt trước (Mặt Bùa Đỏ / Hùng Đỏ)
      ctx.fillStyle = '#991b1b';
      ctx.beginPath();
      ctx.moveTo(cx - s, cy);
      ctx.lineTo(cx, cy + s * 0.58);
      ctx.lineTo(cx, cy + s * 1.58);
      ctx.lineTo(cx - s, cy + s);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Mặt bên phải (Mặt Bùa Xanh / Ông Táy)
      ctx.fillStyle = '#064e3b';
      ctx.beginPath();
      ctx.moveTo(cx, cy + s * 0.58);
      ctx.lineTo(cx + s, cy);
      ctx.lineTo(cx + s, cy + s);
      ctx.lineTo(cx, cy + s * 1.58);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#10b981';
      ctx.stroke();

      // Mặt trên đỉnh (Mặt Bùa Tím / Tuấn & Bà Mận)
      ctx.fillStyle = '#581c87';
      ctx.beginPath();
      ctx.moveTo(cx, cy - s * 0.58);
      ctx.lineTo(cx + s, cy);
      ctx.lineTo(cx, cy + s * 0.58);
      ctx.lineTo(cx - s, cy);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#c084fc';
      ctx.stroke();

      // Lưới chia 9 ô con trên từng mặt (Rubik 3x3x3 1m³)
      ctx.strokeStyle = '#fde047';
      ctx.lineWidth = 0.8;
      // Đường phân chia mặt trên
      ctx.beginPath();
      ctx.moveTo(cx - s * 0.33, cy - s * 0.19);
      ctx.lineTo(cx + s * 0.67, cy + s * 0.39);
      ctx.moveTo(cx - s * 0.67, cy + s * 0.19);
      ctx.lineTo(cx + s * 0.33, cy + s * 0.77);
      ctx.stroke();

      // Ký tự cổ "囚" (Tù) phát sáng vàng kim tại tâm Rubik
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('囚', cx, cy + 5);

      // Hạt tinh hoa năng lượng 108 nhịp bay quanh
      for (let i = 0; i < 4; i++) {
        const particleAngle = animTimer * 3 + (i * Math.PI) / 2;
        const px = cx + Math.cos(particleAngle) * 32;
        const py = cy + Math.sin(particleAngle) * 20;
        ctx.fillStyle = i % 2 === 0 ? '#facc15' : '#c084fc';
        ctx.fillRect(px - 1.5, py - 1.5, 3, 3);
      }
    } else if (obj.type === 'altar_muoi_den') {
      // =========================================================================
      // --- BÀN THỜ BÙA MUỐI ĐEN ĐINH QUỐC TUẤN (ARC 8 - A08-E002) ---
      // =========================================================================
      // Đống muối đen tuyền phủ hàn khí tím
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.ellipse(obj.w / 2, -6, 18, 7, 0, 0, Math.PI * 2);
      ctx.fill();
      // Tinh thể muối đen phát quang
      ctx.fillStyle = '#a855f7';
      for (let i = 0; i < 6; i++) {
        ctx.fillRect(obj.w / 2 - 12 + i * 4, -9 + (i % 3) * 2, 2.5, 2.5);
      }
      // Cán quét của Đinh Quốc Tuấn cắm nghiêng trên đống muối
      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 8, -2);
      ctx.lineTo(obj.w / 2 + 10, -28);
      ctx.stroke();
      // Bó rơm quét rải muối
      ctx.fillStyle = '#92400e';
      ctx.fillRect(obj.w / 2 - 12, -8, 8, 6);
      // Cuốn sổ đỏ yểm bùa ghi tên Khôi
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(obj.w / 2 + 6, -14, 8, 10);
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(obj.w / 2 + 8, -12, 4, 6);
    } else if (obj.type === 'altar_lo_than') {
      // =========================================================================
      // --- VẠC THAN TÀ KHÍ ÔNG TÁY (ARC 8 - A08-E003) ---
      // =========================================================================
      // Vạc gang đen 3 chân
      ctx.fillStyle = '#18181b';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -14, 14, 0, Math.PI);
      ctx.fill();
      ctx.fillRect(obj.w / 2 - 14, -20, 28, 7);
      // Chân vạc
      ctx.fillRect(obj.w / 2 - 12, -7, 4, 7);
      ctx.fillRect(obj.w / 2 + 8, -7, 4, 7);
      // Than hồng hắc ám bập bùng
      const coalGlow = Math.sin(animTimer * 8) * 3;
      ctx.fillStyle = '#b91c1c';
      ctx.fillRect(obj.w / 2 - 10, -22, 20, 5);
      ctx.fillStyle = '#f97316';
      ctx.fillRect(obj.w / 2 - 6, -24 + coalGlow * 0.4, 12, 4);
      // Bùa máu gà vàng đỏ yểm trên thành vạc
      ctx.fillStyle = '#facc15';
      ctx.fillRect(obj.w / 2 - 4, -18, 8, 12);
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(obj.w / 2 - 2, -15, 4, 6);
      // Khói tà hỏa lưu huỳnh
      ctx.fillStyle = 'rgba(239, 68, 68, 0.4)';
      const fireSmoke = Math.sin(animTimer * 5) * 4;
      ctx.fillRect(obj.w / 2 - 3 + fireSmoke, -34, 3, 10);
    } else if (obj.type === 'altar_dao_hung') {
      // =========================================================================
      // --- Ổ KHÓA DAO ĐỎ HÙNG ĐỎ (ARC 8 - A08-E004) ---
      // =========================================================================
      // Giá đá cắm binh khí
      ctx.fillStyle = '#334155';
      ctx.fillRect(obj.w / 2 - 14, -10, 28, 10);
      // Chiếc áo khoác đỏ rực rách tả tơi máng trên cọc
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(obj.w / 2 - 8, -26, 16, 16);
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(obj.w / 2 - 6, -18, 12, 4);
      // Dao găm neon đỏ cắm sâu vào thềm đá
      ctx.fillStyle = '#f87171';
      ctx.fillRect(obj.w / 2 - 2, -22, 4, 16);
      // Chìa khóa đồng ma trận Rubik phát sáng hoàng kim
      ctx.fillStyle = '#fde047';
      ctx.fillRect(obj.w / 2 + 5, -20, 3, 12);
      ctx.fillRect(obj.w / 2 + 3, -24, 7, 4);
    } else if (obj.type === 'bep_chao_gung') {
      // =========================================================================
      // --- BẾP THAN CHÁO GỪNG BÀ MẬN (ARC 8 - A08-E005) ---
      // =========================================================================
      // Bếp lò đất nung hồng ấm áp
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -10, 12, 0, Math.PI);
      ctx.fill();
      ctx.fillRect(obj.w / 2 - 12, -14, 24, 5);
      // Ngọn than củi đỏ rực sưởi ấm
      ctx.fillStyle = '#f97316';
      ctx.fillRect(obj.w / 2 - 8, -13, 16, 4);
      // Nồi đất cháo gừng đang sôi lục bục
      ctx.fillStyle = '#57534e';
      ctx.fillRect(obj.w / 2 - 9, -24, 18, 11);
      // Nắp vung hé mở để lộ cháo vàng óng thơm phức
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(obj.w / 2 - 7, -25, 14, 3);
      // Làn khói cháo gừng thơm cay ngào ngạt lan tỏa
      ctx.fillStyle = 'rgba(254, 243, 199, 0.75)';
      const gungSmoke = Math.sin(animTimer * 4) * 3;
      ctx.fillRect(obj.w / 2 - 2 + gungSmoke, -36, 3, 11);
      ctx.fillRect(obj.w / 2 + 3 - gungSmoke, -34, 2, 9);
    } else if (obj.type === 'mo_tai_bi_dao') {
      // =========================================================================
      // --- NẤM MỘ TÀI DOG BỊ ĐÀO XỚI (ARC 9 - A09-E001) ---
      // =========================================================================
      // Nấm đất đỏ bị cuốc xới tanh bành
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.ellipse(obj.w / 2, -6, 22, 12, 0, 0, Math.PI * 2);
      ctx.fill();
      // Ván áo quan vỡ vụn màu đen
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(obj.w / 2 - 14, -14, 28, 8);
      // Hốc huyệt mộ rỗng toác rỉ tà khí đen
      ctx.fillStyle = '#09090b';
      ctx.fillRect(obj.w / 2 - 10, -12, 20, 6);
      // Cuốc đào mộ tà môn cán gỗ rỉ máu cắm nghiêng
      ctx.strokeStyle = '#57534e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 + 12, 0);
      ctx.lineTo(obj.w / 2 + 22, -26);
      ctx.stroke();
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(obj.w / 2 + 18, -28, 8, 4);
      // Mảnh vải áo sát nách màu chàm rách của Hiếu vướng trên cọc
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(obj.w / 2 - 16, -22, 7, 10);
      // Vệt ma khí tím lơ lửng của tay thép Thảo
      ctx.fillStyle = 'rgba(168, 85, 247, 0.5)';
      const tPulse = Math.sin(animTimer * 6) * 3;
      ctx.fillRect(obj.w / 2 - 4 + tPulse, -32, 8, 3);
    } else if (obj.type === 'ban_mo_hoan_nao') {
      // =========================================================================
      // --- BÀN MỔ HOÁN NÃO DÃ MAN (ARC 9 - A09-E002) ---
      // =========================================================================
      // Bàn mổ đá tảng nguyên khối màu xám đen
      ctx.fillStyle = '#334155';
      ctx.fillRect(obj.w / 2 - 20, -18, 40, 18);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(obj.w / 2 - 18, -22, 36, 6);
      // Rãnh dẫn huyết tà môn đỏ sẫm trên mặt bàn
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(obj.w / 2 - 14, -21, 28, 2);
      // Giá kẹp sọ và dụng cụ mổ sọ kim loại
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(obj.w / 2 - 12, -28, 3, 7);
      ctx.fillRect(obj.w / 2 + 9, -28, 3, 7);
      // Đèn mổ tà thuật tỏa ánh sáng tím lục ma quái
      const lampGlow = Math.sin(animTimer * 5) * 3;
      ctx.fillStyle = '#a855f7';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -34 + lampGlow, 5, 0, Math.PI * 2);
      ctx.fill();
      // Cuốn Hồ Sơ Mổ Sọ Hoán Não bìa đen
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(obj.w / 2 - 5, -24, 10, 5);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(obj.w / 2 - 3, -23, 6, 2);
    } else if (obj.type === 'dai_te_hut_via') {
      // =========================================================================
      // --- ĐÀI TẾ HÚT VÍA TAY THÉP (ARC 9 - A09-E003) ---
      // =========================================================================
      // Bệ đá bát giác đài tế
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -12, 18, 0, Math.PI);
      ctx.fill();
      ctx.fillRect(obj.w / 2 - 18, -20, 36, 10);
      // 4 cột đá trụ phù chú yểm bùa
      ctx.fillStyle = '#4c1d95';
      ctx.fillRect(obj.w / 2 - 16, -34, 4, 16);
      ctx.fillRect(obj.w / 2 + 12, -34, 4, 16);
      // Mảnh Tay Thép của Thảo cắm ở tâm đài tế phát xung điện 108 nhịp
      ctx.fillStyle = '#64748b';
      ctx.fillRect(obj.w / 2 - 3, -32, 6, 14);
      ctx.fillStyle = '#38bdf8';
      const spark = Math.sin(animTimer * 14) * 4;
      ctx.fillRect(obj.w / 2 - 2, -36 + spark * 0.3, 4, 4);
      // Vòng tròn hút vía xoáy tròn tà khí
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -26, 14 + Math.sin(animTimer * 8) * 3, 0, Math.PI * 2);
      ctx.stroke();
    } else if (obj.type === 'ky_uc_nao_tai') {
      // =========================================================================
      // --- BÀN KÝ ỨC NÃO TÀI (ARC 9 - A09-E004) ---
      // =========================================================================
      // Đài đá hoa sen cổ kính
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -8, 14, 0, Math.PI);
      ctx.fill();
      ctx.fillRect(obj.w / 2 - 14, -14, 28, 6);
      // Cây gậy trúc của Tài Dog đặt trang nghiêm
      ctx.fillStyle = '#65a30d';
      ctx.fillRect(obj.w / 2 - 12, -17, 24, 3);
      // Giọt huyết lệ và nước mắt trẻ thơ phát quang lam ngọc
      const tearGlow = Math.sin(animTimer * 5) * 3;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -26 + tearGlow * 0.4, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(obj.w / 2 - 2, -28 + tearGlow * 0.4, 2, 2);
      // Vầng hào quang ký ức Bản Cáu ấm áp
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -26, 16, 0, Math.PI * 2);
      ctx.stroke();
    } else if (obj.type === 'diem_hen_luc_trieu_du') {
      // =========================================================================
      // --- ĐIỂM HẸN CÁP THÉP LỤC TRIỀU DƯ (ARC 9 - A09-E005) ---
      // =========================================================================
      // Mỏm đá vách đứng mốc 1088
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(obj.w / 2 - 18, -12, 36, 12);
      // Cọc mỏ neo cáp thép đóng sâu vào đá
      ctx.fillStyle = '#64748b';
      ctx.fillRect(obj.w / 2 - 14, -28, 6, 18);
      // Cuộn cáp thép 108 sợi bện dày sáng chói
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 6, -20, 10, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 6, -20, 6, 0, Math.PI * 2);
      ctx.stroke();
      // Ánh sáng vàng mở đường sang Arc 10
      const goldRay = Math.sin(animTimer * 6) * 4;
      ctx.fillStyle = '#facc15';
      ctx.fillRect(obj.w / 2 + 4, -36 + goldRay * 0.3, 4, 8);
    } else if (obj.type === 'neo_cap_thep_1' || obj.type === 'neo_cap_thep_2' || obj.type === 'neo_cap_thep_3') {
      // =========================================================================
      // --- MỎ NEO CÁP THÉP VÁCH ĐÁ MỐC 1088 (ARC 10 - A10-E001) ---
      // =========================================================================
      // Tảng đá vách dựng đứng
      ctx.fillStyle = '#334155';
      ctx.fillRect(obj.w / 2 - 14, -12, 28, 12);
      // Mỏ neo thép đóng sâu vào khe đá
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(obj.w / 2 - 4, -28, 8, 18);
      // Vòng khuyên thép bện cáp
      ctx.strokeStyle = obj.activated ? '#38bdf8' : '#94a3b8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -28, 7, 0, Math.PI * 2);
      ctx.stroke();
      // Sợi cáp thép căng ngang hẻm núi phát quang
      if (obj.activated) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(obj.w / 2, -28);
        ctx.lineTo(obj.w / 2 + 30, -38);
        ctx.stroke();
        // Ánh thép phát sáng
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(obj.w / 2, -28, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (obj.type === 'rubik_nguc_mon_cuong_108') {
      // =========================================================================
      // --- KHỐI ĐÁ RUBIK 1M³ NGỤC MÔN CƯƠNG 108 NHỊP (ARC 10 - A10-E003) ---
      // =========================================================================
      // Bệ đá lập phương 1m³ với 6 mặt phù chú
      const cubeBob = Math.sin(animTimer * 4) * 2;
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(obj.w / 2 - 18, -36 + cubeBob, 36, 36);
      // Lưới ma trận 3x3 mỗi mặt lập phương
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 1;
      for (let i = 1; i <= 2; i++) {
        ctx.beginPath();
        ctx.moveTo(obj.w / 2 - 18 + i * 12, -36 + cubeBob);
        ctx.lineTo(obj.w / 2 - 18 + i * 12, cubeBob);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(obj.w / 2 - 18, -36 + i * 12 + cubeBob);
        ctx.lineTo(obj.w / 2 + 18, -36 + i * 12 + cubeBob);
        ctx.stroke();
      }
      // Vết nứt vỡ rực sáng ánh xanh băng tuyết sau 108 nhịp gõ
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 14, -34 + cubeBob);
      ctx.lineTo(obj.w / 2 - 2, -18 + cubeBob);
      ctx.lineTo(obj.w / 2 + 12, -6 + cubeBob);
      ctx.stroke();
      // 108 sợi cáp thép bện móc vào 4 góc khối đá
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 24, -42 + cubeBob);
      ctx.lineTo(obj.w / 2 - 18, -36 + cubeBob);
      ctx.moveTo(obj.w / 2 + 24, -42 + cubeBob);
      ctx.lineTo(obj.w / 2 + 18, -36 + cubeBob);
      ctx.stroke();
      // Vòng sóng âm 108 nhịp tỏa ra
      const ring = Math.sin(animTimer * 8) * 6;
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -18 + cubeBob, 24 + ring, 0, Math.PI * 2);
      ctx.stroke();
    } else if (obj.type === 'khung_khoi_phuc_sinh_luc') {
      // =========================================================================
      // --- BÌNH ĐÀI GIẢI THOÁT KHÔI & ÁO PHAO ĐEN RÁCH (ARC 10 - A10-E004) ---
      // =========================================================================
      // Bình đài tuyết phủ ấm áp
      ctx.fillStyle = '#334155';
      ctx.fillRect(obj.w / 2 - 22, -14, 44, 14);
      // Chiếc Áo Phao Đen Rách vai của Dư máng trên giá gỗ
      ctx.fillStyle = '#09090b';
      ctx.fillRect(obj.w / 2 - 12, -38, 24, 22);
      ctx.fillStyle = '#27272a';
      ctx.fillRect(obj.w / 2 - 9, -36, 18, 16);
      // Vết rách vai áo phao đặc công phong trần
      ctx.fillStyle = '#71717a';
      ctx.fillRect(obj.w / 2 + 4, -37, 6, 3);
      // Nồi nước gừng đun sôi bốc hơi nghi ngút
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 20, -22, 10, 8);
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(obj.w / 2 - 19, -23, 8, 2);
      // Khói nước gừng ấm áp
      ctx.fillStyle = 'rgba(254, 243, 199, 0.8)';
      const steamWave = Math.sin(animTimer * 5) * 3;
      ctx.fillRect(obj.w / 2 - 16 + steamWave, -34, 2, 9);
      // Lưỡi Liềm Tử Thần cắm đứng sẵn sàng tái chiến
      ctx.fillStyle = '#64748b';
      ctx.fillRect(obj.w / 2 + 16, -34, 3, 22);
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(obj.w / 2 + 14, -30, 8, -Math.PI / 2, Math.PI / 4);
      ctx.stroke();
    } else if (obj.type === 'cong_dinh_hai_thang_canh_cong') {
      // =========================================================================
      // --- CỔNG ĐÌNH LỤC NÀ — HAI THẰNG CANH CỔNG (ARC 10 - A10-E005) ---
      // =========================================================================
      // Thềm đá đình làng cổ
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 24, -12, 48, 12);
      // Cột đình gỗ lim đỏ sẫm hai bên ("Hai Thằng Canh Cổng")
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(obj.w / 2 - 20, -42, 6, 30);
      ctx.fillRect(obj.w / 2 + 14, -42, 6, 30);
      // Xà ngang mái đình ngói vảy rêu phong
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(obj.w / 2 - 24, -46, 48, 6);
      // Chiếc Chuông Gió Trường Mầm Non treo đung đưa
      const chimeSway = Math.sin(animTimer * 4) * 4;
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2, -40);
      ctx.lineTo(obj.w / 2 + chimeSway, -28);
      ctx.stroke();
      ctx.fillStyle = '#65a30d';
      ctx.fillRect(obj.w / 2 - 4 + chimeSway, -28, 8, 6);
      // Chó Đốm ngồi canh cổng trung thành
      ctx.fillStyle = '#fed7aa';
      ctx.fillRect(obj.w / 2 - 6, -18, 12, 8);
      ctx.fillStyle = '#78350f'; // Đốm lông nâu
      ctx.fillRect(obj.w / 2 - 2, -17, 4, 3);
    } else if (obj.type === 'rao_chan_cong_mam_non') {
      // =========================================================================
      // --- RÀO CHẮN CỔNG TRƯỜNG MẦM NON BẢN CÁU (ARC 11 - A11-E001) ---
      // =========================================================================
      // Cột cổng sắt rào chắn màu xanh dương nhạt
      ctx.fillStyle = '#1e3a8a';
      ctx.fillRect(obj.w / 2 - 20, -42, 6, 42);
      ctx.fillRect(obj.w / 2 + 14, -42, 6, 42);
      // Biển tên: TRƯỜNG MẦM NON BẢN CÁU
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(obj.w / 2 - 22, -48, 44, 9);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 7px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('MN BẢN CÁU', obj.w / 2, -41);
      // Dây thép gai & bùa tà môn phong tỏa
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 18, -32);
      ctx.lineTo(obj.w / 2 + 16, -18);
      ctx.moveTo(obj.w / 2 - 18, -18);
      ctx.lineTo(obj.w / 2 + 16, -32);
      ctx.stroke();
      // Ổ khóa xích sắt rỉ sét
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(obj.w / 2 - 4, -28, 8, 8);
    } else if (obj.type === 'cot_tru_xich_du_giang_cap') {
      // =========================================================================
      // --- CỘT TRỤ XÍCH ĐU GIĂNG CÁP THÉP CÙNG DƯ (ARC 11 - A11-E002) ---
      // =========================================================================
      // Khung xà đu bằng ống thép màu xanh lam
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(obj.w / 2 - 22, -44, 5, 44);
      ctx.fillRect(obj.w / 2 + 17, -44, 5, 44);
      ctx.fillRect(obj.w / 2 - 24, -48, 48, 6);
      // Xích đu đung đưa trong gió bão
      const swingAngle = Math.sin(animTimer * 5) * 6;
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 10, -42);
      ctx.lineTo(obj.w / 2 - 10 + swingAngle, -16);
      ctx.moveTo(obj.w / 2 + 10, -42);
      ctx.lineTo(obj.w / 2 + 10 + swingAngle, -16);
      ctx.stroke();
      // Miếng ván gỗ ngồi xích đu màu cam
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(obj.w / 2 - 14 + swingAngle, -16, 28, 4);
      // 108 sợi cáp thép tôi luyện của Dư quấn quanh xà gồ rực sáng cyan
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -45, 8, 0, Math.PI * 2);
      ctx.stroke();
      // Khóa chốt cáp thép căng ngang
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -45, 3.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (obj.type === 'diem_dung_liem_cuoi') {
      // =========================================================================
      // --- ĐIỂM DỪNG LIỀM CUỐI — TRIẾT LÝ DỪNG LẠI (ARC 11 - A11-E005) ---
      // =========================================================================
      // Vòng tròn hào quang thái bình vàng kim
      const halo = Math.sin(animTimer * 4) * 4;
      ctx.fillStyle = 'rgba(250, 204, 21, 0.25)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -24, 26 + halo, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -24, 20, 0, Math.PI * 2);
      ctx.stroke();
      // Chữ "DỪNG" đại tự thư pháp vàng chói lọi
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 13px serif';
      ctx.textAlign = 'center';
      ctx.fillText('DỪNG', obj.w / 2, -19);
      // Hoa tuyết tinh khiết rơi quanh
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 4; i++) {
        const rad = animTimer * 2 + (i * Math.PI) / 2;
        ctx.fillRect(obj.w / 2 + Math.cos(rad) * 16, -24 + Math.sin(rad) * 16, 2, 2);
      }
    } else if (obj.type === 'cua_phong_hoc_20_tre_em') {
      // =========================================================================
      // --- CỬA PHÒNG HỌC 20 ĐỨA TRẺ & HỒN TÀI (ARC 11 - A11-E006) ---
      // =========================================================================
      // Khung cửa lớp học mầm non bằng gỗ sồi
      ctx.fillStyle = '#78350f';
      ctx.fillRect(obj.w / 2 - 22, -48, 44, 48);
      // Cánh cửa kính phản chiếu ánh đèn lồng vàng ấm
      ctx.fillStyle = '#fef3c7';
      ctx.fillRect(obj.w / 2 - 16, -42, 32, 24);
      // Chong chóng giấy màu tuổi thơ đang xoay tròn
      const spin = animTimer * 8;
      ctx.save();
      ctx.translate(obj.w / 2, -30);
      ctx.rotate(spin);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-6, -2, 12, 4);
      ctx.fillStyle = '#3b82f6';
      ctx.fillRect(-2, -6, 4, 12);
      ctx.restore();
      // Linh hồn Tài Dog mỉm cười dạng hào quang cam ấm áp phía trên
      const ghostBob = Math.sin(animTimer * 5) * 3;
      ctx.fillStyle = 'rgba(251, 146, 60, 0.45)';
      ctx.beginPath();
      ctx.arc(obj.w / 2, -58 + ghostBob, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fdba74';
      ctx.font = 'bold 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('TÀI DOG ✦', obj.w / 2, -56 + ghostBob);
    } else if (obj.type === 'them_da_hai_thang_canh_cong_ending') {
      // =========================================================================
      // --- THỀM ĐÁ ĐÌNH LỤC NÀ — HAI THẰNG CANH CỔNG ĐÓN BÌNH MINH (ARC 11 - A11-E007) ---
      // =========================================================================
      // Thềm đá đình cổ kính ngàn năm
      ctx.fillStyle = '#475569';
      ctx.fillRect(obj.w / 2 - 26, -14, 52, 14);
      // Khăn trắng lau liềm gấp vuông góc
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(obj.w / 2 - 18, -17, 10, 5);
      // Liềm Tử Thần đặt nằm yên bình trên thềm đá
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(obj.w / 2 - 14, -20, 6, -Math.PI / 2, Math.PI / 3);
      ctx.stroke();
      // Ấm nước chè gừng bằng đồng bốc khói ấm
      ctx.fillStyle = '#b45309';
      ctx.fillRect(obj.w / 2 + 10, -22, 10, 10);
      ctx.fillStyle = 'rgba(254, 240, 138, 0.7)';
      const teaSteam = Math.sin(animTimer * 6) * 2;
      ctx.fillRect(obj.w / 2 + 14 + teaSteam, -30, 2, 7);
      // Gậy trúc 108 rãnh dựng cạnh cột đình
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(obj.w / 2 + 2, -42, 3, 30);
      // Tia nắng bình minh 2068 chiếu rọi
      ctx.fillStyle = 'rgba(250, 204, 21, 0.35)';
      ctx.beginPath();
      ctx.moveTo(obj.w / 2 - 30, -55);
      ctx.lineTo(obj.w / 2 + 30, -55);
      ctx.lineTo(obj.w / 2 + 20, 0);
      ctx.lineTo(obj.w / 2 - 20, 0);
      ctx.fill();
    } else if (obj.type === 'cong_luan_hoi_12_arc') {
      // =========================================================================
      // --- CỔNG LUÂN HỒI 12 ARC — HUYỀN THOẠI BÌNH LIÊU VƯƠNG (Requirement 11) ---
      // =========================================================================
      const pulse = Math.sin(animTimer * 5) * 5;
      const rotate = animTimer * 1.5;

      // Hào quang không gian luân hồi xoáy tròn
      const portalGrad = ctx.createRadialGradient(obj.w / 2, -35, 10, obj.w / 2, -35, 36 + pulse);
      portalGrad.addColorStop(0, '#facc15');
      portalGrad.addColorStop(0.35, '#38bdf8');
      portalGrad.addColorStop(0.7, '#8b5cf6');
      portalGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = portalGrad;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -35, 36 + pulse, 0, Math.PI * 2);
      ctx.fill();

      // Hai cột trụ đá cẩm thạch khắc 12 chương hồi
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(obj.w / 2 - 32, -65, 8, 65);
      ctx.fillRect(obj.w / 2 + 24, -65, 8, 65);

      // Hoa văn vàng kim trên cột
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(obj.w / 2 - 30, -60, 4, 10);
      ctx.fillRect(obj.w / 2 - 30, -40, 4, 10);
      ctx.fillRect(obj.w / 2 - 30, -20, 4, 10);
      ctx.fillRect(obj.w / 2 + 26, -60, 4, 10);
      ctx.fillRect(obj.w / 2 + 26, -40, 4, 10);
      ctx.fillRect(obj.w / 2 + 26, -20, 4, 10);

      // Xà ngang hình vòng cung nối hai cột trụ
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(obj.w / 2, -65, 28, Math.PI, 0);
      ctx.stroke();

      // Tâm xoáy thời gian đa chiều
      ctx.save();
      ctx.translate(obj.w / 2, -35);
      ctx.rotate(rotate);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        ctx.arc(0, 0, 8 + i * 4, (i * Math.PI) / 3, (i * Math.PI) / 3 + 1.2);
        ctx.stroke();
      }
      ctx.restore();

      // Biển đề tên Cổng
      ctx.fillStyle = '#020617';
      ctx.fillRect(obj.w / 2 - 40, -82, 80, 14);
      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(obj.w / 2 - 40, -82, 80, 14);
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 8px serif';
      ctx.textAlign = 'center';
      ctx.fillText('CỔNG LUÂN HỒI 12 ARC', obj.w / 2, -72);
    }

    // Hint prompt
    const float = Math.sin(animTimer * 5) * 3;
    ctx.font = '9px "Be Vietnam Pro", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fef08a';
    ctx.fillText(obj.prompt, obj.w / 2, -obj.h - 10 + float);

    ctx.restore();
  }
}
