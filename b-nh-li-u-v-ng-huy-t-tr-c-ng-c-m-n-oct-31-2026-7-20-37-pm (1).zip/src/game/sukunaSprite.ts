/**
 * 2D Side-Scrolling Pixel Art Sprite Sheet & Renderer
 * 32x32 Pixels Per Frame — Terraria Style — Anime Style Ryomen Sukuna
 *
 * Features:
 * - 32x32 pixel matrix per frame with Terraria 1-pixel dark outlines & cluster shading
 * - Anime Ryomen Sukuna features: spiky salmon-pink hair (#fb7185/#fda4af), black undercut (#18181b),
 *   4 glowing red eyes with sub-eye slits (#ef4444/#991b1b), cursed black tattoos on face/shoulders/wrists,
 *   smug demonic grin, open-collar white kimono (#f8fafc) and black obi sash (#0f172a).
 * - Full action suite: Idle (2 frames), Walk (4 frames), Jump, Fall, Dismantle (Kai),
 *   Cleave (Hachi), Kamino Fuga (Flame Bow & Arrow Release), Malevolent Shrine (Enmaten Hand Sign),
 *   and World-Cutting Slash.
 * - Interactive Sprite Sheet Generator & Exporter for UI inspection.
 */

export interface SukunaFrameData {
  name: string;
  pixels: string[][]; // 32 rows x 32 cols color strings or ''
}

export type SukunaAnimationState =
  | 'idle'
  | 'walk'
  | 'jump'
  | 'fall'
  | 'dismantle'
  | 'cleave'
  | 'kamino'
  | 'shrine'
  | 'worldSlash'
  | 'attack1'
  | 'attack2'
  | 'attack3';

export class SukunaSpriteEngine {
  public static readonly FRAME_SIZE = 32;

  // Color Palette (Terraria / Anime Style)
  public static readonly PALETTE = {
    OUTLINE: '#09090b',       // Terraria 1px silhouette outline
    HAIR_PINK_LIGHT: '#fda4af',// Light salmon pink
    HAIR_PINK_BASE: '#fb7185', // Base spiky hair
    HAIR_PINK_SHADOW: '#e11d48',// Hair shadow
    HAIR_UNDERCUT: '#18181b',  // Black shaved undercut
    SKIN_LIGHT: '#fed7aa',    // Fair anime skin highlight
    SKIN_BASE: '#fdba74',     // Base warm skin tone
    SKIN_SHADOW: '#ea580c',   // Shading under chin/muscles
    EYE_RED: '#ef4444',       // Crimson glowing eye
    EYE_PUPIL: '#ffffff',     // Piercing iris gleam
    EYE_SLIT_DARK: '#991b1b', // 2nd eye-slit under eyes
    CURSE_MARK: '#09090b',    // Sukuna cursed tattoos
    CURSE_AURA: '#dc2626',    // Faint crimson bleed from markings
    MOUTH_DARK: '#450a0a',    // Smirking demonic mouth
    FANG_WHITE: '#ffffff',    // Sharp white tooth
    KIMONO_WHITE: '#f8fafc',  // White robe highlight
    KIMONO_SHADOW: '#cbd5e1', // White robe fold shadow
    KIMONO_DEEP: '#94a3b8',   // Deep drapery crease
    OBI_BLACK: '#0f172a',     // Dark navy/black sash
    OBI_HIGHLIGHT: '#334155', // Sash knot highlight
    FIRE_ORANGE: '#f97316',   // Fuga flame spark
    FIRE_YELLOW: '#fef08a',   // Condensed arrow core
    SLASH_DISTORT: '#e2e8f0', // Razor distortion
    VOID_PURPLE: '#c084fc',   // World Slash cosmic void
  };

  /**
   * Helper to draw a crisp 32x32 sprite frame directly to a Canvas context
   * at specified world position and scale.
   */
  public static renderSukuna(
    ctx: CanvasRenderingContext2D,
    worldX: number,
    worldY: number,
    state: string,
    direction: number, // 1: right, -1: left
    animTimer: number,
    scale: number = 1.6, // Scales 32x32 to match game bounding box (~51px height)
    isDashing: boolean = false
  ) {
    ctx.save();
    ctx.translate(Math.floor(worldX), Math.floor(worldY));
    if (direction === -1) {
      ctx.scale(-1, 1);
    }

    // Shadow on the ground
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, 2, 14, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dash trail: crimson/black distortion shadow
    if (isDashing) {
      ctx.fillStyle = 'rgba(220, 38, 38, 0.4)';
      ctx.fillRect(-18, -44, 28, 42);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      ctx.fillRect(-22, -42, 22, 38);
    }

    // Scale up from 32x32 grid (origin bottom-center: x = -16, y = -32)
    ctx.scale(scale, scale);
    const originX = -16;
    const originY = -32;

    this.drawFramePixels(ctx, originX, originY, state, animTimer);

    ctx.restore();
  }

  /**
   * Procedural 32x32 Pixel Matrix Builder for each action
   */
  private static drawFramePixels(
    ctx: CanvasRenderingContext2D,
    ox: number,
    oy: number,
    state: string,
    animTimer: number
  ) {
    const P = this.PALETTE;

    // Animation offsets
    const isWalk = state === 'run';
    const isJump = state === 'jump';
    const isFall = state === 'fall';
    const walkPhase = Math.floor((animTimer * 9) % 4);
    const breatheBob = !isWalk && !isJump && !isFall ? Math.floor(Math.sin(animTimer * 4) * 0.9) : 0;
    const legSwing = isWalk ? (walkPhase === 0 ? 2 : walkPhase === 1 ? -1 : walkPhase === 2 ? -2 : 1) : 0;

    // Helper to draw single pixel on 32x32 grid
    const px = (x: number, y: number, color: string) => {
      ctx.fillStyle = color;
      ctx.fillRect(ox + x, oy + y, 1, 1);
    };

    // Helper to draw a horizontal pixel line
    const hline = (x: number, y: number, len: number, color: string) => {
      ctx.fillStyle = color;
      ctx.fillRect(ox + x, oy + y, len, 1);
    };

    // Helper to draw a filled box
    const box = (x: number, y: number, w: number, h: number, color: string) => {
      ctx.fillStyle = color;
      ctx.fillRect(ox + x, oy + y, w, h);
    };

    const headY = 4 + breatheBob;
    const torsoY = 13 + breatheBob;

    // =========================================================================
    // 1. LEGS & FEET (Terraria White Baggy Hakama / Kimono Pants)
    // =========================================================================
    const legL_X = 12 + legSwing;
    const legR_X = 16 - legSwing;
    const footY = isJump ? 27 : 29;

    // Left leg
    box(legL_X, 23, 3, 6, P.KIMONO_WHITE);
    box(legL_X - 1, 24, 1, 5, P.OUTLINE);
    box(legL_X + 3, 23, 1, 6, P.KIMONO_SHADOW);
    // Right leg
    box(legR_X, 23, 3, 6, P.KIMONO_SHADOW);
    box(legR_X + 3, 24, 1, 5, P.OUTLINE);

    // Black combat shoes / traditional sandals
    box(legL_X - 1, footY, 4, 2, P.OUTLINE);
    px(legL_X, footY, P.SKIN_BASE);
    box(legR_X, footY, 4, 2, P.OUTLINE);
    px(legR_X + 1, footY, P.SKIN_BASE);

    // =========================================================================
    // 2. KIMONO ROBE & OBI SASH (Terraria style drapery)
    // =========================================================================
    // White kimono skirt / robe body
    box(11, torsoY + 4, 10, 7, P.KIMONO_WHITE);
    box(10, torsoY + 4, 1, 6, P.OUTLINE);
    box(21, torsoY + 4, 1, 6, P.OUTLINE);
    hline(11, torsoY + 10, 10, P.KIMONO_SHADOW);

    // Dark Obi sash around waist (black/navy)
    box(11, torsoY + 2, 10, 3, P.OBI_BLACK);
    hline(12, torsoY + 2, 8, P.OBI_HIGHLIGHT);
    // Obi knot hanging down left
    box(9, torsoY + 3, 2, 4, P.OBI_BLACK);
    px(10, torsoY + 4, P.OBI_HIGHLIGHT);

    // Kimono Torso (open collar showing Sukuna's chest tattoos)
    box(11, torsoY - 4, 10, 6, P.KIMONO_WHITE);
    box(10, torsoY - 4, 1, 6, P.OUTLINE);
    box(21, torsoY - 4, 1, 6, P.OUTLINE);

    // Open V-neck revealing muscular chest & cursed lines
    box(14, torsoY - 3, 4, 5, P.SKIN_BASE);
    px(15, torsoY - 3, P.SKIN_LIGHT);
    px(16, torsoY - 3, P.SKIN_LIGHT);
    // Chest cursed tattoos (Sukuna's circular/symmetric black markings)
    px(15, torsoY - 2, P.CURSE_MARK);
    px(16, torsoY - 2, P.CURSE_MARK);
    px(14, torsoY - 1, P.CURSE_MARK);
    px(17, torsoY - 1, P.CURSE_MARK);
    px(15, torsoY, P.CURSE_MARK);

    // =========================================================================
    // 3. HEAD, HAIR, CURSED TATTOOS & FOUR EYES
    // =========================================================================
    // Face skin base
    box(12, headY + 2, 8, 7, P.SKIN_BASE);
    box(13, headY + 3, 6, 4, P.SKIN_LIGHT);
    // Jaw outline
    px(11, headY + 3, P.OUTLINE);
    px(20, headY + 3, P.OUTLINE);
    box(13, headY + 8, 6, 1, P.SKIN_SHADOW);
    box(14, headY + 9, 4, 1, P.OUTLINE); // Chin

    // Shaved dark undercut (#18181b)
    box(11, headY + 1, 2, 4, P.HAIR_UNDERCUT);
    box(19, headY + 1, 2, 4, P.HAIR_UNDERCUT);

    // Spiky Salmon-Pink Hair (Iconic Sukuna Anime spikes)
    box(12, headY - 3, 8, 5, P.HAIR_PINK_BASE);
    box(13, headY - 4, 6, 2, P.HAIR_PINK_LIGHT);
    // Spikes pointing up & back
    px(11, headY - 2, P.HAIR_PINK_SHADOW);
    px(10, headY - 3, P.HAIR_PINK_BASE);
    px(12, headY - 5, P.HAIR_PINK_LIGHT);
    px(15, headY - 5, P.HAIR_PINK_LIGHT);
    px(17, headY - 5, P.HAIR_PINK_BASE);
    px(19, headY - 4, P.HAIR_PINK_BASE);
    px(20, headY - 3, P.HAIR_PINK_SHADOW);
    px(21, headY - 2, P.HAIR_PINK_SHADOW);
    // Hair black outline
    px(10, headY - 4, P.OUTLINE);
    px(12, headY - 6, P.OUTLINE);
    px(15, headY - 6, P.OUTLINE);
    px(17, headY - 6, P.OUTLINE);
    px(19, headY - 5, P.OUTLINE);
    px(21, headY - 3, P.OUTLINE);

    // Forehead Cursed Mark (Diamond / dot & double bar)
    px(15, headY + 1, P.CURSE_MARK);
    px(16, headY + 1, P.CURSE_MARK);
    px(14, headY + 2, P.CURSE_MARK);
    px(17, headY + 2, P.CURSE_MARK);

    // PRIMARY TWO PIERCING RED EYES
    px(14, headY + 4, P.EYE_RED);
    px(15, headY + 4, P.EYE_PUPIL);
    px(17, headY + 4, P.EYE_RED);
    px(18, headY + 4, P.EYE_PUPIL);

    // SECONDARY TWO CURVED EYE SLITS UNDERNEATH (4-EYED DEMON)
    px(14, headY + 5, P.EYE_SLIT_DARK);
    px(17, headY + 5, P.EYE_SLIT_DARK);

    // Cheek Cursed Lines (Symmetrical black stripes curving down)
    px(12, headY + 5, P.CURSE_MARK);
    px(13, headY + 6, P.CURSE_MARK);
    px(18, headY + 6, P.CURSE_MARK);
    px(19, headY + 5, P.CURSE_MARK);
    px(15, headY + 6, P.CURSE_MARK); // Nose bridge mark

    // Demonic Smirking Mouth with sharp fang
    px(15, headY + 7, P.MOUTH_DARK);
    px(16, headY + 7, P.FANG_WHITE);
    px(17, headY + 7, P.MOUTH_DARK);

    // =========================================================================
    // 4. ARMS & ACTION-SPECIFIC WEAPON/SKILL POSES
    // =========================================================================
    if (state === 'skill_dismantle') {
      // --- DISMANTLE (Kai / Giải): Casual Finger Flick / Hand Slice ---
      // Left arm resting casually on hip
      box(8, torsoY - 1, 3, 5, P.KIMONO_WHITE);
      box(7, torsoY + 3, 2, 2, P.SKIN_BASE);
      // Right arm thrusting forward, index finger extended
      box(19, torsoY - 2, 5, 3, P.KIMONO_WHITE);
      box(24, torsoY - 2, 4, 2, P.SKIN_BASE);
      // Cursed black bands on wrist
      px(23, torsoY - 2, P.CURSE_MARK);
      px(23, torsoY - 1, P.CURSE_MARK);

      // Razor-sharp nearly invisible distortion line + crimson/black spark trail
      px(28, torsoY - 2, P.SLASH_DISTORT);
      px(29, torsoY - 3, P.SLASH_DISTORT);
      px(30, torsoY - 4, P.OUTLINE);
      px(31, torsoY - 5, P.OUTLINE);
      // Crimson bleed particles
      px(27, torsoY - 1, P.CURSE_AURA);
      px(28, torsoY - 4, P.CURSE_AURA);
      px(30, torsoY - 2, P.EYE_RED);
    } else if (state === 'skill_cleave') {
      // --- CLEAVE (Hachi / Bát): Heavy Slashing Claw Lunge ---
      // Left arm back
      box(8, torsoY - 2, 3, 4, P.KIMONO_SHADOW);
      // Right arm lunging violently forward with open claw
      box(19, torsoY - 3, 6, 4, P.KIMONO_WHITE);
      box(25, torsoY - 4, 4, 4, P.SKIN_BASE);
      // Black wrist tattoos
      px(24, torsoY - 3, P.CURSE_MARK);
      px(24, torsoY - 2, P.CURSE_MARK);
      // Heavy adaptive red slashing aura around claw
      px(29, torsoY - 5, P.CURSE_AURA);
      px(29, torsoY - 2, P.EYE_RED);
      px(30, torsoY - 4, P.SLASH_DISTORT);
      px(30, torsoY - 1, P.EYE_RED);
      px(31, torsoY - 3, P.SLASH_DISTORT);
    } else if (state === 'skill_kamino') {
      // --- FUGA / KAMINO (Táo / Hỏa Diệu): Fire Bow & Condensed Arrow ---
      // Left arm extended holding flame bow
      box(18, torsoY - 2, 6, 3, P.KIMONO_WHITE);
      box(24, torsoY - 3, 3, 3, P.SKIN_BASE);
      // Right arm pulled back drawing the arrow
      box(8, torsoY - 2, 4, 3, P.KIMONO_WHITE);
      box(7, torsoY - 2, 2, 2, P.SKIN_BASE);

      // Condensed bright orange-red fire arrow projectile held between fingers
      hline(20, torsoY - 2, 10, P.FIRE_ORANGE);
      hline(22, torsoY - 2, 7, P.FIRE_YELLOW);
      px(30, torsoY - 3, P.FIRE_ORANGE);
      px(30, torsoY - 1, P.FIRE_ORANGE);
      px(31, torsoY - 2, P.FIRE_YELLOW);
      // Floating pixel flame sparks
      px(26, torsoY - 4, P.FIRE_ORANGE);
      px(28, torsoY, P.FIRE_YELLOW);
    } else if (state === 'skill_shrine') {
      // --- MALEVOLENT SHRINE: Enmaten Hand Sign (Thủ Ấn Diêm Ma Thiên) ---
      // Both hands brought together in front of chest, interlocked fingers, thumbs pressed
      box(14, torsoY - 2, 4, 4, P.SKIN_BASE);
      px(15, torsoY - 2, P.CURSE_MARK);
      px(16, torsoY - 2, P.CURSE_MARK);
      px(15, torsoY - 3, P.SKIN_LIGHT);
      px(16, torsoY - 3, P.SKIN_LIGHT);
      // Both sleeves flaring out
      box(8, torsoY - 3, 4, 5, P.KIMONO_WHITE);
      box(20, torsoY - 3, 4, 5, P.KIMONO_WHITE);
      // Blazing red curse aura flaring around hands
      px(13, torsoY - 3, P.CURSE_AURA);
      px(18, torsoY - 3, P.CURSE_AURA);
      px(14, torsoY - 4, P.EYE_RED);
      px(17, torsoY - 4, P.EYE_RED);
      px(15, torsoY - 5, P.EYE_PUPIL);
      px(16, torsoY - 5, P.EYE_PUPIL);
    } else if (state === 'skill_world_slash') {
      // --- WORLD-CUTTING SLASH: Ascended Spatial Rupture Pose ---
      box(8, torsoY - 4, 3, 6, P.KIMONO_WHITE);
      box(21, torsoY - 4, 3, 6, P.KIMONO_WHITE);
      box(14, torsoY - 3, 4, 4, P.SKIN_BASE);
      // Cosmic void aura around hands
      px(13, torsoY - 4, P.VOID_PURPLE);
      px(18, torsoY - 4, P.VOID_PURPLE);
      px(14, torsoY - 5, P.SLASH_DISTORT);
      px(17, torsoY - 5, P.SLASH_DISTORT);
      px(15, torsoY - 6, P.OUTLINE);
      px(16, torsoY - 6, P.OUTLINE);
    } else if (state === 'attack1' || state === 'attack2' || state === 'attack3') {
      // --- Basic Attack: Rapid Cursed Martial Arts Strike ---
      const swingR = state === 'attack1' ? 4 : state === 'attack2' ? 6 : 8;
      box(18, torsoY - 2, 5, 3, P.KIMONO_WHITE);
      box(23, torsoY - 2, 3, 3, P.SKIN_BASE);
      px(26 + Math.min(4, swingR), torsoY - 2, P.CURSE_AURA);
      px(27 + Math.min(4, swingR), torsoY - 3, P.SLASH_DISTORT);
    } else {
      // --- Normal / Idle / Walk: Arms folded inside kimono or hanging naturally ---
      box(9, torsoY - 1, 3, 6, P.KIMONO_WHITE);
      box(9, torsoY + 5, 2, 2, P.SKIN_BASE);
      box(20, torsoY - 1, 3, 6, P.KIMONO_WHITE);
      box(21, torsoY + 5, 2, 2, P.SKIN_BASE);
      // Black tattoo wrist cuff
      px(9, torsoY + 4, P.CURSE_MARK);
      px(21, torsoY + 4, P.CURSE_MARK);
    }
  }

  /**
   * Render a specific frame scaled up (for UI preview modals)
   */
  public static renderFrame(
    ctx: CanvasRenderingContext2D,
    anim: SukunaAnimationState,
    frameIndex: number,
    destX: number,
    destY: number,
    scale: number = 4
  ) {
    const stateMap: Record<SukunaAnimationState, string> = {
      idle: 'idle',
      walk: 'run',
      jump: 'jump',
      fall: 'fall',
      dismantle: 'skill_dismantle',
      cleave: 'skill_cleave',
      kamino: 'skill_kamino',
      shrine: 'skill_shrine',
      worldSlash: 'skill_world_slash',
      attack1: 'attack1',
      attack2: 'attack2',
      attack3: 'attack3',
    };

    const state = stateMap[anim] || 'idle';
    const timer = frameIndex * 0.12;

    ctx.save();
    ctx.translate(destX, destY);
    ctx.scale(scale, scale);
    this.drawFramePixels(ctx, 0, 0, state, timer);
    ctx.restore();
  }

  /**
   * Generates a complete 2D Sprite Sheet Canvas (e.g. 8 columns x 2 rows of 32x32 frames)
   * Terraria style with labeled animation frames for preview and export.
   */
  public static generateFullSpriteSheet(): HTMLCanvasElement {
    const sheetCanvas = document.createElement('canvas');
    const cols = 8;
    const rows = 2;
    const frameSize = 32;
    sheetCanvas.width = cols * frameSize;
    sheetCanvas.height = rows * frameSize;

    const ctx = sheetCanvas.getContext('2d');
    if (!ctx) return sheetCanvas;

    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, sheetCanvas.width, sheetCanvas.height);

    const frames = [
      { name: 'idle_1', state: 'idle', timer: 0 },
      { name: 'idle_2', state: 'idle', timer: 0.8 },
      { name: 'walk_1', state: 'run', timer: 0.05 },
      { name: 'walk_2', state: 'run', timer: 0.15 },
      { name: 'walk_3', state: 'run', timer: 0.25 },
      { name: 'walk_4', state: 'run', timer: 0.35 },
      { name: 'jump', state: 'jump', timer: 0 },
      { name: 'fall', state: 'fall', timer: 0 },
      { name: 'dismantle', state: 'skill_dismantle', timer: 0 },
      { name: 'cleave', state: 'skill_cleave', timer: 0 },
      { name: 'kamino_fuga', state: 'skill_kamino', timer: 0 },
      { name: 'malevolent_shrine', state: 'skill_shrine', timer: 0 },
      { name: 'world_slash', state: 'skill_world_slash', timer: 0 },
      { name: 'attack_1', state: 'attack1', timer: 0 },
      { name: 'attack_2', state: 'attack2', timer: 0 },
      { name: 'attack_3', state: 'attack3', timer: 0 },
    ];

    frames.forEach((f, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const cellX = col * frameSize;
      const cellY = row * frameSize;

      ctx.save();
      // Render inside the 32x32 cell
      this.drawFramePixels(ctx, cellX, cellY, f.state, f.timer);
      ctx.restore();
    });

    return sheetCanvas;
  }
}
