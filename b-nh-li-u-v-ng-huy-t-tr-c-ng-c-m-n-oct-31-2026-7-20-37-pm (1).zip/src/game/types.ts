/**
 * Core Types & Interfaces for BÌNH LIÊU VƯƠNG 2D Game
 */

export type GameScreen = 'title' | 'playing' | 'paused' | 'gameover' | 'victory';

export interface Vector2D {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export type Direction = 1 | -1; // 1 = right, -1 = left

export type PlayerActionState =
  | 'idle'
  | 'run'
  | 'jump'
  | 'fall'
  | 'dash'
  | 'attack1'
  | 'attack2'
  | 'attack3'
  | 'attack_kokusen'
  | 'skill_dismantle'
  | 'skill_cleave'
  | 'skill_kamino'
  | 'skill_shrine'
  | 'skill_world_slash'
  | 'skill_kamutoke_lightning'
  | 'skill_khevan'
  | 'skill_tuthan'
  | 'skill_neon_gay'
  | 'skill_coi_cuu_thuong'
  | 'skill_hoi_quang'
  | 'sealed_tuyet_trang'
  | 'sealed_nguc_mon'
  | 'hurt'
  | 'dead';

export interface HotbarSlotItem {
  id: string;
  name: string;
  type: 'weapon' | 'helmet' | 'chest' | 'pants' | 'boots' | 'healing';
  icon: string;
  count?: number;
  equipped?: boolean;
}

export interface PlayerStats {
  level: number;
  xp: number;
  maxXp: number;
  hp: number;
  maxHp: number;
  qi: number; // Chú lực / Nội lực
  maxQi: number;
  attackPower: number;
  defense: number;
  // Trang bị 6 ô đồ (Hotbar: Vũ khí, Mũ giáp, Giáp thân, Giáp quần, Giáp chân, Đồ hồi máu)
  equippedWeapon: 'than_vu_giai' | 'liem_tu_than' | 'nam_dam_hac_thiem';
  equippedHelmet: string | null;
  equippedChest: string | null;
  equippedPants: string | null;
  equippedBoots: string | null;
  equippedHealing: string | null;
  hotbarSlots: HotbarSlotItem[];
  // Hắc Thiểm & Trạng thái Thức Tỉnh (Awakening State - 120% tiềm năng)
  isAwakened: boolean;
  awakenedTimer: number;
  hpRegenTimer: number; // Hồi 5 máu mỗi giây
  // Giáp của người chơi và độ bền (Armor & Durability)
  armor: number;
  maxArmor: number;
  armorDurability: number; // Độ bền giáp (0 - 100)
  maxArmorDurability: number;
  equippedArmorName: string | null;
  // Tiến trình 12 Arc chính thức theo lore
  currentArc: number; // 1 đến 12
  arcTitle: string;
  // Sát thương chí mạng (50% đến 100% Crit Rate)
  critRate: number; // 0.50 đến 1.00
  critDamageMultiplier: number; // 2.5x
  // Hệ thống rèn & nâng cấp vũ khí
  weaponLevel: number; // +0 đến +10
  weaponElement: 'none' | 'ice' | 'neon' | 'lightning' | 'lifesteal'; // Hiệu ứng nguyên tố ghép vào vũ khí
  upgradeShards: number; // Mảnh rèn thần binh rơi từ quái
  // Đợt quái (5 đợt, 100 quái mỗi arc)
  waveNumber: number;
  totalWaves: number;
  monstersRemainingInArc: number;
  totalMonstersPerArc: number;
  noStacks: number; // Lớp [Nợ] từ [Cuộn Tranh Chưa Giao] (tối đa 5)
  hasBangGiap: boolean; // Băng Giáp từ Tuyết Phủ 109
  stillTimer: number; // Đếm thời gian đứng yên để kích hoạt Băng Giáp
  isHoiQuangActive: boolean; // Winter Shibuya - Hồi Quang
  hoiQuangTimer: number;
  hasUsedTuyếtTrắng: boolean; // Đã kích hoạt Tuyết Trắng Chôn Tên chưa
  isSealedInIce: boolean;
  iceTombTimer: number;
  ngucMonTimer: number; // Thời gian đếm ngược 3s xé tranh
  hasButBang: boolean; // Mở khóa Bút Băng sau khi phá phong ấn
  killCount: number; // Đếm mạng hạ gục cho thoại đặc biệt
  neonBuffTimer: number; // Thời gian kích hoạt tăng 40% tốc đánh từ [Neon Gãy]
  killQuote?: string | null;
  killQuoteTimer?: number;
  sealWarningText?: string | null;
  sealWarningTimer?: number;
  characterSkin?: 'khoi' | 'sukuna'; // Chế độ hiển thị Sprite: Khôi hoặc Ryomen Sukuna 32x32 Terraria Pixel Art
  // Hệ thống mục tiêu trải nghiệm thời gian thực (Live Gameplay Objective Tracker)
  objectiveTitle?: string;
  objectiveDetail?: string;
  woodCount?: number;
  isHearthLit?: boolean;
  beastsDefeated?: number;
  totalBeasts?: number;
  // Arc 2 Objective Tracking (Winter Arc 1.0)
  dummyHits?: number;
  maxDummyHits?: number;
  isFeverRecovered?: boolean;
  bulliesDefeated?: number;
  totalBullies?: number;
  hasSparedBully?: boolean;
  // Arc 3 Objective Tracking (Trận Thầy Trò — Đêm Giết Thầy)
  hasBrokenStaff?: boolean;
  isStaffPreserved?: boolean;
  mathClassVisited?: boolean;
  arc3Completed?: boolean;
  // Arc 4 Objective Tracking (Bình Liêu Vương 18 Tuổi & Chữ "DỪNG")
  thugsDefeated?: number;
  totalThugs?: number;
  sevenNightsDuelCompleted?: boolean;
  cableClimbMastered?: boolean;
  hasCuonTranhChuaGiao?: boolean;
  arc4Completed?: boolean;
  // Arc 5 Objective Tracking (Winter Shibuya Incident 2028)
  shibuyaEnemiesDefeated?: number;
  totalShibuyaEnemies?: number;
  shibuyaBossDefeated?: boolean;
  hasUsedNeonSign?: boolean;
  hasVisitedAmbulance?: boolean;
  arc5Completed?: boolean;
  hasReceivedShibuyaTitle?: boolean;
  // Arc 6 Objective Tracking (Chiến Binh Thác Khe Vằn 2029)
  hasLookedIntoWater?: boolean;
  kheVanBeastsDefeated?: number;
  totalKheVanBeasts?: number;
  cableDuelCompleted?: boolean;
  treoMinhProgress?: number;
  isTreoMinhCompleted?: boolean;
  tamMaDefeated?: boolean;
  isKheVanTramMastered?: boolean;
  arc6Completed?: boolean;
  // Arc 7 Objective Tracking (Tài Dog Và Cái "Giữ" Cuối Cùng 2030 – 2065)
  hasCaredForTai?: boolean;
  hasCutBambooGift?: boolean;
  hasWitnessedTaiTrangTroi?: boolean;
  hasLockedScytheInSafe?: boolean;
  hasSavedDomAtGrave?: boolean;
  taMonDefeated?: number;
  totalTaMon?: number;
  arc7Completed?: boolean;
  // Arc 8 Objective Tracking (Rubik Ngục Môn Cương — Ba Chú Linh 2065 – 2068)
  hasDiscoveredRubikMatrix?: boolean;
  tuanDefeated?: boolean;
  hasPurifiedBlackSalt?: boolean;
  tayDefeated?: boolean;
  hasQuenchedEvilCoal?: boolean;
  hungDefeated?: boolean;
  hasObtainedRubikKey?: boolean;
  hasReceivedGingerPorridge?: boolean;
  hasEnteredRubikCube?: boolean;
  arc8Completed?: boolean;
  // Arc 9 Objective Tracking (Chu Mạnh Hiếu & Thuật Hoán Não 2065 – 2068)
  hasInvestigatedDesecratedGrave?: boolean;
  cluesFoundCount?: number;
  taSuDefeated?: number;
  totalTaSu?: number;
  hasDestroyedOperatingTable?: boolean;
  hieuAvatarDefeated?: boolean;
  hasTriggeredBrainRejection?: boolean;
  hasMetLucTrieuDuArc9?: boolean;
  arc9Completed?: boolean;
  // Arc 10 Objective Tracking (Lục Triều Dư / Kéo Khôi Trở Lại 2068)
  cableAnchorsCount?: number;
  hacDaoDefeated?: number;
  totalHacDao?: number;
  bossDaoThuDefeated?: boolean;
  rubik108BeatsTriggered?: boolean;
  hasReceivedAoPhaoDenRach?: boolean;
  doThamTaMonDefeated?: number;
  totalDoThamTaMon?: number;
  hasCompletedTwoGatekeepersTrial?: boolean;
  arc10Completed?: boolean;
  // Arc 11 Objective Tracking (Trận Cuối Ở Trường Mầm Non 2068 - Grand Finale)
  mamNonGuardsDefeated?: number;
  totalMamNonGuards?: number;
  hasPulledSwingCableTrap?: boolean;
  bossHieuPhase1Defeated?: boolean;
  bossHieuPhase2Defeated?: boolean;
  hasSparedChuHieuEnding?: boolean;
  hasRescued20Children?: boolean;
  arc11Completed?: boolean;
  gameCompleted?: boolean;
  chantStep?: number; // 1: Niệm chú (Long Lân...), 2: Thủ ấn (Enmaten), 3: Chỉ hướng
  chantTimer?: number;
  chantText?: string | null;
  skillCooldowns: {
    dismantle: number; // Giải
    cleave: number;    // Bát
    kamino: number;    // Táo (Hỏa Diệu / Kamino)
    shrine: number;    // Phục Ma Ngự Trù Tử (Malevolent Shrine)
    worldSlash: number;// Nhát chém Cắt Đứt Thế Gian (World-Cutting Slash)
    kamutoke: number;  // Sấm Sét Thần Vũ Giải
    tuthanDotKich: number;
    kheVanTram: number;
    neonGay: number;
    coiCuuThuong: number;
    hoiQuang: number;
    cuonTranh: number;
    dash: number;
  };
}

export interface InventoryItem {
  id: string;
  name: string;
  category: 'consumable' | 'relic' | 'lore' | 'armor' | 'material';
  description: string;
  quantity: number;
  loreNote?: string;
  effect?: 'heal' | 'qi' | 'buff' | 'armor' | 'upgrade';
  value?: number;
}

export interface Quest {
  id: string;
  title: string;
  chapter: string;
  summary: string;
  targetObjective: string;
  completed: boolean;
  active: boolean;
  rewardXp: number;
}

export interface DialogSpeaker {
  id: string;
  name: string;
  title: string;
  color: string;
  avatarId: string;
}

export interface DialogLine {
  speaker: DialogSpeaker;
  text: string;
  actionHint?: string;
  onComplete?: () => void;
}

export interface DialogSequence {
  id: string;
  lines: DialogLine[];
  onFinish?: () => void;
}

export type EnemyType =
  | 'dummy'
  | 'wolf_bien_gioi'   // Sói Tuyết Biên Phòng (A01-E001)
  | 'boar_nanh_bac'    // Lợn Rừng Nanh Bạc Lục Nà (A01-E001)
  | 'bandit_bien_gioi' // Kẻ Cướp Lương Thực Biên Giới
  | 'bully_tiger'      // Đạt "Hổ Mun" - Boss Bắt Nạt Con Nhà Võ (Arc 2)
  | 'bully_minion'     // Tú Rỗ & Kiên Sứt - Tay Sai Bắt Nạt Học Đường (Arc 2)
  | 'huyet_truc_scout'
  | 'huyet_truc_elite'
  | 'spirit_tuan'       // Đinh Quốc Tuấn (Thằng ghi sổ)
  | 'spirit_tay'        // Ông Táy (Thằng bỏ bùa)
  | 'spirit_hung'       // Hùng Đỏ (Thằng đâm sau)
  | 'boss_chu_manh_hieu' // Chu Mạnh Hiếu (Dạng 1 Hoán Não & Dạng 2 Bản Khuyết Tật)
  | 'boss_hoang_can'   // Trúc Thánh Hoàng Cần (Arc 3: Trận Thầy Trò Nóc Chợ Bình Liêu)
  | 'bien_gioi_thug'    // Toán giang hồ buôn lậu biên giới Mốc 1088 (Arc 4)
  | 'boss_chu_hieu_que_young' // Chu Hiếu Què 16 tuổi (Lôi Ảnh Thủ - Trận 7 đêm sân đình)
  | 'huyet_truc_tokyo_scout' // Đao thủ Huyết Trúc Tokyo (Arc 5)
  | 'huyet_truc_tokyo_enforcer' // Võ sư Huyết Trúc Tokyo (Arc 5)
  | 'boss_huyet_truc_tokyo_leader' // Thủ Lĩnh Huyết Trúc Shibuya (Arc 5 Boss)
  | 'bao_hoa_mai_khe_van' // Báo Hoa Mai Vách Đá Khe Vằn (Arc 6)
  | 'thuy_quai_khe_van' // Thủy Quái Suối Thác Khe Vằn (Arc 6)
  | 'boss_tam_ma_shibuya' // Boss Tâm Ma Shibuya (Hiện thân ảo giác sát khí Arc 6)
  | 'ta_mon_dao_thu' // Đao Thủ Tà Môn Móng Cái (Arc 7)
  | 'hac_dao_sat_thu' // Sát Thủ Hắc Đạo Rình Mộ (Arc 7)
  | 'ta_su_hoan_nao' // Tà Sư Mổ Sọ Hoán Não Lạng Sơn (Arc 9)
  | 'boss_chu_manh_hieu_avatar' // Hóa Thân Chu Mạnh Hiếu Hoán Não (Arc 9 Boss)
  | 'hac_dao_phong_toa' // Đao Thủ Hắc Đạo Phong Tỏa Mốc 1088 (Arc 10)
  | 'boss_trum_dao_thu_hac_dao' // Trùm Đao Thủ Canh Ngục Rubik 1m³ (Arc 10 Boss)
  | 'do_tham_ta_mon'; // Trinh Sát Tà Môn Trường Mầm Non (Arc 10)

export interface Enemy {
  id: string;
  type: EnemyType;
  name: string;
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  direction: Direction;
  state: 'idle' | 'patrol' | 'chase' | 'attack' | 'hurt' | 'dead';
  patrolMinX: number;
  patrolMaxX: number;
  detectionRange: number;
  attackRange: number;
  attackCooldown: number;
  maxAttackCooldown: number;
  hurtTimer: number;
  attackTimer: number;
  damage: number;
  xpReward: number;
  isBoss?: boolean;
  // Thanh giáp của quái / Boss (300,000 giáp cho Boss)
  armor?: number;
  maxArmor?: number;
  // Chu Mạnh Hiếu Dạng 2 - Bản Khuyết Tật
  phase?: number;
  isPhase2?: boolean;
  isTransforming?: boolean;
  transformTimer?: number;
  // Kỹ năng quái thường và Boss
  skillCooldown?: number;
  maxSkillCooldown?: number;
  skillType?:
    | 'dash_strike'
    | 'ground_slam'
    | 'ice_burst'
    | 'dark_wave'
    | 'loi_anh_thu'
    | 'noc_ran_mong_cai'
    | 'coi_ao_can_3'
    | 'kiem_muoi_hoi_mau'
    | 'hoang_long_tran_dia'
    | 'truc_phong_tram'
    | 'loi_anh_thu_young'
    | 'coi_ao_can_ba'
    | 'huyet_dao_cuong_sat'
    | 'tokyo_shadow_strike'
    | 'thac_nuoc_kich'
    | 'shibuya_blood_storm'
    | 'bao_vo_mong_vuot'
    | 'gaikan_tecchisen' // Cái Quan Thiết Vi Sơn (Bành trướng Lãnh địa của Jogo - áp dụng tất cả Boss)
    | 'maximum_meteor'  // Cực Phiên: Vẫn (Triệu hồi thiên thạch lửa khổng lồ)
    | 'ember_insects'   // Hỏa Lịch Trùng (Côn trùng lửa bám nổ)
    | 'fire_wave'       // Hỏa Chùy / Phun Lửa
    | 'domain_amplification'; // Lãnh Địa Triển Duyên (Trung hòa thuật thức)
  sealCooldown?: number;
  isCastingSeal?: boolean;
  castTimer?: number;
  speechBubble?: string;
  speechTimer?: number;
  targetNPCId?: string | null;
  // Nhảy và Lãnh địa
  canJump?: boolean;
  jumpCount?: number;
  jumpCooldown?: number;
  isGaikanTecchisenActive?: boolean;
  domainTimer?: number;
  // Kỹ năng Hỏa Hoạn của Jogo
  isMaximumMeteorCasting?: boolean;
  meteorTimer?: number;
  meteorX?: number;
  meteorY?: number;
  isEmberInsectsActive?: boolean;
  emberInsectsTimer?: number;
  isDomainAmplificationActive?: boolean;
  domainAmplificationTimer?: number;
}

export interface NPC {
  id: string;
  name: string;
  title: string;
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
  maxHp: number;
  avatarId: string;
  dialogId: string;
  hasQuestNotification?: boolean;
  speechBubble?: string;
  speechTimer?: number;
  isCombatant?: boolean; // Can fight alongside Khôi
  vx?: number;
  vy?: number;
  direction?: Direction;
  state?: 'idle' | 'support' | 'cable_strike' | 'wire_pull' | 'attack' | 'hurt' | 'jump';
  attackCooldown?: number;
  damage?: number;
  critRate?: number;
  targetEnemyId?: string | null;
  weaponName?: string; // e.g. Hỏa Long Katana, Gậy Trúc Hoàng Long
  jumpCount?: number;
  maxJumps?: number; // Lục Triều Dư: 2, Các NPC khác: 1
  jumpCooldown?: number;
  canDoubleJump?: boolean;
  isWireSwinging?: boolean;
  patrolMinX?: number;
  patrolMaxX?: number;
}

export interface DroppedItem {
  id: string;
  type: 'exp_orb' | 'potion_hp' | 'potion_atk' | 'bread' | 'armor_drop' | 'upgrade_shard';
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  value: number;
  life: number;
  maxLife: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  alpha: number;
  type: 'spark' | 'leaf' | 'dust' | 'water' | 'smoke' | 'qi' | 'feather' | 'ice' | 'neon' | 'salt' | 'fire' | 'blood' | 'seal';
  rotation?: number;
  vRot?: number;
}

export interface DamageNumber {
  x: number;
  y: number;
  value: number;
  color: string;
  isCrit?: boolean;
  life: number;
  maxLife: number;
}

export interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
  type?: 'solid' | 'one-way' | 'hazard' | 'water';
  color?: string;
}

export interface ZonePortal {
  x: number;
  y: number;
  w: number;
  h: number;
  targetZoneId: string;
  targetX: number;
  targetY: number;
  promptText: string;
}

export interface ArcStoryEvent {
  id: string; // e.g. 'A01-E001'
  arcNumber: number;
  title: string;
  year: string;
  location: string;
  characters: string[];
  description: string[];
  verbatimLore: string[];
  canonicalDialogue: { speaker: string; text: string; role?: string }[];
  objective: string;
  status: 'locked' | 'active' | 'completed';
  requiredZoneId?: string;
  targetCoords?: { x: number; y: number };
  rewardXp: number;
  rewardItemIds?: string[];
  auditStatus: 'hoàn thành' | 'chưa hoàn thành' | 'cần làm rõ';
}

export interface InteractiveObject {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  name: string;
  type:
    | 'shrine'
    | 'chest'
    | 'rubik_gate'
    | 'cable_anchor'
    | 'story_altar'
    | 'herb_node'
    | 'mine'
    | 'wounded_soldier'
    | 'chronicle_gate'
    | 'hearth_fire'
    | 'dry_wood'
    | 'bamboo_dummy'
    | 'lunch_basket'
    | 'medicine_pot'
    | 'sparing_choice'
    | 'broken_bamboo_staff'
    | 'mo_truc_7_cay'
    | 'math_desk_12a2'
    | 'noc_cho_shrine'
    | 'moc_da_1088'
    | 'san_dau_7_dem'
    | 'day_cap_khe_van'
    | 'cuon_tranh_altar'
    | 'xe_banh_mi_ong_tay'
    | 'dong_muoi_dinh_quoc_tuan'
    | 'bang_neon_gay_109'
    | 'xe_cuu_thuong_317'
    | 'tuyet_phu_109_anchor'
    | 'cuon_tranh_phong_an_altar'
    | 've_may_bay_ve_khe_van'
    | 'ho_nuoc_chan_thac'
    | 'day_cap_thac_100_tang'
    | 'diem_treo_minh_6_thang'
    | 'tang_da_khe_van_tram'
    | 'cong_dinh_ban_cau_arc6'
    | 'thuoc_nam_duong_tim'
    | 'cay_truc_non_tang_tai'
    | 'giuong_benh_tai_dog'
    | 'ket_sat_khoa_liem'
    | 'bia_mo_tai_dog'
    | 'cong_dinh_canh_mo_arc7'
    | 'rubik_cube_center'
    | 'altar_muoi_den'
    | 'altar_lo_than'
    | 'altar_dao_hung'
    | 'bep_chao_gung'
    | 'mo_tai_bi_dao'
    | 'ban_mo_hoan_nao'
    | 'dai_te_hut_via'
    | 'ky_uc_nao_tai'
    | 'diem_hen_luc_trieu_du'
    | 'neo_cap_thep_1'
    | 'neo_cap_thep_2'
    | 'neo_cap_thep_3'
    | 'rubik_nguc_mon_cuong_108'
    | 'khung_khoi_phuc_sinh_luc'
    | 'cong_dinh_hai_thang_canh_cong'
    | 'rao_chan_cong_mam_non'
    | 'cot_tru_xich_du_giang_cap'
    | 'diem_dung_liem_cuoi'
    | 'cua_phong_hoc_20_tre_em'
    | 'them_da_hai_thang_canh_cong_ending'
    | 'cong_luan_hoi_12_arc';
  prompt: string;
  activated: boolean;
  requiresItem?: string;
  arcEventId?: string; // Tích hợp trực tiếp sự kiện Arc
  onInteract: () => void;
}

export interface Zone {
  id: string;
  name: string;
  subtitle: string;
  theme: 'village' | 'mountain' | 'waterfall' | 'midnight';
  width: number;
  height: number;
  playerStartX: number;
  playerStartY: number;
  platforms: Platform[];
  enemies: Enemy[];
  npcs: NPC[];
  portals: ZonePortal[];
  interactiveObjects: InteractiveObject[];
  weather?: 'rain' | 'mist' | 'falling_leaves' | 'snow' | 'none';
}

export interface InputState {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  jump: boolean;
  justJumped: boolean;
  attack: boolean;
  justAttacked: boolean;
  dash: boolean;
  justDashed: boolean;
  skill1: boolean; // Khe Vằn Trảm / Neon Gãy
  justSkill1: boolean;
  skill2: boolean; // Tử Thần Đột Kích / Còi Cứu Thương
  justSkill2: boolean;
  skillHoiQuang: boolean; // Winter Shibuya - Hồi Quang
  justSkillHoiQuang: boolean;
  skillCuonTranh: boolean; // Cuộn Tranh Chưa Giao (tiêu hao Nợ hồi máu)
  justSkillCuonTranh: boolean;
  // Sukuna's Innate Technique: Shrine (Ngự Trù Tử) & Kamutoke
  skillDismantle: boolean; // Giải
  justSkillDismantle: boolean;
  skillCleave: boolean;    // Bát
  justSkillCleave: boolean;
  skillKamino: boolean;    // Táo (Hỏa Diệu Fuga)
  justSkillKamino: boolean;
  skillShrine: boolean;    // Phục Ma Ngự Trù Tử (Lãnh địa)
  justSkillShrine: boolean;
  skillWorldSlash: boolean; // Nhát chém Cắt Đứt Thế Gian (World Cutting Slash)
  justSkillWorldSlash: boolean;
  skillKamutoke: boolean;  // Sấm sét Thần Vũ Giải
  justSkillKamutoke: boolean;
  useQuickHeal: boolean;
  justUseQuickHeal: boolean;
  tearScroll: boolean; // Xé Cuộn Tranh khi Ngục Môn Cương xuất hiện
  justTearScroll: boolean;
  interact: boolean;
  justInteracted: boolean;
  joystickX: number; // -1 to 1
  joystickY: number; // -1 to 1
}

export interface GameSettings {
  soundEnabled: boolean;
  volume: number;
  touchControlsOpacity: number;
  screenShake: boolean;
  vibration: boolean;
}

export interface SavedGameState {
  version: number;
  timestamp: number;
  currentZoneId: string;
  playerStats: PlayerStats;
  inventory: InventoryItem[];
  quests: Quest[];
  unlockedLore: string[];
  checkpoint: {
    zoneId: string;
    x: number;
    y: number;
  };
}
